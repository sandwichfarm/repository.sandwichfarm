<!-- GSD:project-start source:PROJECT.md -->
## Project

**plugin.audio.subsonic — Modernization**

A Kodi music addon that streams from any Subsonic-API server (Subsonic, Airsonic, Navidrome, gonic, LMS) for music listeners running Kodi. The plugin has been unmaintained for years; this project hard-forks it under `dskvr/plugin.audio.subsonic`, fixes the rot, pulls in the open community PRs, and modernizes it for current Kodi releases.

**Core Value:** A current Kodi user can install this addon on Kodi Omega, point it at their Subsonic-compatible server, and reliably browse, play, and star music — without hitting Python 3 import bugs, broken auth, or stale caches.

### Constraints

- **Tech stack**: Python only (Kodi addons run in the embedded Python interpreter). No C extensions, no native deps. — Why: Kodi addon constraints
- **Compatibility**: Must work on both Kodi 21 (Py 3.11) and Kodi 20 (Py 3.8). — Why: user base spans both LTS releases
- **Distribution**: Kodi addons are pure-Python zips with `addon.xml` metadata; no compile/build step. — Why: how the platform works
- **Dependencies**: Cannot rely on PyPI installs at runtime; everything must be vendored or come via Kodi `script.module.*` deps in `addon.xml`. — Why: end users have no pip
- **API surface**: Must remain a functioning client of the Subsonic REST API; OpenSubsonic extensions are additive only. — Why: server compatibility matrix
- **Security**: Plugin handles user music-server credentials. No regressions in credential handling. — Why: trust
- **Backward data compat**: Existing user settings (server URL, creds, prefs) must keep working after the refactor. — Why: don't break existing installs
<!-- GSD:project-end -->

<!-- GSD:stack-start source:codebase/STACK.md -->
## Technology Stack

## Languages
- Python 3 - All addon logic in `main.py`, `service.py`, and library modules
- XML - Addon manifest and configuration (`addon.xml`, `resources/settings.xml`)
## Runtime
- Kodi media center - Required host application
- Python standard library only - No external dependencies beyond Kodi's bundled modules
## Frameworks
- Kodi Python API (xbmc, xbmcaddon, xbmcplugin, xbmcgui, xbmcvfs) - Provides plugin infrastructure and UI integration
- Kodi audio plugin interface - Provides music streaming and playback integration via `xbmc.python.pluginsource` extension point
- Kodi service module (`xbmc.service` extension) - Runs background scrobbling service in `service.py`
## Key Dependencies
- `libsonic` (v0.7.9) - Subsonic API client library in `lib/libsonic/`
- `simpleplugin` - Kodi plugin framework in `lib/simpleplugin/`
- `json` - JSON parsing and serialization
- `hashlib` - MD5 hashing (artist info caching)
- `datetime` - Date/time operations (ISO8601 conversion)
- `collections.abc` - Abstract base classes (MutableMapping)
- `shutil` - File operations (download functionality)
- `os`, `re` - Path and regex operations
- `urllib` - HTTP communication (handled by libsonic)
- `ssl`, `socket` - TLS/SSL handling in libsonic
- `time`, `random` - Cache timing and randomization
## Configuration
- `addon.xml` - Version 3.0.2, requires Kodi Python 3.0.0+
- `resources/settings.xml` - User-configurable settings including:
- Settings stored in Kodi's addon configuration system
- No `.env` file or external configuration required
## Platform Requirements
- Python 3.x interpreter (Kodi 19+)
- Standard POSIX tools for editing (vim, nano, etc.)
- Kodi 18+ (major_version checks in code)
- Python 3.0.0+ addon support
- Audio plugin capable installation
- Kodi 18+ (Leia or later)
- Active Subsonic or Subsonic-compatible server
- Network connectivity to Subsonic server
## Build & Deployment
- Zip archive of addon folder as Kodi addon
- Published to Kodi community addon repository
- GitHub releases: https://github.com/warwickh/plugin.audio.subsonic
<!-- GSD:stack-end -->

<!-- GSD:conventions-start source:CONVENTIONS.md -->
## Conventions

## Naming Patterns
- Module files: lowercase with underscores (e.g., `connection.py`, `errors.py`, `simpleplugin.py`)
- Main entry points: `main.py`, `service.py`
- Pattern: PEP 8 lowercase_with_underscores
- Lowercase with underscores (e.g., `get_connection()`, `walk_folders()`, `cache_refresh()`)
- Action handler functions: lowercase underscore-separated (e.g., `browse_library()`, `list_albums()`, `play_track()`)
- Getter functions: `get_*` prefix (e.g., `get_entry_track()`, `get_connection()`, `get_artist_info()`)
- Helper/walker functions: `walk_*` prefix for generators (e.g., `walk_folders()`, `walk_artists()`, `walk_playlist()`)
- Checker functions: `is_*` or `can_*` prefix (e.g., `is_starred()`, `can_star()`, `can_download()`)
- Pattern: PEP 8 snake_case throughout
- Local variables: lowercase_with_underscores (e.g., `connection`, `listing`, `album_id`)
- Parameters: snake_case (e.g., `folder_id`, `artist_id`, `menu_id`)
- Global variables: lowercase (e.g., `connection`, `local_starred`, `cached`)
- Dictionaries: descriptive names (e.g., `query_args`, `storage`, `cache_file`)
- Loop variables: single lowercase or descriptive (e.g., `item`, `menu_id`, `index`)
- NamedTuples: PascalCase (e.g., `ListContext`, `PlayContext`)
- Custom exceptions: PascalCase ending with Error (e.g., `SonicError`, `ParameterError`, `CredentialError`)
- Class instances from external libraries use provided names (e.g., `Connection` from libsonic)
## Code Style
- Character encoding declaration at top: `# -*- coding: utf-8 -*-`
- No explicit linter/formatter configuration found
- Code style is informal with mixed spacing around operators
- Example: `connection==None` (double equals, no spaces), `connection = get_connection()` (spaces around equals)
- Parameter alignment: uses aligned equals for readability (see `main.py` lines 188-192)
- No linter configuration file detected (no `.flake8`, `pylintrc`, `setup.cfg`)
- No formatter configuration detected (no `.prettierrc`, black config)
- Code quality not enforced via CI
## Import Organization
- No path aliases detected in codebase
- Plugins use direct imports after path modification: `sys.path.append(xbmcvfs.translatePath(...))`
## Error Handling
- Bare `except:` clauses used extensively (lines 59, 407, 472, 708 in `main.py`) - catches all exceptions without discrimination
- Specific exception handling in some places: `except KeyError as e:` (lines 797, 805, 1044)
- Specific exception handling: `except IndexError:` in `service.py` line 96
- Generic `except Exception as e:` in `service.py` line 99
- Pattern: Try block wraps Subsonic API calls; silent failures with popup notifications on error
- Return `False` on connection failure as sentinel value (see `get_connection()` function)
- Most error handlers either log or popup notification, then silently return
## Logging
- `plugin.log(message)` - info/debug level logging
- `plugin.log_error(message)` - error level logging
- `plugin.log_debug(message)` - debug level logging (used in helper functions)
- `xbmc.log(message, xbmc.LOGINFO/LOGDEBUG/LOGERROR)` - direct Kodi API (see `service.py`)
- Logging used for debugging and tracking important operations (connection attempts, data retrieval, user actions)
- Log messages typically include context: function name, ID values, operation type
- Conditional debug logging appears commented out in production (e.g., line 1057 in `main.py`)
- `plugin.log('play_track #' + id)` - operation logging
- `plugin.log('Starred %s #%s' % (type,json.dumps(ids)))` - action logging with context
- `plugin.log_error('Unable to star %s #%s' % (type,json.dumps(ids)))` - error logging
## Comments
- Code has minimal inline comments
- Comments appear where logic is non-obvious or requires context about Subsonic API behavior
- Comments document TODO items (see "TO FIX" pattern)
- Comments explain why a decision was made (see lines 636-638 in `main.py`)
- Python docstrings used in helper functions and data transformation functions (lines 1283-1297 in `main.py`)
- Docstrings use triple-quoted strings with description of parameters and return values
- Example from `resolve_url()` (lines 1282-1298):
## Function Design
- Functions vary from 2 lines (simple getters like `is_starred()`) to 50+ lines (complex operations like `list_albums()`)
- Most action handlers are 20-60 lines
- Utility functions are typically under 20 lines
- Params dict pattern: actions receive a `params` dict from the Kodi plugin router
- Named parameters in helper functions
- Optional parameters with defaults used (e.g., `get_artist_info(artist_id, forced=False)`)
- No type hints used
- Action handlers return implicitly (None) - they call `add_directory_items()` instead
- Helper functions return dicts, lists, or boolean values
- Generators used for data iteration (e.g., `walk_folders()`, `walk_artists()`)
- Sentinel values: `False` returned on connection failure
## Module Design
- No `__all__` declaration in main modules
- simpleplugin library exports explicitly: `__all__ = ['SimplePluginError', 'Storage', ...]`
- Kodi addon entry points: `main.py` and `service.py` run directly via `if __name__ == "__main__"`
- `lib/libsonic/__init__.py` re-exports Connection and errors (line 24 in `main.py` imports `libsonic` module)
- `lib/simpleplugin/__init__.py` imports Plugin and Addon classes
## Code Organization Patterns
- Global `connection` object cached in both `main.py` and `service.py`
- Global `local_starred` set for caching starred tracks
- Global `cachetime` from addon settings
- Pattern: lazy initialization with `if connection==None` check
- NamedTuples for context objects: `ListContext`, `PlayContext`
- Dictionaries for item entries (listing items with label, url, thumb, info)
- Generator pattern for API response iteration (walk functions)
- Settings accessed via `Addon().get_setting(name)` calls
- Settings cached in globals (e.g., `cachetime = int(Addon().get_setting('cachetime'))`)
- Type conversion with `convert` parameter: `Addon().get_setting('username', convert=False)`
<!-- GSD:conventions-end -->

<!-- GSD:architecture-start source:ARCHITECTURE.md -->
## Architecture

## Pattern Overview
- Simpleplugin micro-framework handles URL routing and plugin lifecycle
- Libsonic library abstracts Subsonic REST API communication
- Global connection singleton manages server communication
- Walk generators fetch server data incrementally
- Entry formatters transform raw API responses into Kodi ListItem dicts
## Layers
- Purpose: Integrate with Kodi media center via plugin.audio extension points
- Location: `main.py` (plugin source), `service.py` (background service)
- Contains: Entry point handlers, URL routing decorators
- Depends on: simpleplugin.Plugin, Kodi xbmc/xbmcplugin APIs
- Used by: Kodi on addon activation/action
- Purpose: Route plugin URLs to handler functions, manage addon state
- Location: `lib/simpleplugin/simpleplugin.py`
- Contains: Plugin class with @action decorator, Addon settings/storage wrapper, Params dict parser
- Depends on: xbmcaddon, xbmcgui, xbmcvfs Kodi APIs
- Used by: main.py action handlers
- Purpose: Abstract Subsonic REST API into Python method calls
- Location: `lib/libsonic/connection.py`
- Contains: Connection class building URLs, handling auth, parsing XML responses
- Depends on: urllib, http.client for HTTP; no external Subsonic SDK
- Used by: walk_* generator functions to fetch data
- Purpose: Convert Subsonic API responses into Kodi UI dicts
- Location: `main.py` walk_* and get_entry_* functions
- Contains: Generators that walk API responses, entry formatters that build ListItem structures
- Depends on: libsonic for API access
- Used by: Action handlers to build UI listings
- Purpose: Handle user navigation, starring, downloading, playback
- Location: `main.py` action-decorated functions (root, menu_albums, list_tracks, play_track, etc.)
- Contains: List building (add_directory_items), playback resolution (resolve_url), context actions
- Depends on: xbmcplugin, xbmcgui for UI rendering
- Used by: Kodi when user clicks items
- Purpose: Monitor playback for scrobbling to Subsonic
- Location: `service.py`
- Contains: Monitor loop checking Player.Progress, triggering scrobble at 50%
- Depends on: libsonic.Connection for scrobble API, xbmc.Monitor
- Used by: Kodi in background during playback
## Data Flow
- **Global connection singleton**: `connection = None` in module scope, lazily initialized by get_connection()
- **Starred items cache**: Cached in `plugin.get_storage()` (pickled dict on disk), refreshed every `cachetime` minutes
- **Local starred set**: `local_starred` module variable loaded from cache, used for display (star-colored labels)
- **Kodi addon settings**: Loaded via `Addon().get_setting('key')`, cached in memory, changes require explicit reload
## Key Abstractions
- Purpose: Encapsulate Subsonic API endpoint logic
- Location: `lib/libsonic/connection.py` class Connection
- Pattern: Builds auth params, constructs URLs, parses responses
- Examples: `connection.ping()`, `connection.getAlbumList2()`, `connection.streamUrl()`, `connection.scrobble()`
- Purpose: Lazy iteration over API responses without loading all at once
- Examples: `walk_albums()`, `walk_album()`, `walk_artist()`, `walk_tracks_starred()`
- Pattern: yield from response dict navigation with KeyError fallback to empty generator
- Used to: Memory-efficiently handle large collections
- Purpose: Transform API dict to Kodi ListItem dict format
- Examples: `get_entry_album()`, `get_entry_track()`, `get_entry_artist()`, `get_entry_playlist()`
- Pattern: Extract fields from item dict, build URL via plugin.get_url(), add metadata, add context actions
- Returns: Dict with keys: label, url, thumb, fanart, is_playable (for tracks), info, context_menu
- Purpose: Package listing metadata for Kodi UI rendering
- Location: `main.py` line 33, namedtuple ListContext
- Fields: listing (list of dicts), succeeded (bool), update_listing, cache_to_disk, sort_methods, view_mode, content, category
- Used by: add_directory_items() to call xbmcplugin APIs with proper settings
- Purpose: Package playable item metadata for resolution
- Location: `main.py` line 34, namedtuple PlayContext
- Fields: path (stream URL string), play_item (optional dict), succeeded (bool)
- Used by: _set_resolved_url() to call xbmcplugin.setResolvedUrl()
## Entry Points
- Location: `/home/sandwich/Develop/plugin.audio.subsonic/main.py`
- Triggers: Kodi calls when user clicks addon in menus
- Responsibilities: Parse URL params, route to action handlers, manage UI state, handle user actions
- Flow: `if __name__ == "__main__": plugin.run()` at line 1558 invokes Simpleplugin routing
- Location: `/home/sandwich/Develop/plugin.audio.subsonic/service.py`
- Triggers: Kodi starts during playback (addon extension point)
- Responsibilities: Monitor track playback, trigger scrobbling at 50% progress
- Flow: `if __name__ == '__main__': if scrobbleEnabled: while not monitor.abortRequested()...`
- Location: `/home/sandwich/Develop/plugin.audio.subsonic/addon.xml`
- Defines: Plugin metadata, extension points, required dependencies
- Extension point `xbmc.python.pluginsource` → `main.py`
- Extension point `xbmc.service` → `service.py`
## Error Handling
- Connection failures: popup('Connection error') and return False to skip action
- Bare except clauses catch all exceptions (connection, parsing), log errors, continue (fragile pattern noted in CONCERNS.md)
- Walk generators use try/except KeyError to yield empty (no crash on missing fields)
- Starred cache: KeyError fallback for missing 'updated' key initializes new cache
## Cross-Cutting Concerns
- Uses xbmc.log() with severity levels (LOGDEBUG, LOGINFO, LOGERROR)
- plugin.log() and plugin.log_error() wrapper methods
- Traces: Connection attempts, cache refreshes, downloaded items
- can_star(type, ids) checks if starring is available for item type
- can_download(type, id) checks if downloads are enabled
- Download folder existence check before download
- Input dialog validation for search queries
- Configured via addon settings (subsonic_url, username, password, port, apiVersion)
- Supports insecure SSL (self-signed certs), legacy auth, GET requests
- Stored in Kodi addon settings (encrypted storage by Kodi)
- Lazy initialization: connection created on first use, reused as global singleton
- `resources/settings.xml` defines UI settings categories (General, Advanced)
- Settings loaded via `Addon().get_setting('key')` with optional type conversion
- Supported settings: subsonic_url, port, username, password, bitrate_streaming, transcode_format_streaming, apiversion, insecure, useget, legacyauth, cachetime, merge, scrobble, albums_per_page, tracks_per_page, download_folder
<!-- GSD:architecture-end -->

<!-- GSD:workflow-start source:GSD defaults -->
## GSD Workflow Enforcement

Before using Edit, Write, or other file-changing tools, start work through a GSD command so planning artifacts and execution context stay in sync.

Use these entry points:
- `/gsd:quick` for small fixes, doc updates, and ad-hoc tasks
- `/gsd:debug` for investigation and bug fixing
- `/gsd:execute-phase` for planned phase work

Do not make direct repo edits outside a GSD workflow unless the user explicitly asks to bypass it.
<!-- GSD:workflow-end -->



<!-- GSD:profile-start -->
## Developer Profile

> Profile not yet configured. Run `/gsd:profile-user` to generate your developer profile.
> This section is managed by `generate-claude-profile` -- do not edit manually.
<!-- GSD:profile-end -->
