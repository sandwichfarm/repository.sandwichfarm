# Stack Research

**Domain:** Kodi audio addon — Python, modernization target Kodi 20/21
**Researched:** 2026-04-28
**Confidence:** MEDIUM-HIGH (most claims verified via official sources; a few specifics are forum-sourced)

---

## Recommended Stack

### Core Technologies

| Technology | Version | Purpose | Why Recommended |
|------------|---------|---------|-----------------|
| Python | 3.8 (min) / 3.11 (target) | Runtime | Kodi 20 Nexus bundles Python 3.8; Kodi 21 Omega bundles Python 3.11. Write to 3.8 syntax floor, test both. |
| xbmc.python (addon.xml) | `3.0.0` (import min) | Addon manifest Python dep | `3.0.0` is the Matrix/Nexus/Omega minimum. Kodi's own `addon-check` tool flags anything below 3.0.0 as a problem. Nexus and Omega both advise `3.0.1` but `3.0.0` is the safe lowest common denominator for the broadest install base. |
| Vendored libsonic (modernized) | py-sonic 0.7.9 base, patched | Subsonic REST API client | Already vendored; zero net-new runtime dependency. Modernize in-place: replace `urllib2` with `urllib.request`, add Subsonic salt+token auth (API ≥ 1.13), add OpenSubsonic API-key auth header. See the `py-opensonic` (khers) source as the reference implementation for both auth flows. |

### Development / Test Tools

| Tool | Version | Purpose | Why |
|------|---------|---------|-----|
| pytest | 9.0.x | Unit test runner | Standard. Kodi forum and community blog posts specifically recommend pytest for addon unit testing. Fixtures + `autouse` make sys.modules injection clean. |
| Kodistubs | 21.0.0 | Kodi API type stubs + test shims | Official romanvm project on PyPI; versioned to Kodi (21.0.0 = Kodi 21). Provides PEP-484 type annotations for all five Kodi modules. Install 21.0.0 as dev dep. For CI running `--python-version 3.8` behaviour, the stubs' return types are fine across both Kodi versions since the API surface didn't change between Nexus and Omega for the features this addon uses. |
| unittest.mock (stdlib) | stdlib (3.8+) | Behavioural mocking of Kodi modules | Kodistubs are stubs — they don't implement behaviour. Pair with `unittest.mock.MagicMock` injected into `sys.modules` in `conftest.py` (see pattern below). No extra package needed. |
| mypy | 1.20.x | Static type checker | Current (1.20.2 released 2026-04-21). Use `--python-version 3.8` to check against the lower target. Kodistubs already include PEP-484 annotations so Kodi API calls will type-check without hand-written stubs. Run mypy in CI but do not block on it in the first milestone — adopt incrementally. |
| ruff | 0.15.x | Linter + formatter | Replaces black, flake8, isort, pyupgrade as a single binary. Latest stable: 0.15.12 (2026-04-24). Set `target-version = "py38"` in `pyproject.toml` to flag constructs unavailable on Python 3.8. |
| kodi-addon-checker (`xbmc/addon-check`) | latest | Validate addon.xml, metadata | Official Kodi addon-check tool. Run via `xbmc/action-kodi-addon-checker` GitHub Action (v1.2) or locally with `pip install kodi-addon-checker`. Catches missing metadata, wrong xbmc.python version, encoding issues. |

### Supporting Libraries (for reference/research only — NOT to vendor)

| Library | Version | Notes |
|---------|---------|-------|
| py-opensonic (khers) | 9.0.1 (2026-04-11) | Reference for OpenSubsonic API-key auth and modern Subsonic method coverage. DO NOT vendor — depends on `requests`, `aiohttp`, `mashumaro`. Use as a spec to implement auth flows in the existing vendored libsonic. |
| knuckles | 1.2.0 (2024-11-24) | OpenSubsonic-only Python wrapper. Strictly follows OpenSubsonic spec, retro-compatible with Subsonic. Niche (3 stars). Not recommended for vendoring — unclear stdlib-only status. Reference only if py-opensonic is unclear on a specific method. |

---

## Installation (dev environment only — no runtime install step for Kodi)

```bash
# All of these are dev/CI tools only — they never ship inside the addon zip
pip install pytest==9.0.*
pip install Kodistubs==21.0.0
pip install mypy==1.20.*
pip install ruff==0.15.*
pip install kodi-addon-checker
```

No `requirements.txt` for the addon itself — Kodi addons must be self-contained zips. All runtime code is vendored or stdlib.

---

## Kodi API Mocking Pattern

The canonical approach: install Kodistubs as a dev dep, then in `conftest.py` inject MagicMock objects into `sys.modules` before any addon module is imported. Kodistubs provides the type signatures; `MagicMock` provides the callable behaviour.

```python
# tests/conftest.py
from unittest.mock import MagicMock
import sys

# Inject before any addon import
for module_name in ("xbmc", "xbmcgui", "xbmcplugin", "xbmcaddon", "xbmcvfs"):
    sys.modules[module_name] = MagicMock()

# Fine-tune specific return values that addon code branches on, e.g.:
sys.modules["xbmcaddon"].Addon.return_value.getSetting.return_value = ""
sys.modules["xbmc"].LOGDEBUG = 0
sys.modules["xbmc"].LOGINFO = 1
sys.modules["xbmc"].LOGERROR = 4
```

This is the pattern recommended by the Kodistubs docs and the Kodi forum testing thread. The stubs' type annotations still apply in IDEs and mypy because Kodistubs is importable in the dev venv; at runtime in tests, the `sys.modules` inject shadows the stubs with mocks.

**Confidence:** HIGH — corroborated by Kodistubs official docs, romanvm.github.io/Kodistubs/using.html, and the Kodi forum thread at forum.kodi.tv/showthread.php?tid=361089.

---

## addon.xml Compatibility Declaration

To support Kodi 20 (Nexus) and Kodi 21 (Omega) together:

```xml
<requires>
    <import addon="xbmc.python" version="3.0.0"/>
</requires>
```

- `3.0.0` is the backwards-compatible minimum accepted by Matrix, Nexus, and Omega.
- `3.0.1` is the "advised" version for Nexus/Omega per `kodi_addon_checker/check_dependencies.py` in `xbmc/addon-check`, but importing at `3.0.0` passes validation and runs on all three Kodi generations.
- The current `addon.xml` already declares `version="3.0.0"` — no change needed for the import version line.
- What DOES need changing: `provider-name`, `source`, and description URLs (point to `dskvr` fork, not `warwickh`).

**xbmc.python version ↔ Kodi mapping** (sourced from `xbmc/addon-check/blob/master/kodi_addon_checker/check_dependencies.py`):

| Kodi Release | xbmc.python minimum | xbmc.python advised |
|-------------|---------------------|---------------------|
| 19 Matrix | 3.0.0 | 3.0.0 |
| 20 Nexus | 3.0.0 | 3.0.1 |
| 21 Omega | 3.0.0 | 3.0.1 |

**Confidence:** HIGH — sourced from official Kodi addon-check source code.

---

## Python Version: Kodi Bundled Interpreters

| Kodi Release | Bundled Python (Windows/Android) | Notes |
|-------------|----------------------------------|-------|
| 20 Nexus | 3.8.x (3.8.10 on Windows confirmed) | Linux/macOS use system Python |
| 21 Omega | 3.11.x (can build with 3.12, but 3.11 shipped in official builds) | Linux/macOS use system Python |

Write code to the Python 3.8 syntax floor: no `match`/`case`, no `ParamSpec`, no `TypeAlias` (3.10+), use `from __future__ import annotations` if you need PEP-604 union syntax (`X | Y`) in type hints.

**Confidence:** MEDIUM — confirmed Python 3.8.10 for Nexus (Windows) via Kodi forum; Omega/3.11 from Kodi official release notes. Linux always uses system Python, which may be newer.

---

## Type Hints + mypy

**Use them. Here is the rationale and the constraint:**

- Kodi does not parse type annotations at runtime — they are ignored by the interpreter (PEP-563 `from __future__ import annotations` defers evaluation entirely). Zero runtime cost.
- Kodistubs 21.0.0 includes PEP-484 annotations for all Kodi API functions, so `xbmcplugin.addDirectoryItem(...)` will type-check against correct signatures.
- Use `from __future__ import annotations` at the top of every module — this defers annotation evaluation and is safe on Python 3.8.
- Run mypy with `--python-version 3.8 --ignore-missing-imports` in CI. The `--ignore-missing-imports` flag handles any Kodi modules not covered by stubs.
- Introduce dataclasses (stdlib 3.7+) for Subsonic response shapes — they are safe on both 3.8 and 3.11.

**Real-world precedent:** `plugin.video.retrospect` (actively maintained, updated Apr 2026, Python 3.8+) uses a `tests/` directory. Several mature Kodi addons use Kodistubs for IDE type completion and mypy.

**Confidence:** MEDIUM-HIGH — Kodistubs type annotation coverage confirmed via official docs; mypy compatibility at `--python-version 3.8` confirmed via mypy 1.20 release notes (still supports targeting 3.8 even though mypy itself requires running on 3.10+).

---

## GitHub Actions CI Matrix

```yaml
# .github/workflows/test.yml
name: Test

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.8", "3.11"]
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
      - run: pip install pytest Kodistubs==21.0.0
      - run: pytest tests/

  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.11"
      - run: pip install ruff mypy Kodistubs==21.0.0
      - run: ruff check .
      - run: ruff format --check .
      - run: mypy --python-version 3.8 --ignore-missing-imports .

  addon-check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: xbmc/action-kodi-addon-checker@v1.2
        with:
          kodi-version: nexus
          addon-id: plugin.audio.subsonic
```

Notes:
- Matrix tests against both Python 3.8 (Nexus floor) and 3.11 (Omega).
- `xbmc/action-kodi-addon-checker@v1.2` last released 2020 but still functional for metadata validation; it uses `kodi-version: nexus` as the minimum target.
- Kodistubs 21.0.0 installs fine on Python 3.8 — the stubs package targets Python 3.6+.

---

## Linting and Formatting

**Use ruff exclusively.** Do not add black, flake8, isort, or pylint separately — ruff subsumes all of them.

```toml
# pyproject.toml
[tool.ruff]
target-version = "py38"
line-length = 99

[tool.ruff.lint]
select = [
    "E",   # pycodestyle errors
    "W",   # pycodestyle warnings
    "F",   # pyflakes
    "I",   # isort
    "UP",  # pyupgrade (flags constructs not available on py38 floor)
    "B",   # flake8-bugbear
    "C4",  # flake8-comprehensions
]
ignore = ["E501"]  # line length handled by formatter

[tool.ruff.format]
quote-style = "double"

[tool.mypy]
python_version = "3.8"
ignore_missing_imports = true
warn_unused_ignores = true
```

**Kodi official addon repo style requirements:** The official Kodi repository does not mandate any specific formatter for community addons. `kodi-addon-checker` validates structure and metadata, not code style. We are distributing as a GitHub zip (not official repo submission in v1), so no external style gate applies.

**Confidence:** HIGH for ruff recommendation (current standard in Python ecosystem 2026); HIGH for Kodi style absence of formal requirements.

---

## Addon Packaging

**v1 distribution: GitHub zip, not official Kodi repo.** The packaging decision is documented as deferred in PROJECT.md.

For CI-generated release zips:

```yaml
# In .github/workflows/release.yml (triggered on tag push)
- name: Create addon zip
  run: |
    git archive --prefix=plugin.audio.subsonic/ HEAD \
      | gzip > plugin.audio.subsonic-${{ github.ref_name }}.zip
- name: Upload release asset
  uses: softprops/action-gh-release@v2
  with:
    files: plugin.audio.subsonic-*.zip
```

The `git archive` approach respects `.gitattributes` `export-ignore` directives — add `tests/`, `.github/`, `pyproject.toml`, `.ruff.toml` to `export-ignore` so the installable zip only contains runtime code.

For future official repo submission: `xbmc/action-kodi-addon-submitter@v1.3` automates the PR-to-`repo-plugins` flow. Not needed for v1.

**kodi-addon-checker** (`xbmc/addon-check`): Run this in CI to catch addon.xml problems before users hit them. It is the same tool the official Kodi repository uses to gate submissions.

**Confidence:** MEDIUM-HIGH — `git archive` + `softprops/action-gh-release` is standard; `action-kodi-addon-submitter` is official Kodi tooling.

---

## Alternatives Considered

| Recommended | Alternative | Why Not |
|-------------|-------------|---------|
| Kodistubs + unittest.mock in sys.modules | `kodi-mock` (willforde) | Archived Nov 2024, read-only, marked WIP, unmaintained |
| Kodistubs + unittest.mock in sys.modules | Full integration test in Docker Kodi | Out of scope for v1 (PROJECT.md explicitly defers this); unit-only is the stated goal |
| Vendored libsonic (modernized in-place) | py-opensonic (khers) as replacement | py-opensonic requires `aiohttp` + `requests` + `mashumaro` — none are vendorable safely in a Kodi addon without pulling in their transitive deps; adds ~500KB of pure-Python code with no end-user pip access |
| Vendored libsonic (modernized in-place) | knuckles | 3 GitHub stars, unclear vendorability, async-first API surface doesn't match Kodi's synchronous plugin execution model |
| ruff | black + flake8 + isort | Three tools with conflicting opinions; ruff subsumes all three and is faster |
| xbmc.python 3.0.0 in addon.xml | 3.0.1 | 3.0.0 is the actual minimum accepted by all three target Kodi versions; 3.0.1 would drop Matrix users (not a concern here, Matrix is EOL for us) but also has no practical API difference |

---

## What NOT to Use

| Avoid | Why | Use Instead |
|-------|-----|-------------|
| `kodi-mock` (willforde) | Archived Nov 2024, unmaintained, incomplete | Kodistubs + `unittest.mock` sys.modules injection |
| py-opensonic as a vendored lib | Depends on `aiohttp`, `requests`, `mashumaro` — cannot vendor in a Kodi addon zip without bundling their deps too | Modernize vendored `libsonic` in-place; use py-opensonic only as OpenSubsonic spec reference |
| py-sonic (crustymonkey) upstream | No OpenSubsonic support; appears unmaintained (last meaningful activity unclear); does not implement API-key auth | Modernize vendored libsonic in-place using py-opensonic as reference |
| `pytest-mypy` plugin | Couples format checking to test runs; slows test cycle; mypy is better run as a separate CI step | Run mypy as a standalone `mypy .` step in a dedicated CI job |
| black (standalone) | Redundant — ruff's formatter replicates black's output; two tools for one job | `ruff format` |
| `xbmc/action-kodi-addon-checker` as sole quality gate | Last released 2020; runs older `kodi-addon-checker`; will miss modern addon.xml schema details for Omega | Run it for broad sanity checks but also validate addon.xml manually against the schema |

---

## Version Compatibility Matrix

| Package | Python 3.8 | Python 3.11 | Notes |
|---------|-----------|-------------|-------|
| Kodistubs 21.0.0 | YES | YES | Package targets Python 3.6+ |
| pytest 9.0.x | YES | YES | Pytest 9 requires Python 3.8+ |
| mypy 1.20.x | Run on 3.10+ (mypy itself); can TARGET 3.8 with `--python-version 3.8` | YES | mypy 1.20 dropped support for running on Python 3.9; use `actions/setup-python` with 3.10+ in CI for the mypy job, but set `python_version = "3.8"` in config |
| ruff 0.15.x | YES | YES | ruff is a Rust binary; Python version is only the target version config |
| vendored libsonic (modernized) | YES | YES | Must remove `urllib2` references (Python 2 only) |

**Critical note on mypy in CI:** Run the mypy lint job on Python 3.10 or 3.11 (mypy 1.20 requires Python 3.10+ to run), but configure `python_version = "3.8"` in `pyproject.toml` so it checks for 3.8 compatibility issues in the addon source code. This is a run-on/target-for split — standard mypy practice.

---

## Sources

- [Kodistubs PyPI](https://pypi.org/project/Kodistubs/) — version history (21.0.0 = 2024-04-07, 20.0.1 = 2023-07-06) — HIGH confidence
- [romanvm/Kodistubs GitHub](https://github.com/romanvm/Kodistubs) — stubs cover xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs; PEP-484 annotations — HIGH confidence
- [romanvm.github.io/Kodistubs/using.html](https://romanvm.github.io/Kodistubs/using.html) — official recommended testing pattern (stubs + mocking library) — HIGH confidence
- [xbmc/addon-check check_dependencies.py](https://github.com/xbmc/addon-check/blob/master/kodi_addon_checker/check_dependencies.py) — xbmc.python version mapping per Kodi release — HIGH confidence
- [xbmc/xbmc addons/xbmc.python/addon.xml](https://github.com/xbmc/xbmc/blob/master/addons/xbmc.python/addon.xml) — current xbmc.python version is 3.0.2 in master — HIGH confidence
- [khers/py-opensonic GitHub](https://github.com/khers/py-opensonic) — v9.0.1 (2026-04-11), depends on aiohttp + requests + mashumaro — HIGH confidence
- [py-opensonic requirements.txt](https://github.com/khers/py-opensonic/blob/master/requirements.txt) — aiohttp 3.13.2+, requests 2.31.0+, mashumaro 3.15+ — HIGH confidence
- [OpenSubsonic API-key auth spec](https://opensubsonic.netlify.app/docs/extensions/apikeyauth/) — spec reference for implementing API-key auth in libsonic — HIGH confidence
- [kutu-dev/knuckles GitHub](https://github.com/kutu-dev/knuckles) — v1.2.0 (2024-11-24), 3 stars — MEDIUM confidence
- [astral-sh/ruff releases](https://github.com/astral-sh/ruff/releases) — 0.15.12 (2026-04-24) — HIGH confidence
- [mypy 1.20 release announcement](https://mypy-lang.blogspot.com/2026/03/mypy-120-released.html) — current version, Python 3.10+ runtime requirement — HIGH confidence
- [xbmc/action-kodi-addon-checker](https://github.com/xbmc/action-kodi-addon-checker) — v1.2 (2020), still functional for metadata validation — MEDIUM confidence
- [xbmc/action-kodi-addon-submitter](https://github.com/xbmc/action-kodi-addon-submitter) — v1.3 (2022), official zip + submission action — MEDIUM confidence
- [Kodi forum: add-on testing thread](https://forum.kodi.tv/showthread.php?tid=361089) — community recommended patterns — MEDIUM confidence (single source, forum)
- [Kodi forum: Python version for Nexus/Omega](https://forum.kodi.tv/showthread.php?tid=381891) — Python 3.8.10 on Windows for Nexus confirmed — MEDIUM confidence

---
*Stack research for: Kodi audio addon modernization (plugin.audio.subsonic)*
*Researched: 2026-04-28*
