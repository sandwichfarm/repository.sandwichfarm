# Feature Research

**Domain:** Kodi audio addon — Subsonic-API / OpenSubsonic music streaming client
**Researched:** 2026-04-28
**Confidence:** HIGH (OpenSubsonic spec + Navidrome docs verified), MEDIUM (Kodi API specifics), LOW (competitor parity claims)

---

## Already-Have (validated in existing code)

These are confirmed by `.planning/codebase/ARCHITECTURE.md` and `PROJECT.md`. They are not tasks — they are baseline.

| Feature | Implementation Location | Notes |
|---------|------------------------|-------|
| Browse artists, albums, tracks, playlists | `main.py` action handlers | Newest/random/most-played/recently-played album views |
| Stream with bitrate + transcode format | `connection.streamUrl()` + settings | MP3, OGG, RAW (m4a arriving via PR #53) |
| Star/unstar tracks and albums | `star` / `unstar` context menu | On-disk cache via `plugin.get_storage()` |
| Download songs to local folder | `do_download()` | User-configured path |
| Background scrobble at 50% via Subsonic `scrobble.view` | `service.py` | Last.fm pass-through on the server side |
| Per-user Subsonic settings | `resources/settings.xml` | URL, port, user, pass, API version, SSL toggle |
| Album search (PR #47 already merged) | `menu_albums` | Search by album name |
| Favorite Albums menu (PR #49, pending merge) | `menu_albums` | New album-list type |
| m4a / AAC transcode option (PR #53, pending merge) | `settings.xml` transcode format | AAC container support |
| `estimateContentLength` (PR #54, pending merge) | `connection.streamUrl()` | Enables gapless handoff to Kodi player |

---

## Feature Landscape

### Table Stakes — Users Expect These in 2026

Features every serious Subsonic client now has. Missing them makes the addon feel incomplete against any modern alternative.

| Feature | Why Expected | Complexity | Notes |
|---------|--------------|------------|-------|
| Gapless playback | Every modern Subsonic client (Symfonium, Arpeggi, DSub, Supersonic, Amperfy) ships it. PR #54 (`estimateContentLength`) unblocks this. | LOW | PR #54 is the fix; Kodi's own player handles the gap once the content-length hint is correct. No addon-side DSP needed. |
| Salt+token auth (API ≥ 1.13) | Plaintext-password auth is a 2012 artifact. Navidrome, gonic, and LMS all support token auth. Credential leaks in logs are a serious trust issue. | LOW | Subsonic added `t=` + `s=` params in 1.13. Libsonic already has the logic; just wire it as the default. |
| OpenSubsonic API-key auth | Navidrome and gonic both advertise `apiKeyAuthentication` via `getOpenSubsonicExtensions`. Modern clients detect and use it. | MEDIUM | Requires calling `getOpenSubsonicExtensions` first, then falling back to token auth for legacy servers. |
| `getOpenSubsonicExtensions` capability probe | Enables all conditional OpenSubsonic feature gates. Without it the addon must assume a lowest-common-denominator API surface. | LOW | One unauthenticated GET at startup; result cached in session. |
| Genre browsing (`getGenres` + `getSongsByGenre`) | Every major client (plugin.kodi.navidrome, Feishin, Substreamer, Symfonium) exposes genre navigation. It is a standard browse axis users rely on. | LOW | Both endpoints have been in Subsonic since 1.9.0. Libsonic already wraps them. |
| 5-star user rating (`setRating`) | Navidrome separates "heart/favourite" (star/unstar, already present) from 0–5 star rating. Modern clients surface both. Users who organize by rating are blocked without it. | LOW | Single `setRating.view` call; context menu item next to star/unstar. |
| MusicBrainz ID passthrough to Kodi InfoTag | Kodi's `MusicInfoTag` accepts `musicbrainztrackid`, `musicbrainzartistid`, `musicbrainzalbumid`. OpenSubsonic `Child` now emits `musicBrainzId`. Skin scrapers and Last.fm matching depend on it. | LOW | Extract from OpenSubsonic response fields; set on `InfoTagMusic`. |
| Correct `setContent` types for listings | `xbmcplugin.setContent(handle, 'songs')` for track lists, `'albums'` for album lists. Enables skin-appropriate view modes (thumbnails for albums, table for tracks). Current code may be inconsistent. | LOW | Pure metadata correctness; no API change. |
| Proper `addSortMethod` declarations | `SORT_METHOD_ARTIST`, `SORT_METHOD_ALBUM`, `SORT_METHOD_TRACKNUM` on appropriate views. Lets Kodi skins offer column-sort UI. | LOW | One-line call per view; zero server roundtrips. |

### Differentiators — Competitive Advantage

Features not universally expected but which create real user delight on a Kodi-centric setup.

| Feature | Value Proposition | Complexity | Notes |
|---------|-------------------|------------|-------|
| Synchronized lyrics via `getLyricsBySongId` (OpenSubsonic) | The `getLyricsBySongId` extension is implemented by Navidrome and gonic. Kodi has `script.cu.lrclyrics` which can consume lyrics from addons; but the simpler path is to embed plain/synced text in `InfoTagMusic.setLyrics()`. Feishin and Supersonic already do this; no Kodi Subsonic addon does. | MEDIUM | Requires `songLyrics` extension check via `getOpenSubsonicExtensions`. Fall back gracefully to legacy `getLyrics` (unsynced, Subsonic 1.2+). Does not require `script.cu.lrclyrics` dependency — embed in InfoTag. |
| OpenSubsonic ReplayGain passthrough to Kodi | OpenSubsonic `Child` response now carries a `replayGain` object (`trackGain`, `albumGain`, `trackPeak`, `albumPeak`, `baseGain`, `fallbackGain`). Kodi reads RG from file tags; for streamed content it cannot. An addon can apply gain as a pre-gain volume hint via `xbmcplugin` properties. | MEDIUM | Kodi does not expose a direct "set RG gain" hook for plugin-served URLs. Workaround: emit `ListItem.setProperty("ReplayGain_Track_Gain", "+X.XX dB")` — Kodi's player reads these as RG hints. Needs testing on Omega. Confidence: LOW on exact Kodi property name. |
| Internet radio stations (`getInternetRadioStations`) | Navidrome and gonic support server-managed radio stations. The `plugin.kodi.navidrome` fork already exposes a "Radios" browse category. Users who manage radio in Navidrome expect it in their Kodi client too. | LOW | Read-only listing + playback via direct stream URL. No write operations needed for v1. |
| Cross-device play queue resume (`savePlayQueue` / `getPlayQueue`) | Standard Subsonic endpoints since 1.12.0. Every other serious client (Supersonic, Symfonium, Feishin) implements this. Lets users start listening on their phone and resume on Kodi — a genuinely Kodi-native use case. | MEDIUM | Requires storing Kodi's current queue and periodically calling `savePlayQueue`; on launch, optionally offer to restore last queue. Service layer complication: must not interfere with non-Subsonic playback. |
| ListenBrainz scrobble option | Privacy-conscious users prefer ListenBrainz over Last.fm. Navidrome supports server-side LB scrobbling (user configures token in Navidrome settings); the addon's `scrobble.view` call triggers it automatically. No addon-side change needed — but documenting this clearly, and exposing a setting to toggle scrobble on/off, improves trust. | LOW | Already-present scrobble toggle setting. Document LB support in addon description. |
| `search3` with ID3-based results | `search3` returns `ArtistID3` and `AlbumID3` objects (ID3 tag-based, not folder-based) with richer metadata (genres list, MusicBrainz IDs, replayGain on tracks). Current code uses `search2` which returns folder-based objects. Using `search3` aligns with how all other modern clients search. | LOW | Drop-in libsonic swap. Only breaks if addon mixes `search3` artist IDs with folder-based `getMusicDirectory` calls — which it should not. |

### Anti-Features — Deliberately NOT Build

Features that seem valuable but create disproportionate cost or conflict with the addon's scope.

| Feature | Why Requested | Why Problematic | Better Approach |
|---------|---------------|-----------------|-----------------|
| Podcast browser (`getPodcasts`, `getNewestPodcasts`) | Subsonic API has full podcast support; Navidrome does not implement it (music-only). Other servers do (Airsonic-Advanced). | Kodi has dedicated, maintained podcast addons (`plugin.audio.podcasts`, `Add-on:RSS Podcasts`). Duplicating podcast UI in a music addon splits responsibility. Navidrome (the dominant server) does not support it at all, so the code would be dead for most users. | Do not build. Direct users to Kodi podcast addons. |
| Jukebox mode (`jukeboxControl`) | Power users want to control server-side playback from Kodi remote. | Jukebox mode controls playback on the *server's* audio hardware, not Kodi's. It is semantically opposite to streaming: you lose Kodi's local player, ReplayGain, gapless, and skin NowPlaying views. Very few clients ship it (DSub does; Feishin has an open issue since 2023). Navidrome has active bugs with jukebox client detection. | Do not build in this milestone. Revisit if users specifically request it with a concrete use case. |
| Sync-to-device / offline caching | Download-to-folder already exists. Mobile clients need full offline management; Kodi is a living-room device. | Kodi runs on devices that are usually always-on and always-networked. Full offline sync (delta detection, resume, metadata storage) is a separate product. The existing download-to-folder feature covers the "I want a copy" case. | Keep existing download-to-folder. Do not build sync state machine. |
| Social features (sharing links, `getShares`, `createShare`) | Subsonic API supports sharing. | Kodi is a personal media player, not a social platform. Share links require an externally routable server URL, which many homelab setups do not have. Zero demand expressed in any Kodi Subsonic forum thread. | Do not build. |
| Subsonic admin endpoints (user management, `getUsers`, `createUser`, etc.) | Server admins want a single pane. | Kodi addons are player-side, not server-admin UIs. Kodi's input model (remote control, 10-foot interface) is hostile to form-heavy admin workflows. Navidrome and every other server has a web UI for this. | Do not build. Users should manage servers via the server's own web interface. |
| Client-side Last.fm scrobbling via Last.fm SDK | Wants to scrobble even if the server does not support it. | Adds a runtime dependency (Last.fm SDK or direct HTTP to audioscrobbler) that must be vendored. The existing server-side scrobble path already covers this: Navidrome and gonic both proxy scrobbles to Last.fm and ListenBrainz on behalf of the user. Duplicating this client-side re-introduces the credential-handling complexity the server-side approach avoids. | Keep server-side scrobble via `scrobble.view`. Document to users that server-side scrobbling works for both Last.fm and ListenBrainz if configured in the server. |
| Kodi Music Library database injection | Some power users want Subsonic tracks to appear in the native Kodi music library for skin integration. | Kodi's music library is built from file-path-scanned local or SMB sources with a scraper pipeline. Plugin-served URLs do not integrate with the library scanner without a VFS provider — a fundamentally different extension type (`xbmc.python.filesystem`). Attempting to fake library entries via `RunPlugin` hacks is fragile and breaks on library rescans. | Expose clean `setContent`, `addSortMethod`, and `InfoTagMusic` metadata so skin themes render the plugin's own views well. This covers 95% of the use case with zero fragility. |

---

## OpenSubsonic-Specific Extensions

Broken out separately because these require a capability probe before use.

| Extension Name | `getOpenSubsonicExtensions` Key | What It Unlocks | Navidrome Support | gonic Support | Complexity |
|----------------|--------------------------------|-----------------|-------------------|---------------|------------|
| `getOpenSubsonicExtensions` itself | N/A — the gate | All other extensions; API-key auth path; structured metadata fields | Yes (stable) | Yes | LOW |
| API Key Authentication | `apiKeyAuthentication` | Replace token+salt auth with a single opaque key; more secure, simpler rotation | Yes | Yes | MEDIUM |
| `search3` with empty query | `search3` clarification | Full-library sync (empty query returns all); also returns `ArtistID3`/`AlbumID3` with richer metadata | Yes | Yes | LOW |
| `getLyricsBySongId` | `songLyrics` | Structured synced + unsynced lyrics keyed by track ID | Yes (v0.49+, active bugs) | Unknown | MEDIUM |
| ReplayGain fields on `Child` | Base OpenSubsonic (not an extension — core spec addition) | `replayGain.trackGain`, `albumGain`, `trackPeak`, `albumPeak`, `baseGain`, `fallbackGain` on every track response | Yes | Yes | MEDIUM |
| MusicBrainz ID fields on `Child`, `ArtistID3`, `AlbumID3` | Base OpenSubsonic core addition | `musicBrainzId` on tracks, artists, albums — enables Kodi InfoTag passthrough and external scraper matching | Yes | Yes | LOW |
| `formPost` | `formPost` | POST bodies instead of GET query strings — avoids URL length limits on large playlists | Yes | Yes | LOW (optional hardening) |
| `transcodeOffset` | `transcodeOffset` | Start transcoded stream at a byte offset — needed for seek-resume of long tracks | Yes | Unknown | HIGH (Kodi seek integration is non-trivial) |
| `reportPlayback` | `playbackReport` | Rich playback event timeline (start, progress, end, skip) — more precise than `scrobble.view` | Yes (develop branch) | Unknown | MEDIUM — defer to v2 |
| `songSimilarity` | `sonicSimilarity` | "Radio" mode — get similar songs from server | Yes (develop branch) | Unknown | MEDIUM — defer to v2 |

**Implementation guidance:** Call `getOpenSubsonicExtensions` once per session (unauthenticated, cache result). For each OpenSubsonic feature, check the extension list before using it; fall back silently to the legacy equivalent or skip the feature.

---

## Scrobbling Architecture (2026)

**How it works today in this addon:** `service.py` polls playback every 10 s, triggers `scrobble.view` on the Subsonic server at 50% play progress. The server (Navidrome, gonic) then forwards the scrobble to Last.fm and/or ListenBrainz using the user's personal credentials configured server-side.

**Privacy model:**
- Server-side scrobbling: the user's Last.fm / ListenBrainz credentials live on the server, not in Kodi. The addon never touches them. This is the correct privacy boundary.
- Navidrome supports both Last.fm and ListenBrainz server-side. gonic supports Last.fm server-side.
- The addon's role is purely to call `scrobble.view` at the right time. No client-side Last.fm SDK is needed or desirable.

**Known issues in current code:** `service.py` crashes on load due to missing `import sys` (listed in PROJECT.md as an active bug). This is a blocking fix, not a feature.

**2026 improvement:** The OpenSubsonic `reportPlayback` extension (when stable in Navidrome) will replace the coarse 50%-trigger with a proper event timeline. Defer to v2 — the extension is still in the Navidrome `develop` branch.

---

## Feature Dependencies

```
[getOpenSubsonicExtensions probe]
    └──gates──> [API Key Auth]
    └──gates──> [getLyricsBySongId / lyrics display]
    └──gates──> [ReplayGain passthrough]
    └──gates──> [search3 empty-query support]
    └──gates──> [formPost hardening]

[Salt+token auth] ──prerequisite──> [API Key Auth]
    (token auth must work as fallback before adding API-key path)

[gapless playback (estimateContentLength PR #54)]
    ──enhances──> [cross-device play queue resume]
    (gapless makes queue resume feel seamless)

[search3 adoption]
    ──prerequisite for──> [ReplayGain on search results]
    ──prerequisite for──> [MusicBrainz IDs on search results]

[service.py crash fix (import sys)]
    ──prerequisite for──> [scrobble working at all]
    ──prerequisite for──> [reportPlayback (future)]

[InfoTagMusic MusicBrainz IDs]
    ──enhances──> [Kodi skin scraper matching]
    (skins use MBIDs to fetch artist art / biographies)
```

**Dependency notes:**
- **getOpenSubsonicExtensions gates everything OpenSubsonic:** implement the probe in `get_connection()` initialization before any other OpenSubsonic feature.
- **Token auth must precede API-key auth:** if API-key auth fails or is not advertised, the addon must fall back to token auth, not plaintext.
- **service.py crash is a blocker for all scrobbling:** fix `import sys` before any scrobble-related feature work.
- **search3 vs search2:** IDs returned from `search3` (ID3-based) must not be passed to `getMusicDirectory()` (folder-based). The two namespaces do not mix. Ensure the codebase uses ID3-based calls (`getAlbum`, `getArtist`) consistently with `search3` results.

---

## MVP Definition (this milestone)

### Launch With (v1 — this milestone)

These must ship for the addon to be a credible, non-embarrassing modernization.

- [ ] Service crash fix (`import sys` in `service.py`) — scrobble is advertised as a feature; it must work
- [ ] Merge PR #49 (Favorite Albums) — already vetted by community
- [ ] Merge PR #53 (m4a transcoding) — already vetted by community
- [ ] Merge PR #54 (estimateContentLength / gapless) — already vetted by community
- [ ] Salt+token auth as default (fall back to legacy for pre-1.13 servers)
- [ ] `getOpenSubsonicExtensions` capability probe — gate for all OpenSubsonic features
- [ ] OpenSubsonic API-key auth (conditional on probe result)
- [ ] `search3` adoption (replaces `search2`; richer metadata including MusicBrainz IDs)
- [ ] Genre browsing (`getGenres` + `getSongsByGenre`) — table stakes, LOW complexity
- [ ] 5-star rating context menu item (`setRating`) — table stakes, LOW complexity
- [ ] Internet radio stations (`getInternetRadioStations`) — LOW complexity, already in competitor addon
- [ ] Correct `setContent` type declarations (`'songs'`, `'albums'`, `'artists'`) — skin view correctness
- [ ] MusicBrainz ID passthrough to `InfoTagMusic` — enables skin scraper matching
- [ ] Credential leak audit (remove passwords from `xbmc.log` output)

### Add After Validation (v1.x)

- [ ] Synchronized lyrics via `getLyricsBySongId` — worth doing but needs `songLyrics` extension to be stable in Navidrome (active bugs as of late 2025)
- [ ] ReplayGain hints as ListItem properties — needs Kodi Omega testing to confirm exact property name
- [ ] Cross-device play queue resume (`savePlayQueue` / `getPlayQueue`) — medium complexity, high user value
- [ ] Improved pagination for large libraries (artists/albums) — performance, not correctness

### Future Consideration (v2+)

- [ ] `reportPlayback` (OpenSubsonic playback timeline scrobbling) — extension still in Navidrome `develop` branch as of 2026-04-28
- [ ] Sonic similarity / radio mode (`getSimilarSongs2`, `getTopSongs`, `songSimilarity` extension) — nice discovery feature, low urgency
- [ ] `transcodeOffset` for seek-resume of transcoded streams — Kodi seek integration is non-trivial
- [ ] Jukebox mode — only after explicit user demand and Navidrome bug resolution

---

## Feature Prioritization Matrix

| Feature | User Value | Implementation Cost | Priority |
|---------|------------|---------------------|----------|
| service.py crash fix | HIGH | LOW | P1 |
| Salt+token auth | HIGH | LOW | P1 |
| PR #49 / #53 / #54 merges | HIGH | LOW | P1 |
| `getOpenSubsonicExtensions` probe | HIGH | LOW | P1 |
| OpenSubsonic API-key auth | HIGH | MEDIUM | P1 |
| `search3` adoption | HIGH | LOW | P1 |
| Genre browsing | HIGH | LOW | P1 |
| 5-star rating | MEDIUM | LOW | P1 |
| Internet radio stations | MEDIUM | LOW | P1 |
| Correct `setContent` types | MEDIUM | LOW | P1 |
| MusicBrainz ID passthrough | MEDIUM | LOW | P1 |
| Credential audit / log cleanup | HIGH | LOW | P1 |
| Synchronized lyrics | MEDIUM | MEDIUM | P2 |
| ReplayGain hints | MEDIUM | MEDIUM | P2 |
| Play queue resume | HIGH | MEDIUM | P2 |
| Library pagination | MEDIUM | MEDIUM | P2 |
| reportPlayback scrobbling | MEDIUM | MEDIUM | P3 |
| Sonic similarity / radio | LOW | MEDIUM | P3 |
| transcodeOffset seek | LOW | HIGH | P3 |
| Jukebox mode | LOW | HIGH | P3 |

---

## Competitor Feature Analysis

| Feature | plugin.kodi.navidrome (BobHasNoSoul, archived 2020) | plugin.kodi.navidrome (colinfredynand, active) | plugin.audio.subsonic (this addon) |
|---------|------|------|------|
| Artist / Album / Track browse | Yes | Yes | Yes |
| Playlist browse + playback | Yes | Yes | Yes |
| Star / favourite | Yes | Yes | Yes |
| Genre browse | No | Yes | No (table stakes gap) |
| Scrobble | No | Yes (full) | Yes (broken: import sys crash) |
| Transcoding settings | No | Yes (MP3) | Yes (MP3, OGG, m4a via PR) |
| Gapless | No | Unknown | Partial (PR #54 fixes it) |
| Internet radio | No | Yes | No (differentiator gap) |
| Search | No | Yes (artist/album/song) | Yes (with album search from PR #47) |
| 5-star rating | No | No | No (table stakes gap) |
| OpenSubsonic extensions | No | No | Planned |
| Lyrics | No | No | Planned (v1.x) |
| ReplayGain | No | No | Planned (v1.x) |
| Play queue resume | No | No | Planned (v1.x) |
| Token / API-key auth | No | No | Planned (v1) |
| Kodi 21 (Omega) compatible | No (archived) | Yes | Planned (v1) |

---

## Sources

- [OpenSubsonic API Overview](https://opensubsonic.netlify.app/docs/) — HIGH confidence
- [OpenSubsonic getOpenSubsonicExtensions endpoint](https://opensubsonic.netlify.app/docs/endpoints/getopensubsonicextensions/) — HIGH confidence
- [OpenSubsonic ReplayGain response type](https://opensubsonic.netlify.app/docs/responses/replaygain/) — HIGH confidence
- [Navidrome Subsonic API Compatibility](https://www.navidrome.org/docs/developers/subsonic-api/) — HIGH confidence
- [Navidrome OpenSubsonic extensions tracking issue #2695](https://github.com/navidrome/navidrome/issues/2695) — HIGH confidence (develop branch list)
- [Navidrome scrobbling docs](https://www.navidrome.org/docs/usage/features/scrobbling/) — HIGH confidence
- [Navidrome client apps list](https://www.navidrome.org/apps/) — HIGH confidence
- [DeepWiki Navidrome Subsonic API endpoints](https://deepwiki.com/navidrome/navidrome/4.1-subsonic-api-endpoints) — MEDIUM confidence
- [plugin.kodi.navidrome (colinfredynand)](https://github.com/colinfredynand/plugin.kodi.navidrome) — MEDIUM confidence
- [plugin.audio.navidrome README (BobHasNoSoul)](https://github.com/BobHasNoSoul/plugin.audio.navidrome/blob/master/README.md) — HIGH confidence (archived, known baseline)
- [Kodi xbmcplugin documentation](https://xbmc.github.io/docs.kodi.tv/master/kodi-base/d1/d32/group__python__xbmcplugin.html) — HIGH confidence
- [Kodi ListItem documentation](https://xbmc.github.io/docs.kodi.tv/master/kodi-base/d8/d29/group__python__xbmcgui__listitem.html) — HIGH confidence
- [search3 vs search2 clarification (opensubsonic discussion #4)](https://github.com/opensubsonic/open-subsonic-api/discussions/4) — HIGH confidence
- [Navidrome star vs rating distinction](https://support.symfonium.app/t/add-option-for-star-rating-songs-full-albums/508) — MEDIUM confidence (Symfonium forum)
- [CU LRC Lyrics Kodi addon](https://kodi.wiki/view/Add-on:CU_LRC_Lyrics) — HIGH confidence (Kodi Wiki)
- Navidrome `getLyricsBySongId` bugs: [issue #4631](https://github.com/navidrome/navidrome/issues/4631), [issue #4233](https://github.com/navidrome/navidrome/issues/4233) — HIGH confidence

---

*Feature research for: plugin.audio.subsonic modernization milestone*
*Researched: 2026-04-28*
