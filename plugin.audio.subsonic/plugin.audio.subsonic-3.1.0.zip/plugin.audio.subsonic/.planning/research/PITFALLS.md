# Pitfalls Research

**Domain:** Kodi audio addon modernization (Subsonic client)
**Researched:** 2026-04-28
**Confidence:** HIGH (most pitfalls confirmed against actual codebase in .planning/codebase/ plus official Kodi docs and OpenSubsonic spec)

---

## Critical Pitfalls

### Pitfall 1: xbmc.translatePath Removed in Kodi 20+

**What goes wrong:**
`xbmc.translatePath()` was moved to `xbmcvfs.translatePath()` in Kodi 19 and the `xbmc` version was removed in Kodi 20. Any code still calling the old location raises `AttributeError: module 'xbmc' has no attribute 'translatePath'` and the addon fails to load entirely.

**Why it happens:**
The existing `simpleplugin.py` vendor copy has a version guard (`simpleplugin.py:70-77`) that reads the Kodi major version as a string and compares it with `< '19'`. String comparison of version numbers breaks once the major version reaches two digits (`'20' < '19'` is False, but `'9' > '19'` is False, so the logic silently passes the wrong branch on some inputs). The guard uses `xbmcvfs.translatePath` on v19+, which is correct, but the fragile string comparison means the wrong branch can be chosen.

**How to avoid:**
Parse the major version as an integer: `int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])`. In the replacement router, always call `xbmcvfs.translatePath()` unconditionally — we target Kodi 20+ only, so no version guard is needed at all.

**Warning signs:**
- Addon fails on install with `AttributeError` in kodi.log
- `simpleplugin.py` line 74 comparing strings: `if _kodi_major_version() < '19'`

**Phase to address:** Foundation / Compatibility phase (fix before touching anything else; this is a hard crash on current Kodi)

**Known in codebase:** CONCERNS.md — "Hardcoded Kodi version check / string comparison of versions is fragile"

---

### Pitfall 2: urllib2 NameError on GET Requests with Multi-Value Params

**What goes wrong:**
`lib/libsonic/connection.py:2848` and `2875` reference `urllib2.Request()` in the `if self._useGET:` branch of `_getRequestWithList` and `_getRequestWithLists`. `urllib2` does not exist in Python 3. These lines are dead in the normal POST code path, but `useGET=True` (which users may set for compatibility) triggers `NameError: name 'urllib2' is not defined` at runtime.

**Why it happens:**
Incomplete Python 3 port — the main request path was migrated to `urllib.request.Request` but the GET variant in the multi-value list helpers was missed.

**How to avoid:**
Replace both `urllib2.Request(url)` calls with `urllib.request.Request(url)`. Write a unit test that exercises `_getRequestWithList` with `useGET=True`.

**Warning signs:**
- Crash only when `useGET` setting is enabled AND the action calls `star()`, `updatePlaylist()`, or other multi-ID operations
- Error is `NameError: name 'urllib2' is not defined` in kodi.log
- Silently suppressed by bare `except:` in `get_connection()`, so user only sees "Connection error"

**Phase to address:** Foundation / Compatibility phase (one-line fix; high crash risk for `useGET` users)

**Known in codebase:** CONCERNS.md — "urllib2 reference in Python 3 code"

---

### Pitfall 3: Missing `import sys` Crashes service.py on Every Launch

**What goes wrong:**
`service.py:7` calls `sys.path.append(...)` before `sys` is imported. The service raises `NameError: name 'sys' is not defined` immediately, killing scrobbling for all users.

**Why it happens:**
`main.py` never calls `import sys` explicitly either — it relies on `sys` being a side-effect import of another module. That accident doesn't happen in `service.py`'s import order.

**How to avoid:**
Add `import sys` as the first standard-library import in `service.py`. Verify with a pytest import test: `import service` should not raise.

**Warning signs:**
- Service never appears in Kodi's running services list
- `NameError: name 'sys' is not defined` in kodi.log immediately after Kodi starts
- Scrobbling silently broken for every user

**Phase to address:** Foundation / Compatibility phase (single-line fix, highest priority)

**Known in codebase:** CONCERNS.md — "Missing sys Import in service.py"

---

### Pitfall 4: Bare `except:` Swallowing Every Real Error

**What goes wrong:**
`main.py:59` (inside `get_connection()`), `407`, `472`, `708`, `1244` and `service.py:20,48` use bare `except:` or `except Exception as e:`. This catches `KeyboardInterrupt`, `SystemExit`, `MemoryError`, and all real connection / parse failures. Stack traces are never logged. The user sees "Connection error" with no way to diagnose the real problem. During a refactor, bare excepts also silently hide import errors in new modules.

**Why it happens:**
Copy-paste from older code + fear of uncaught exceptions surfacing to Kodi's UI. The pattern was acceptable in Python 2 where `except:` was the norm, but it is an active debugging hazard in Python 3.

**How to avoid:**
Replace every bare `except:` with `except (ConnectionError, json.JSONDecodeError, KeyError) as exc:` (use the narrowest type that makes sense). Log the full traceback: `xbmc.log(traceback.format_exc(), xbmc.LOGERROR)`. Use `except Exception as exc:` at most as a last-resort catch in the outermost handler with mandatory traceback logging.

**Warning signs:**
- Any `except:` or `except Exception:` without `traceback.format_exc()` in the log call
- Tests cannot exercise error paths because the exception is swallowed
- Users report "Connection error" with nothing else in the log

**Phase to address:** Foundation phase for the most dangerous sites (get_connection, service.py); remaining sites during refactor

**Known in codebase:** CONCERNS.md — "Broad Exception Handling" with exact line numbers

---

### Pitfall 5: ListItem.setInfo('music', {...}) Deprecated in Kodi 20

**What goes wrong:**
`ListItem.setInfo()` for music metadata is deprecated since Kodi 20 and will be removed in a future version. The replacement is `ListItem.getMusicInfoTag()` (returns an `InfoTagMusic` object with typed setters). Using the old API logs deprecation warnings on every item render. More importantly, `setInfo()` silently ignores unknown keys — so migrating to the new API exposes wrong field names that were silently dropped before.

**Why it happens:**
Kodi's v20 Python API introduced per-media-type info tag objects (`InfoTagMusic`, `InfoTagVideo`, etc.) to replace the generic dictionary approach. The change was backward-compatible on v20 (warnings only), but the old API may be removed in a future release (Piers / v22+).

**How to avoid:**
In the new module for track/album/artist entry building, always use `li.getMusicInfoTag()` and call typed setters (`setTitle()`, `setArtist()`, `setAlbum()`, `setTrackNumber()`, `setDuration()`, etc.). Add this to CI by checking that no `setInfo('music'` string appears in new modules.

**Warning signs:**
- `DEPRECATED: ListItem.setInfo() is deprecated` flooding kodi.log during any list view
- `get_entry_track()` / `get_entry_album()` still passing a dict to `setInfo()`

**Phase to address:** Entry-builder refactor phase (affects every track/album item rendered)

---

### Pitfall 6: Pagination Never Detects End of List

**What goes wrong:**
`list_albums()` and `list_tracks()` always append a "Next Page" item (via `navigate_next()`), even after the last album/track has been shown. The code has `# if type(items) != type(True): TO FIX` on lines 449 and 546, indicating this was known and never completed.

The Subsonic/OpenSubsonic API (`getAlbumList2`, `getAlbumList`, random tracks) returns an empty array — or fewer items than `size` — when the end of the list is reached. There is no `totalCount` field; end detection must be inferred by comparing `len(returned_items) < requested_size`.

**Why it happens:**
The detection logic was stubbed out and never implemented. The commented-out condition checked `type(items) != type(True)` (looking for a False sentinel returned by a failed API call), which is the wrong approach — a successful empty-page response is a list, not `False`.

**How to avoid:**
After calling the generator and collecting `items = list(generator)`, check `if len(items) < page_size` before appending the "Next" link. For `getAlbumList2` the max is 500; for `search3` server implementations vary (cap at 500 to be safe). For `type=random`, there is no concept of "next page" — never show the next-page link for random listings.

**Warning signs:**
- "Next (2)" button appears even after last page shows 0 or fewer-than-requested items
- `# TO FIX` comment on lines 449 and 546 of main.py

**Phase to address:** Pagination refactor phase

**Known in codebase:** CONCERNS.md — "No validation of page/offset parameters" and "TO FIX" markers

---

### Pitfall 7: Starred Cache Not Refreshed After Star/Unstar Action

**What goes wrong:**
After `star_item()` or `unstar_item()` succeeds, `cache_refresh(True)` is called — which does a full network round-trip to reload all starred IDs from the server. The UI list is not refreshed afterward. Two `# TO FIX` comments on lines 725-726 document this: `#TO FIX clear starred lists caches ?` and `#TO FIX refresh current list after star set ?`

Additionally, `local_starred` is a module-level `set({})` (actually a list after first population), and `cache_refresh()` uses `global local_starred`. If Kodi calls the plugin action in a new process (which it often does), `local_starred` is reset to empty and the disk cache must be reloaded from the pickle file. There is no locking; concurrent reads during a refresh can return a stale or empty set.

**How to avoid:**
(1) After a successful star/unstar, optimistically update the in-memory cache immediately (add/remove the ID) rather than doing a full reload. (2) Trigger a container refresh with `xbmc.executebuiltin('Container.Refresh')` so the UI shows updated star icons. (3) Replace the global mutable list with a proper cache class that reads from disk on construction and writes atomically. (4) For per-session cache, use `xbmcgui.Window` property storage (simpleplugin's `MemStorage`) for the in-process lifetime and the pickle file for persistence.

**Warning signs:**
- Star action succeeds but list still shows item as unstarred
- `# TO FIX` on lines 725-726
- `global local_starred` set at module level in main.py:32

**Phase to address:** Cache rework phase

**Known in codebase:** CONCERNS.md — "Global local_starred cache / No thread safety"

---

### Pitfall 8: Subsonic Token Auth Fails on Servers Storing Hashed Passwords

**What goes wrong:**
The Subsonic salt+token scheme (`t = md5(password + salt)`) requires the server to know the user's **plaintext** password to reconstruct the token for comparison. Servers that store only a one-way hash of the password (e.g., some LDAP-integrated deployments, some Ampache configurations) **cannot verify token auth** and must fall back to the legacy `p=enc:hexpassword` scheme. Navidrome stores passwords in a way that supports token auth, but Airsonic with LDAP users does not.

Additionally, OpenSubsonic adds API-key auth (`apiKey=<key>` with no `u`/`t`/`s`). When this is used, the standard `u`/`t`/`s` parameters must not be present — sending them alongside `apiKey` is an error on conformant servers.

**Why it happens:**
The addon currently exposes `legacyauth` as a boolean toggle but defaults to modern (token) auth for everything. Users on LDAP-backed servers hit silent auth failure; the bare `except:` in `get_connection()` turns this into "Connection error" with no diagnostic.

**How to avoid:**
(1) Keep the `legacyauth` toggle but rename it / document it as "plaintext auth fallback — required for LDAP users". (2) Implement OpenSubsonic API-key auth as a third mode, gated by `getOpenSubsonicExtensions` discovery. (3) Never send `u`/`t`/`s` alongside `apiKey`. (4) On auth failure, log the HTTP response body (not the password) so users can self-diagnose.

**Warning signs:**
- `Connection error` popup with nothing diagnostic in kodi.log
- Server returns HTTP 401 or JSON `{"subsonic-response": {"status": "failed", "error": {"code": 40, "message": "Wrong username or password."}}}`
- User is on Airsonic with LDAP or has `legacyAuth=False` but server requires plaintext

**Phase to address:** Auth migration phase

---

### Pitfall 9: Credential Leak in xbmc.log via URL Logging

**What goes wrong:**
`libsonic/connection.py` has commented-out `xbmc.log("Standard URL %s"%url, ...)` and `xbmc.log("UseGET URL %s"%(url), ...)` debug lines (lines 2822-2823, 2826-2827). The URL contains `t=<token>` and `s=<salt>`. If debug logging is re-enabled — even accidentally during development — the token+salt pair is written to kodi.log in plaintext. While token+salt is time-bounded (each request uses a new salt), an attacker with log access can replay them for a window of time. With `legacyAuth=True` the URL contains the hex-encoded password, which is worse.

Additionally, `connection.py:162-163` has a live debug `print(len(self._hostname.split('/')))` and `xbmc.log("Got a folder %s"...)`.

**How to avoid:**
(1) Never log constructed request URLs. Log only the viewName (endpoint) and a success/fail indicator. (2) When logging errors, log the response body only, never the request URL or headers. (3) Gate all debug logging with `xbmc.LOGDEBUG` level so it appears only with debug logging enabled, and never at `LOGINFO`. (4) Add a CI check that greps new code for patterns like `log.*url` or `log.*password`.

**Warning signs:**
- Any `xbmc.log` call that includes a variable holding the full request URL
- `print()` statements in libsonic (these go to the process stdout, not kodi.log, but are still visible in some deployments)

**Phase to address:** Auth + security phase; must land before any public release

**Known in codebase:** CONCERNS.md — "Credential Storage and Transmission"

---

### Pitfall 10: Global `connection` Singleton Not Reset on Settings Change

**What goes wrong:**
`connection = None` at module level is populated once by `get_connection()` and cached for the lifetime of the process. Since each Kodi plugin invocation is a new process, this is usually fine. However, `service.py` is a long-running process — it caches its own `connection = None` and never re-initializes it after user settings change (server URL, username, password). If the user changes their password or server URL, scrobbling continues trying the old connection object and silently fails until Kodi restarts.

**Why it happens:**
The service was designed assuming settings don't change at runtime. No `Monitor.onSettingsChanged()` hook is implemented.

**How to avoid:**
In `service.py`, subclass `xbmc.Monitor` and override `onSettingsChanged()` to reset `connection = None`. This forces re-initialization on the next scrobble attempt. Alternatively, read settings fresh on each scrobble call rather than caching a connection object.

**Warning signs:**
- Scrobbling stops after a password change without restarting Kodi
- `service.py` has no `class MyMonitor(xbmc.Monitor)` with `onSettingsChanged`
- `connection = None` at module level in service.py with no reset mechanism

**Phase to address:** service.py hardening phase

**Known in codebase:** CONCERNS.md — "Global State and Singleton Pattern"

---

## Technical Debt Patterns

| Shortcut | Immediate Benefit | Long-term Cost | When Acceptable |
|----------|-------------------|----------------|-----------------|
| `@plugin.action()` decorator routing | Zero boilerplate for action dispatch | Couples every handler to simpleplugin; importing main.py in tests instantiates the plugin object, calling xbmc APIs | Never; replace with plain dict dispatch or path-based router |
| Settings read at module level (`cachetime = int(Addon().get_setting('cachetime'))`) | One-liner | Breaks import in tests (calls xbmcaddon before any mock is in place); also re-reads on every Kodi process, even when settings haven't changed | Never; read settings inside functions or inject via constructor |
| Global `connection` and `local_starred` | Trivial lazy init | Thread safety issues; service.py holds stale connection; tests cannot reset state between runs | Never in new code; use dependency injection |
| Bare `except:` for connection init | Avoids unhandled exceptions in Kodi UI | Swallows real errors; makes testing impossible; hides import errors during refactor | Never; always `except (SpecificError, AnotherError) as exc:` with logging |
| Vendored simpleplugin and libsonic with no version pinning | No external deps at distribution time | Upstream bug fixes never arrive; our modifications diverge silently | Acceptable to keep vendored, but pin to a known version and document it |
| Pickle for Storage | Works without JSON schema migration | Pickle format changes between Python minor versions can corrupt storage on Kodi upgrade | Acceptable short-term; migrate to JSON-backed storage for the starred cache in the rework phase |
| `cache_to_disk=True` on all album views | Views cached by Kodi for fast re-entry | Stale Kodi view cache is not invalidated when new albums are added to the server; users see old listings | Acceptable with a short TTL; must be disabled for starred views |

---

## Integration Gotchas

| Integration | Common Mistake | Correct Approach |
|-------------|----------------|------------------|
| Navidrome `getMusicDirectory` | Treating the response as a real folder tree; it is synthesized as Artist/Album/Song | Use `getArtists` / `getArtist` / `getAlbum` for ID3-tag-based browsing; only use `getMusicDirectory` for folder browsing when user explicitly chooses that view |
| Navidrome scrobble | Calling `stream` and assuming play is tracked | Navidrome only marks songs as played via `scrobble` with `submission=true`; the `stream` call does not increment play count |
| OpenSubsonic `getOpenSubsonicExtensions` | Not calling it, or calling it and crashing on legacy servers that return HTTP 501 or a Subsonic error | Wrap in `try/except` and treat any non-200 or error response as "no extensions supported"; gate all OpenSubsonic features on the result |
| OpenSubsonic API-key auth | Sending `u`, `t`, `s` alongside `apiKey` | When `apiKey` is present, omit all of `u`, `t`, `s`, and `p`; they are mutually exclusive |
| `getAlbumList2` with `type=alphabeticalByName` | Assuming the total count is available | The API has no `totalCount`; detect end-of-list by `len(returned) < size`; max size is 500 |
| `search3` across servers | Assuming all servers support Lucene-style query syntax | Navidrome supports only simple autocomplete; send plain strings without operators |
| Subsonic `stream` URL construction | Building the URL in the addon and storing it as the ListItem path | The URL contains auth credentials (t/s or legacyauth password). Use `xbmcplugin.setResolvedUrl` with a resolved URL rather than embedding the full auth URL in the directory listing cache |
| `getCoverArt` without explicit size | Receiving full-resolution images, causing unnecessary bandwidth and OOM on embedded devices | Always pass `size=<N>` (e.g., 300 for thumbnails, 600 for fanart); cache the Kodi art URL via ListItem art hints |

---

## Performance Traps

| Trap | Symptoms | Prevention | When It Breaks |
|------|----------|------------|----------------|
| `walk_directory(merge_artist=True)` unlimited recursion | Kodi freezes on server with deep folder trees or circular refs in response | Add a `max_depth` param (default 5); track visited IDs; use iterative BFS not recursive DFS | Any server with folder depth > ~50 or a malformed `isDir` response |
| `list(generator)` over full artist/album library | Multi-second pause before list renders; OOM on very large libraries | Use `xbmcplugin.addDirectoryItems` with a lazy iterator; never `list()` a full library walk | Libraries over ~10,000 albums on low-memory Kodi boxes (Android TV sticks) |
| `cache_refresh()` blocking network call in main plugin thread | UI spinner hangs for up to 30 s on slow servers | Move cache refresh to a background thread or service; return stale data immediately, update asynchronously | Any server with latency > 1 s |
| `Addon().get_setting()` called 20+ times per directory render | Perceptible slowdown on large listings | Read settings once per request into a `Settings` dataclass; pass it through | Visible on lists with 200+ items |
| Starred cache full reload on every star action | Star/unstar takes several seconds on large libraries | Optimistic local update; server sync in background | Libraries > ~5,000 starred tracks |

---

## Security Mistakes

| Mistake | Risk | Prevention |
|---------|------|------------|
| Full auth URL logged at DEBUG | Token+salt or legacy hex-password exposed in kodi.log; file is world-readable on single-user systems | Log only endpoint name and response status; never log the URL string |
| `insecure=True` without warning | MITM attack bypasses HTTPS; credentials go to attacker's server | Show a persistent dialog warning when `insecure=True` is enabled; log `LOGWARNING` on every connection established with this flag |
| Weak `_getSalt()` entropy | If `random.random()` is used as salt source (training-data risk), token is predictable | Verify `_getSalt` uses `secrets.token_hex(16)` or `os.urandom`; replace `random` with `secrets` if needed |
| Plaintext password in settings.xml | Credentials readable by any process running as the same OS user | Document this limitation clearly; consider migration to Kodi credential storage when available; never log the raw password |
| Stream URL embedded in directory listing | If Kodi caches the listing to disk, auth tokens are persisted in the cache file | Always resolve stream URLs lazily via `xbmcplugin.setResolvedUrl`; do not store URLs with embedded auth in `get_url()` calls |

---

## UX Pitfalls

| Pitfall | User Impact | Better Approach |
|---------|-------------|-----------------|
| "Connection error" popup with no actionable text | User has no idea if the problem is wrong URL, wrong password, SSL, or network | Show specific error: "Cannot reach server — check URL and port" vs "Auth failed — check username/password" |
| "Next (2)" appears even when the list is fully loaded | User clicks Next and gets an empty page; feels broken | Only show Next link when `len(items) == page_size` |
| Star/unstar shows no UI feedback that the icon changed | User re-stars the same item thinking the first tap didn't work | Call `Container.Refresh` after a successful star/unstar to force icon update |
| Download starts with no progress indication | User doesn't know if the download is running | Use Kodi's built-in download progress dialog or a notification with progress |
| Scrobble popup on every track | Annoying on long album listening sessions | Make scrobble notification opt-in; default to silent success, notification only on failure |

---

## "Looks Done But Isn't" Checklist

- [ ] **Pagination:** Verify "Next Page" link is absent when `len(items) < page_size` — the TO FIX comments mean it always shows
- [ ] **Star refresh:** After starring an item, confirm the icon changes in the current list — it does not without `Container.Refresh`
- [ ] **Service scrobble:** Confirm `service.py` actually starts — it crashes on launch due to missing `import sys`
- [ ] **useGET mode:** Test star and playlist-update actions with `useGET=True` — they NameError on `urllib2`
- [ ] **OpenSubsonic discovery:** Confirm `getOpenSubsonicExtensions` is called and result is cached, not called on every request
- [ ] **Auth error diagnosis:** Confirm that a wrong-password scenario produces a useful log message, not just "Connection error"
- [ ] **Settings migration:** Confirm existing users' `settings.xml` key names match the new code after any settings rename — broken settings silently fall back to defaults
- [ ] **ListItem.setInfo deprecation:** Confirm no `setInfo('music', ...)` calls remain in new modules after migration to `InfoTagMusic`
- [ ] **Stream URL credential exposure:** Confirm that play URLs stored in listing items do not contain raw `t=`, `s=`, or `p=` parameters
- [ ] **Scrobble dedup:** Confirm a single play at exactly 50% progress does not fire two scrobble calls (timer loop races with progress update)

---

## Recovery Strategies

| Pitfall | Recovery Cost | Recovery Steps |
|---------|---------------|----------------|
| Wrong `xbmcvfs.translatePath` branch taken | LOW | One-line fix; drop version guard entirely; always use `xbmcvfs.translatePath` |
| `urllib2` NameError on GET requests | LOW | Two-line fix in `_getRequestWithList` and `_getRequestWithLists` |
| Missing `import sys` in service.py | LOW | One-line fix at top of file |
| Bare `except:` masking real errors | MEDIUM | Systematic sweep; ~10 sites; each needs targeted exception types identified by reading the surrounding code |
| `ListItem.setInfo()` deprecation in entry builders | MEDIUM | Each builder function needs an `InfoTagMusic` rewrite; ~5 functions; types for all music fields must be verified |
| Starred cache corruption (pickle format mismatch) | MEDIUM | Delete the storage file (`~/.kodi/userdata/addon_data/plugin.audio.subsonic/*.storage`); cache rebuilds on next launch |
| Settings key name mismatch after refactor | HIGH | Must preserve exact `id=` attribute values in `resources/settings.xml`; any rename breaks existing installs silently |
| Stream URL with embedded credentials in cached Kodi view | MEDIUM | Flush Kodi's addon content cache; implement lazy URL resolution via setResolvedUrl going forward |

---

## Pitfall-to-Phase Mapping

| Pitfall | Prevention Phase | Verification |
|---------|------------------|--------------|
| xbmc.translatePath removed | Foundation (Compatibility) | `grep -r 'xbmc.translatePath'` returns zero hits in new code |
| urllib2 NameError | Foundation (Compatibility) | Unit test: `_getRequestWithList` with `useGET=True` does not raise |
| Missing `import sys` | Foundation (Compatibility) | `import service` in pytest without xbmc mocks must not raise NameError |
| Bare `except:` blocks | Foundation + Refactor | `grep -rn 'except:$'` returns zero hits in new code |
| ListItem.setInfo deprecated | Entry-builder refactor | `grep -r 'setInfo.*music'` returns zero hits; kodi.log shows no DEPRECATED warnings |
| Pagination never ends | Pagination phase | Test: request page N where N*size > total; "Next" link absent |
| Starred cache not refreshed | Cache rework phase | UI test: star item, assert icon changes in same list without manual refresh |
| Token auth fails on LDAP servers | Auth migration phase | Document legacyauth use case; test against gonic with legacyAuth=True |
| Credential leak in logs | Auth + Security phase | `grep -r 'log.*url\|log.*password\|log.*token'` in libsonic; zero hits at INFO or above |
| Global connection stale in service | service.py hardening | `onSettingsChanged` resets `connection = None`; test by mocking settings change |
| Settings key names break existing users | Settings migration phase | All `id=` attribute values in settings.xml preserved or explicitly migrated |
| Stream URL credential exposure | Playback phase | Confirm `get_url(action='play_track', ...)` contains no `t=` or `p=` query params |
| `walk_directory` infinite recursion | Refactor phase | Test with a mock response containing circular `isDir` references |
| `Addon()` called per list item | Performance phase | Profile: instantiate `Settings` once at request start; pass through call chain |

---

## Sources

- Kodi forum thread: Python version per release — https://forum.kodi.tv/showthread.php?tid=381891
- Kodi official API docs: translatePath removed in Kodi 20 — https://github.com/powlo/weather.metoffice/issues/6
- Kodi deprecated API list — https://xbmc.github.io/docs.kodi.tv/master/kodi-dev-kit/deprecated.html
- ListItem.setInfo() deprecation issues — https://github.com/jellyfin/jellyfin-kodi/issues/919
- OpenSubsonic getAlbumList2 spec (max 500, no totalCount) — https://opensubsonic.netlify.app/docs/endpoints/getalbumlist2/
- OpenSubsonic API key auth spec — https://opensubsonic.netlify.app/docs/api-reference/
- Navidrome Subsonic compatibility notes (getMusicDirectory, scrobble behavior) — https://www.navidrome.org/docs/developers/subsonic-api/
- Airsonic LDAP / token auth limitation — https://github.com/tamland/airsonic-refix/issues/138
- Kodi service addon pattern — https://kodi.wiki/view/Service_add-ons
- Kodistubs (mock xbmc for tests) — https://romanvm.github.io/Kodistubs/using.html
- Kodi addon testing without runtime — https://blog.misharov.pro/2021-03-03/kodi-addon-testing
- kodi-mock library — https://github.com/willforde/kodi-mock
- Navidrome CVE-2025-27112 (auth bypass via empty password hash) — https://github.com/advisories/GHSA-c3p4-vm8f-386p
- Existing codebase concerns — .planning/codebase/CONCERNS.md (2026-04-28)

---
*Pitfalls research for: Kodi audio addon modernization (plugin.audio.subsonic)*
*Researched: 2026-04-28*
