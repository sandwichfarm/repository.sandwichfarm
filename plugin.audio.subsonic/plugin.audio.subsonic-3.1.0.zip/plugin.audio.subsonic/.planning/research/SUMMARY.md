# Project Research Summary

**Project:** plugin.audio.subsonic — Kodi Subsonic client modernization
**Domain:** Kodi audio addon (brownfield Python refactor + feature expansion)
**Researched:** 2026-04-28
**Confidence:** HIGH (stack and pitfalls verified against official sources and live codebase; architecture corroborated by active reference projects)

---

## Executive Summary

This is a brownfield modernization of a Kodi audio streaming addon that has accumulated years of technical debt on top of a still-functional core. The codebase works for basic use but crashes on launch (service.py), contains dead Python 2 code, has zero test coverage, and makes no use of the OpenSubsonic extensions that every current competing client already implements. The recommended approach is a strict layered refactor: crash fixes and test infrastructure first, then incremental extraction of the monolith, then new features built on the modernized base. Doing features first without the refactor foundation will embed the new code into the same brittle, untestable structure.

The most consequential decisions across all four research areas converge on the same order: (1) fix the three crash bugs that make the addon non-functional today, (2) replace simpleplugin with a first-party router and establish Kodistubs-based unit tests, (3) modernize libsonic in-place with Python 3 idioms and the OpenSubsonic auth/capability probe, and (4) ship new features (genre browsing, search3, API-key auth, radio stations, rating) only after the architecture is stable. The OpenSubsonic `getOpenSubsonicExtensions` capability probe is load-bearing for nearly every feature expansion — it must be implemented in the auth layer before any OpenSubsonic feature is written.

The key risks are: (a) settings key names breaking existing user installs during the refactor — every `id=` attribute in `settings.xml` must be preserved verbatim or explicitly migrated; (b) the `ListItem.setInfo()` deprecation affecting all track/album listings on Kodi 20+ — every entry-builder function must migrate to `InfoTagMusic` typed setters; (c) credential leaks in debug logs that could expose auth tokens — libsonic must never log constructed request URLs. None of these are blocking if addressed in order.

---

## Key Findings

### Recommended Stack

The runtime stack is fixed by the platform: Python 3.8 (Kodi 20 Nexus floor) through 3.11 (Kodi 21 Omega). No runtime dependencies beyond stdlib and the vendored libraries — Kodi addons are self-contained zips, and `pip` is unavailable to end users. All three researchers who touched the stack question independently reached the same conclusion: modernize the vendored `libsonic` in-place rather than replacing it. The only credible alternative (`py-opensonic`) requires `aiohttp`, `requests`, and `mashumaro` — none of which can be safely bundled without dragging in hundreds of kilobytes of transitive deps.

The development toolchain is conventional and well-chosen: `pytest 9.x` + `Kodistubs 21.0.0` + `unittest.mock` injected into `sys.modules` for the Kodi API shim, `ruff 0.15.x` for linting and formatting (replaces black + flake8 + isort), `mypy 1.20.x` targeting `--python-version 3.8` for type checking, and `kodi-addon-checker` in CI for addon.xml validation. No exotic choices; every tool is official, current, or documented in the Kodi community.

**Core technologies:**
- Python 3.8 (min) / 3.11 (target): runtime constraint — write to 3.8 syntax floor, `from __future__ import annotations` for type hints, no `match`/`case`
- Vendored `libsonic` (modernized in-place): only viable Subsonic client for a Kodi addon zip; use `py-opensonic` as spec reference only
- Kodistubs 21.0.0 + `unittest.mock` sys.modules injection: the canonical Kodi addon test pattern; no alternative is maintained
- `ruff 0.15.x` (`target-version = "py38"`): single tool replacing black + flake8 + isort + pyupgrade
- `mypy 1.20.x` (run on Python 3.10+, target 3.8): run/target split is standard; Kodistubs provide Kodi API type annotations for free
- `xbmc.python 3.0.0` in `addon.xml`: correct minimum accepted by Matrix/Nexus/Omega; no change needed to current declaration

### Expected Features

**Must have for v1 (table stakes — addon is embarrassingly incomplete without these):**
- Service crash fix (`import sys` in service.py) — scrobbling is advertised but completely broken for all users
- PR merges #49 (Favorite Albums), #53 (m4a transcoding), #54 (estimateContentLength / gapless) — already community-vetted
- Salt+token auth as default (fall back to legacy for pre-1.13 servers) — plaintext password auth is a 2012 artifact
- `getOpenSubsonicExtensions` capability probe — gates all OpenSubsonic features; must come first in auth layer
- OpenSubsonic API-key auth (gated by probe) — both Navidrome and gonic advertise it
- `search3` adoption (replaces `search2`) — richer metadata including MusicBrainz IDs; all modern clients use it
- Genre browsing (`getGenres` + `getSongsByGenre`) — every competitor has this; we do not
- 5-star rating context menu (`setRating`) — Navidrome separates heart/favorite from star rating
- Internet radio stations (`getInternetRadioStations`) — low complexity; competitor `plugin.kodi.navidrome` already has it
- Correct `setContent` types (`'songs'`, `'albums'`, `'artists'`) and `addSortMethod` declarations — skin view correctness
- MusicBrainz ID passthrough to `InfoTagMusic` — enables skin scraper matching
- Credential audit — remove tokens and passwords from `xbmc.log` output before any public release

**Should have after v1 validation (differentiators):**
- Synchronized lyrics via `getLyricsBySongId` (requires `songLyrics` extension; Navidrome bugs not yet resolved)
- ReplayGain hints as ListItem properties (needs Kodi Omega empirical testing for exact property name)
- Cross-device play queue resume (`savePlayQueue` / `getPlayQueue`)
- Improved pagination for large libraries

**Defer to v2+:**
- `reportPlayback` OpenSubsonic scrobbling (extension still in Navidrome `develop` branch)
- Sonic similarity / radio mode
- `transcodeOffset` for seek-resume of transcoded streams (Kodi seek integration is non-trivial)
- Jukebox mode (Navidrome has active bugs; semantically opposite to what Kodi users want)
- Podcast browser (Navidrome does not support it; Kodi has dedicated podcast addons)

**Explicitly anti-features — do not build:**
- Sync-to-device / offline caching (Kodi is always-on; download-to-folder covers the use case)
- Social sharing links (zero demand in forum threads)
- Server admin endpoints (wrong UI paradigm for a 10-foot interface)
- Kodi Music Library database injection (requires a VFS provider, a different extension type entirely)

### Architecture Approach

The recommended architecture replaces the 1561-line monolith with a layered structure: thin entry points (`main.py`, `service.py` become 10-20 line bootstraps), a first-party decorator router on `sys.argv` (55 lines; kills the simpleplugin dependency), handler modules grouped by concern (`browse.py`, `search.py`, `playback.py`, `actions.py`), a `listings.py` that owns all `xbmcplugin`/`xbmcgui` calls (keeping them out of testable business logic), a typed `settings.py` facade (one injection point for tests), `TypedDict` models for Subsonic API response shapes, and an `api/client.py` wrapper that owns auth strategy selection and the OpenSubsonic capability probe. This structure matches the pattern used by `plugin.audio.tidal2` and `kodi-plugin-routing`, the two highest-quality reference implementations found.

**Major components:**
1. `router.py` — thin `@route()` decorator dispatch; owns `url_for()`; replaces simpleplugin
2. `api/client.py` — single boundary to libsonic; owns auth mode selection (legacy/token/API-key) and the OpenSubsonic capability probe
3. `settings.py` — typed facade over `xbmcaddon`; single mock target in tests
4. `models.py` — `TypedDict` for API responses, `@dataclass` for internal state; no Kodi imports
5. `listings.py` — all `xbmcplugin`/`xbmcgui` calls; uses `InfoTagMusic` typed setters (not deprecated `setInfo`)
6. `browse.py`, `search.py`, `playback.py`, `actions.py` — handler modules registered with `@route()`
7. `scrobbler.py` — `xbmc.Monitor` subclass; receives injected `ApiClient`; testable in isolation
8. `cache.py` — per-session TTL dict + optional `xbmcvfs` JSON persistence; replaces pickle + global `local_starred`

**Key architectural principle:** The plugin process (`main.py`) and service process (`service.py`) are separate OS processes and share no module-level state. The global `connection = None` singleton anti-pattern must be eliminated in both. Communication between them, if needed, goes through `xbmcgui.Window(10000)` properties only.

### Critical Pitfalls

All ten pitfalls in PITFALLS.md are confirmed against the actual codebase. The five most dangerous:

1. **Missing `import sys` in `service.py`** — single-line crash on every Kodi launch; scrobbling is silently dead for all users. One-line fix; must be first.
2. **`urllib2` NameError on GET requests in libsonic** — silent under the bare `except:` wrapper; surfaces as "Connection error" only for `useGET=True` users doing multi-ID operations. Two-line fix in `connection.py:2848,2875`.
3. **`xbmc.translatePath` removed in Kodi 20+** — `simpleplugin.py` uses fragile string comparison of version numbers. Fix: drop the version guard entirely and unconditionally use `xbmcvfs.translatePath` (we target Kodi 20+ only).
4. **`ListItem.setInfo('music', {...})` deprecated in Kodi 20** — affects every track and album list item rendered; slated for removal in a future release. All entry-builder functions must migrate to `li.getMusicInfoTag()` with typed setters.
5. **Settings key names silently break existing user installs** — any rename of `id=` attributes in `settings.xml` falls back to defaults with no error. All existing setting IDs must be preserved verbatim through the refactor, or a migration shim added.

Secondary pitfalls to address in order: credential leaks in `xbmc.log` (tokens in URL strings), bare `except:` blocks masking all real errors (8 sites in `main.py` + 2 in `service.py`), pagination never detecting end-of-list (two `# TO FIX` markers), starred cache not refreshed in UI after star/unstar, and token auth failing on LDAP-backed servers.

---

## Implications for Roadmap

### Phase 1: Foundation — Crash Fixes + Test Infrastructure
**Rationale:** Nothing else can be built on a codebase that crashes on load and has zero test coverage. The three crash bugs are confirmed blocking issues against real users on current Kodi. The test scaffold must exist before any module is extracted, because extracted modules need tests on the same day they are created.
**Delivers:** Addon that loads without crashing on Kodi 20 and 21; `pytest` infrastructure with Kodi API mocked via Kodistubs + `sys.modules`; GitHub Actions CI running tests on Python 3.8 and 3.11; `ruff` and `mypy` CI jobs; `kodi-addon-checker` in CI.
**Addresses:** service.py scrobble crash, urllib2 NameError, translatePath crash, bare `except:` at the most dangerous sites (get_connection, service.py)
**Avoids:** All subsequent refactor work being done without a safety net

### Phase 2: Merge Community PRs
**Rationale:** PRs #49, #53, #54 are community-vetted and directly address user-visible gaps. Merging them before the structural refactor avoids conflicts between PR code and refactored module boundaries.
**Delivers:** Gapless playback, m4a transcoding, Favorite Albums menu — all working on the modernized base.
**Avoids:** Three-way merge conflicts if PRs are applied after module extraction

### Phase 3: Structural Refactor (simpleplugin replacement + module extraction)
**Rationale:** The monolithic `main.py` must be broken up before new features are added, or new code inherits the same untestable structure. The 7-step extraction order (settings/models → api/client → cache → router → handlers → scrobbler) has clear dependency logic; each step unblocks the next, with tests written immediately after each extraction.
**Delivers:** `router.py` replacing simpleplugin; all handler modules extracted; `main.py` and `service.py` reduced to bootstraps; all 8 `# TO FIX` markers resolved; all bare `except:` blocks replaced; `ListItem.setInfo` deprecated calls replaced with `InfoTagMusic`; pickle-backed starred cache replaced with JSON + `xbmcvfs`.
**Uses:** Kodistubs + pytest for test coverage on every extracted module
**Avoids:** Settings key name breakage (preserve all `id=` attributes), global `connection` singleton

### Phase 4: Auth Modernization + Security
**Rationale:** Auth must be modernized before new features are layered on top, because every new API call will use the auth layer. The `getOpenSubsonicExtensions` probe in `api/client.py` is the literal dependency gate for every subsequent OpenSubsonic feature. Credential leak audit must happen before any public release.
**Delivers:** Salt+token auth as default (legacy fallback preserved); `getOpenSubsonicExtensions` probe cached per session; OpenSubsonic API-key auth when advertised; credential audit (no tokens in `xbmc.log`); `insecure=True` warning dialog; `secrets`-based salt generation.
**Avoids:** Sending `u`/`t`/`s` alongside `apiKey` (mutually exclusive per OpenSubsonic spec); breaking LDAP users who need `legacyauth`

### Phase 5: Feature Expansion (OpenSubsonic + table stakes gaps)
**Rationale:** Only possible cleanly after auth is modernized. All features here are gated on the OpenSubsonic probe being in place. Genre browsing, search3, rating, and radio stations are LOW complexity and fill visible gaps against competitor addons.
**Delivers:** Genre browsing; `search3` replacing `search2`; 5-star rating context menu; internet radio stations; MusicBrainz ID passthrough to `InfoTagMusic`; correct `setContent` type declarations; `addSortMethod` on all views.
**Addresses:** All table-stakes gaps identified in the competitor feature matrix

### Phase 6: Polish + v1.x Features
**Rationale:** v1 release is cut after Phase 5 is validated. Phase 6 features require either empirical testing (ReplayGain property names on Omega) or depend on upstream server stability (Navidrome lyrics bugs).
**Delivers:** Synchronized lyrics via `getLyricsBySongId` (when Navidrome bugs are resolved); ReplayGain hints as ListItem properties (after Omega testing); cross-device play queue resume; library pagination improvements.
**Research flags:** ReplayGain Kodi property names need empirical verification on Omega. `getLyricsBySongId` needs real-server testing against Navidrome v0.49+.

### Phase Ordering Rationale

- Phase 1 before everything: three crashes mean the addon does not function for significant user segments.
- Phase 2 before refactor: community PRs are patches against `main.py` as it currently exists; applying after restructuring creates three-way merge conflicts.
- Phase 3 before auth/features: adding OpenSubsonic features into the monolith would require rewriting them again post-refactor.
- Phase 4 (auth) before Phase 5 (features): `getOpenSubsonicExtensions` is the literal dependency gate for every OpenSubsonic feature — it must exist and be cached before any feature code branches on it.
- Phase 5 features are ordered LOW-complexity-first: genre, search3, rating, radio are all single-function additions.

### Research Flags

Phases needing deeper research during planning:
- **Phase 4 (Auth):** Token auth failure on LDAP-backed servers needs empirical testing. Exact libsonic code changes for API-key auth require close inspection of `connection.py` parameter handling.
- **Phase 6 (ReplayGain):** Exact Kodi ListItem property names for streaming ReplayGain hints are not confirmed in official docs. Confidence is LOW. Must be tested on a live Kodi 21 Omega install.
- **Phase 6 (Lyrics):** Navidrome `getLyricsBySongId` has two open bug reports (#4631, #4233). Build only after those are resolved or the failure mode is well-understood.

Phases with established patterns (skip research-phase):
- **Phase 1:** All three crash fixes are one-to-three-line changes confirmed in the codebase. No ambiguity.
- **Phase 2:** PR merges are already reviewed and working against existing code.
- **Phase 3:** The extraction pattern is well-documented in `plugin.audio.tidal2` and `kodi-plugin-routing`. No novel problems.
- **Phase 5 (genre, search3, rating, radio):** All use standard Subsonic endpoints documented in the OpenSubsonic spec.

---

## Cross-Cutting Findings

These points were independently reached by multiple researchers and represent the highest-confidence decisions:

**1. `service.py` `import sys` crash is the single highest-priority fix.**
All four researchers flag it. It is a one-line fix. Every user who relies on scrobbling is silently affected.

**2. The `getOpenSubsonicExtensions` probe must come before any OpenSubsonic feature code.**
FEATURES and ARCHITECTURE both structure their phase suggestions around this. The probe is unauthenticated, cached per session, and is the single gate for API-key auth, lyrics, ReplayGain, search3 empty-query, and formPost.

**3. Drop simpleplugin; write a first-party router.**
STACK (vendored libs should be modernized or dropped), ARCHITECTURE (simpleplugin is 1300 lines of cruft; the pattern is 55 lines), and PITFALLS (the string version comparison in simpleplugin is a hard crash on Kodi 20+) all agree independently. The `kodi-plugin-routing` reference implementation proves the pattern.

**4. Kodistubs + `unittest.mock` `sys.modules` injection is the correct test pattern.**
STACK confirmed it against official Kodistubs docs. ARCHITECTURE provided the exact `conftest.py` implementation. PITFALLS noted that without a test scaffold, refactoring is flying blind. All three are consistent.

**5. Modernize libsonic in-place; do not replace it.**
STACK and ARCHITECTURE both arrived here independently. `py-opensonic` requires aiohttp + requests + mashumaro (~500KB of unvendorable deps). `knuckles` has 3 GitHub stars and an async-first API surface incompatible with Kodi's synchronous plugin model.

**6. `ListItem.setInfo('music', {...})` must be replaced with `InfoTagMusic` in every entry builder.**
PITFALLS confirmed this as a Kodi 20 deprecation. ARCHITECTURE placed this work in `listings.py`. FEATURES noted it as a requirement for correct skin view behavior. All three imply the same migration.

---

## Conflicts Resolved

**Conflict 1: "Modernize libsonic in-place" (STACK) vs. ARCHITECTURE**
No actual conflict. ARCHITECTURE recommends the same conclusion — wrap libsonic behind `api/client.py` and modernize the internals, but keep it vendored. Both documents mean the same thing by "modernize."

**Conflict 2: Python version matrix — Kodi 20 ships Python 3.8 or 3.11?**
Resolved. STACK correctly states: Kodi 20 Nexus bundles Python 3.8 (confirmed 3.8.10 on Windows); Kodi 21 Omega bundles Python 3.11. Any reference to "Kodi 20 also ships Python 3.11" is incorrect. The CI matrix of `["3.8", "3.11"]` is correct. Write to 3.8 syntax floor in all cases.

**Conflict 3: Phase ordering — FEATURES vs. ARCHITECTURE**
FEATURES suggests doing crash fixes + pending PRs as a single first phase. ARCHITECTURE suggests crash fixes + test scaffold as Phase 1, then extraction before any PRs. The synthesized recommendation separates these: crash fixes + test scaffold first (Phase 1), then PR merges (Phase 2), then structural refactor (Phase 3). This avoids applying the community PRs against an already-refactored codebase structure they were not written against.

---

## Open Questions

These items require empirical verification and cannot be resolved from documentation alone:

1. **ReplayGain ListItem property names on Kodi Omega:** Exact `ListItem.setProperty()` key names for streaming ReplayGain hints are not confirmed in official Kodi Python API docs. Confidence is LOW. Must be tested against a live Kodi 21 install before the feature is built.
2. **Navidrome `getLyricsBySongId` stability:** The `songLyrics` OpenSubsonic extension has two open Navidrome bugs (issues #4631, #4233). The lyrics feature should not be committed until tested against a current Navidrome server.
3. **gonic and LMS compatibility of OpenSubsonic probe:** `getOpenSubsonicExtensions` behavior on gonic and LMS needs real-server testing. The fallback (treat any non-200 or error response as "no extensions") is safe but should be verified empirically.
4. **Token auth on LDAP-backed Airsonic:** The LDAP incompatibility with salt+token auth is documented in forum posts and one GitHub issue but not in official Airsonic docs. Testing against an LDAP-backed instance would confirm the failure mode.
5. **`estimateContentLength` and gapless on Omega:** PR #54 targets gapless playback. Whether Kodi 21 Omega's player actually achieves gapless with this hint needs verification in a live environment.

---

## Confidence Assessment

| Area | Confidence | Notes |
|------|------------|-------|
| Stack | HIGH | Core tech choices verified against official Kodi addon-check source, Kodistubs PyPI, mypy 1.20 release notes, ruff releases. Python version per Kodi release confirmed via Kodi forum + official release notes. |
| Features | HIGH | OpenSubsonic spec is official and unambiguous. Navidrome API compatibility table is official documentation. Competitor feature gap analysis confirmed via live GitHub repos. Lyrics feature flagged LOW specifically due to open Navidrome bugs. |
| Architecture | HIGH | Pattern confirmed in three active reference projects (tidal2, kodi-plugin-routing, spotify). Kodistubs test pattern is documented in official project docs. The 7-step extraction order has clear dependency logic grounded in real module boundaries. |
| Pitfalls | HIGH | All critical pitfalls confirmed against actual codebase file/line references in CONCERNS.md. Not inferred — verified against live code. `ListItem.setInfo` deprecation confirmed via Kodi official deprecated API list. |

**Overall confidence: HIGH**

### Gaps to Address

- **ReplayGain Kodi property names:** Cannot be resolved without a running Kodi 21 install. Defer the feature until empirical testing is possible; do not build on a guess.
- **Navidrome lyrics bugs:** Monitor Navidrome issues #4631 and #4233. Build lyrics feature only after those are resolved or the bugs are well-understood.
- **Integration test absence:** v1 is intentionally unit-tests-only. Auth fallback logic, actual streaming, and scrobble timing will not be caught by CI. Manual verification against a live Navidrome instance is required before any release.
- **settings.xml migration strategy:** The refactor will reorganize settings into a typed facade. The exact mapping of old `id=` values to new typed properties must be documented explicitly during Phase 3 to prevent silent fallback-to-default for existing users.

---

## Sources

### Primary (HIGH confidence)
- [Kodistubs 21.0.0 PyPI + romanvm/Kodistubs GitHub](https://github.com/romanvm/Kodistubs) — test pattern, type stubs, Python 3.6+ compatibility
- [xbmc/addon-check check_dependencies.py](https://github.com/xbmc/addon-check/blob/master/kodi_addon_checker/check_dependencies.py) — xbmc.python version per Kodi release
- [OpenSubsonic API spec](https://opensubsonic.netlify.app/docs/) — getOpenSubsonicExtensions, apiKeyAuthentication, search3, ReplayGain response type
- [Navidrome Subsonic API Compatibility](https://www.navidrome.org/docs/developers/subsonic-api/) — endpoint support matrix
- [khers/py-opensonic requirements.txt](https://github.com/khers/py-opensonic/blob/master/requirements.txt) — confirmed aiohttp + requests + mashumaro deps (basis for "do not vendor" decision)
- [kodi-plugin-routing source](https://github.com/tamland/kodi-plugin-routing) — thin router pattern reference
- [plugin.audio.tidal2](https://github.com/arnesongit/plugin.audio.tidal2) — structural reference for streaming music addon
- [Kodi deprecated API list](https://xbmc.github.io/docs.kodi.tv/master/kodi-dev-kit/deprecated.html) — ListItem.setInfo deprecation
- `.planning/codebase/CONCERNS.md` (2026-04-28) — live codebase analysis with file/line references for every pitfall

### Secondary (MEDIUM confidence)
- [Kodi forum Python version thread](https://forum.kodi.tv/showthread.php?tid=381891) — Python 3.8.10 for Nexus Windows confirmed
- [Kodi forum addon testing thread](https://forum.kodi.tv/showthread.php?tid=361089) — community testing pattern consensus
- [plugin.kodi.navidrome (colinfredynand)](https://github.com/colinfredynand/plugin.kodi.navidrome) — competitor feature baseline
- [Navidrome getLyricsBySongId bug #4631](https://github.com/navidrome/navidrome/issues/4631) and [#4233](https://github.com/navidrome/navidrome/issues/4233) — lyrics feature instability
- [Airsonic LDAP token auth limitation](https://github.com/tamland/airsonic-refix/issues/138) — auth fallback requirement for LDAP users

### Tertiary (LOW confidence)
- ReplayGain ListItem property names for streaming — no official Kodi doc confirmed; needs empirical test on Omega
- Navidrome `reportPlayback` extension timeline — in `develop` branch; no stable release date

---

*Research completed: 2026-04-28*
*Ready for roadmap: yes*
