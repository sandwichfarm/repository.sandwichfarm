# Architecture Research

**Domain:** Kodi audio addon — Subsonic API streaming client refactor
**Researched:** 2026-04-28
**Confidence:** HIGH (patterns drawn from active reference projects + official Kodi docs)

## Standard Architecture

### System Overview

```
┌──────────────────────────────────────────────────────────────────┐
│                    Kodi Platform Layer                           │
│  xbmcplugin   xbmcgui   xbmcaddon   xbmcvfs   xbmc.Monitor      │
├──────────────────────────────────────────────────────────────────┤
│                    Addon Entry Points                            │
│  ┌──────────────────────┐   ┌───────────────────────────────┐   │
│  │   main.py            │   │   service.py                  │   │
│  │  (plugin source)     │   │  (background service)         │   │
│  └──────────┬───────────┘   └──────────────┬────────────────┘   │
│             │                              │                     │
├─────────────┼──────────────────────────────┼─────────────────────┤
│             │    Plugin Application Layer  │                     │
│  ┌──────────▼───────────┐   ┌─────────────▼──────────────────┐  │
│  │   router.py          │   │   scrobbler.py                 │  │
│  │  (URL dispatch)      │   │  (Monitor subclass)            │  │
│  └──────────┬───────────┘   └──────────────────────────────-─┘  │
│             │                                                    │
│  ┌──────────▼───────────────────────────────────────────────┐   │
│  │                  Handler Modules                          │   │
│  │  browse.py  search.py  playback.py  actions.py           │   │
│  └──────────────────────────┬────────────────────────────────┘  │
├───────────────────────────── │ ──────────────────────────────────┤
│             │    Core Services Layer       │                     │
│  ┌──────────▼───────────┐   ┌─────────────▼──────────────────┐  │
│  │   api/client.py      │   │   cache.py                     │  │
│  │  (libsonic wrapper)  │   │  (TTL dict + xbmcvfs)          │  │
│  └──────────┬───────────┘   └────────────────────────────────┘  │
│             │                                                    │
│  ┌──────────▼───────────┐   ┌────────────────────────────────┐  │
│  │   models.py          │   │   settings.py                  │  │
│  │  (TypedDicts/        │   │  (settings facade)             │  │
│  │   dataclasses)       │   └────────────────────────────────┘  │
│  └──────────────────────┘                                       │
├──────────────────────────────────────────────────────────────────┤
│                    Vendored Libraries                            │
│  ┌──────────────────────┐                                       │
│  │   lib/libsonic/      │                                       │
│  │  (modernized py-sonic)│                                       │
│  └──────────────────────┘                                       │
└──────────────────────────────────────────────────────────────────┘
```

### Component Responsibilities

| Component | Responsibility | Communicates With |
|-----------|---------------|-------------------|
| `main.py` | Entry point only — bootstrap sys.path, import router, call `router.run()` | router.py |
| `service.py` | Entry point only — bootstrap, instantiate Scrobbler, run monitor loop | scrobbler.py |
| `router.py` | Parse `sys.argv`, dispatch URL to handler function, hold `plugin_id` constant | handler modules, settings |
| `browse.py` | Directory listing handlers: artists, albums, folders, playlists, starred | api/client.py, models, cache, listings.py |
| `search.py` | Search dialog + result handlers | api/client.py, models, listings.py |
| `playback.py` | URL resolution for `play_track` action, stream URL building | api/client.py, settings |
| `actions.py` | Side-effect actions: star/unstar, download, context menu construction | api/client.py, settings |
| `api/client.py` | Thin wrapper over libsonic.Connection; owns auth strategy selection (token vs apikey) | lib/libsonic, models |
| `models.py` | TypedDicts for Subsonic API response shapes; dataclasses for internal state | (no deps — pure data) |
| `cache.py` | Per-session in-memory dict with TTL; optional xbmcvfs JSON persistence | xbmcvfs |
| `settings.py` | Typed facade over `xbmcaddon.Addon().getSetting()`; single read point | xbmcaddon |
| `listings.py` | Build Kodi ListItem dicts from models; call xbmcplugin.addDirectoryItem | xbmcplugin, xbmcgui, models |
| `scrobbler.py` | `xbmc.Monitor` subclass; URL regex → track ID → scrobble at 50% | api/client.py, settings |
| `lib/libsonic/` | HTTP client to Subsonic REST API; XML/JSON parsing; vendored | urllib.request, http.client |

## Recommended Project Structure

```
plugin.audio.subsonic/
├── addon.xml
├── main.py                  # 10-15 lines: sys.path setup, import router, router.run()
├── service.py               # 15-20 lines: sys.path setup, import scrobbler, run loop
├── icon.png
├── fanart.jpg
├── resources/
│   ├── settings.xml
│   └── language/
├── lib/
│   └── libsonic/            # vendored, modernized
│       ├── __init__.py
│       ├── connection.py
│       └── errors.py
├── resources/lib/           # addon application code lives here (Kodi convention)
│   ├── __init__.py
│   ├── router.py            # URL routing without simpleplugin
│   ├── settings.py          # typed settings facade
│   ├── models.py            # TypedDicts + dataclasses for API responses
│   ├── cache.py             # per-session cache
│   ├── listings.py          # Kodi ListItem builder (xbmcplugin/xbmcgui calls)
│   ├── browse.py            # browse/list action handlers
│   ├── search.py            # search action handlers
│   ├── playback.py          # play_track handler + stream URL resolution
│   ├── actions.py           # star/unstar/download handlers
│   ├── scrobbler.py         # xbmc.Monitor subclass
│   └── api/
│       ├── __init__.py
│       └── client.py        # ApiClient wrapping libsonic.Connection
└── tests/
    ├── conftest.py          # sys.modules mocks for xbmc*
    ├── test_models.py
    ├── test_cache.py
    ├── test_router.py
    ├── test_client.py
    └── test_browse.py
```

### Structure Rationale

- **`resources/lib/`:** Kodi's convention for addon application code (visible in tidal2, Spotify, Squeezebox addons). Keeps addon root clean. Kodi adds `resources/lib` to `sys.path` automatically via the addon manifest.
- **`api/client.py` subdirectory:** Isolates all libsonic interaction behind one import boundary. The client module is the only module that touches `lib/libsonic/`; everything else gets typed models back.
- **Thin entry points:** `main.py` and `service.py` become 10-20 line bootstraps. This is the dominant pattern in mature addons (tidal2: `from resources.lib.tidal2 import main; main.run()`). Keeps untestable entry-point glue minimal.
- **`scrobbler.py` separate from `service.py`:** `service.py` can't be unit-tested (it imports `xbmc.Monitor` at module level). `scrobbler.py` contains the logic class; `service.py` just instantiates it. Tests exercise `Scrobbler` in isolation with mock xbmc.

## Architectural Patterns

### Pattern 1: Thin Decorator Router on `sys.argv`

**What:** First-party router holding a `dict[str, Callable]` populated by `@route('/path')` decorators. `run()` parses `sys.argv[2]` with `urllib.parse.parse_qs`, extracts `action`, calls the registered function.

**When to use:** Always. This is what simpleplugin's `Plugin` class does, minus 1300 lines of cruft. The tamland `kodi-plugin-routing` library (used by tidal2 via `script.module.routing`) proves the pattern: `@plugin.route('/artists')` → `def artists():` with `url_for(artists)` for URL construction.

**Trade-offs:** Need to write `url_for()` equivalent (30 lines). Worth it: removes vendored dependency, gives full control, makes router unit-testable.

**Example:**
```python
# resources/lib/router.py
import sys
import urllib.parse
from typing import Callable

_routes: dict[str, Callable] = {}
PLUGIN_ID = "plugin.audio.subsonic"

def route(action: str):
    def decorator(fn: Callable) -> Callable:
        _routes[action] = fn
        return fn
    return decorator

def url_for(action: str, **params) -> str:
    qs = urllib.parse.urlencode({"action": action, **params})
    return f"plugin://{PLUGIN_ID}/?{qs}"

def run():
    params = dict(urllib.parse.parse_qsl(
        urllib.parse.urlparse(sys.argv[2]).query
    ))
    action = params.get("action", "root")
    handler = _routes.get(action)
    if handler is None:
        raise ValueError(f"No handler for action={action!r}")
    handler(**{k: v for k, v in params.items() if k != "action"})
```

Action handler registration in a separate module:
```python
# resources/lib/browse.py
from .router import route, url_for

@route("root")
def root():
    ...

@route("list_artists")
def list_artists(page: str = "1"):
    ...
```

### Pattern 2: TypedDict for API Responses, Dataclass for Internal State

**What:** Use `TypedDict` for Subsonic API response shapes (they arrive as dicts from libsonic's JSON/XML parsing and stay dict-like). Use `@dataclass` for internal state objects that are created and mutated in application logic.

**When to use:** TypedDicts for anything that comes out of `libsonic` responses. Dataclasses for pagination state, cache entries, play context.

**Trade-offs:** TypedDict requires no runtime cost (pure type-checking). Dataclass adds `__init__`/`__repr__` for free. Pydantic is too heavy to vendor (500KB+ with compiled extensions); avoid. This pattern works on Python 3.8 without backports.

**Example:**
```python
# resources/lib/models.py
from typing import Optional
from typing_extensions import TypedDict  # or from typing import TypedDict (3.8+)
from dataclasses import dataclass

class SubsonicArtist(TypedDict):
    id: str
    name: str
    albumCount: int
    coverArt: Optional[str]
    starred: Optional[str]  # ISO timestamp if starred

class SubsonicTrack(TypedDict):
    id: str
    title: str
    artist: str
    artistId: Optional[str]
    album: str
    albumId: Optional[str]
    duration: int
    bitRate: Optional[int]
    contentType: str
    suffix: str
    coverArt: Optional[str]
    year: Optional[int]
    track: Optional[int]
    starred: Optional[str]

@dataclass
class PageState:
    page: int
    page_size: int
    offset: int
    has_more: bool

@dataclass
class PlayContext:
    stream_url: str
    track_id: str
    title: str
    duration: int
```

### Pattern 3: Per-Session In-Memory Cache with xbmcvfs Persistence

**What:** Two-level cache — a plain `dict` holding `(value, expires_at)` tuples for the plugin process lifetime (fast, zero I/O), backed by an optional xbmcvfs JSON file for cross-session persistence of expensive data (starred items, artist lists).

**When to use:** Directory listings: memory only, short TTL (5 min). Starred item set: persist to xbmcvfs, honor `starred` timestamp field from server. Never cache stream URLs.

**Trade-offs:** Memory cache dies when the plugin process exits (every Kodi navigation event). xbmcvfs JSON is available across plugin invocations. SQLite (via `script.module.simplecache`) is an option but adds a script.module dep; avoid for v1.

**Example:**
```python
# resources/lib/cache.py
import json
import time
from typing import Any, Optional
import xbmcvfs

_mem: dict[str, tuple[Any, float]] = {}

def get(key: str) -> Optional[Any]:
    entry = _mem.get(key)
    if entry and entry[1] > time.time():
        return entry[0]
    return None

def set(key: str, value: Any, ttl_seconds: int = 300) -> None:
    _mem[key] = (value, time.time() + ttl_seconds)

def persist_write(path: str, data: Any) -> None:
    payload = json.dumps(data).encode("utf-8")
    with xbmcvfs.File(path, "wb") as f:
        f.write(bytearray(payload))

def persist_read(path: str) -> Optional[Any]:
    try:
        with xbmcvfs.File(path, "rb") as f:
            raw = bytes(f.readBytes(1 << 20))
        return json.loads(raw.decode("utf-8")) if raw else None
    except Exception:
        return None
```

### Pattern 4: Settings Facade

**What:** A single `Settings` class (or module-level typed properties) wraps `xbmcaddon.Addon().getSetting()`. Every module imports `settings` and calls typed properties, never raw string keys.

**When to use:** Always. Prevents scattered `Addon().getSetting('password')` calls across 8 modules, and makes tests trivial to mock at one injection point.

**Example:**
```python
# resources/lib/settings.py
import xbmcaddon

class Settings:
    def __init__(self):
        self._addon = xbmcaddon.Addon()

    @property
    def server_url(self) -> str:
        return self._addon.getSetting("subsonic_url")

    @property
    def port(self) -> int:
        return int(self._addon.getSetting("port") or "4040")

    @property
    def username(self) -> str:
        return self._addon.getSetting("username")

    @property
    def password(self) -> str:
        return self._addon.getSetting("password")

    @property
    def use_legacy_auth(self) -> bool:
        return self._addon.getSetting("legacyauth") == "true"

    @property
    def api_key(self) -> str:
        return self._addon.getSetting("apikey")
```

### Pattern 5: ApiClient Auth Strategy Selection

**What:** The `ApiClient` constructor reads settings to decide auth mode: API-key (OpenSubsonic), salt+token (API >= 1.13), or legacy MD5. The client probes `getOpenSubsonicExtensions()` on first connect to detect apiKeyAuthentication support.

**When to use:** New auth must be negotiated at connection time, not scattered through libsonic internals.

**Trade-offs:** First-connect probe adds one round-trip. Cache the result for the session. If probe fails gracefully, fall back to salt+token.

### Pattern 6: Service/Plugin Isolation via Shared Nothing

**What:** `service.py` (scrobbler) and `main.py` (plugin) share no module-level state. Both import from `resources/lib/` independently, each creating their own `Settings` instance and their own `ApiClient`. Communication from plugin → service happens (if needed) via `xbmcgui.Window(10000)` properties — the Kodi-standard IPC channel (used by spotify addon).

**When to use:** Always for Kodi addons. The plugin process is ephemeral (spawned per URL, exits after `endOfDirectory`). The service process is long-lived. They run in different OS processes under Kodi's Python interpreter. Sharing module-level globals is impossible and wrong.

**Practical consequence for scrobbler:** `service.py` bootstraps its own `Settings` + `ApiClient` at startup, not at import time of `scrobbler.py`. The `Scrobbler` class receives a client instance in `__init__` — this is the dependency injection point that tests exploit.

## Data Flow

### Browse/List Flow

```
Kodi UI click
    ↓
main.py → router.run()
    ↓  parse sys.argv[2] → action="list_albums", page="1"
browse.py:list_albums(page="1")
    ↓
cache.get("albums:newest:1")  → miss
    ↓
api/client.py:ApiClient.get_album_list(ltype="newest", page=1)
    ↓
lib/libsonic/connection.py:getAlbumList2(offset=0, size=50)
    ↓  HTTP GET → Subsonic server
raw dict response
    ↓
ApiClient parses → list[SubsonicAlbum]  (TypedDict)
    ↓
cache.set("albums:newest:1", albums, ttl=300)
    ↓
listings.py:build_album_listing(albums, page=1)
    ↓  creates xbmcgui.ListItem per album, sets art/metadata
xbmcplugin.addDirectoryItems(handle, items)
xbmcplugin.endOfDirectory(handle)
    ↓
Kodi renders directory
```

### Playback Flow

```
User clicks track ListItem
    ↓
Kodi calls plugin://...?action=play_track&id=<id>
    ↓
main.py → router.run() → playback.py:play_track(id="<id>")
    ↓
api/client.py:ApiClient.stream_url(track_id, bitrate, fmt)
    ↓
lib/libsonic:connection.streamUrl() → http://server/rest/stream.view?...
    ↓
xbmcplugin.setResolvedUrl(handle, True, xbmcgui.ListItem(path=url))
    ↓
Kodi streams audio
```

### Scrobble Flow

```
Kodi starts track playback
    ↓
service.py Scrobbler(xbmc.Monitor) detects HasMedia
    ↓  polls every 10s
xbmc.getInfoLabel("Player.FilenameAndPath")
    ↓  extract track_id via urllib.parse (not regex)
xbmc.getInfoLabel("Player.Progress")
    ↓  >= 50% AND not yet scrobbled
api/client.py:ApiClient.scrobble(track_id)
    ↓
lib/libsonic:connection.scrobble() → HTTP POST
    ↓
scrobbled = True (prevent duplicate)
```

### Auth Negotiation Flow (first connect)

```
ApiClient.__init__(settings)
    ↓
probe: libsonic.connection.getOpenSubsonicExtensions()
    ↓  check for "apiKeyAuthentication" in extensions
if apikey in settings AND server supports it:
    use apiKey= param (no u= param per OpenSubsonic spec)
elif settings.api_version >= "1.13":
    use u=, t=md5(password+salt), s=salt
else:
    use u=, p=password (legacy — warn in log)
    ↓
store auth_mode in session, skip probe on subsequent calls
```

## Suggested Build Order

The following sequence minimizes rework. Each step unblocks the next.

### Step 1: Crash fixes + test scaffold (unblocks everything)

**What:** Fix `import sys` in service.py. Fix `urllib2` in libsonic. Add `tests/conftest.py` with `sys.modules` mocks for `xbmc`, `xbmcgui`, `xbmcplugin`, `xbmcaddon`, `xbmcvfs`. Add `pytest.ini`. Run pytest (zero tests pass but infrastructure works).

**Why first:** The crash fixes make the addon load at all. The test scaffold must exist before any module extraction, because extracted modules need tests immediately to confirm they were extracted correctly. Setting up mocks first means every subsequent module can have tests on the same day it's created.

**Dependency:** Nothing depends on this except everything.

### Step 2: Extract `settings.py` and `models.py`

**What:** Create `resources/lib/settings.py` (typed facade). Create `resources/lib/models.py` (TypedDicts for every API response shape in main.py). No behavior change yet — main.py still exists unchanged; these are new modules only.

**Why second:** These two modules have zero Kodi API dependencies (settings.py imports xbmcaddon but that's mocked; models.py imports nothing). Both are fully unit-testable immediately. Every subsequent module depends on them — get them stable first. The type annotations also serve as a forcing function to understand the data shapes before rewriting the handlers.

**Dependency:** Needs conftest.py from Step 1.

### Step 3: Extract `api/client.py` (libsonic wrapper)

**What:** Create `resources/lib/api/client.py`. Move `get_connection()` logic here. Implement auth mode selection (legacy, salt+token, apikey). Replace `urllib2.Request` in libsonic. Add `import sys` to service.py. Write unit tests for `ApiClient.build_auth_params()` using only stdlib.

**Why third:** The API client is the most depended-upon module. Once it exists and is tested, all handler modules can be extracted against it. Auth modernization lives here — isolating it to one file means one PR changes auth everywhere.

**Dependency:** Needs models.py from Step 2. Does not need router.

### Step 4: Extract `cache.py`

**What:** Create `resources/lib/cache.py` with the two-level pattern. Replace the global `local_starred` module variable and `plugin.get_storage()` calls with the new cache module. Unit-test `get`/`set`/`persist_write`/`persist_read` with mock xbmcvfs.

**Why fourth:** Cache is used by browse handlers. Extract it before extracting browse.py so the browse module can import the cache cleanly. This also kills the last global mutable state in main.py.

**Dependency:** Needs conftest.py. Does not need router or handlers.

### Step 5: Write `router.py` (replace simpleplugin routing)

**What:** Implement the thin decorator router as described in Pattern 1. Write unit tests that exercise `route()`, `url_for()`, and `run()` with a synthetic `sys.argv`. Do NOT yet register any handlers — just test the dispatch mechanism in isolation.

**Why fifth:** Router is structurally independent of handlers. Writing it before extracting handlers means you have a tested dispatch mechanism ready. Extracting handlers one at a time into a broken router is painful — test the router first.

**Dependency:** No handler deps. Needs conftest.py.

### Step 6: Extract handler modules (browse, search, playback, actions)

**What:** Move action-decorated functions from main.py into `browse.py`, `search.py`, `playback.py`, `actions.py`. Replace `@plugin.action()` with `@route("action_name")`. Replace `plugin.get_url()` calls with `url_for()`. Replace walk_* generators and get_entry_* formatters: walk_* stay close to their handler module; get_entry_* move to `listings.py`.

**Why sixth:** Handlers depend on everything already extracted (settings, models, client, cache, router). Extract them last so they can be written cleanly against stable APIs. Extract one handler at a time, running the full test suite after each to catch regressions.

**Dependency:** Steps 2-5 all complete.

### Step 7: Extract `scrobbler.py` + fix service.py

**What:** Move the monitor/scrobble logic into `resources/lib/scrobbler.py` as a `Scrobbler(xbmc.Monitor)` class. `service.py` becomes a 15-line bootstrap. Fix URL parsing in scrobbler to use `urllib.parse` instead of regex. Write unit tests for scrobble-at-50% logic with mock xbmc.Player.

**Why last:** Service is lowest-priority for test coverage. The scrobbler accesses `xbmc.Monitor` and player info which require more mocking setup. Extracting it last avoids the mocking complexity until the higher-value modules are done.

**Dependency:** Needs ApiClient (Step 3).

### Build Order Summary

```
Step 1: test scaffold + crash fixes          (unblocks all)
Step 2: settings.py + models.py              (unblocks api, handlers)
Step 3: api/client.py + libsonic fixes       (unblocks handlers)
Step 4: cache.py                             (unblocks browse.py)
Step 5: router.py                            (unblocks handler extraction)
Step 6: browse.py, search.py,                (main refactor work)
        playback.py, actions.py, listings.py
Step 7: scrobbler.py + service.py cleanup    (background service)
```

## Anti-Patterns

### Anti-Pattern 1: Global `connection = None` Singleton

**What people do:** Declare `connection = None` at module scope in main.py, use `global connection` inside a `get_connection()` function.

**Why it's wrong:** The Kodi plugin process is spawned fresh on each URL invocation (each navigation click). The global is reset to `None` every invocation. The singleton gives false confidence of reuse that doesn't exist across navigations. It also makes tests impossible without `import main; main.connection = mock_conn`.

**Do this instead:** Instantiate `ApiClient(settings)` at the top of each handler dispatch. The connection cost is negligible (no persistent TCP connection in HTTP/1.1 REST). Tests inject mock clients via the constructor.

### Anti-Pattern 2: Routing by `eval()` or `getattr()` on Action Name

**What people do:** The Spotify addon uses `eval("self." + action)()` to dispatch. Some older addons use `getattr(module, action)()`.

**Why it's wrong:** Arbitrary code execution from URL parameters. A crafted plugin URL can call any method. Also untestable and breaks static analysis.

**Do this instead:** Explicit `dict[str, Callable]` routing table populated by the `@route()` decorator. Unknown actions raise a `ValueError` — visible, not silently ignored.

### Anti-Pattern 3: URL Building via f-strings or String Concatenation

**What people do:** `url = f"plugin://plugin.audio.subsonic/?action=list_albums&page={page}"`. Breaks if any value contains `&`, `=`, or non-ASCII.

**Why it's wrong:** URL injection. Also fragile when parameters are reordered (see service.py regex bug).

**Do this instead:** `url_for("list_albums", page=page)` which uses `urllib.parse.urlencode`. All consumers produce well-formed URLs; the scrobbler reads them with `urllib.parse.parse_qs`.

### Anti-Pattern 4: Bare `except:` Clauses

**What people do:** `except:` or `except Exception: pass` around entire action handlers.

**Why it's wrong:** Swallows real bugs. The 8 `# TO FIX` comments in main.py exist because these handlers silently fail instead of surfacing errors.

**Do this instead:** Catch specific exceptions (`ConnectionError`, `libsonic.errors.SonicError`, `KeyError`) and log with `xbmc.log(traceback.format_exc(), xbmc.LOGERROR)`. Let unexpected exceptions propagate so Kodi shows a real error.

### Anti-Pattern 5: Mixing Kodi API Calls into Business Logic

**What people do:** Call `xbmcplugin.addDirectoryItem()` inside the same function that fetches and transforms API data.

**Why it's wrong:** Makes the fetch/transform logic untestable (needs live Kodi). The Spotify plugin's `PluginContent` class is 1000+ lines because it conflates API calls with UI rendering.

**Do this instead:** Handler functions have three distinct phases: (1) fetch via `ApiClient` → gets models, (2) transform via `listings.py` → gets ListItem dicts, (3) render via `xbmcplugin.*`. Only phase 3 is untestable outside Kodi. Phases 1 and 2 are fully testable.

## Integration Points

### External Services

| Service | Integration Pattern | Notes |
|---------|---------------------|-------|
| Subsonic/Navidrome server | HTTP REST via libsonic `Connection` | All calls go through `api/client.py`, never direct |
| OpenSubsonic extensions | `getOpenSubsonicExtensions()` probe on first connect | Cache result in session; graceful fallback |
| Kodi art cache | Return `coverArt` URLs with `size=` param in thumbnail fields | Kodi caches these; don't roll your own art cache |

### Internal Boundaries

| Boundary | Communication | Notes |
|----------|---------------|-------|
| `main.py` → `router.py` | Direct import, `router.run()` call | One line in main.py |
| `service.py` → `scrobbler.py` | Direct import, `Scrobbler(client).run()` | Service creates ApiClient, passes to Scrobbler |
| Handler → `api/client.py` | Direct function calls → returns TypedDicts | No globals; client instantiated in handler |
| Handler → `cache.py` | Module-level `get()`/`set()` | Cache is effectively a process-scoped singleton (acceptable — it's intentional) |
| Plugin → Service IPC | `xbmcgui.Window(10000)` properties | Only needed if plugin needs to signal service; v1 scrobbler doesn't require this |
| `listings.py` → models | TypedDicts consumed, ListItem dicts produced | No xbmcplugin imports in handler modules |

## Real-World References

### Active Reference Projects

- **plugin.audio.tidal2** — https://github.com/arnesongit/plugin.audio.tidal2
  Uses `script.module.routing` (tamland's router), `service.py` background service, `resources/lib/tidal2/` package layout. Best structural reference for a streaming music addon.

- **kodi-plugin-routing** — https://github.com/tamland/kodi-plugin-routing
  The `lib/routing.py` (120 lines) is the exact router pattern to internalize. `@plugin.route()`, `url_for()`, `plugin.run()`. Dormant but stable; copy the pattern, don't take the dependency.

- **plugin.audio.spotify** — https://github.com/kodi-community-addons/plugin.audio.spotify
  Shows `SimpleCache` usage, `main_service.py` isolation, and `xbmcgui.Window(10000)` IPC. Anti-reference for routing (uses `eval()`) and for monolithic classes — don't copy that part.

- **Kodistubs** — https://github.com/romanvm/Kodistubs
  Install via `pip install git+https://github.com/romanvm/Kodistubs.git` in test venv. Provides stub `xbmc`, `xbmcaddon`, `xbmcgui`, `xbmcplugin`, `xbmcvfs` — the foundation for the `tests/conftest.py` `sys.modules` patch.

- **OpenSubsonic API docs** — https://opensubsonic.netlify.app/docs/
  Ground truth for `getOpenSubsonicExtensions`, `apiKeyAuthentication` extension, and `search3`. Use when deciding which libsonic methods to update.

- **py-opensonic (khers)** — https://github.com/khers/py-opensonic
  Modern Python Subsonic client (async, unasync). Study its auth implementation for salt+token and apikey patterns before rewriting libsonic's auth section.

### Testing Pattern (conftest.py)

The standard Kodi unit-test setup injects stub modules before any addon code is imported:

```python
# tests/conftest.py
import sys
from unittest.mock import MagicMock

# Inject stubs before importing any addon code
for module_name in ["xbmc", "xbmcaddon", "xbmcgui", "xbmcplugin", "xbmcvfs"]:
    sys.modules[module_name] = MagicMock()

# Or install Kodistubs and let them be importable:
# pip install git+https://github.com/romanvm/Kodistubs.git
# Then just ensure the stubs are on PYTHONPATH
```

With `MagicMock()` stubs, every `xbmc.log()` call silently succeeds, every `xbmcaddon.Addon()` returns a mock, and every `xbmcplugin.addDirectoryItem()` call is recorded for assertion. Pure business logic (auth token generation, model parsing, URL building, cache TTL) runs fully outside Kodi.

## Sources

- Kodi Audio-Video Add-on Tutorial: https://kodi.wiki/view/Audio-video_add-on_tutorial (MEDIUM confidence — official but sparse)
- tamland kodi-plugin-routing implementation: https://github.com/tamland/kodi-plugin-routing (HIGH — source-verified)
- plugin.audio.tidal2 entry point pattern: https://github.com/arnesongit/plugin.audio.tidal2 (HIGH — source-verified)
- plugin.audio.spotify service isolation: https://github.com/kodi-community-addons/plugin.audio.spotify (HIGH — source-verified)
- Kodistubs documentation: https://romanvm.github.io/Kodistubs/ (HIGH — official project docs)
- OpenSubsonic apiKeyAuthentication: https://opensubsonic.netlify.app/docs/extensions/apikeyauth/ (HIGH — official spec)
- script.module.simplecache (SQLite dual-layer cache pattern): https://github.com/kodi-community-addons/script.module.simplecache (HIGH — source-verified)
- Kodi addon testing patterns: https://blog.misharov.pro/2021-03-03/kodi-addon-testing (MEDIUM — community, not official)

---
*Architecture research for: Kodi audio addon (Subsonic client) refactor*
*Researched: 2026-04-28*
