# Codebase Structure

**Analysis Date:** 2026-04-28

## Directory Layout

```
plugin.audio.subsonic/
├── addon.xml                    # Kodi plugin manifest, defines entry points
├── main.py                      # Plugin source: action handlers, routing, UI logic
├── service.py                   # Background service: playback monitoring, scrobbling
├── icon.png                     # Addon icon for Kodi UI
├── fanart.jpg                   # Addon fanart background
├── LICENSE                      # MIT license
├── README.md                    # User-facing documentation
├── CHANGELOG.md                 # Version history
├── lib/                         # Third-party libraries bundled with addon
│   ├── simpleplugin/           # Micro-framework for Kodi plugin routing
│   │   ├── __init__.py         # Exports simpleplugin module
│   │   └── simpleplugin.py     # Plugin class, action decorators, storage, addon wrappers
│   └── libsonic/               # Subsonic REST API client library
│       ├── __init__.py         # Exports Connection class
│       ├── connection.py       # HTTP client, URL building, API methods, XML parsing
│       └── errors.py           # Custom exception classes
├── resources/                   # Localizable content and settings
│   ├── settings.xml            # Addon settings UI definition
│   └── language/               # Localization files
│       ├── English/
│       │   └── strings.po      # English language strings (menu labels, messages)
│       ├── French/
│       │   └── strings.po      # French language strings
│       └── German/
│           └── strings.po      # German language strings
└── .planning/                   # Documentation for code mapping
    └── codebase/               # Architecture and structure documents
```

## Directory Purposes

**plugin.audio.subsonic/ (root):**
- Purpose: Kodi addon root - contains manifest, entry point scripts, bundled libraries
- Contains: Python scripts (main.py, service.py), addon metadata (addon.xml), assets (icon, fanart)
- Key files: `addon.xml` (manifest), `main.py` (plugin entry), `service.py` (background service)

**lib/simpleplugin/:**
- Purpose: Micro-framework for building Kodi plugins with action-based routing
- Contains: Plugin class with @action decorator, Addon/Settings wrappers, Storage backends, URL parameter parsing
- Key files: `simpleplugin.py` (1355 lines) - defines Plugin, Addon, Storage, Params classes
- Pattern: Decorator-based action handlers - decorate functions with @plugin.action() to route URLs

**lib/libsonic/:**
- Purpose: Python client library for Subsonic REST API (py-sonic v0.7.9)
- Contains: HTTP connection management, API method wrappers, response parsing
- Key files: `connection.py` (2983 lines) - Connection class with 100+ API methods
- API Methods: ping(), getArtist(), getAlbum(), getAlbumList2(), stream(), scrobble(), star(), download(), etc.

**resources/settings.xml:**
- Purpose: Define addon settings UI that appears in Kodi addon settings dialog
- Contains: Two categories (General, Advanced) with 14 settings
- Settings control: Server URL, auth, pagination sizes, transcode settings, API version, cache time, scrobbling

**resources/language/:**
- Purpose: Localization strings for UI labels, menus, messages
- Contains: strings.po files with message IDs and translations
- Used by: Addon().get_localized_string(30XXX) calls in main.py to fetch localized labels

## Key File Locations

**Entry Points:**
- `main.py`: Plugin source entry point (URL routing, action handlers)
- `service.py`: Background service entry point (playback monitoring)

**Configuration:**
- `addon.xml`: Kodi manifest defining extension points, metadata, dependencies (Kodi 3.0.0+)
- `resources/settings.xml`: Addon settings UI definition for user preferences

**Core Logic:**
- `main.py`: 1562 lines
  - Lines 1-34: Imports, global state (connection, cachetime, local_starred)
  - Lines 35-66: get_connection() singleton
  - Lines 68-644: Action handlers (@plugin.action decorated)
    - root() - main menu
    - menu_albums(), menu_tracks() - album/track submenu
    - browse_folders(), browse_indexes(), list_directory() - folder browsing
    - browse_library() - library view (ID3)
    - list_albums(), list_tracks(), list_playlists() - paginated listings
    - search(), search_album() - search with dialog input
    - play_track() - URL resolution for playback
    - star_item() - starring/unstarring
    - download_item() - download management
  - Lines 645-735: Entry formatters (get_entry_* functions)
  - Lines 768-1099: Label/format helpers and pagination
  - Lines 1036-1067: Starred items caching
  - Lines 1100-1278: Context menu actions and download logic
  - Lines 1279-1401: Listing rendering (create_listing, add_directory_items, resolve_url)
  - Lines 1403-1556: Walk generators (yield-based API iterators)
  - Lines 1557-1562: Plugin main entry

**Library Code:**
- `lib/simpleplugin/simpleplugin.py`: 1355 lines
  - Params class: URL parameter dict with property access
  - Storage/MemStorage: Persistent and memory-based key-value storage
  - Addon class: Wrapper for xbmcaddon with settings/storage access
  - Plugin class: Main routing framework with @action decorators
  - RoutedPlugin class: URL pattern-based routing (@route decorator)
  - Helper functions: translate_path(), log_exception context manager

- `lib/libsonic/connection.py`: 2983 lines
  - Connection.__init__(): Authenticate and build API client
  - Connection.ping(): Test server connectivity
  - Connection.getAlbumList2(ltype, size, offset, ...): List albums by type
  - Connection.getAlbum(albumId): Get album details with tracks
  - Connection.getArtist(artistId): Get artist with albums
  - Connection.getStarred(): Get user-starred items
  - Connection.streamUrl(sid, maxBitRate, tformat): Generate streaming URL
  - Connection.scrobble(id): Submit play to server
  - Connection.star/unstar(): Mark items as favorites
  - Connection.download(id): Get file stream for download
  - Connection.getCoverArtUrl(coverArt): Get cover art URL
  - Plus 100+ more API methods mapping Subsonic REST endpoints

**Testing:**
- None detected (no test directory or *.test.py files)

## Naming Conventions

**Files:**
- Entry points: lowercase (main.py, service.py, addon.xml)
- Libraries: lowercase with underscores (simpleplugin.py, connection.py)
- Addon metadata: XML (addon.xml, settings.xml)
- Media assets: lowercase with extension (icon.png, fanart.jpg)

**Functions:**
- Action handlers: lowercase with underscores (root, menu_albums, list_tracks, play_track, star_item, download_item)
- Walk generators: walk_* prefix (walk_artists, walk_albums, walk_album, walk_tracks_starred, walk_directory, walk_playlists)
- Entry formatters: get_entry_* prefix (get_entry_artist, get_entry_album, get_entry_track, get_entry_playlist)
- Label/format: get_*_label, convert_* prefix (get_entry_track_label, convert_date_from_iso8601)
- Cache management: *_cache_* (cache_refresh, stars_cache_get)
- Context menu: context_action_* (context_action_star, context_action_download)
- Helper checks: can_* (can_star, can_download)
- Helpers: helper_* or descriptive (get_connection, popup, create_listing, create_list_item, resolve_url, _set_resolved_url)

**Variables:**
- Module-level globals: connection, cachetime, local_starred, scrobbled (service.py)
- Parameters dict: params (ubiquitous in handlers)
- Response items: item, items (from API responses)
- IDs: id, artist_id, album_id, playlist_id, folder_id, menu_id, track_id (context-specific)
- Settings: merge_artist, scrobbleEnabled, download_folder (from Addon().get_setting())
- Lists: listing, ids_list (UI building, batch operations)
- Metadata dicts: entry, album, artist, track, song, genre, playlist (API response dicts)

**Types:**
- Named tuples: ListContext, PlayContext (line 33-34 main.py)
- Storage: plugin.get_storage() returns Storage context manager with dict-like interface
- Generators: Functions starting with walk_* use Python generators (yield)

## Where to Add New Code

**New Feature (browsing/listing):**
- Primary code: `main.py` add new @plugin.action() handler
- Data fetching: Call appropriate libsonic.Connection method or add to connection.py
- Data transformation: Create walk_* generator (if needed) and get_entry_* formatter
- UI building: Use existing create_listing() and add_directory_items() pattern
- Settings: Add to resources/settings.xml if configuration needed

**New API Method (for Subsonic endpoint):**
- Implementation: `lib/libsonic/connection.py` add method to Connection class
- Pattern: Build URL with self._get_path(), parse response, return dict
- Usage: Call from main.py action handlers via connection.methodName()

**New Component/Module:**
- Reusable helpers: Add to main.py if small, or create `lib/helpers.py` if large
- UI widgets: Existing patterns (popups, dialogs) use xbmcgui directly
- Storage/caching: Use plugin.get_storage() with namedtuple or dict keys

**Utilities:**
- Shared helpers: main.py (pop out to lib/helpers.py if > 500 lines)
- URL/parameter handling: simpleplugin.Plugin.get_url() and params parsing
- Caching: plugin.get_storage() (persistent pickled storage) or in-memory dicts

## Special Directories

**lib/:**
- Purpose: Third-party or local libraries bundled with addon
- Generated: No (manually vendored libraries)
- Committed: Yes (simpleplugin and libsonic are committed to repo)
- Access: sys.path.append() in main.py and service.py at runtime

**resources/:**
- Purpose: Localization and settings metadata
- Generated: No (hand-written XML and PO files)
- Committed: Yes (user-facing content)
- Structure: settings.xml (root), language/<locale>/strings.po (per-language translations)

**resources/language/:**
- Purpose: Localized strings for UI rendering
- Files: strings.po per language (English, French, German currently)
- Format: PO (Portable Object) format with message IDs (30XXX) and translations
- Usage: Addon().get_localized_string(30024) fetches localized "Albums (Frequent)"

---

*Structure analysis: 2026-04-28*
