# Codebase Concerns

**Analysis Date:** 2026-04-28

## Monolithic Main File

**Large procedural codebase:**
- Issue: `main.py` is 1,561 lines, containing 55 functions mixed together without clear separation of concerns. Makes navigation, testing, and refactoring difficult.
- Files: `main.py`
- Impact: Hard to maintain, difficult to test individual features, increases bug surface area
- Fix approach: Refactor into separate modules: actions module, UI helpers module, data access module. Start with extracting walker functions and entry builders.

## Broad Exception Handling

**Bare except clauses throughout codebase:**
- Issue: Multiple bare `except:` statements that catch all exceptions and silently pass or log minimally (`main.py:59, 407, 472, 708, 1244` and `service.py:20, 48`). Masks unexpected errors and makes debugging difficult.
- Files: `main.py:59`, `main.py:407`, `main.py:472`, `main.py:708`, `main.py:1244`, `service.py:20`, `service.py:48`
- Impact: Silent failures in connection setup, JSON parsing, and downloads. No stack traces recorded. User sees "Connection error" popup without diagnostic info.
- Fix approach: Replace bare `except:` with specific exception types (`ConnectionError`, `json.JSONDecodeError`, `KeyError`, etc.). Log full traceback with `plugin.log_exception()`. Only catch exceptions you can actually handle.

## Missing sys Import in service.py

**NameError at runtime:**
- Issue: `service.py` uses `sys.path.append()` on line 7 but does not import `sys`. Will raise `NameError: name 'sys' is not defined` when the service starts.
- Files: `service.py:1-7`
- Impact: Service scrobbling feature fails to load entirely
- Fix approach: Add `import sys` at top of `service.py`

## Python 2 Compatibility Code in Python 3-only Addon

**Dead code from Python 2 era:**
- Issue: `simpleplugin.py:12-13` defines `basestring = str` and `long = int` for Python 2 compatibility. Addon requires `xbmc.python` 3.0.0 minimum (`addon.xml:4`), so this code is unnecessary overhead.
- Files: `lib/simpleplugin/simpleplugin.py:12-13`
- Impact: Slight memory/load overhead; confusion about actual Python version support
- Fix approach: Remove Python 2 compatibility shims from simpleplugin. Update `getargspec = inspect.getfullargspec` comment to note it's Python 3 only.

## Vendored libsonic Library Issues

**Large, stale third-party code:**
- Issue: `lib/libsonic/connection.py` is 2,983 lines of vendored code. Embedded in addon repo, no version tracking, no upstream updates possible.
- Files: `lib/libsonic/connection.py`, `lib/libsonic/errors.py`
- Impact: Bug fixes and security patches in libsonic upstream will not reach this addon. Increases maintenance burden.
- Fix approach: Consider extracting libsonic as a separate package dependency or publishing a maintained fork with clear version tracking.

**urllib2 reference in Python 3 code:**
- Issue: `lib/libsonic/connection.py:2848, 2875` use `urllib2.Request()`, which doesn't exist in Python 3 (was merged into `urllib.request`). These lines are in conditional code paths (`if self._useGET` in `_getRequestWithList` and `_getRequestWithLists`).
- Files: `lib/libsonic/connection.py:2848`, `lib/libsonic/connection.py:2875`
- Impact: Using GET requests with multi-value parameters (rare) will crash with `NameError`
- Fix approach: Replace `urllib2.Request` with `urllib.request.Request` in both locations.

**Inconsistent SSL context handling:**
- Issue: `lib/libsonic/connection.py:2779-2781` checks `sys.version_info[:3] >= (2, 7, 9)`. Python 2 support ended 2020; this check is dead code. Code assumes it may run on Python 2, but addon requires Python 3.0+.
- Files: `lib/libsonic/connection.py:2779-2781`
- Impact: Confusing code path, dead branch, false sense of compatibility
- Fix approach: Remove version check; always use `ssl._create_unverified_context()` when `insecure=True`.

## Insecure SSL by Default (When User Enables It)

**Certificate verification bypass available:**
- Issue: `insecure` setting in addon allows user to disable SSL certificate verification (set via `Addon().get_setting('insecure')`). When enabled, `lib/libsonic/connection.py:2780-2781` uses `ssl._create_unverified_context()`, which accepts self-signed and expired certificates.
- Files: `main.py:54`, `service.py:43`, `lib/libsonic/connection.py:911-913`, `960-962`, `2779-2781`
- Impact: User credentials sent over HTTPS to untrusted/spoofed servers if "insecure" mode is enabled. No MITM protection.
- Current mitigation: Feature is opt-in (disabled by default). Documentation should warn against enabling for untrusted networks.
- Recommendations: (1) Add warning dialog when user enables insecure mode. (2) Log insecure connections clearly. (3) Consider removing `insecure` option entirely for better default-secure posture.

## Credential Storage and Transmission

**Plaintext password in addon settings:**
- Issue: Username and password are stored in Kodi's addon settings (retrieved via `Addon().get_setting('username', convert=False)` and `Addon().get_setting('password', convert=False)` in `main.py:50-51`, `service.py:39-40`). Kodi stores settings in plaintext XML (`~/.kodi/userdata/addon_data/plugin.audio.subsonic/settings.xml`).
- Files: `main.py:50-51`, `service.py:39-40`, `lib/libsonic/connection.py:170-171` (stored as `self._rawPass`)
- Impact: Credentials visible to any process that can read user's Kodi profile directory (same user account)
- Current mitigation: Credentials are only sent over HTTPS (when properly configured). legacyAuth option uses MD5 hashing (weak).
- Recommendations: (1) Document that addon settings are not encrypted. (2) Advise users to use strong Subsonic server credentials. (3) Consider storing credentials in Kodi's credential manager if available.

**Legacy MD5-based authentication support:**
- Issue: `lib/libsonic/connection.py:2805-2809` implements pre-1.13.0 Subsonic API auth using `md5(password + salt).hexdigest()`. User can enable via `legacyauth` setting. MD5 is cryptographically broken.
- Files: `lib/libsonic/connection.py:2805-2809`, `main.py:55`, `service.py:44`
- Impact: If user enables legacyAuth on old Subsonic servers, password is hashed with MD5 (vulnerable to collision attacks)
- Current mitigation: Modern API (1.13.0+) uses token-based auth: `md5(password + random_salt).hexdigest()`. Default is modern auth.
- Recommendations: Deprecate legacyAuth support. Log warning if user enables it. Set default to `legacyauth=False` everywhere.

## Global State and Singleton Pattern

**Global connection object:**
- Issue: `main.py:29` and `service.py:16` declare `connection = None` at module level. Function `get_connection()` uses `global connection` to cache a single Connection instance (lines `main.py:42`, `service.py:31`). If connection dies or settings change, cached connection is not refreshed.
- Files: `main.py:29, 42-66`, `service.py:16, 31-55`
- Impact: Settings changes (e.g., server URL, username) require addon restart to take effect. Connection errors may persist even after server recovers.
- Fix approach: Implement proper connection pooling or lazy re-initialization. Check connection health before use. Support connection parameter changes without global state.

**Global local_starred cache:**
- Issue: `main.py:32` declares `local_starred = set({})` at module level. Functions `cache_refresh()` and `stars_cache_get()` use `global local_starred` to maintain starred track IDs (`main.py:1037, 1065`). No thread safety.
- Files: `main.py:32, 1037, 1065`
- Impact: If cache is stale and another thread checks starred status, result is inconsistent. Kodi may call multiple plugin actions concurrently.
- Fix approach: Move to plugin storage (disk-backed, thread-safe). Use file locking for concurrent access.

## Input Validation Gaps

**Unvalidated search input:**
- Issue: `search()` and `search_album()` accept raw user input from `xbmcgui.Dialog().input()` and pass directly to `connection.search2(query=d)` (`main.py:597, 627`). No sanitization or length limit.
- Files: `main.py:582-609`, `main.py:613-643`
- Impact: Very long or special-character-heavy input could cause server timeouts or parsing errors. No visible feedback loop.
- Fix approach: Validate query length (e.g., max 256 chars). Catch timeout exceptions from search and show user-friendly error.

**No validation of page/offset parameters:**
- Issue: `list_albums()` and `list_tracks()` extract page number from params: `int(params.get('page',1)) - 1` (`main.py:415, 480`). No bounds checking.
- Files: `main.py:415`, `main.py:480`
- Impact: Negative page numbers, extremely large offsets, or invalid types passed via URL could cause server errors
- Fix approach: Add bounds checks: ensure page >= 1. Validate offset doesn't exceed total count.

## Undone Work and TODOs

**Incomplete features marked "TO FIX":**
- Issue: 8 TODO markers found in code indicating incomplete or questionable implementations:
  - `main.py:449` – pagination logic incomplete: `# if type(items) != type(True): TO FIX`
  - `main.py:502` – `#TO FIX` (no context)
  - `main.py:546` – pagination incomplete: `# if type(items) != type(True): TO FIX`
  - `main.py:670` – type coercion: `#TO FIX better statement ?`
  - `main.py:725-726` – cache refresh after star: `#TO FIX clear starred lists caches ?` and `#TO FIX refresh current list after star set ?`
  - `main.py:964-966` – date field confusion: `#TO FIX _DATE or _DATEADDED ?`
- Files: `main.py:449`, `main.py:502`, `main.py:546`, `main.py:670`, `main.py:725-726`, `main.py:964-966`
- Impact: Pagination may not detect end of list. Star/unstar does not refresh UI. Date fields may be wrong.
- Fix approach: Complete pagination detection. Implement list refresh after star action. Clarify date field selection.

## Silent Failures in Download

**Broad exception catch with minimal feedback:**
- Issue: `download_tracks()` function (`main.py:1160-1254`) wraps file download in bare `except:` at line 1244. Errors are logged but user only sees generic "Error while downloading track #X" popup.
- Files: `main.py:1244-1247`
- Impact: User doesn't know if failure was network error, disk full, permission error, or corrupt response
- Fix approach: Catch specific exceptions: `IOError` (disk), `urllib.error.URLError` (network), `json.JSONDecodeError` (bad response). Show detailed error messages.

## Performance Issues

**No caching of directory listings:**
- Issue: Every directory browse (`browse_folders()`, `browse_library()`, etc.) calls libsonic API directly. No local cache (except artist info, which has its own cache).
- Files: `main.py:245-302`, `main.py:305-342`, etc.
- Impact: Slow navigation on metered/high-latency connections. Subsonic server overhead.
- Fix approach: Add LRU cache for directory listings. Implement TTL-based cache (e.g., 5 min default, configurable).

**Inefficient walk_directory with recursion:**
- Issue: `walk_directory()` at `main.py:1447-1461` recursively merges artist directories when `merge_artist=True`. No depth limit or cycle detection.
- Files: `main.py:1447-1461`
- Impact: Malformed server response with circular references could cause infinite recursion and stack overflow.
- Fix approach: Add max depth limit. Track visited IDs to prevent cycles. Make recursion optional via flag.

**Cache refresh blocks on network:**
- Issue: `cache_refresh()` (`main.py:1036-1062`) fetches starred tracks from server every `cachetime` minutes (default from `Addon().get_setting('cachetime')`). Blocking call in main thread when cache expires.
- Files: `main.py:1036-1062`, `main.py:30`
- Impact: UI hangs if Subsonic server is slow or unreachable. User sees spinner for up to network timeout.
- Fix approach: Move cache refresh to background thread. Cache stale data on disk. Return immediately with stale cache while refresh happens async.

## Logging and Debugging

**Mixed logging patterns:**
- Issue: Code uses both `print()` (`main.py:789, 808`) and `xbmc.log()` (`main.py:1116`) and `plugin.log()` (throughout). No consistent log level strategy.
- Files: `main.py:789`, `main.py:808`, `main.py:1116`, and many `plugin.log()` calls
- Impact: Important messages may not reach user-accessible Kodi logs. Console output only visible if script run directly, not in Kodi context.
- Fix approach: Standardize on `plugin.log()` and `xbmc.log()` only. Remove all `print()` statements. Use log levels: DEBUG for verbose, INFO for important, ERROR for failures.

**Leftover debug statements:**
- Issue: `lib/libsonic/connection.py:162-163` has debug print: `print(len(self._hostname.split('/')))` and `xbmc.log("Got a folder %s"...)`. Unused.
- Files: `lib/libsonic/connection.py:162-163`
- Impact: Unnecessary logging overhead. Confuses log analysis.
- Fix approach: Remove.

## Test Coverage Gaps

**No test suite detected:**
- Issue: No `tests/`, `test_*.py`, or `*_test.py` files found. No unit tests, integration tests, or fixtures.
- Files: None exist
- Risk: Changes to walker functions, entry builders, or connection logic have no automated safety net. Bugs found only in manual testing or user reports.
- Priority: High – recommend adding unit tests for `walk_*` functions and `get_entry_*` builders.

## Fragile URL Parsing in service.py

**Regex parsing of plugin URL:**
- Issue: `service.py:84` extracts track ID from playback URL using regex: `pattern = re.compile(r'plugin:\/\/plugin\.audio\.subsonic\/\?action=play_track&id=(.*?)&')`. Assumes exact URL structure; fails if URL format changes or parameters are reordered.
- Files: `service.py:84-85`
- Impact: Scrobbling breaks if plugin URL format is changed. No error handling for unmatched pattern (IndexError caught generically at line 96).
- Fix approach: Use URL parsing library (`urllib.parse.urlparse`, `parse_qs`) instead of regex. Make robust to parameter reordering.

## Deprecated or Risky Kodi APIs

**Hardcoded Kodi version check:**
- Issue: `simpleplugin.py:70-77` checks `Kodi major_version < '19'` to decide between `xbmc.translatePath()` and `xbmcvfs.translatePath()`. Compares strings, not integers (could fail if version >= 20).
- Files: `lib/simpleplugin/simpleplugin.py:70-77`
- Impact: May use wrong path translation function in Kodi 20+. String comparison of versions is fragile.
- Fix approach: Parse version as integers: `int(major_version)` and compare numerically.

**View mode string assumption:**
- Issue: `main.py:1401` sets view mode using string ID: `xbmc.executebuiltin('Container.SetViewMode({0})'.format(context.view_mode))`. No validation that view_mode is an integer.
- Files: `main.py:1400-1401`
- Impact: Invalid view_mode string could crash with Kodi error. Addon doesn't enforce valid view modes.
- Fix approach: Validate view_mode is integer in view_mode setting. Fall back to default if invalid.

---

*Concerns audit: 2026-04-28*
