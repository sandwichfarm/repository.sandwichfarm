# Technology Stack

**Analysis Date:** 2026-04-28

## Languages

**Primary:**
- Python 3 - All addon logic in `main.py`, `service.py`, and library modules

**Secondary:**
- XML - Addon manifest and configuration (`addon.xml`, `resources/settings.xml`)

## Runtime

**Environment:**
- Kodi media center - Required host application

**Package Manager:**
- Python standard library only - No external dependencies beyond Kodi's bundled modules

## Frameworks

**Core:**
- Kodi Python API (xbmc, xbmcaddon, xbmcplugin, xbmcgui, xbmcvfs) - Provides plugin infrastructure and UI integration

**Audio/Media:**
- Kodi audio plugin interface - Provides music streaming and playback integration via `xbmc.python.pluginsource` extension point

**Service:**
- Kodi service module (`xbmc.service` extension) - Runs background scrobbling service in `service.py`

## Key Dependencies

**Internal:**
- `libsonic` (v0.7.9) - Subsonic API client library in `lib/libsonic/`
- `simpleplugin` - Kodi plugin framework in `lib/simpleplugin/`

**Standard Library:**
- `json` - JSON parsing and serialization
- `hashlib` - MD5 hashing (artist info caching)
- `datetime` - Date/time operations (ISO8601 conversion)
- `collections.abc` - Abstract base classes (MutableMapping)
- `shutil` - File operations (download functionality)
- `os`, `re` - Path and regex operations
- `urllib` - HTTP communication (handled by libsonic)
- `ssl`, `socket` - TLS/SSL handling in libsonic
- `time`, `random` - Cache timing and randomization

## Configuration

**Addon Manifest:**
- `addon.xml` - Version 3.0.2, requires Kodi Python 3.0.0+

**Settings:**
- `resources/settings.xml` - User-configurable settings including:
  - Server connection (URL, port, username, password)
  - API version (1.11.0 through 1.16.0)
  - Authentication options (legacy auth, insecure SSL)
  - Streaming preferences (bitrate, transcode format)
  - Download folder
  - Cache timing (1-3600 minutes)
  - Features (merge artist folders, scrobbling)

**Environment:**
- Settings stored in Kodi's addon configuration system
- No `.env` file or external configuration required

## Platform Requirements

**Development:**
- Python 3.x interpreter (Kodi 19+)
- Standard POSIX tools for editing (vim, nano, etc.)

**Kodi Requirements:**
- Kodi 18+ (major_version checks in code)
- Python 3.0.0+ addon support
- Audio plugin capable installation

**Production:**
- Kodi 18+ (Leia or later)
- Active Subsonic or Subsonic-compatible server
- Network connectivity to Subsonic server

## Build & Deployment

**No compilation needed** - Pure Python plugin runs in Kodi's interpreter

**Distribution:**
- Zip archive of addon folder as Kodi addon
- Published to Kodi community addon repository
- GitHub releases: https://github.com/warwickh/plugin.audio.subsonic

---

*Stack analysis: 2026-04-28*
