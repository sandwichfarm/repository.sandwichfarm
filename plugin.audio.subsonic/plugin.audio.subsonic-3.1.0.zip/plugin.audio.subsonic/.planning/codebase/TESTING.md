# Testing Patterns

**Analysis Date:** 2026-04-28

## Test Infrastructure

**Current State:**
- **No tests found** - Project contains no test files, fixtures, or test configuration
- No `tests/` directory exists
- No test runner configuration (pytest.ini, setup.cfg, tox.ini, pyproject.toml)
- No test CI/CD pipeline (no `.github/workflows/` directory)
- No test dependencies in any manifest file

**Finding:** This is a Kodi addon with no automated test coverage.

## Manual Testing Approach

Since this project relies on the Kodi media center runtime, automated testing is challenging:

**Kodi Addon Testing Constraints:**
- Requires a running Kodi instance to test plugin actions
- Depends on Kodi's plugin router (@plugin.action() decorator)
- Depends on external Subsonic server for data retrieval
- Heavy reliance on Kodi APIs (xbmc, xbmcgui, xbmcplugin, xbmcvfs, xbmcaddon)

**Current Testing Method:** Manual in-environment testing only
- Developers must install addon in Kodi and test UI interactions
- No automated verification of:
  - API response parsing
  - Listing generation
  - Download functionality
  - Scrobbling logic
  - Error handling paths

## Architecture Patterns (Testable Components)

**Separable Logic:**
The codebase has some components that could be unit tested in isolation:

**1. Data Transformation Functions (Currently Untested):**
- `get_entry_track()` - transforms Subsonic track dict to Kodi ListItem dict
- `get_entry_album()` - transforms album dict
- `get_entry_artist()` - transforms artist dict
- `get_entry_playlist()` - transforms playlist dict
- Location: `main.py` lines 768-927
- Could be tested with mock item dicts

**2. Generator Functions (Currently Untested):**
- `walk_folders()`, `walk_artists()`, `walk_albums()`, `walk_tracks_random()`, etc.
- Location: `main.py` lines 1403-1555
- Pattern: Extract data from Subsonic API response dict, iterate and yield items
- Could be tested with mocked API responses

**3. Validation Functions (Currently Untested):**
- `is_starred()` - checks if track ID in starred cache
- `can_star()`, `can_download()` - check capability flags
- Location: `main.py` lines 929-1159
- Could be tested with simple dict/set fixtures

**4. Cache Functions (Currently Untested):**
- `cache_refresh()` - refreshes starred track cache
- `stars_cache_get()` - retrieves cached starred tracks
- Location: `main.py` lines 1036-1067
- Depend on plugin.get_storage() which requires Kodi

**5. Helper Functions (Currently Untested):**
- `convert_date_from_iso8601()` - date parsing
- Location: `main.py` lines 1091-1098
- Pure function, easy to test

## Code Structure for Testing

**How Action Handlers Are Routed:**
```python
@plugin.action()
def root(params):
    connection = get_connection()
    if connection==False:
        return
    listing = []
    # ... build listing ...
    add_directory_items(create_listing(listing, ...))
```

**Testing Barrier:** The @plugin.action() decorator and add_directory_items() call make isolated testing impossible without:
- Mocking the plugin instance
- Mocking Kodi's xbmcplugin module
- Mocking the get_connection() global

## Connection/Integration Testing Limitations

**External Dependencies:**
- Subsonic server (required for all integration tests)
- Kodi instance (required for plugin testing)
- No test Subsonic instance or mock server defined

**Current API Usage Pattern (lines 41-66):**
```python
def get_connection():
    global connection
    if connection==None:
        connected = False
        try:
            connection = libsonic.Connection(
                baseUrl=Addon().get_setting('subsonic_url'),
                username=Addon().get_setting('username', convert=False),
                password=Addon().get_setting('password', convert=False),
                port=Addon().get_setting('port'),
                apiVersion=Addon().get_setting('apiversion'),
                insecure=Addon().get_setting('insecure'),
                legacyAuth=Addon().get_setting('legacyauth'),
                useGET=Addon().get_setting('useget'),
            )
            connected = connection.ping()
        except:
            pass
        if connected==False:
            popup('Connection error')
            return False
    return connection
```

**Issues for Testing:**
- Bare `except:` catches all exceptions, making error paths untestable
- No way to mock libsonic.Connection without modifying code
- Settings come from Addon() which requires Kodi runtime
- Connection cached globally, making test isolation impossible

## Dependencies for Hypothetical Test Suite

**If tests were to be added:**

```bash
# Unit test runner
pytest >= 7.0

# Mocking Kodi APIs
pytest-mock
unittest.mock

# Mocking Subsonic responses
responses  # or similar HTTP mocking

# Coverage analysis (currently not tracked)
pytest-cov
```

**No test configuration file exists**, so this is aspirational.

## Service Module Testing

**File:** `service.py` (lines 1-106)

**What It Does:**
- Background scrobbling service for Kodi
- Runs in infinite loop checking if media is playing
- Extracts track ID from player URI using regex
- Calls `scrobble_track()` when track reaches 50% progress

**Testable Unit:** `scrobble_track()` function (lines 57-69)
```python
def scrobble_track(track_id):
    connection = get_connection()
    if connection==False:
        return False
    res = connection.scrobble(track_id)
    if res['status'] == 'ok':
        popup("Scrobbled track")
        return True
    else:
        popup("Scrobble failed")
        return False
```

**Testing Barrier:**
- Depends on global connection object
- Calls popup() which uses Kodi API
- No way to inject mock connection

## Missing Test Coverage Areas

**High Priority (Core Features):**
1. **Connection handling** - get_connection() error paths
2. **Playlist/album listing** - walk_* generator functions with edge cases
3. **Data transformation** - get_entry_* functions handling missing/malformed data
4. **Star/download actions** - context menu handlers

**Medium Priority:**
5. **Search functionality** - search() and search_album() user input handling
6. **Caching logic** - cache_refresh() expiration logic
7. **Date parsing** - convert_date_from_iso8601() edge cases

**Low Priority:**
8. **Download functionality** - download_tracks(), download_album() (requires filesystem)
9. **Scrobbling service** - service.py loop (requires Kodi runtime)

## Obstacles to Testing

**Language/Framework Constraints:**
1. **Kodi Addon Framework** - Requires xbmc/xbmcgui/xbmcplugin runtime
2. **No Dependency Injection** - Functions depend on global connection and addon settings
3. **Bare Exception Handling** - No way to test error paths with bare `except:` clauses
4. **External Service Dependency** - All meaningful tests require running Subsonic server
5. **No Mocking Infrastructure** - Code not written with testability in mind

**Recommended Fixes (Out of Scope):**
- Refactor get_connection() to be injectable or testable
- Replace bare `except:` with specific exception types
- Add unit tests for pure functions (convert_date_from_iso8601, validation functions)
- Add integration tests with mock Subsonic responses
- Use pytest + pytest-mock if tests are added

---

*Testing analysis: 2026-04-28*
