# External Integrations

**Analysis Date:** 2026-04-28

## APIs & External Services

**Subsonic REST API:**
- Primary music server API for streaming and library management
  - SDK/Client: Custom `libsonic` wrapper (in `lib/libsonic/connection.py`)
  - Auth: HTTP Basic Auth + MD5 digest (username/password from settings)
  - Version support: API 1.11.0 - 1.16.0 (configurable)
  - Connection: `libsonic.Connection()` instantiated in `get_connection()` at `main.py:41` and `service.py:30`

## Data Storage

**Databases:**
- None - Remote only (Subsonic server is authoritative)

**File Storage:**
- Local filesystem only
  - Download folder: User-configurable path for track downloads (`resources/settings.xml:14`)
  - Cache: Kodi's built-in storage API via `plugin.get_storage()` at `main.py:794, 1040, 1064`
  - Temporary: Scrobble state and artist info cached in memory

**Caching:**
- Kodi's plugin storage system (local cache files in Kodi config)
- `cache_refresh()` at `main.py:1036` - Caches starred track IDs with configurable TTL (1-3600 minutes)
- `get_artist_info()` at `main.py:788` - MD5-hashed artist info cache with random expiry (1-111 hours)

## Authentication & Identity

**Auth Provider:**
- Custom (Subsonic server HTTP Basic Auth)
  - Implementation: Username/password combination
  - Options: Legacy auth (pre-1.13.0) or modern auth with salt/MD5
  - SSL: Support for self-signed certificates via `insecure` setting (`addon.xml:54`)
  - Credential storage: Kodi addon settings (encrypted by Kodi)

## Monitoring & Observability

**Error Tracking:**
- None - Errors logged to Kodi's log system only

**Logs:**
- Kodi logger (`xbmc.log()` calls throughout `main.py` and `service.py`)
- Debug level: Conditional debug output in connection (`service.py:90`, `main.py:273, 273`)
- Popup notifications for user-facing errors (`main.py:35-39`)

## CI/CD & Deployment

**Hosting:**
- GitHub: https://github.com/warwickh/plugin.audio.subsonic
- Kodi community addon repository

**CI Pipeline:**
- None detected in codebase (manual release process)

## Subsonic API Endpoints Used

**Core Library Operations:**
- `ping.view` - Connection test (`connection.py:233`)
- `getMusicFolders.view` - List music folders (`connection.py:326`, `main.py:1440`)
- `getIndexes.view` - Get artist index (`connection.py:389`, `main.py:1403`)
- `getMusicDirectory.view` - Get directory contents (`connection.py:431`, `main.py:1451`)
- `getArtists.view` - Get all artists (ID3 tags) (`connection.py:1730`, `main.py:1475`)
- `getArtist.view` - Get albums by artist (`connection.py:1760`, `main.py:1463`)
- `getAlbumList.view`, `getAlbumList2.view` - Get albums by type (newest, recent, frequent, random) (`connection.py:1277, 1332`, `main.py:1500`)
- `getAlbum.view` - Get album details and tracks (`connection.py:1805`, `main.py:1522`, `main.py:1264`)
- `getSong.view` - Get individual track details (`connection.py:1859`, `main.py:1206`)

**Search Operations:**
- `search2.view` - Multi-type search (songs, albums, artists) (`connection.py:527`, `main.py:597`)

**Playlist Operations:**
- `getPlaylists.view` - List user playlists (`connection.py:668`, `main.py:1421`)
- `getPlaylist.view` - Get playlist contents (`connection.py:700`, `main.py:1428`)

**Streaming & Download:**
- `stream.view` - Stream audio with optional transcoding (`connection.py:814`)
- `streamUrl()` - Get streaming URL with bitrate/format control (`connection.py:864`, `main.py:658`)
- `download.view` - Download track file (`connection.py:794`, `main.py:1231`)

**Favorites/Starring:**
- `getStarred.view` - Get starred songs (file-based) (`connection.py:1959`, `main.py:1546`)
- `getStarred2.view` - Get starred songs (ID3-based) (`connection.py:2015`)
- `star.view` - Mark songs/albums/artists as starred (`connection.py:2104`, `main.py:701`)
- `unstar.view` - Remove star from songs/albums/artists (`connection.py:2139`, `main.py:701`)

**Metadata & Info:**
- `getCoverArt.view` - Get cover art image (`connection.py:917`)
- `getCoverArtUrl()` - Get cover art URL (`connection.py:940`, `main.py:769, 813, 843, 885`)
- `getGenres.view` - Get genre list (`connection.py:2175`, `main.py:1488`)
- `getRandomSongs.view` - Get random tracks (`connection.py:1389`, `main.py:1534`)
- `getArtistInfo2.view` - Get artist biography/images (`connection.py:2507`, `main.py:802`)

**Playback Tracking:**
- `scrobble.view` - Submit scrobble (play count/timestamp) (`connection.py:966`, `service.py:62`)

**License/Status:**
- `getLicense.view` - Get server license info (`connection.py:256`)
- `getScanStatus.view` - Get media scan status (`connection.py:280`)

## Authentication Details

**libsonic Connection Parameters:**
- `baseUrl` - Subsonic server URL from `resources/settings.xml:6`
- `username` - From `resources/settings.xml:8`
- `password` - From `resources/settings.xml:9` (hidden type)
- `port` - From `resources/settings.xml:7` (default 80)
- `apiVersion` - From `resources/settings.xml:23` (default 1.15.0)
- `insecure` - SSL cert verification bypass (`resources/settings.xml:24`)
- `legacyAuth` - Pre-1.13.0 auth method (`resources/settings.xml:26`)
- `useGET` - HTTP verb selection (`resources/settings.xml:25`)

**Security Notes:**
- Passwords stored in Kodi's encrypted addon settings
- Self-signed certificate support via `insecure` flag
- MD5 challenge-response auth (legacy) or salt-based (modern)
- Connection test via `ping()` before allowing API calls (`main.py:41-66`)

## Webhooks & Callbacks

**Incoming:**
- None

**Outgoing:**
- Scrobbling callback only (Last.fm integration on Subsonic server side)

---

*Integration audit: 2026-04-28*
