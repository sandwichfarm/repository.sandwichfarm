# Architecture

**Analysis Date:** 2026-04-28

## Pattern Overview

**Overall:** Kodi Audio Plugin using MVC-like pattern with Simpleplugin routing framework

**Key Characteristics:**
- Simpleplugin micro-framework handles URL routing and plugin lifecycle
- Libsonic library abstracts Subsonic REST API communication
- Global connection singleton manages server communication
- Walk generators fetch server data incrementally
- Entry formatters transform raw API responses into Kodi ListItem dicts

## Layers

**Kodi Plugin Layer:**
- Purpose: Integrate with Kodi media center via plugin.audio extension points
- Location: `main.py` (plugin source), `service.py` (background service)
- Contains: Entry point handlers, URL routing decorators
- Depends on: simpleplugin.Plugin, Kodi xbmc/xbmcplugin APIs
- Used by: Kodi on addon activation/action

**Routing Layer (Simpleplugin):**
- Purpose: Route plugin URLs to handler functions, manage addon state
- Location: `lib/simpleplugin/simpleplugin.py`
- Contains: Plugin class with @action decorator, Addon settings/storage wrapper, Params dict parser
- Depends on: xbmcaddon, xbmcgui, xbmcvfs Kodi APIs
- Used by: main.py action handlers

**API Communication Layer (Libsonic):**
- Purpose: Abstract Subsonic REST API into Python method calls
- Location: `lib/libsonic/connection.py`
- Contains: Connection class building URLs, handling auth, parsing XML responses
- Depends on: urllib, http.client for HTTP; no external Subsonic SDK
- Used by: walk_* generator functions to fetch data

**Data Transformation Layer:**
- Purpose: Convert Subsonic API responses into Kodi UI dicts
- Location: `main.py` walk_* and get_entry_* functions
- Contains: Generators that walk API responses, entry formatters that build ListItem structures
- Depends on: libsonic for API access
- Used by: Action handlers to build UI listings

**UI Interaction Layer:**
- Purpose: Handle user navigation, starring, downloading, playback
- Location: `main.py` action-decorated functions (root, menu_albums, list_tracks, play_track, etc.)
- Contains: List building (add_directory_items), playback resolution (resolve_url), context actions
- Depends on: xbmcplugin, xbmcgui for UI rendering
- Used by: Kodi when user clicks items

**Background Service Layer:**
- Purpose: Monitor playback for scrobbling to Subsonic
- Location: `service.py`
- Contains: Monitor loop checking Player.Progress, triggering scrobble at 50%
- Depends on: libsonic.Connection for scrobble API, xbmc.Monitor
- Used by: Kodi in background during playback

## Data Flow

**Browse/List Flow:**

1. User selects menu item in Kodi UI
2. Kodi calls plugin URL with action param (e.g., `plugin://plugin.audio.subsonic/?action=list_albums&...`)
3. Simpleplugin Plugin.run() parses URL into Params dict, routes to @action handler (e.g., `list_albums()`)
4. Handler validates connection via get_connection() (creates or reuses global singleton)
5. Handler calls walk_* generator (e.g., `walk_albums(ltype='newest')`)
6. walk_* calls connection.getAlbumList2() → Libsonic builds HTTP URL, sends to Subsonic
7. Libsonic parses XML response into dict, yields individual album dicts
8. Handler builds listing by mapping each album through get_entry_album(item, params)
9. get_entry_album() creates dict with label, thumb URL (via connection.getCoverArtUrl), info metadata, context actions
10. Handler calls add_directory_items(create_listing(listing)) which calls xbmcplugin.addDirectoryItem for each
11. xbmcplugin.endOfDirectory() signals Kodi UI to render directory

**Playback Flow:**

1. User clicks playable track item in Kodi
2. Kodi calls `plugin://plugin.audio.subsonic/?action=play_track&id=<track_id>`
3. play_track() handler calls connection.streamUrl(sid=id, maxBitRate=X, tformat=Y)
4. Libsonic returns stream URL (e.g., `http://server/rest/stream.view?id=123&...`)
5. play_track() calls _set_resolved_url(resolve_url(url))
6. _set_resolved_url() creates xbmcgui.ListItem with path=url
7. xbmcplugin.setResolvedUrl() tells Kodi to play the URL with Kodi's built-in streaming

**Background Scrobbling Flow (service.py):**

1. Kodi service starts (addon extension point)
2. service.py checks scrobble setting
3. Creates Monitor loop, polls every 10 seconds while Player.HasMedia is true
4. Extracts current filename via xbmc.getInfoLabel()
5. Regex matches plugin URL to extract track ID
6. Checks Player.Progress; when >= 50% for first time, calls connection.scrobble(track_id)
7. Libsonic sends scrobble API call to Subsonic
8. Sets scrobbled=True to prevent duplicate scrobbles on same track

**State Management:**

- **Global connection singleton**: `connection = None` in module scope, lazily initialized by get_connection()
- **Starred items cache**: Cached in `plugin.get_storage()` (pickled dict on disk), refreshed every `cachetime` minutes
- **Local starred set**: `local_starred` module variable loaded from cache, used for display (star-colored labels)
- **Kodi addon settings**: Loaded via `Addon().get_setting('key')`, cached in memory, changes require explicit reload

## Key Abstractions

**Connection:**
- Purpose: Encapsulate Subsonic API endpoint logic
- Location: `lib/libsonic/connection.py` class Connection
- Pattern: Builds auth params, constructs URLs, parses responses
- Examples: `connection.ping()`, `connection.getAlbumList2()`, `connection.streamUrl()`, `connection.scrobble()`

**Walk Generators:**
- Purpose: Lazy iteration over API responses without loading all at once
- Examples: `walk_albums()`, `walk_album()`, `walk_artist()`, `walk_tracks_starred()`
- Pattern: yield from response dict navigation with KeyError fallback to empty generator
- Used to: Memory-efficiently handle large collections

**Entry Formatters:**
- Purpose: Transform API dict to Kodi ListItem dict format
- Examples: `get_entry_album()`, `get_entry_track()`, `get_entry_artist()`, `get_entry_playlist()`
- Pattern: Extract fields from item dict, build URL via plugin.get_url(), add metadata, add context actions
- Returns: Dict with keys: label, url, thumb, fanart, is_playable (for tracks), info, context_menu

**List Context:**
- Purpose: Package listing metadata for Kodi UI rendering
- Location: `main.py` line 33, namedtuple ListContext
- Fields: listing (list of dicts), succeeded (bool), update_listing, cache_to_disk, sort_methods, view_mode, content, category
- Used by: add_directory_items() to call xbmcplugin APIs with proper settings

**Play Context:**
- Purpose: Package playable item metadata for resolution
- Location: `main.py` line 34, namedtuple PlayContext
- Fields: path (stream URL string), play_item (optional dict), succeeded (bool)
- Used by: _set_resolved_url() to call xbmcplugin.setResolvedUrl()

## Entry Points

**main.py (Plugin Source):**
- Location: `/home/sandwich/Develop/plugin.audio.subsonic/main.py`
- Triggers: Kodi calls when user clicks addon in menus
- Responsibilities: Parse URL params, route to action handlers, manage UI state, handle user actions
- Flow: `if __name__ == "__main__": plugin.run()` at line 1558 invokes Simpleplugin routing

**service.py (Background Service):**
- Location: `/home/sandwich/Develop/plugin.audio.subsonic/service.py`
- Triggers: Kodi starts during playback (addon extension point)
- Responsibilities: Monitor track playback, trigger scrobbling at 50% progress
- Flow: `if __name__ == '__main__': if scrobbleEnabled: while not monitor.abortRequested()...`

**addon.xml:**
- Location: `/home/sandwich/Develop/plugin.audio.subsonic/addon.xml`
- Defines: Plugin metadata, extension points, required dependencies
- Extension point `xbmc.python.pluginsource` → `main.py`
- Extension point `xbmc.service` → `service.py`

## Error Handling

**Strategy:** Graceful degradation with user notifications

**Patterns:**
- Connection failures: popup('Connection error') and return False to skip action
- Bare except clauses catch all exceptions (connection, parsing), log errors, continue (fragile pattern noted in CONCERNS.md)
- Walk generators use try/except KeyError to yield empty (no crash on missing fields)
- Starred cache: KeyError fallback for missing 'updated' key initializes new cache

## Cross-Cutting Concerns

**Logging:** 
- Uses xbmc.log() with severity levels (LOGDEBUG, LOGINFO, LOGERROR)
- plugin.log() and plugin.log_error() wrapper methods
- Traces: Connection attempts, cache refreshes, downloaded items

**Validation:**
- can_star(type, ids) checks if starring is available for item type
- can_download(type, id) checks if downloads are enabled
- Download folder existence check before download
- Input dialog validation for search queries

**Authentication:**
- Configured via addon settings (subsonic_url, username, password, port, apiVersion)
- Supports insecure SSL (self-signed certs), legacy auth, GET requests
- Stored in Kodi addon settings (encrypted storage by Kodi)
- Lazy initialization: connection created on first use, reused as global singleton

**Settings/Configuration:**
- `resources/settings.xml` defines UI settings categories (General, Advanced)
- Settings loaded via `Addon().get_setting('key')` with optional type conversion
- Supported settings: subsonic_url, port, username, password, bitrate_streaming, transcode_format_streaming, apiversion, insecure, useget, legacyauth, cachetime, merge, scrobble, albums_per_page, tracks_per_page, download_folder

---

*Architecture analysis: 2026-04-28*
