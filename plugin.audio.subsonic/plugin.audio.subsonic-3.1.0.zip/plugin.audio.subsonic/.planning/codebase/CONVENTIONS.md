# Coding Conventions

**Analysis Date:** 2026-04-28

## Naming Patterns

**Files:**
- Module files: lowercase with underscores (e.g., `connection.py`, `errors.py`, `simpleplugin.py`)
- Main entry points: `main.py`, `service.py`
- Pattern: PEP 8 lowercase_with_underscores

**Functions:**
- Lowercase with underscores (e.g., `get_connection()`, `walk_folders()`, `cache_refresh()`)
- Action handler functions: lowercase underscore-separated (e.g., `browse_library()`, `list_albums()`, `play_track()`)
- Getter functions: `get_*` prefix (e.g., `get_entry_track()`, `get_connection()`, `get_artist_info()`)
- Helper/walker functions: `walk_*` prefix for generators (e.g., `walk_folders()`, `walk_artists()`, `walk_playlist()`)
- Checker functions: `is_*` or `can_*` prefix (e.g., `is_starred()`, `can_star()`, `can_download()`)
- Pattern: PEP 8 snake_case throughout

**Variables:**
- Local variables: lowercase_with_underscores (e.g., `connection`, `listing`, `album_id`)
- Parameters: snake_case (e.g., `folder_id`, `artist_id`, `menu_id`)
- Global variables: lowercase (e.g., `connection`, `local_starred`, `cached`)
- Dictionaries: descriptive names (e.g., `query_args`, `storage`, `cache_file`)
- Loop variables: single lowercase or descriptive (e.g., `item`, `menu_id`, `index`)

**Types/Classes:**
- NamedTuples: PascalCase (e.g., `ListContext`, `PlayContext`)
- Custom exceptions: PascalCase ending with Error (e.g., `SonicError`, `ParameterError`, `CredentialError`)
- Class instances from external libraries use provided names (e.g., `Connection` from libsonic)

## Code Style

**Formatting:**
- Character encoding declaration at top: `# -*- coding: utf-8 -*-`
- No explicit linter/formatter configuration found
- Code style is informal with mixed spacing around operators
- Example: `connection==None` (double equals, no spaces), `connection = get_connection()` (spaces around equals)
- Parameter alignment: uses aligned equals for readability (see `main.py` lines 188-192)

**Linting:**
- No linter configuration file detected (no `.flake8`, `pylintrc`, `setup.cfg`)
- No formatter configuration detected (no `.prettierrc`, black config)
- Code quality not enforced via CI

## Import Organization

**Order:**
1. Standard library imports (builtin modules)
2. Third-party library imports (xbmc, xbmcvfs, xbmcaddon, xbmcplugin, xbmcgui)
3. Internal project imports (libsonic, simpleplugin)

**Path Aliases:**
- No path aliases detected in codebase
- Plugins use direct imports after path modification: `sys.path.append(xbmcvfs.translatePath(...))`

**Example from `main.py` lines 4-24:**
```python
import xbmcvfs
import os
import xbmcaddon
import xbmcplugin
import xbmcgui
import json
import shutil
import time
import hashlib
import random
from datetime import datetime
from collections.abc import MutableMapping
from collections import namedtuple

sys.path.append(xbmcvfs.translatePath(os.path.join(...)))

import libsonic
from simpleplugin import Plugin
from simpleplugin import Addon
```

## Error Handling

**Patterns:**
- Bare `except:` clauses used extensively (lines 59, 407, 472, 708 in `main.py`) - catches all exceptions without discrimination
- Specific exception handling in some places: `except KeyError as e:` (lines 797, 805, 1044)
- Specific exception handling: `except IndexError:` in `service.py` line 96
- Generic `except Exception as e:` in `service.py` line 99
- Pattern: Try block wraps Subsonic API calls; silent failures with popup notifications on error
- Return `False` on connection failure as sentinel value (see `get_connection()` function)
- Most error handlers either log or popup notification, then silently return

**Example from `get_connection()` (lines 41-66):**
```python
def get_connection():
    global connection
    if connection==None:   
        connected = False  
        try:
            connection = libsonic.Connection(...)
            connected = connection.ping()
        except:
            pass
        if connected==False:
            popup('Connection error')
            return False
    return connection
```

## Logging

**Framework:** Plugin wrapper (`simpleplugin`) logging and Kodi's `xbmc.log`

**Patterns:**
- `plugin.log(message)` - info/debug level logging
- `plugin.log_error(message)` - error level logging
- `plugin.log_debug(message)` - debug level logging (used in helper functions)
- `xbmc.log(message, xbmc.LOGINFO/LOGDEBUG/LOGERROR)` - direct Kodi API (see `service.py`)
- Logging used for debugging and tracking important operations (connection attempts, data retrieval, user actions)
- Log messages typically include context: function name, ID values, operation type
- Conditional debug logging appears commented out in production (e.g., line 1057 in `main.py`)

**Example patterns:**
- `plugin.log('play_track #' + id)` - operation logging
- `plugin.log('Starred %s #%s' % (type,json.dumps(ids)))` - action logging with context
- `plugin.log_error('Unable to star %s #%s' % (type,json.dumps(ids)))` - error logging

## Comments

**When to Comment:**
- Code has minimal inline comments
- Comments appear where logic is non-obvious or requires context about Subsonic API behavior
- Comments document TODO items (see "TO FIX" pattern)
- Comments explain why a decision was made (see lines 636-638 in `main.py`)

**JSDoc/TSDoc:**
- Python docstrings used in helper functions and data transformation functions (lines 1283-1297 in `main.py`)
- Docstrings use triple-quoted strings with description of parameters and return values
- Example from `resolve_url()` (lines 1282-1298):
```python
def resolve_url(path='', play_item=None, succeeded=True):
    """
    Create and return a context dict to resolve a playable URL
    :param path: the path to a playable media.
    :type path: str or unicode
    :param play_item: a dict of item properties...
    :return: context object containing necessary parameters
    :rtype: PlayContext
    """
```

## Function Design

**Size:**
- Functions vary from 2 lines (simple getters like `is_starred()`) to 50+ lines (complex operations like `list_albums()`)
- Most action handlers are 20-60 lines
- Utility functions are typically under 20 lines

**Parameters:**
- Params dict pattern: actions receive a `params` dict from the Kodi plugin router
- Named parameters in helper functions
- Optional parameters with defaults used (e.g., `get_artist_info(artist_id, forced=False)`)
- No type hints used

**Return Values:**
- Action handlers return implicitly (None) - they call `add_directory_items()` instead
- Helper functions return dicts, lists, or boolean values
- Generators used for data iteration (e.g., `walk_folders()`, `walk_artists()`)
- Sentinel values: `False` returned on connection failure

**Example action handler pattern (lines 69-138):**
```python
@plugin.action()
def root(params):
    connection = get_connection()
    if connection==False:
        return
    listing = []
    menus = {...}
    for mid in menus:
        listing.append({...})
    add_directory_items(create_listing(listing, ...))
```

## Module Design

**Exports:**
- No `__all__` declaration in main modules
- simpleplugin library exports explicitly: `__all__ = ['SimplePluginError', 'Storage', ...]`
- Kodi addon entry points: `main.py` and `service.py` run directly via `if __name__ == "__main__"`

**Barrel Files:**
- `lib/libsonic/__init__.py` re-exports Connection and errors (line 24 in `main.py` imports `libsonic` module)
- `lib/simpleplugin/__init__.py` imports Plugin and Addon classes

## Code Organization Patterns

**Global State:**
- Global `connection` object cached in both `main.py` and `service.py`
- Global `local_starred` set for caching starred tracks
- Global `cachetime` from addon settings
- Pattern: lazy initialization with `if connection==None` check

**Data Structures:**
- NamedTuples for context objects: `ListContext`, `PlayContext`
- Dictionaries for item entries (listing items with label, url, thumb, info)
- Generator pattern for API response iteration (walk functions)

**Settings Access:**
- Settings accessed via `Addon().get_setting(name)` calls
- Settings cached in globals (e.g., `cachetime = int(Addon().get_setting('cachetime'))`)
- Type conversion with `convert` parameter: `Addon().get_setting('username', convert=False)`

---

*Convention analysis: 2026-04-28*
