# plugin.audio.subsonic — Modernization

## What This Is

A Kodi music addon that streams from any Subsonic-API server (Subsonic, Airsonic, Navidrome, gonic, LMS) for music listeners running Kodi 21 Omega and Kodi 20 Nexus. The plugin was unmaintained for years; v1.0 hard-forked it under `dskvr/plugin.audio.subsonic`, fixed the rot, pulled in three open community PRs, modernized the codebase end-to-end, and shipped as v3.1.0.

## Core Value

A current Kodi user can install this addon on Kodi Omega, point it at their Subsonic-compatible server, and reliably browse, play, and star music — without hitting Python 3 import bugs, broken auth, or stale caches.

## Current State

**Shipped: v3.1.0 (milestone v1.0 — Modernization)** on 2026-04-29.

- 6 phases / 27 plans / 114 commits / 240 unit tests
- Crash-free on Kodi 21 (Python 3.11) and Kodi 20 (Python 3.8)
- 1561-line monolithic `main.py` reduced to a 19-line bootstrap; all logic in `resources/lib/subsonic/` package (13 modules)
- First-party `@route()` decorator router replaces vendored `simpleplugin`
- Salt+token + OpenSubsonic API-key auth; legacyauth fallback preserved
- Genre browsing, search3, 5-star rating, internet radio, MusicBrainz IDs all wired
- CI runs pytest + ruff + mypy + kodi-addon-checker on every push
- 28 runtime UAT items remain for live server verification (see `.planning/milestones/v1.0-phases/06-polish-server-verification/06-MASTER-UAT.md` once phases are archived, or `.planning/phases/06-polish-server-verification/06-MASTER-UAT.md` until then)

## Requirements

### Validated

<!-- Shipped and confirmed in v1.0 — see .planning/milestones/v1.0-REQUIREMENTS.md for the full list. -->

- ✓ Compatibility on Kodi 20 + 21 with Python 3.8 + 3.11 — v1.0
- ✓ All three crash-on-launch bugs (BUG-01 missing import sys, COMPAT-03 urllib2, COMPAT-04 translatePath) — v1.0
- ✓ Three community PRs merged: Favorite Albums (#49), m4a transcoding (#53), gapless playback (#54) — v1.0
- ✓ Structural refactor: thin bootstraps, 13-module package, custom router, type hints, mypy --strict, 240 unit tests — v1.0
- ✓ Auth modernization: salt+token default, OpenSubsonic API-key, legacy fallback, credential leak audit — v1.0
- ✓ Feature expansion: genres, search3, 5-star rating, internet radio, MusicBrainz IDs — v1.0
- ✓ CI matrix: pytest 3.8+3.11, ruff, mypy, kodi-addon-checker — v1.0

(Full validated set in `.planning/milestones/v1.0-REQUIREMENTS.md` — 55 of 55 v1 reqs.)

### Active

<!-- Carried forward from PROJECT.md "Active" minus everything that landed in v1.0. -->

(None yet — run `/gsd:new-milestone` to define the next milestone.)

### Out of Scope

<!-- Hard exclusions still in effect. -->

- **PR-back to warwickh upstream** — `dskvr/plugin.audio.subsonic` is the canonical hard fork; we don't push patches back.
- **Kodi 19 Matrix and earlier** — predates the Python 3.11 / Kodi 20+ floor we target.
- **Kodi 22 Piers** — still in development; revisit when stable.
- **Removing the insecure-SSL toggle entirely** — homelab users with self-signed certs depend on it; keep the escape hatch.
- **Sync-to-device / offline caching beyond download-to-folder** — Kodi is always-on.
- **Social sharing, server-admin endpoints, jukebox mode** — wrong UI paradigm or zero demand.
- **Podcast browser** — Navidrome lacks server support; Kodi has dedicated podcast addons.
- **Client-side Last.fm SDK** — Subsonic's `scrobble.view` already forwards.
- **Replacing libsonic with py-opensonic** — unvendorable transitive deps.

## Next Milestone Goals

These are candidate themes for a future v1.1 or v2.0 — pulled from the deferred items in v1.0 and post-audit observations. Run `/gsd:new-milestone` to formalize.

**v1.1 — UAT closure + hotfixes** (likely)
- Walk through the 28-item master UAT against real Subsonic / Airsonic / Navidrome / gonic / LMS instances
- Fix any regressions surfaced
- Optional: trim the vendored `lib/simpleplugin/` directory now that it's no longer imported

**v2.0 — Polish + distribution** (longer-horizon)
- Synchronized lyrics via `getLyricsBySongId` (when Navidrome bugs #4631/#4233 resolve)
- ReplayGain hints as ListItem properties (after empirical Kodi 21 testing)
- Cross-device play queue resume (`savePlayQueue` / `getPlayQueue`)
- `reportPlayback` OpenSubsonic scrobbling (when stable in Navidrome release branch)
- Per-server credential storage (multiple servers in one install)
- Integration tests against Navidrome Docker container
- Submit to xbmc/repo-plugins official Kodi addon repo OR stand up a custom Kodi repo
- GitHub Actions release automation (signed zip, changelog, kodi-addon-checker gating)

## Context

**Project lineage:** `gordielachance` → `basilfx` → `warwickh` → forked to `dskvr/plugin.audio.subsonic` for v1.0. The dskvr fork already had the Search Album feature (PR #47 from GioF71) at fork time; v1.0 added the three remaining open warwickh PRs (#49 Favorite Albums, #53 m4a, #54 gapless).

**Codebase as of v1.0:**
- ~25k LOC delta from the pre-v1.0 baseline (139 files changed, +25,056 / -1,686)
- Pure Python; no compiled extensions; vendored `lib/libsonic/` (modernized) and `lib/simpleplugin/` (dormant, not deleted)
- 240 pytest unit tests; mypy --strict clean on 15 modules; ruff clean
- CI: GitHub Actions matrix on Python 3.8 + 3.11

**Server ecosystem (2026):** Navidrome dominates self-hosted Subsonic-compatible servers; OpenSubsonic is the de-facto extension layer. The addon's auth layer (Phase 4) probes capability and degrades gracefully against legacy Subsonic / Airsonic.

## Constraints

- **Tech stack:** Python only (Kodi addon runtime). No PyPI install at runtime — vendor or use Kodi `script.module.*`.
- **Compatibility:** Kodi 21 (Py 3.11) + Kodi 20 (Py 3.8). Don't introduce 3.9+ syntax without `from __future__ import annotations`.
- **Distribution:** Pure-Python zip with `addon.xml` metadata; no build step. Released v3.1.0 via GitHub.
- **API surface:** Subsonic REST API client; OpenSubsonic extensions are additive only — never required.
- **Security:** No credentials in `xbmc.log` (audited and enforced in Phase 4). Addon stores user music-server credentials.
- **Backward compat:** All `id=` attributes in `resources/settings.xml` preserved verbatim across the v1.0 refactor — existing user installs upgrade cleanly.

## Key Decisions

| Decision | Rationale | Outcome |
|----------|-----------|---------|
| Hard fork under `dskvr/plugin.audio.subsonic` | Upstream `warwickh` unmaintained; no plan to PR back | ✓ Good — unblocked the modernization |
| Target Kodi 21 + Kodi 20 | Cover both stable releases users actually run | ✓ Good — CI matrix gates both |
| Pull in all 3 open warwickh PRs (#49, #53, #54) | Community-vetted fixes/features | ✓ Good — all merged with attribution |
| Keep vendored libs but modernize them | Aligns with Kodi addon distribution norms | ✓ Good — libsonic is Py3 idiomatic; simpleplugin dormant |
| Drop simpleplugin routing for first-party `@route()` | 1300 lines of cruft → 77 lines | ✓ Good — fully tested, mypy --strict clean |
| Modularize + type-hint + dataclass `main.py` | 1561-line monolith → 19-line bootstrap + 13 modules | ✓ Good — refactor unblocked feature work |
| Migrate to salt+token + API-key auth | Plaintext password is a 2012 artifact | ✓ Good — Phase 4 shipped with legacyauth fallback |
| Support all major Subsonic-API servers + OpenSubsonic extensions | Reflects 2026 ecosystem | ✓ Good — Phase 5 features all gated correctly |
| Tests are unit-only with mocked Kodi APIs | Integration testing requires running Kodi | ✓ Good — 240 tests, fast (<1s); Kodi runtime UAT deferred to v2 |
| Distribution mechanism deferred post-v1.0 | Get code working before deciding how to ship | — Pending — v2 will tackle xbmc/repo-plugins or custom Kodi repo |

## Evolution

This document evolves at phase transitions and milestone boundaries.

**After each phase transition** (via `/gsd:transition`):
1. Requirements invalidated? → Move to Out of Scope with reason
2. Requirements validated? → Move to Validated with phase reference
3. New requirements emerged? → Add to Active
4. Decisions to log? → Add to Key Decisions
5. "What This Is" still accurate? → Update if drifted

**After each milestone** (via `/gsd:complete-milestone`):
1. Full review of all sections
2. Core Value check — still the right priority?
3. Audit Out of Scope — reasons still valid?
4. Update Context with current state

---
*Last updated: 2026-04-29 after v1.0 Modernization milestone shipped*
