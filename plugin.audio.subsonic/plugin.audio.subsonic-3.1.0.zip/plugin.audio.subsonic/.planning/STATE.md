---
gsd_state_version: 1.0
milestone: v1.0
milestone_name: milestone
status: verifying
stopped_at: Completed 05-feature-expansion 05-04-verify-PLAN.md
last_updated: "2026-04-28T22:34:48.685Z"
last_activity: 2026-04-28
progress:
  total_phases: 6
  completed_phases: 5
  total_plans: 27
  completed_plans: 27
  percent: 0
---

# Project State

## Project Reference

See: .planning/PROJECT.md (updated 2026-04-28)

**Core value:** A current Kodi user can install this addon on Kodi Omega, point it at their Subsonic-compatible server, and reliably browse, play, and star music — without hitting Python 3 import bugs, broken auth, or stale caches.
**Current focus:** Phase 05 — feature-expansion

## Current Position

Phase: 06
Plan: Not started
Status: Phase complete — ready for verification
Last activity: 2026-04-28

Progress: [░░░░░░░░░░] 0%

## Performance Metrics

**Velocity:**

- Total plans completed: 0
- Average duration: —
- Total execution time: 0 hours

**By Phase:**

| Phase | Plans | Total | Avg/Plan |
|-------|-------|-------|----------|
| - | - | - | - |

**Recent Trend:**

- Last 5 plans: none yet
- Trend: —

*Updated after each plan completion*
| Phase 01-foundation P04 | 1 | 1 tasks | 1 files |
| Phase 01-foundation P01-crash-fixes | 7 | 3 tasks | 4 files |
| Phase 01-foundation P03 | 5 | 2 tasks | 6 files |
| Phase 01-foundation P02-bare-excepts | 5 | 2 tasks | 2 files |
| Phase 01-foundation P05 | 5 | 2 tasks | 0 files |
| Phase 02-community-prs P02 | 1 | 1 tasks | 1 files |
| Phase 02-community-prs P01 | 2 | 1 tasks | 1 files |
| Phase 02-community-prs P03 | 8m | 2 tasks | 4 files |
| Phase 02-community-prs P04 | 5 | 2 tasks | 0 files |
| Phase 03-structural-refactor P03 | 2 | 1 tasks | 3 files |
| Phase 03-structural-refactor P02 | 103s | 2 tasks | 4 files |
| Phase 03-structural-refactor P01 | 2 | 2 tasks | 6 files |
| Phase 03 P05 | 1 | 1 tasks | 2 files |
| Phase 03-structural-refactor P04 | 2 | 2 tasks | 4 files |
| Phase 03 P07 | 8 | 3 tasks | 3 files |
| Phase 03 P06 | 2 | 2 tasks | 4 files |
| Phase 03-structural-refactor P08 | 15 | 2 tasks | 7 files |
| Phase 03-structural-refactor P09 | 8 | 2 tasks | 6 files |
| Phase 03-structural-refactor P10 | 15 | 2 tasks | 1 files |
| Phase 04-auth-modernization P01 | 147 | 2 tasks | 6 files |
| Phase 04-auth-modernization P03 | 1 | 1 tasks | 2 files |
| Phase 04-auth-modernization P02 | 600 | 2 tasks | 3 files |
| Phase 05-feature-expansion P01 | 90s | 2 tasks | 4 files |
| Phase 05-feature-expansion P05-02 | 2 | 2 tasks | 3 files |
| Phase 05-feature-expansion P03 | 231 | 2 tasks | 7 files |
| Phase 05-feature-expansion P05-04 | 15 | 2 tasks | 6 files |

## Accumulated Context

### Decisions

Decisions are logged in PROJECT.md Key Decisions table.
Recent decisions affecting current work:

- Roadmap: Community PRs go before structural refactor (Phase 2 before Phase 3) — PRs are patches against main.py as it currently exists; applying after restructuring creates three-way merge conflicts
- Roadmap: `getOpenSubsonicExtensions` probe belongs in Phase 4 (Auth), not Phase 5 (Features) — it is the literal dependency gate for every OpenSubsonic feature
- Roadmap: PERF-04 (cover art sizing) and PERF-05 (setContent/addSortMethod) assigned to Phase 3 — they are part of building listings.py correctly, not new features
- [Phase 01-foundation]: fail-fast: false on pytest matrix — both Python 3.8 and 3.11 always run so failures on either are visible
- [Phase 01-foundation]: mypy 1.20 run-on/target-for split: lint job runs on Python 3.11, pyproject.toml python_version=3.8 for compatibility checking
- [Phase 01-foundation]: Keep _kodi_major_version() in simpleplugin — used by log_notice at line 652; only translate_path simplified to call xbmcvfs unconditionally
- [Phase 01-foundation]: xbmc.getInfoLabel mock must return real version string to avoid TypeError in simpleplugin._kodi_major_version() Py3 comparison
- [Phase 01-foundation]: get_setting mock returns '0' not '' to prevent ValueError in int() conversion at main.py module level
- [Phase 01-foundation]: Virtual environment at .venv/ for pytest — Arch Linux PEP 668 blocks pip --user; venv is the correct non-root approach
- [Phase 01-foundation]: Use except Exception as exc (not bare except:) at connection/settings sites — allows KeyboardInterrupt and SystemExit to propagate while capturing all real errors
- [Phase 01-foundation]: Log traceback.format_exc() at xbmc.LOGERROR for connection failures — full stack trace in kodi.log enables self-diagnosis of auth/network/import errors
- [Phase 01-foundation]: 6 tests pass (not 4): test_service_import_sys.py contributes 2 extra tests beyond the 4 planned — all green
- [Phase 01-foundation]: Python 3.8 gate is CI-only — not installed locally on Arch; CI matrix is the authoritative 3.8 check
- [Phase 01-foundation]: Remaining bare excepts at main.py lines 410/475/711/1247 are deferred scope (outside get_connection()) — not blocking Phase 01
- [Phase 02-community-prs]: PR #54: closing paren uses 4-space indent (not 3-space from PR author) to match surrounding code style
- [Phase 02-community-prs]: PR #53: Applied manually via Edit tool — upstream diff trivial, no cherry-pick needed; normalised double-space before values= as upstream PR specifies
- [Phase 02-community-prs]: PR #49: walk_albums starred branch does manual in-Python pagination via getStarred2(); # TO FIX comment preserved for Phase 3
- [Phase 02-community-prs]: All three community PRs coexist cleanly — pytest 6/6 pass with PR #53, #54, #49 changes applied simultaneously
- [Phase 03-structural-refactor]: router.py: dispatch raises ValueError for unknown actions; url_for takes action name string; set_routes clears and replaces _ROUTES for bootstrap context injection (B4 fix)
- [Phase 03-structural-refactor]: Cache stores (value, expires_at) tuples; lazy on-demand TTL, no background refresh
- [Phase 03-structural-refactor]: safe_log prepends 'Subsonic: ' to all messages and redacts auth params via _AUTH_RE before xbmc.log
- [Phase 03-structural-refactor]: TypedDict total=False for all API response types to handle real-world server field variance
- [Phase 03-structural-refactor]: Settings constructor injection pattern (Settings(addon=mock)) for clean test isolation
- [Phase 03]: _mock_list_item() uses plain MagicMock (no spec=) since xbmcgui is itself a MagicMock in tests — speccing a Mock raises InvalidSpecError
- [Phase 03-structural-refactor]: ApiClient constructed with Settings object, no module-level singleton (ARCH-11)
- [Phase 03-structural-refactor]: stream_url() delegates entirely to libsonic.streamUrl() — no credential injection in ApiClient
- [Phase 03-structural-refactor]: get_open_subsonic_extensions() is Phase 3 stub — Phase 4 wires it to auth-mode selection
- [Phase 03]: BUG-05 fix: cache.invalidate('starred') + Container.Refresh after star/unstar in actions.py
- [Phase 03]: BUG-03 fix: _parse_bool_param() str.lower() membership check replaces fragile (unstar) and (unstar != 'None') and (unstar != 'False') chain
- [Phase 03]: actions.py has no xbmcgui/xbmcplugin imports — download_item uses log_error for missing folder instead of Dialog popup (ARCH-05)
- [Phase 03]: browse.py list_albums artist_id view doesn't paginate (all albums loaded at once)
- [Phase 03]: search.py uses show_search_dialog from listings — no direct xbmcgui import (ARCH-05)
- [Phase 03]: Phase 3 keeps search2; search3 migration deferred to Phase 5 (FEAT-02)
- [Phase 03-structural-refactor]: B4 fix: _ORIGINAL_ROUTES snapshot at bootstrap module load (not at invocation) prevents import-cache race on second run_plugin() call
- [Phase 03-structural-refactor]: sys.path.insert(0) used instead of sys.path.append to give resources/lib priority over Kodi-bundled copies
- [Phase 03-structural-refactor]: Scrobbler.onSettingsChanged uses local import (from subsonic.settings import Settings) to avoid module-level circular import risk
- [Phase 03-structural-refactor]: mypy updated to python_version=3.9 (dropped 3.8), explicit_package_bases=true added to resolve path collision
- [Phase 03-structural-refactor]: browse.py items list types annotated as List[SubsonicAlbum]/List[SubsonicTrack] for mypy clean pass
- [Phase 03-structural-refactor]: Kodi runtime UAT steps (a-f: browse/play/star/pagination) deferred to Phase 6 HUMAN-UAT.md — cannot automate Kodi addon loading in CI
- [Phase 04-auth-modernization]: subsonic_api_key placed in ADVANCED tab after legacyauth — consistent with other auth settings, no new category needed
- [Phase 04-auth-modernization]: bool() cast applied to all Settings bool comparisons — fixes mypy --strict no-any-return throughout settings.py
- [Phase 04-auth-modernization]: Insecure-SSL gate implemented as _check_insecure_ssl_acknowledgement in bootstrap.py, called before ApiClient construction in run_plugin (AUTH-07)
- [Phase 04-auth-modernization]: legacy auth checked first in choose_auth_mode priority chain — LDAP escape hatch always wins
- [Phase 04-auth-modernization]: probe_extensions caches empty set on error — non-OpenSubsonic servers never retry probe
- [Phase 04-auth-modernization]: get_open_subsonic_extensions Phase 3 stub delegates to probe_extensions for cache coherence
- [Phase 05-feature-expansion]: InternetRadioStation and get_internet_radio_stations guarded with try/except for server compatibility
- [Phase 05-feature-expansion]: search3 added alongside existing search() for backward compat; Wave 2 plans use search3
- [Phase 05-feature-expansion]: show_rating_select does not use track_id internally — parameter reserved for caller dispatch
- [Phase 05-feature-expansion]: build_genre_item uses no InfoTagMusic — genres are nav folders not playable media
- [Phase 05-feature-expansion]: Patched show_rating_select via subsonic.actions module ref (not listings) because from-import binds name directly in actions namespace
- [Phase 05-feature-expansion]: list_genre_tracks uses hide_artist=False so cross-genre tracks show artist name
- [Phase 05-feature-expansion]: Runtime UAT deferred to Phase 6 — cannot automate Kodi addon loading in CI; human approval covers code-inspection verification only
- [Phase 05-feature-expansion]: ruff py38 syntax fixes applied to test suite to maintain Python 3.8 compatibility (walrus operator excluded from tests)

### Pending Todos

None yet.

### Blockers/Concerns

- Phase 4: Token auth failure on LDAP-backed Airsonic servers needs empirical testing before AUTH-02 is marked complete
- Phase 6: ReplayGain ListItem property names on Kodi Omega are not confirmed in official docs (LOW confidence) — deferred to v2
- Phase 6: Navidrome `getLyricsBySongId` has open bugs (#4631, #4233) — deferred to v2

## Session Continuity

Last session: 2026-04-28T21:52:17.786Z
Stopped at: Completed 05-feature-expansion 05-04-verify-PLAN.md
Resume file: None
