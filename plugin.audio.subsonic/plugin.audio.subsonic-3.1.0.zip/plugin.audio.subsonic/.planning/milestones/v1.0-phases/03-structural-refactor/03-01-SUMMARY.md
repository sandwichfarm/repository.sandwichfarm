---
phase: 03-structural-refactor
plan: 01
subsystem: models-settings-foundation
tags: [models, settings, typed-dict, dataclass, foundation, wave-1]
dependency_graph:
  requires: []
  provides:
    - subsonic.models (SubsonicArtist, SubsonicAlbum, SubsonicTrack, SubsonicPlaylist, SubsonicGenre, PageState, PlayContext, CacheEntry)
    - subsonic.settings (Settings)
    - resources/lib/__init__.py
    - resources/lib/subsonic/__init__.py
  affects: [03-02, 03-03, 03-04, 03-05, 03-06, 03-07, 03-08]
tech_stack:
  added: []
  patterns:
    - TypedDict with total=False for Subsonic API response shapes
    - @dataclass for internal plugin state objects
    - Settings facade with constructor-injected addon for testability
    - TDD (RED/GREEN) for all new modules
key_files:
  created:
    - resources/lib/__init__.py
    - resources/lib/subsonic/__init__.py
    - resources/lib/subsonic/models.py
    - resources/lib/subsonic/settings.py
    - tests/test_models.py
    - tests/test_settings.py
  modified: []
decisions:
  - "TypedDict total=False: all API response TypedDicts use total=False to accommodate real-world servers returning inconsistent field subsets"
  - "Settings constructor injection: Settings(addon=mock) pattern chosen over module-level mock patching — cleaner in tests and avoids import-time xbmcaddon dependency"
  - "TypedDict try/except import: guards against Python <3.8 where typing.TypedDict was unavailable, falls back to typing_extensions"
metrics:
  duration_minutes: 2
  completed_date: "2026-04-28"
  tasks_completed: 2
  files_created: 6
  files_modified: 0
  tests_added: 39
  tests_passing: 39
---

# Phase 3 Plan 1: Subsonic Package Foundation (models + settings) Summary

**One-liner:** TypedDict response shapes (5 types) and dataclass state objects (3 types) in models.py, plus a typed Settings facade reading all 16 settings.xml ids verbatim via constructor-injected xbmcaddon.

## What Was Built

### Task 1: Package structure and models.py (commit 0ebc0cc)

Created the `resources/lib/subsonic/` package with:

- `resources/lib/__init__.py` — package marker
- `resources/lib/subsonic/__init__.py` — package marker exporting `__version__ = "3.0.2"`
- `resources/lib/subsonic/models.py` — 5 TypedDicts + 3 dataclasses

TypedDicts (all `total=False` for real-world API compatibility):
- `SubsonicArtist` — id, name, albumCount, coverArt, starred
- `SubsonicAlbum` — id, name, artist, artistId, coverArt, songCount, duration, created, starred, year, genre, musicBrainzId
- `SubsonicTrack` — id, title, artist, artistId, album, albumId, duration, bitRate, contentType, suffix, coverArt, year, track, discNumber, starred, musicBrainzId
- `SubsonicPlaylist` — id, name, songCount, duration, created, coverArt, comment, owner, public
- `SubsonicGenre` — value, songCount, albumCount

Dataclasses:
- `PageState(page=1, page_size=50, offset=0, has_more=True)` — pagination position
- `PlayContext(stream_url, track_id, title, duration=0)` — resolved playback context
- `CacheEntry(value, expires_at)` — TTL cache entry holding any value

### Task 2: settings.py typed facade (commit 18a97ba)

Created `resources/lib/subsonic/settings.py` with:

- `Settings` class accepting optional `addon` constructor parameter for testability
- 16 typed properties covering every `id=` attribute in `resources/settings.xml`
- Sensible defaults on parse errors: port→4040, albums_per_page→50, tracks_per_page→100, cache_time→3600
- Boolean properties use `.lower() == "true"` (case-insensitive, matches Kodi's `bool` setting format)

All 16 settings.xml id= values preserved verbatim (COMPAT-06):
`subsonic_url`, `port`, `username`, `password`, `albums_per_page`, `tracks_per_page`, `download_folder`, `transcode_format_streaming`, `bitrate_streaming`, `apiversion`, `insecure`, `useget`, `legacyauth`, `cachetime`, `merge`, `scrobble`

## Test Results

```
tests/test_models.py    11/11 passed
tests/test_settings.py  28/28 passed
Total: 39/39 passed
```

The `test_settings_ids_verbatim` test exhaustively verifies that every property triggers a `getSetting()` call with the exact `id=` string from `settings.xml` — no id drift is possible without breaking this test.

## Decisions Made

1. **TypedDict `total=False`**: All API response TypedDicts use `total=False`. Real-world Subsonic servers return inconsistent field subsets; `total=False` prevents false type errors and matches real data shapes.

2. **Settings constructor injection**: `Settings(addon=None)` defaults to `xbmcaddon.Addon()` but accepts a mock. This is cleaner than monkeypatching `xbmcaddon` module-level and avoids import-time failures when xbmcaddon isn't available.

3. **`from __future__ import annotations`**: Both new modules use this for Python 3.8 forward-reference compatibility (the target minimum per `pyproject.toml`).

4. **`typing.TypedDict` with fallback to `typing_extensions`**: The try/except import in `models.py` handles the case where `typing_extensions` might be needed on Python <3.8.

## Deviations from Plan

None — plan executed exactly as written. All specified model shapes, dataclass fields, and settings properties were implemented verbatim per the plan spec.

## Known Stubs

None. All models and settings properties are fully implemented with no placeholder values or stub data flows.

## Self-Check: PASSED
