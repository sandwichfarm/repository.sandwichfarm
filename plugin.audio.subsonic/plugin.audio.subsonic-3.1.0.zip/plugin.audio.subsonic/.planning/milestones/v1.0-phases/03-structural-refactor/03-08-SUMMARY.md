---
phase: "03-structural-refactor"
plan: "08"
subsystem: "bootstrap / entry-points / scrobbler"
tags: ["entry-point", "bootstrap", "scrobbler", "arch-11", "b4-fix"]
dependency_graph:
  requires:
    - "03-06 (handler modules: browse, search, playback, actions)"
    - "03-07 (listings, models — Wave 3 complete)"
  provides:
    - "run_plugin() entry point in bootstrap.py"
    - "run_service() entry point in bootstrap.py"
    - "Scrobbler class in scrobbler.py"
    - "thin main.py (20 lines)"
    - "thin service.py (20 lines)"
  affects:
    - "main.py — fully rewritten (1588 lines → 20 lines)"
    - "service.py — fully rewritten (109 lines → 20 lines)"
    - "tests/test_imports.py — extended with bootstrap + scrobbler smoke tests"
    - "tests/test_service_import_sys.py — updated to accept sys.path.insert"
tech_stack:
  added: []
  patterns:
    - "Module-load-time snapshot (_ORIGINAL_ROUTES) for B4 import-cache fix"
    - "xbmc.Monitor subclass with injected ApiClient (no global singletons)"
    - "urllib.parse.parse_qs for URL parameter extraction (not regex)"
    - "Thin bootstrap pattern (entry-point + sys.path + single function call)"
key_files:
  created:
    - "resources/lib/subsonic/bootstrap.py"
    - "resources/lib/subsonic/scrobbler.py"
    - "tests/test_scrobbler.py"
  modified:
    - "main.py"
    - "service.py"
    - "tests/test_imports.py"
    - "tests/test_service_import_sys.py"
decisions:
  - "Used sys.path.insert(0, ...) rather than sys.path.append — insert gives priority over any Kodi-bundled copies"
  - "_ORIGINAL_ROUTES snapshot taken at bootstrap module load, not at run_plugin() invocation — fixes Python import-cache race (B4)"
  - "Scrobbler uses local import (from subsonic.settings import Settings) inside onSettingsChanged to avoid circular-import risk at module load"
  - "xbmc.Monitor set to a real no-op class in test_scrobbler.py because MagicMock base class prevents subclassing (conftest limitation)"
metrics:
  duration: "~15 minutes"
  completed: "2026-04-28T18:05:21Z"
  tasks_completed: 2
  tasks_total: 2
  files_created: 3
  files_modified: 4
  tests_added: 15
  tests_total: 161
---

# Phase 03 Plan 08: Entry-Point Shrink + Scrobbler Extraction Summary

**One-liner:** main.py + service.py each reduced to 20-line thin bootstraps; bootstrap.py wires ApiClient/Cache/router with B4 import-cache fix; Scrobbler class extracted with injected ApiClient and 50%-progress dedup logic.

## What Was Built

### `resources/lib/subsonic/bootstrap.py` (125 lines)

- `run_plugin(argv)` — constructs Settings, ApiClient, Cache; calls `_patch_routes_with_context`; dispatches.
- `run_service()` — constructs its own Settings + ApiClient (ARCH-11); instantiates Scrobbler; runs monitor loop.
- `_patch_routes_with_context(client, settings, cache, handle)` — wraps each handler from `_ORIGINAL_ROUTES` to inject context; calls `set_routes(wrapped)` atomically.
- `_ORIGINAL_ROUTES` — module-load-time snapshot of `_ROUTES` after all handler module imports. **B4 fix**: wrapping from this snapshot instead of the live `_ROUTES` prevents the import-cache race where a second `run_plugin()` call in the same process would wrap an empty `_ROUTES` (Python caches module imports; `@route()` decorators don't re-fire on the second import).

### `resources/lib/subsonic/scrobbler.py` (107 lines)

- `Scrobbler(xbmc.Monitor)` — background monitor subclass.
- Constructor accepts injected `client: ApiClient` and `settings: Settings` (ARCH-11 — no global connection).
- `_extract_track_id(url)` — uses `urllib.parse.parse_qs` (not regex); returns empty string for non-Subsonic or non-play_track URLs.
- `run()` — polls every 10 seconds; scrobbles at ≥50% progress; dedup via `_scrobbled` flag; resets on track change or progress < 50%.
- `onSettingsChanged()` — re-reads Settings when user changes addon settings (Pitfall 10 fix).

### `main.py` — 20 lines (ARCH-01)
```
sys.path.insert → resources/lib, lib
from subsonic.bootstrap import run_plugin
if __name__ == "__main__": run_plugin(sys.argv)
```

### `service.py` — 20 lines (ARCH-02)
```
sys.path.insert → resources/lib, lib
from subsonic.bootstrap import run_service
if __name__ == "__main__": run_service()
```

### `tests/test_scrobbler.py` — 13 tests

Covers: `_extract_track_id` (6 cases), scrobble-fires-at-50% trigger, dedup, reset-on-low-progress, reset-on-track-change, client-called-with-correct-id, failure-leaves-scrobbled-False, `onSettingsChanged` refreshes `_settings`.

## Deviations from Plan

### Auto-fixed Issues

**1. [Rule 1 - Bug] `test_service_import_sys.py::test_import_sys_before_sys_path_append` failed after rewrite**
- **Found during:** Task 1 verification
- **Issue:** The existing test asserted `sys.path.append` was present in service.py. The new bootstrap uses `sys.path.insert` (superior — gives priority over Kodi-bundled copies).
- **Fix:** Updated the test assertion to accept either `sys.path.append` or `sys.path.insert`.
- **Files modified:** `tests/test_service_import_sys.py`
- **Commit:** 17ae767

**2. [Rule 1 - Bug] `xbmc.Monitor` MagicMock prevents Scrobbler subclassing in tests**
- **Found during:** Task 2 (TDD — tests failed on construction)
- **Issue:** `conftest.py` sets `xbmc = MagicMock()`, so `xbmc.Monitor` is also a `MagicMock`. Inheriting from a `MagicMock` makes the subclass a mock itself — all instance method calls return new mocks rather than executing real code.
- **Fix:** In `test_scrobbler.py`, replaced `xbmc.Monitor` with a real no-op class before importing `Scrobbler`. The conftest pattern cannot be changed globally (it would affect all other tests).
- **Files modified:** `tests/test_scrobbler.py`
- **Commit:** ed367ff

**3. [Rule 1 - Bug] `patch("subsonic.scrobbler.Settings")` raised `AttributeError`**
- **Found during:** Task 2 `test_on_settings_changed_refreshes_settings`
- **Issue:** `onSettingsChanged` does `from subsonic.settings import Settings` as a local import inside the method body, so `Settings` is never bound at module level in `scrobbler.py`. `patch("subsonic.scrobbler.Settings")` correctly fails.
- **Fix:** Changed patch target to `subsonic.settings.Settings` which is where the local import resolves.
- **Files modified:** `tests/test_scrobbler.py`
- **Commit:** ed367ff

## Known Stubs

None. All entry-point and scrobbling logic is fully wired. `run_service()` checks `settings.scrobble_enabled` before starting the monitor loop (guards against no-op service startup).

## Test Results

```
161 passed in 0.16s
```

All pre-existing 146 tests continue to pass. 15 new tests added (13 scrobbler + 2 import smoke tests).

## Success Criteria Verification

- [x] `resources/lib/subsonic/bootstrap.py` created — `run_plugin()`, `run_service()`, `_ORIGINAL_ROUTES` snapshot, `_patch_routes_with_context`
- [x] `resources/lib/subsonic/scrobbler.py` created — `Scrobbler(xbmc.Monitor)` with injected ApiClient
- [x] `main.py` rewritten — 20 lines (≤30 ARCH-01)
- [x] `service.py` rewritten — 20 lines (≤30 ARCH-02)
- [x] `tests/test_scrobbler.py` — 13 tests covering 50% trigger, dedup, settings refresh
- [x] `tests/test_imports.py` extended — bootstrap and scrobbler smoke tests
- [x] Full pytest passes — 161 tests
- [x] `_ORIGINAL_ROUTES` snapshot present (B4 fix)
- [x] `set_routes()` called from `_patch_routes_with_context`
- [x] `parse_qs` used (not regex) in `_extract_track_id`
- [x] `onSettingsChanged` present
- [x] No `global connection = None` in either entry point
- [x] No `from simpleplugin` in either entry point
- [x] `from __future__ import annotations` in both new modules
