---
phase: 03-structural-refactor
plan: "07"
subsystem: playback-actions
tags:
  - bug-fix
  - extraction
  - cache
  - star-unstar
dependency_graph:
  requires:
    - 03-03  # router.py
    - 03-04  # api/client.py
    - 03-05  # cache.py, logging.py
  provides:
    - playback.py play_track handler
    - actions.py star_item/unstar_item/download_item handlers
    - BUG-05 cache invalidation + Container.Refresh after star/unstar
    - BUG-03 _parse_bool_param replacing fragile string checks
  affects:
    - tests/test_actions.py
tech_stack:
  added: []
  patterns:
    - "@route() decorator for handler registration"
    - "xbmc.executebuiltin('Container.Refresh') for UI refresh after mutations"
    - "cache.invalidate(key) for explicit cache busting"
    - "_parse_bool_param() for safe URL param bool parsing"
key_files:
  created:
    - resources/lib/subsonic/playback.py
    - resources/lib/subsonic/actions.py
    - tests/test_actions.py
  modified: []
decisions:
  - "playback.py imports xbmcgui + xbmcplugin because setResolvedUrl requires both — cannot avoid these imports"
  - "actions.py has NO xbmcgui/xbmcplugin (download_item uses log_error instead of Dialog popup for missing folder)"
  - "_parse_bool_param uses str().strip().lower() membership check — handles all legacy URL param variants safely"
metrics:
  duration_minutes: 8
  tasks_completed: 3
  files_created: 3
  files_modified: 0
  completed_date: "2026-04-28"
requirements:
  - ARCH-04
  - ARCH-10
  - BUG-03
  - BUG-05
---

# Phase 3 Plan 7: Playback and Actions Handler Extraction Summary

**One-liner:** Extracted `play_track`, `star_item`, `download_item` handlers into typed modules; fixed BUG-05 starred cache UI refresh and BUG-03 unstar bool parsing in-flight.

## Tasks Completed

| Task | Name | Commit | Files |
|------|------|--------|-------|
| 1 | Create playback.py | e9776f1 | resources/lib/subsonic/playback.py |
| 2 | Create actions.py with cache invalidation and UI refresh (BUG-05) | d20a50c | resources/lib/subsonic/actions.py |
| 3 | Write tests/test_actions.py | f5a2c50 | tests/test_actions.py |

## What Was Built

### resources/lib/subsonic/playback.py

Registers `@route("play_track")` handler. Resolves the stream URL via `client.stream_url(track_id, bitrate, fmt)` and hands it to Kodi via `xbmcplugin.setResolvedUrl()` — the URL is never embedded in a directory listing (avoids credential-in-cache-file pitfall). Sets `EstimateContentLength` property for gapless playback (PR #54 behavior preserved). Targeted `except Exception` with `log_exception` on failure.

### resources/lib/subsonic/actions.py

Registers `@route("star_item")` and `@route("download_item")`.

**BUG-05 fixed (main.py:739-740 TO FIX):**
- `cache.invalidate("starred")` after successful star/unstar so the next browse re-fetches the starred set
- `xbmc.executebuiltin("Container.Refresh")` after success so star icons update in the current listing immediately

**BUG-03 fixed (main.py:684 TO FIX):**
- `_parse_bool_param(value)` replaces `(unstar) and (unstar != 'None') and (unstar != 'False')`. New implementation: `str(value).strip().lower() in ("1", "true", "yes")` — handles all legacy URL string variants correctly.

**main.py:722 bare except fixed:**
- Replaced `except: pass` with `except Exception: log_exception(...)`.

No xbmcgui or xbmcplugin imports in actions.py.

### tests/test_actions.py

11 tests covering:
- `test_parse_bool_param_handles_none_and_strings` — all legacy string variants
- `test_star_item_invalidates_cache` — BUG-05 cache invalidation
- `test_star_item_calls_container_refresh` — BUG-05 UI refresh
- `test_star_item_no_invalidate_on_failure` — no side-effects on failure
- `test_star_item_no_container_refresh_on_failure` — no spurious refresh on failure
- `test_star_item_unstar_uses_client_unstar` — correct method dispatch
- `test_star_item_unstar_false_uses_client_star` — correct method dispatch
- `test_star_item_no_id_is_noop` — early return on empty id
- `test_star_item_album_type_uses_album_ids` — correct parameter routing
- `test_star_item_exception_does_not_invalidate_cache` — exception safety
- `test_unstar_invalidates_cache` — BUG-03 + BUG-05 combined: 'True' string + cache invalidation

## Deviations from Plan

### Auto-fixed Issues

None beyond minor adjustments.

### Scope Adjustments

**1. [Rule 2 - CLAUDE.md constraint] Removed xbmcgui from actions.py**
- **Found during:** Task 2
- **Issue:** `important_constraints` in execution context specified "actions.py imports xbmc (for executebuiltin) but NO xbmcgui or xbmcplugin". Plan code included `xbmcgui.Dialog().ok()` for download folder missing error.
- **Fix:** Replaced `Dialog().ok(...)` with `log_error(...)` — keeps the handler testable without Kodi UI, consistent with ARCH-05 (UI calls live in listings.py).
- **Files modified:** resources/lib/subsonic/actions.py
- **Commit:** d20a50c

**2. [Rule 2 - Critical functionality] os.makedirs before open in _download_tracks**
- **Found during:** Task 2
- **Issue:** Plan code called `os.makedirs` after `client.download()`. If makedirs fails, download was wasted.
- **Fix:** Moved `os.makedirs` before `client.download()` call.
- **Files modified:** resources/lib/subsonic/actions.py
- **Commit:** d20a50c

## Verification Results

```
.venv/bin/python -m pytest tests/test_actions.py -v
11 passed in 0.02s

.venv/bin/python -m pytest --tb=short
138 passed in 0.14s
```

All plan verification criteria met:
- Container.Refresh present in actions.py: YES
- cache.invalidate present in actions.py: YES
- No bare excepts in either module: YES
- `from __future__ import annotations` in both: YES
- No `# TO FIX` comments in new modules: YES
- No xbmcgui/xbmcplugin in actions.py: YES

## Known Stubs

None — all handlers are fully wired.

## Self-Check: PASSED

Files created:
- FOUND: resources/lib/subsonic/playback.py
- FOUND: resources/lib/subsonic/actions.py
- FOUND: tests/test_actions.py

Commits verified:
- e9776f1 — feat(03-07): create playback.py
- d20a50c — feat(03-07): create actions.py
- f5a2c50 — test(03-07): add test_actions.py
