---
phase: 03-structural-refactor
plan: "02"
subsystem: cache-and-logging
tags:
  - cache
  - logging
  - ttl
  - credential-safety
  - perf-02

dependency_graph:
  requires: []
  provides:
    - "Cache class (TTL get/invalidate/persist/starred_set)"
    - "safe_log credential-sanitizing xbmc.log wrappers"
  affects:
    - "actions.py (star/unstar will call cache.invalidate — BUG-05)"
    - "All future modules that call xbmc.log (route through safe_log)"

tech_stack:
  added: []
  patterns:
    - "dataclass with init=False private field for _entries dict"
    - "time.time() TTL pattern — patchable for tests"
    - "xbmcvfs.File context manager for JSON persistence"
    - "re.compile _AUTH_RE.sub redaction before xbmc.log"

key_files:
  created:
    - resources/lib/subsonic/cache.py
    - resources/lib/subsonic/logging.py
    - tests/test_cache.py
    - tests/test_logging.py
  modified: []

decisions:
  - "Cache stores (value, expires_at) tuples; no background refresh — lazy on-demand only"
  - "starred_set uses string comparison for ISO 8601 timestamps (lexicographic order works for same format)"
  - "safe_log prepends 'Subsonic: ' prefix to all log messages for easy grep"
  - "log_exception appends full traceback via traceback.format_exc()"
  - "Used f-string-free format() in logging.py for Python 3.8 compat (f-strings are fine but format() avoids any edge cases with % in messages)"

metrics:
  duration: "103s"
  completed: "2026-04-28"
  tasks_completed: 2
  tasks_total: 2
  files_created: 4
  files_modified: 0
---

# Phase 03 Plan 02: Cache and Logging Utilities Summary

**One-liner:** TTL dict cache with xbmcvfs JSON starred-set persistence (PERF-02) and `_AUTH_RE` credential-sanitizing `xbmc.log` wrappers.

## Tasks Completed

| Task | Name | Commit | Files |
|------|------|--------|-------|
| 1 | Create cache.py with TTL dict, xbmcvfs persistence, starred_set | 6c00d7e | resources/lib/subsonic/cache.py, tests/test_cache.py |
| 2 | Create logging.py with credential-safe log wrappers | b79d008 | resources/lib/subsonic/logging.py, tests/test_logging.py |

## What Was Built

### cache.py

`Cache` dataclass with `cache_dir: str` constructor param:

- `get(key, fetcher, ttl=300.0)` — returns cached value within TTL or calls fetcher, caches result
- `invalidate(key)` — removes key for BUG-05 star/unstar hook
- `persist_write(filename, data)` — serializes JSON via `xbmcvfs.File` context manager
- `persist_read(filename)` — deserializes JSON; returns `None` on any error
- `starred_set(fetcher, server_updated_ts)` — PERF-02: reads stored timestamp from `starred_cache.json`, calls fetcher only when `server_updated_ts > stored_ts` or no stored data exists; persists result

### logging.py

- `_AUTH_RE = re.compile(r"\b(p|t|s|password|token|salt|apiKey)=[^&\s]*")` — redacts auth params
- `safe_log(msg, level)` — sanitizes then calls `xbmc.log("Subsonic: " + sanitized, level)`
- `log_debug / log_info / log_warning / log_error` — level-specific convenience wrappers
- `log_exception(msg)` — appends `traceback.format_exc()` and logs at LOGERROR

## Test Coverage

**test_cache.py** (10 tests):
- TTL cache miss calls fetcher
- TTL cache hit returns cached value; fetcher called only once
- TTL expiry causes re-fetch (mock `time.time`)
- `invalidate()` forces re-fetch
- `invalidate()` on missing key is no-op
- `persist_write` calls `xbmcvfs.File.write` with bytearray-encoded JSON
- `persist_read` returns `None` on `xbmcvfs.File` exception
- `starred_set` calls fetcher + persists when server_updated_ts is newer (PERF-02)
- `starred_set` skips fetcher when timestamps match
- `starred_set` calls fetcher on first run (no stored data)

**test_logging.py** (8 tests):
- Redacts `p=`, `t=`+`s=`, `password=`, `apiKey=`
- Passes non-auth params through unchanged
- Calls `xbmc.log` exactly once per `safe_log` call
- `log_error` uses `xbmc.LOGERROR` level
- `log_debug` uses `xbmc.LOGDEBUG` level

## Deviations from Plan

None — plan executed exactly as written. Both modules match the skeletons in 03-CONTEXT.md specifics section verbatim (with the addition of `log_exception` as a natural complement documented in the plan's action block).

## Known Stubs

None. Both modules are fully implemented with no hardcoded empty values or placeholder text.

## Self-Check: PASSED
