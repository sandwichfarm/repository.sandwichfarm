# Phase 3: Structural Refactor - Context

**Gathered:** 2026-04-28
**Status:** Ready for planning

<domain>
## Phase Boundary

Phase 3 transforms the 1561-line procedural `main.py` and 60-line `service.py` into a layered, tested package under `resources/lib/subsonic/`. The plugin and service entry points become thin bootstraps (≤ 30 lines each). A first-party decorator router replaces the vendored `simpleplugin`. Handler logic is split into focused modules (`browse`, `search`, `playback`, `actions`). The Subsonic API client gets a single boundary (`api/client.py`) that owns auth-mode selection, request building, and the OpenSubsonic capability probe (probe code is added in Phase 3 but exercised in Phase 4). All Kodi UI calls live in `listings.py` so business logic is testable. State that was previously global (the `connection` singleton, the pickled starred cache) is killed; replacements are constructor-injected and isolated per process. All `ListItem.setInfo('music', ...)` callsites migrate to `InfoTagMusic` typed setters. All bare `except:` blocks across `main.py` (and any remaining in `service.py`) are replaced with targeted exception handling. All 8 inline `# TO FIX` comments are addressed in-flight as their containing handlers are extracted. Pagination correctness is rewritten using `len(items) < page_size` rather than the broken `# TO FIX` stubs. Per-session caching with timestamp-based invalidation replaces the disk pickle. Cover art uses `getCoverArt` with an explicit `size` param. Listings declare `setContent` correctly (`'songs'`/`'albums'`/`'artists'`) and call `addSortMethod`. Each new module gets a dedicated `tests/test_<module>.py` aimed at ~70% coverage on new code, all passing on the existing CI matrix from Phase 1.

Out of scope: Auth modernization (Phase 4) — Phase 3 only sets up the boundary; it doesn't switch to salt+token, doesn't gate API-key auth, and doesn't probe extensions at runtime. New features (Phase 5). Live server verification (Phase 6). Removing the vendored `lib/simpleplugin/` directory entirely — keep it on disk but don't import from it; deletion is a Phase 6 cleanup.

</domain>

<decisions>
## Implementation Decisions

### Package layout (locked by user)

- New code lives under `resources/lib/subsonic/`
- `main.py` and `service.py` add `resources/lib` to `sys.path` (or rely on Kodi's `<library>` declaration in `addon.xml`)
- Imports look like `from subsonic.router import route, dispatch` (NOT `from resources.lib.subsonic...`)
- `addon.xml` updated to declare the library if needed (research-locked: tidal2-style `<library>` element)

### Module breakdown (locked by research, confirmed by user "Recommended" Standard granularity)

- `resources/lib/subsonic/__init__.py` — package marker (empty or version export)
- `resources/lib/subsonic/router.py` — decorator-based router on `xbmcplugin`/`sys.argv` (~120 LOC max)
- `resources/lib/subsonic/settings.py` — typed facade over `xbmcaddon.Addon().getSetting()`. One injection point for tests. Keeps every existing `id=` from `resources/settings.xml` verbatim.
- `resources/lib/subsonic/models.py` — `TypedDict`s for Subsonic API responses (Album, Artist, Track, Playlist, Genre, etc.) + `@dataclass`es for internal state (PlayContext, ListContext, CacheEntry, etc.)
- `resources/lib/subsonic/api/__init__.py` — package marker
- `resources/lib/subsonic/api/client.py` — single boundary to libsonic. Owns auth-mode selection, URL building, and the OpenSubsonic capability probe (probe stub in Phase 3, real auth migration in Phase 4)
- `resources/lib/subsonic/cache.py` — TTL `dict[str, tuple[value, expires_at]]` + optional `xbmcvfs` JSON file persistence for starred set
- `resources/lib/subsonic/listings.py` — all `xbmcplugin` + `xbmcgui.ListItem` calls; uses `InfoTagMusic` typed setters (NOT deprecated `setInfo`); declares `setContent` and `addSortMethod` per listing
- `resources/lib/subsonic/browse.py` — handlers for menu/list_albums/list_artists/list_tracks/list_playlists; registered with `@route()`
- `resources/lib/subsonic/search.py` — search handlers (Phase 5 will swap `search2` → `search3`; Phase 3 keeps current behavior)
- `resources/lib/subsonic/playback.py` — `play_track` handler and stream URL resolution
- `resources/lib/subsonic/actions.py` — context actions (star/unstar, download, refresh)
- `resources/lib/subsonic/scrobbler.py` — `xbmc.Monitor` subclass; receives injected `ApiClient`
- `resources/lib/subsonic/logging.py` — credential-safe `xbmc.log()` wrappers (sanitizes auth params from URLs); no leaks (AUTH-06 lands here, full audit happens in Phase 4)

### Build order (locked by research's 7-step plan)

Wave 1 (foundation — pure new code, no main.py edits): `__init__.py` + `models.py` + `settings.py` + `cache.py` + `router.py` + `logging.py`
Wave 2 (libsonic boundary + first handler extraction): `api/client.py` + `listings.py`
Wave 3 (handler extraction in parallel — no shared module surface): `browse.py`, `search.py`, `playback.py`, `actions.py`
Wave 4 (entry-point shrink + service.py rewrite): `main.py` and `service.py` reduced to bootstraps; `scrobbler.py` extracted
Wave 5 (cross-cutting cleanups): `setInfo` → `InfoTagMusic` migration sweep; remaining bare-`except:` cleanup; `# TO FIX` resolutions if any remain after handler extraction; pagination correctness fixes; `setContent` + `addSortMethod` everywhere
Wave 6 (verification): smoke tests + full pytest run + import + lint + checkpoint

### TO FIX handling (locked by user — fix in-flight)

As each handler module is extracted, the executor identifies any `# TO FIX` comments in the source code being moved and fixes them in the same task. The 8 comments are in `main.py` — they should be GONE from the codebase after Wave 5 verification. If any cannot be fixed in-flight (because the fix needs Phase 4+ work), document them in the SUMMARY and add to a "Phase 3 deferred" list.

### Type hint scope (locked by user — comprehensive)

Every new module uses `from __future__ import annotations` at the top. Every function and method has type hints. Every dataclass has type hints. Mypy `--strict` is the target on new code; the CI mypy job (already running from Phase 1) targets `--python-version 3.8` and ignores the vendored libs. Vendored `lib/libsonic/` and `lib/simpleplugin/` are explicitly excluded from mypy. `tests/` may be lenient.

### Test depth (locked by user — per-module unit tests)

Each new module gets `tests/test_<module>.py`. Target ~70% line coverage on new code. The riskiest modules (`router`, `api/client`, `cache`, `models`, `listings`) get deeper coverage. Smoke import tests stay in `tests/test_imports.py` and get extended to cover all new modules.

### State elimination (locked)

- Global `connection = None` in `main.py` deleted; `ApiClient` is constructed in the bootstrap, passed into the router context, threaded through to handlers
- Pickled starred cache (`plugin.get_storage()`) replaced with `cache.py`'s in-memory + `xbmcvfs` JSON file
- `local_starred` module variable killed; same data lives in the cache module
- `service.py` constructs its own `ApiClient` (separate process — must not share globals with the plugin process)

### Settings preservation (locked — COMPAT-06)

The typed facade in `settings.py` exposes Python attribute names that may differ from the `id=` attrs in `settings.xml`, but every `getSetting('id')` callsite uses the literal id. The facade reads them; downstream code reads from the facade. Existing user installs keep their values. NO `id=` rename or removal in this phase.

### Pagination correctness (locked)

`# TO FIX` pagination stubs replaced with: `if len(returned_items) >= page_size: append_next_page_link()`. No `len(items) < page_size` end-detection misuse. Page sizes from settings (`albums_per_page`, `tracks_per_page`).

### setInfo → InfoTagMusic migration (locked — COMPAT-05)

Every `li.setInfo('music', {...})` call in `listings.py` (after extraction) becomes:
```python
tag = li.getMusicInfoTag()
tag.setTitle(...)
tag.setArtist(...)
tag.setAlbum(...)
# ...etc
```
Map every key in the old dict to the corresponding `InfoTagMusic` setter. Skip keys that have no equivalent (rare).

### Cover art (locked — PERF-04)

`listings.py` uses `connection.getCoverArtUrl(coverArt_id, size=512)` (or whatever skin needs). Don't fetch full-resolution thumbs. Kodi's art-cache hints set via `li.setArt({'thumb': url, 'fanart': fanart_url})`.

### setContent + addSortMethod (locked — PERF-05)

Every `endOfDirectory` call site declares `xbmcplugin.setContent(handle, '<type>')` first and adds appropriate `addSortMethod` calls. Types: `'albums'`, `'artists'`, `'songs'`, `'playlists'`, `'genres'`.

### Cache module specifics (locked — PERF-01, PERF-02)

`cache.py`:
- `class Cache:` — constructor takes a `cache_dir` (xbmcvfs profile dir)
- `get(key, fetcher, ttl=300)` — returns cached value or calls fetcher then caches
- `invalidate(key)` — explicit invalidation hook used by star/unstar
- `starred_set()` — special case backed by xbmcvfs JSON; honors server `updated` timestamp
- All times in seconds. No background refresh. Lazy on-demand only.

### Process isolation (locked)

- The plugin (`main.py`) and the service (`service.py`) construct independent `ApiClient` instances
- They cannot share Python module state
- If they need to communicate (Phase 6 might want this for cache invalidation), use `xbmcgui.Window(10000)` properties — but Phase 3 does not introduce that

### Claude's Discretion

- Exact dataclass field names, exact `TypedDict` shapes — derive from libsonic response samples
- Whether to use `@runtime_checkable Protocol` vs ABC for the `ApiClient` interface — pick what tests cleaner
- Whether `settings.py` exposes properties or simple attribute reads on a frozen dataclass — pick what tests cleaner
- Internal helper functions (sanitize_log_url, etc.) live in `logging.py` or a `_utils.py`?  Default: `logging.py`
- Test fixture style — pytest fixtures vs simple module-level mocks; pick what reads cleanest

</decisions>

<code_context>
## Existing Code Insights

### Reusable Assets

- `tests/conftest.py` from Phase 1 — already mocks all Kodi APIs in `sys.modules`. New module tests reuse this.
- `pyproject.toml` from Phase 1 — already has `[tool.ruff]`, `[tool.mypy]`, `[tool.pytest.ini_options]` configured. New module sources need to be findable by mypy.
- `.planning/codebase/ARCHITECTURE.md` and `.planning/codebase/STRUCTURE.md` — current monolith layout reference
- `.planning/codebase/CONCERNS.md` — line refs for the 8 `# TO FIX` and remaining bare excepts (lines 410, 475, 711, 1247 per Phase 1 final state)
- `.planning/research/ARCHITECTURE.md` — definitive architecture reference (read it before planning)
- `.planning/research/STACK.md` — locked tooling
- `lib/libsonic/connection.py` — the API the new `api/client.py` wraps. Inspect to learn the response shape for TypedDicts.

### Established Patterns

- `Addon().get_setting('id')` for settings reads — the typed facade wraps this, doesn't replace it
- `xbmc.log(...)` for logging with severity levels — keep, but route through `logging.py` for sanitization
- `@plugin.action` decorators (simpleplugin) — replaced by `@route()` in the new router
- Walk generators (`walk_albums`, `walk_artist`, etc.) — keep the generator pattern, just move it into modules

### Integration Points

- `addon.xml` may need `<library>` declaration so Kodi adds `resources/lib/` to sys.path automatically — verify against tidal2's manifest
- `tests/conftest.py` may need updating to also mock `xbmcvfs.translatePath` returning a fake profile dir for `cache.py` tests
- `tests/test_imports.py` extended with one `test_import_<module>` per new module
- The `simpleplugin.Plugin` class is currently instantiated at module import in `main.py` — that line goes away when main.py becomes a bootstrap

### Files modified (planning level, predicted, very large)

- New: ~13 files under `resources/lib/subsonic/` plus `api/`
- New: ~10 files under `tests/`
- Heavily modified or fully rewritten: `main.py`, `service.py`
- Possibly modified: `addon.xml` (library declaration), `tests/conftest.py` (xbmcvfs mock), `tests/test_imports.py` (extend smoke test)
- Deleted: nothing (`lib/simpleplugin/` stays on disk for now even though no longer imported)

</code_context>

<specifics>
## Specific Ideas

### Bootstrap structure

`main.py` after refactor:
```python
import sys
import os

ADDON_DIR = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(ADDON_DIR, "resources", "lib"))

from subsonic.bootstrap import run_plugin

if __name__ == "__main__":
    run_plugin(sys.argv)
```

`service.py` after refactor:
```python
import sys
import os

ADDON_DIR = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(ADDON_DIR, "resources", "lib"))

from subsonic.bootstrap import run_service

if __name__ == "__main__":
    run_service()
```

`subsonic.bootstrap.run_plugin` constructs the `ApiClient`, the `Cache`, the router, then calls `dispatch(sys.argv)`.

### Router decorator skeleton

```python
# router.py
from typing import Callable, Dict, Any
from urllib.parse import parse_qsl, urlencode

_ROUTES: Dict[str, Callable] = {}

def route(action: str) -> Callable[[Callable], Callable]:
    def decorator(fn: Callable) -> Callable:
        _ROUTES[action] = fn
        return fn
    return decorator

def url_for(fn: Callable, **kwargs: Any) -> str:
    action = next((k for k, v in _ROUTES.items() if v is fn), fn.__name__)
    base = "plugin://plugin.audio.subsonic/"
    return f"{base}?{urlencode({'action': action, **kwargs})}"

def dispatch(argv: list[str]) -> None:
    qs = argv[2].lstrip("?")
    params = dict(parse_qsl(qs))
    action = params.pop("action", "root")
    handler = _ROUTES.get(action)
    if handler is None:
        # log + endOfDirectory(False)
        return
    handler(params)
```

### TypedDict sample

```python
# models.py
from typing import TypedDict, List, Optional

class Album(TypedDict, total=False):
    id: str
    name: str
    artist: str
    artistId: str
    coverArt: str
    songCount: int
    duration: int
    created: str
    starred: Optional[str]
    year: int
    genre: str
    musicBrainzId: str
```

### Logging sanitizer

```python
# logging.py
import re
from typing import Any
import xbmc

_AUTH_RE = re.compile(r"\b(p|t|s|password|token|salt|apiKey)=[^&\s]*")

def safe_log(msg: str, level: int = xbmc.LOGINFO) -> None:
    xbmc.log(_AUTH_RE.sub(r"\1=REDACTED", msg), level)
```

(Phase 4 expands this — Phase 3 just establishes the module and routes existing log calls through it where touched.)

### Cache skeleton

```python
# cache.py
import time
import json
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Tuple, Optional

@dataclass
class Cache:
    cache_dir: str
    _entries: Dict[str, Tuple[Any, float]] = field(default_factory=dict)

    def get(self, key: str, fetcher: Callable[[], Any], ttl: float = 300) -> Any:
        now = time.time()
        if key in self._entries:
            value, expires = self._entries[key]
            if expires > now:
                return value
        value = fetcher()
        self._entries[key] = (value, now + ttl)
        return value

    def invalidate(self, key: str) -> None:
        self._entries.pop(key, None)
```

</specifics>

<deferred>
## Deferred Ideas

- **Switching to salt+token auth (AUTH-01) and OpenSubsonic API-key auth (AUTH-04)** — Phase 4 owns these. Phase 3's `api/client.py` includes the BOUNDARY but keeps the existing auth-mode behavior unchanged.
- **Running the OpenSubsonic capability probe (AUTH-03)** — same; Phase 3 may include the method but doesn't call it on first connect.
- **Full credential-leak audit (AUTH-06)** — Phase 3 routes `xbmc.log()` calls through `logging.py.safe_log` where they're touched, but a project-wide sweep is Phase 4.
- **Genre browsing (FEAT-01), search3 (FEAT-02), rating (FEAT-03), radio (FEAT-04), MusicBrainz IDs (FEAT-05)** — Phase 5.
- **Removing vendored `lib/simpleplugin/` from disk** — Phase 6 cleanup. Phase 3 just stops importing from it.
- **Live server verification of refactored handlers** — Phase 6.
- **Replacing pickle-backed storage entirely** — Phase 3 introduces the new cache for starred set; the broader `plugin.get_storage()` removal is incremental, may extend into Phase 5.

</deferred>
