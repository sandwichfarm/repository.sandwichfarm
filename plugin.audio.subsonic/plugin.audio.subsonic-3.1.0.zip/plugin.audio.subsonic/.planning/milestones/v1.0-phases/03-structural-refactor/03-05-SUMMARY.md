---
phase: 03-structural-refactor
plan: 05
subsystem: listings
tags: [kodi-ui, infotag-music, compat-05, arch-05, perf-04, perf-05, test-06]
dependency_graph:
  requires:
    - 03-01  # models.py (SubsonicTrack, SubsonicAlbum, SubsonicArtist, SubsonicPlaylist)
  provides:
    - listings.py (build_track_item, build_album_item, build_artist_item, build_playlist_item, end_directory, add_items, show_search_dialog)
  affects:
    - browse.py (Wave 3 — imports listings for all UI output)
    - search.py (Wave 3 — imports show_search_dialog from listings)
    - playback.py (Wave 3 — imports build_track_item from listings)
tech_stack:
  added: []
  patterns:
    - InfoTagMusic typed setters (getMusicInfoTag().setTitle/setArtist/setAlbum/setDuration/etc)
    - end_directory setContent + addSortMethod before endOfDirectory
    - show_search_dialog Dialog().input wrapper
key_files:
  created:
    - resources/lib/subsonic/listings.py
    - tests/test_listings.py
  modified: []
decisions:
  - "_mock_list_item() uses plain MagicMock (no spec=) because xbmcgui.ListItem is itself a MagicMock in the test environment — speccing a Mock with a Mock raises InvalidSpecError"
  - "Module docstring replaced 'setInfo(music, {...})' with 'dict-based setInfo API' to avoid false-positive from the source-inspection test"
metrics:
  duration_minutes: 1
  completed_date: "2026-04-28"
  tasks_completed: 1
  files_created: 2
---

# Phase 03 Plan 05: listings.py — InfoTagMusic Builders Summary

**One-liner:** Created listings.py with getMusicInfoTag() typed setters for all item types, end_directory setContent/addSortMethod enforcement, and show_search_dialog xbmcgui isolation helper.

## What Was Built

`resources/lib/subsonic/listings.py` is the single module that owns all `xbmcplugin` and `xbmcgui.ListItem` calls. Handler modules (browse, search, playback) import from here exclusively — keeping them Kodi-UI-free and unit-testable (ARCH-05).

**Exports:**
- `build_track_item(track, url, cover_url, hide_artist)` — playable track with InfoTagMusic setters
- `build_album_item(album, url, cover_url, hide_artist)` — album folder with InfoTagMusic setters
- `build_artist_item(artist, url, cover_url)` — artist folder with tag.setArtist()
- `build_playlist_item(playlist, url, cover_url)` — playlist folder with InfoTagMusic setters
- `build_nav_item(label, url)` — navigation item (Next Page, etc.)
- `add_items(handle, items)` — bulk addDirectoryItem
- `end_directory(handle, content, sort_methods, succeeded, ...)` — setContent + addSortMethod + endOfDirectory
- `show_search_dialog(prompt)` — wraps Dialog().input, returns None on cancel/empty

**Key architectural constraints enforced:**
- Zero `setInfo('music', ...)` calls — 100% InfoTagMusic typed setters (COMPAT-05)
- Cover art passed in as pre-sized URL by caller (PERF-04 constraint on callers)
- `end_directory` always calls `setContent` and then `addSortMethod` before `endOfDirectory` (PERF-05)
- `show_search_dialog` isolates xbmcgui from handler modules (ARCH-05)

## Tests

`tests/test_listings.py` — 16 tests, all pass.

Covers:
- `getMusicInfoTag()` called for track/album/artist builders
- `setInfo` never called (mock assertion)
- `setArt` receives correct thumb/fanart dict
- `is_folder` return values (tracks=False, albums/artists/playlists=True)
- `end_directory`: setContent called with correct content type
- `end_directory`: addSortMethod called N times for N sort_methods
- `end_directory`: endOfDirectory called with correct handle
- `add_items`: addDirectoryItem called once per item with correct args
- Source inspection: no `setInfo('music'` in listings.py source
- `show_search_dialog`: returns query string on user input
- `show_search_dialog`: returns None on empty/cancel

## Deviations from Plan

### Auto-fixed Issues

**1. [Rule 1 - Bug] `_mock_list_item()` spec= caused InvalidSpecError**
- **Found during:** Task 1 GREEN phase
- **Issue:** `MagicMock(spec=xbmcgui.ListItem)` raises `InvalidSpecError: Cannot spec a Mock object` because `xbmcgui.ListItem` is itself a MagicMock in the test environment
- **Fix:** Removed `spec=xbmcgui.ListItem` from `_mock_list_item()` helper — plain `MagicMock()` is sufficient since we assert specific method calls
- **Files modified:** `tests/test_listings.py`
- **Commit:** 8286b1a

**2. [Rule 1 - Bug] Module docstring triggered source-inspection test failure**
- **Found during:** Task 1 GREEN phase  
- **Issue:** The module docstring contained the literal string `setInfo('music', {...})` as an example of what NOT to do — causing `test_no_setinfo_music_in_listings_module` to fail
- **Fix:** Replaced the exact string with `dict-based setInfo API` in both the module docstring and the `build_track_item` docstring
- **Files modified:** `resources/lib/subsonic/listings.py`
- **Commit:** 8286b1a

## Self-Check: PASSED

- resources/lib/subsonic/listings.py: FOUND
- tests/test_listings.py: FOUND
- commit 70a1e67 (test RED): FOUND
- commit 8286b1a (feat GREEN): FOUND
