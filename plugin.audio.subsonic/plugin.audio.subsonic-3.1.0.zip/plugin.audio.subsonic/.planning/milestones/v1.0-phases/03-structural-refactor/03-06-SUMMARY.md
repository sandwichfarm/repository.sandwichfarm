---
phase: 03-structural-refactor
plan: "06"
subsystem: handlers/browse-search
tags: [browse, search, pagination, bug-fix, arch-05, bug-03, bug-04]
dependency_graph:
  requires:
    - 03-03  # router.py
    - 03-04  # api/client.py
    - 03-05  # listings.py
  provides:
    - browse.py handlers (root, menu_albums, list_albums, list_artists, list_tracks, list_playlists)
    - search.py handlers (search, search_album)
  affects:
    - 03-08  # bootstrap wiring — will call these handlers with injected context
tech_stack:
  added: []
  patterns:
    - "@route() decorator — handler registration"
    - "len(items) >= page_size pagination pattern (BUG-04)"
    - "track.setdefault('track', i+1) playlist tracknumber fix (BUG-03)"
    - "show_search_dialog via listings — no xbmcgui in search.py (ARCH-05)"
key_files:
  created:
    - resources/lib/subsonic/browse.py
    - resources/lib/subsonic/search.py
    - tests/test_browse.py
    - tests/test_search.py
  modified: []
decisions:
  - "browse.py list_albums: artist_id view doesn't paginate (all albums loaded at once)"
  - "browse.py list_tracks: starred and random tracks never paginate"
  - "search.py uses show_search_dialog from listings.py — no direct xbmcgui import (ARCH-05)"
  - "Phase 3 keeps search2 behavior; search3 migration deferred to Phase 5 (FEAT-02)"
metrics:
  duration_minutes: 2
  completed_date: "2026-04-28"
  tasks_completed: 2
  files_created: 4
---

# Phase 3 Plan 6: Browse and Search Handler Extraction Summary

Extracted browse and search handlers from main.py into `browse.py` and `search.py`, registered with the `@route()` decorator. Fixed the two pagination `# TO FIX` bugs (BUG-03, BUG-04) in-flight. No Kodi UI calls in either handler module — all UI via `listings.py`. `search.py` uses `show_search_dialog` from `listings.py` instead of importing `xbmcgui` (ARCH-05).

## Tasks Completed

| Task | Name | Commit | Files |
|------|------|--------|-------|
| 1 | browse.py with pagination fix and all browse handlers | dd6a712 | resources/lib/subsonic/browse.py, tests/test_browse.py |
| 2 | search.py using show_search_dialog (no xbmcgui import) | cbaa857 | resources/lib/subsonic/search.py, tests/test_search.py |

## One-liner

BUG-04 pagination fixed (`len(items) >= page_size`), BUG-03 tracknumber fixed (enumerate position), ARCH-05 satisfied (search.py uses `show_search_dialog` from `listings.py`).

## What Was Built

### `resources/lib/subsonic/browse.py`

- `root` — Main menu with links to artists, albums (by type), tracks, playlists, search
- `menu_albums` — Sub-menu for decade-based year filtering; genre placeholder (Phase 5)
- `list_albums` — Albums listing with corrected pagination (BUG-04 fix)
- `list_artists` — All artists from ID3 tag library via `client.get_artists()`
- `list_tracks` — Tracks listing for album, playlist, starred, random views (BUG-03 fix for playlist tracknumbers)
- `list_playlists` — All playlists

### `resources/lib/subsonic/search.py`

- `search` — Mixed artist/album/song results via search2; uses `show_search_dialog` (ARCH-05)
- `search_album` — Album-only search with `artistCount=0, songCount=0`

## Bugs Fixed In-Flight

### BUG-04: Pagination always showed "Next Page" (main.py:462, main.py:559)

Original code had `# if type(items) != type(True): TO FIX` — the stub unconditionally appended a Next Page link. The new code:

```python
has_more = (not is_random) and (len(items) >= albums_per_page)
```

Next Page is only appended when the server returned a full page of results. Empty pages and partial pages correctly show no Next Page.

### BUG-03: Playlist tracknumbers always 0 (main.py:515)

Original code had `#TO FIX tracknumber = 0 for item in items...` commented out. The new code:

```python
for i, item in enumerate(raw_items):
    track = dict(item)
    track.setdefault("track", i + 1)
    items.append(track)
```

Playlist entries receive `track` field from their position so `InfoTagMusic.setTrackNumber()` in `build_track_item` works correctly.

## Deviations from Plan

### Auto-fixed Issues

None — plan executed exactly as written. The TO FIX comments at main.py:462, main.py:515, and main.py:559 were all addressed in-flight within browse.py as intended.

### Deferred

- `main.py:670` `#TO FIX better statement ?` — unstar bool parsing. This belongs in `actions.py` (Plan 07) as noted in the plan context. Not touched here.
- Genre browsing in `menu_albums` is a stub placeholder (`(Genre browsing in Phase 5)`). This is intentional per the plan — Phase 5 will fill in `list_genres`.

## Known Stubs

- `menu_albums` with `menu_id="by_genre"` shows a placeholder `"(Genre browsing in Phase 5)"` item. This is intentional and documented in the plan as a Phase 5 feature. The `list_genres` handler is not implemented in this plan.

## Test Summary

- `tests/test_browse.py` — 11 tests, all pass
  - Pagination: full page shows Next Page, partial page does not
  - Random albums/tracks: never show Next Page
  - Playlist tracknumber assignment from enumerate position
  - Offset calculation for page N
  - Module import hygiene (no xbmcplugin/xbmcgui)

- `tests/test_search.py` — 8 tests, all pass
  - Import hygiene (no xbmcgui/xbmcplugin, show_search_dialog present)
  - search handler: calls client.search() with correct counts
  - Cancelled search: ends directory with succeeded=False
  - search_album: passes artist_count=0, song_count=0
  - Result item building (artist + album + track items)

Full test suite: 146 tests, all pass.

## Self-Check: PASSED
