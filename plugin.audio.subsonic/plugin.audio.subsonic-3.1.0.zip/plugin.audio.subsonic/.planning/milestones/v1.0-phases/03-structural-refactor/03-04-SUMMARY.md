---
phase: 03-structural-refactor
plan: "04"
subsystem: api-boundary
tags:
  - api
  - libsonic
  - auth-boundary
  - modernization
  - tdd
dependency_graph:
  requires:
    - 03-01  # settings.py facade
    - 03-02  # models.py
  provides:
    - subsonic.api.client.ApiClient
    - modernized lib/libsonic/connection.py
  affects:
    - 03-05  # listings.py (Wave 2 parallel)
    - Wave 3 handlers (browse, search, playback, actions)
tech_stack:
  added:
    - resources/lib/subsonic/api/__init__.py
    - resources/lib/subsonic/api/client.py
  patterns:
    - Dependency injection (Settings → ApiClient constructor)
    - TDD (RED → GREEN, no REFACTOR pass needed)
    - Thin wrapper pattern (ApiClient delegates to libsonic)
key_files:
  created:
    - resources/lib/subsonic/api/__init__.py
    - resources/lib/subsonic/api/client.py
    - tests/test_api_client.py
  modified:
    - lib/libsonic/connection.py
decisions:
  - "ApiClient constructed with Settings object — no module-level connection singleton (ARCH-11)"
  - "stream_url() delegates entirely to libsonic.streamUrl() — no credential injection in ApiClient itself"
  - "get_open_subsonic_extensions() is a Phase 3 stub — exists but never called automatically (Phase 4 will wire this to auth-mode selection)"
  - "legacyAuth flag forwarded verbatim to libsonic — Phase 3 keeps existing auth behaviour unchanged"
metrics:
  duration_minutes: 2
  completed_date: "2026-04-28"
  tasks_completed: 2
  files_changed: 4
---

# Phase 3 Plan 4: API Client Boundary + libsonic Modernization Summary

**One-liner:** ApiClient wrapping libsonic.Connection with Settings injection, plus removal of Python 2 dead code from libsonic/connection.py.

## What Was Built

### Task 1: Modernize lib/libsonic/connection.py
- Removed dead Python 2 SSL version check (`if sys.version_info[:3] >= (2, 7, 9):`). We target Python 3.8+ only; the check was dead code. `ssl._create_unverified_context()` is now called directly when `insecure=True`.
- Removed debug `print()` and `xbmc.log("Got a folder ...")` at `__init__` lines 162-163. These leaked path information and had no log-level guard.
- `urllib2` references were already absent (fixed in Phase 1) — no further changes needed.

### Task 2: Create resources/lib/subsonic/api/ package (TDD)
- `resources/lib/subsonic/api/__init__.py` — package marker.
- `resources/lib/subsonic/api/client.py` — `ApiClient` class (249 lines). Wraps libsonic.Connection, constructed from Settings. Exposes: `ping`, `get_album_list`, `get_album`, `get_artists`, `get_artist`, `get_playlists`, `get_playlist`, `get_starred`, `get_random_songs`, `search`, `stream_url`, `get_cover_art_url`, `star`, `unstar`, `scrobble`, `download`, `get_open_subsonic_extensions`.
- `tests/test_api_client.py` — 26 unit tests. All pass (116/116 in full suite).

## Verification Results

- `grep -rn "urllib2" lib/libsonic/connection.py` → 0 hits
- `grep "version_info.*2.*7.*9" lib/libsonic/connection.py` → 0 hits
- `grep "print.*hostname\|xbmc.log.*Got a folder" lib/libsonic/connection.py` → 0 hits
- `.venv/bin/python -m pytest tests/test_api_client.py -v` → 26 passed
- `.venv/bin/python -m pytest` → 116 passed, 0 failed
- `ApiClient` import with Kodi mocks → OK
- `grep "connection = None" resources/lib/subsonic/api/client.py` → 0 hits (no global state)
- `grep "from __future__ import annotations" resources/lib/subsonic/api/client.py` → present

## Commits

| Task | Commit | Description |
|------|--------|-------------|
| 1 | db55d7a | fix(03-04): modernize libsonic/connection.py - remove Py2 cruft |
| 2 (RED) | 4e83d97 | test(03-04): add failing tests for ApiClient (TDD RED) |
| 2 (GREEN) | 4ca7da1 | feat(03-04): add ApiClient — single boundary to libsonic (TDD GREEN) |

## Deviations from Plan

### Auto-fixed Issues

None — plan executed exactly as written.

**Note on urllib2:** The plan listed urllib2 removal as Task 1 Edit 1 and Edit 2, but grep confirmed zero `urllib2` references existed in connection.py before this plan ran. Phase 1 already fixed them. The SSL version check and debug prints were the actual targets in connection.py.

## Known Stubs

**get_open_subsonic_extensions() — intentional Phase 3 stub:**
- File: `resources/lib/subsonic/api/client.py`
- The method exists and is tested, but ApiClient does not call it at connect-time.
- Phase 4 will wire this into auth-mode selection (probe on first connect, cache result, use apiKey auth if server supports it).
- This is by design per the plan constraints: "Phase 3 establishes the BOUNDARY but does NOT switch to salt+token auth."

## Self-Check: PASSED

Files verified:
- FOUND: resources/lib/subsonic/api/__init__.py
- FOUND: resources/lib/subsonic/api/client.py
- FOUND: tests/test_api_client.py

Commits verified:
- FOUND: db55d7a
- FOUND: 4e83d97
- FOUND: 4ca7da1
