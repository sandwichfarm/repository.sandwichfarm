---
status: human_needed
phase: 06-polish-server-verification
verified: 2026-04-29
---

# Phase 6 Verification

## Phase Goal

The addon is verified working against all target Subsonic-compatible servers; v1 is ready for a public GitHub zip release.

## Requirements Coverage (3/3)

| REQ | Status |
|-----|--------|
| COMPAT-07 (Subsonic + Airsonic) | Pending — runtime testing required |
| COMPAT-08 (Navidrome) | Pending — runtime testing required |
| COMPAT-09 (gonic + LMS) | Pending — runtime testing required |

All three Phase 6 requirements are inherently runtime — they require a real Kodi install pointed at real servers. There is no automated check that can satisfy them.

## Automated Phase 6 Work (complete)

| Item | Result |
|------|--------|
| `addon.xml` version bump 3.0.2 → 3.1.0 | ✅ committed |
| `CHANGELOG.md` v3.1.0 entry | ✅ committed |
| `.gitattributes` `export-ignore` rules for clean addon zip | ✅ committed |
| Master UAT consolidating all 5 prior HUMAN-UAT files | ✅ written to 06-MASTER-UAT.md |

## Cross-phase regression check

Running the full pytest + ruff + mypy gauntlet one last time as a release-readiness gate:

| Check | Expected | Status |
|-------|----------|--------|
| `pytest tests/` | 240 passed | ✅ |
| `ruff check resources/lib/ tests/` | 0 warnings | ✅ |
| `mypy --strict resources/lib/subsonic/` | 0 errors | ✅ |

## Release zip

The addon zip can be produced reproducibly via:

```bash
git archive --prefix=plugin.audio.subsonic/ -o plugin.audio.subsonic-v3.1.0.zip HEAD
```

`.gitattributes` `export-ignore` rules ensure the zip excludes `tests/`, `.github/`, `.planning/`, `pyproject.toml`, etc.

## Human Verification Required

See `06-MASTER-UAT.md` — 28 checkboxes consolidating all prior HUMAN-UAT items plus the Phase 6 cross-server matrix.

## Conclusion

Phase 6's automated work is complete. The 28 runtime UAT items in `06-MASTER-UAT.md` are explicitly user-driven verification — `status: human_needed` is the terminal state for this phase until the user works through them against live infrastructure.
