---
status: partial
phase: 06-polish-server-verification
source: [01-HUMAN-UAT.md, 02-HUMAN-UAT.md, 03-HUMAN-UAT.md, 04-HUMAN-UAT.md, 05-HUMAN-UAT.md]
started: 2026-04-29T00:00:00Z
updated: 2026-04-29T00:00:00Z
---

# Master UAT — plugin.audio.subsonic v3.1.0

This is the consolidated runtime test plan for the v1 milestone. Every prior phase persisted runtime checks here. Work through these against real Kodi + Subsonic-compatible servers and tick each box as you go.

## Prerequisites

- Kodi 21 Omega installed (preferred) and/or Kodi 20 Nexus
- At least one of: Subsonic (legacy), Airsonic, Navidrome, gonic, LMS — running and reachable
- Optional: API key configured on Navidrome for the API-key auth tests

## Server matrix

| Server | Auth modes to exercise | Expected feature coverage |
|--------|------------------------|---------------------------|
| Subsonic / Airsonic | salt+token, legacy | All non-OpenSubsonic features |
| Airsonic + LDAP | legacy (forced fallback) | Browse/play; auth fallback |
| Navidrome | salt+token, API-key | All features incl. OpenSubsonic |
| gonic | salt+token, API-key (best effort) | Browse, play, star |
| LMS | salt+token | Browse, play |

---

## 1 — Phase 1: Foundation (CI gates)

These are CI-side checks; one push to GitHub gates them all.

- [ ] **CI matrix green run** — Push to master, GitHub Actions runs `pytest` on Python 3.8 AND 3.11 + `ruff` + `mypy` + `kodi-addon-checker`. All jobs green.

## 2 — Phase 2: Community PRs (Kodi runtime)

- [ ] **Favorite Albums browse** — Music → Subsonic → Albums → Favorite Albums shows starred albums; pagination correct
- [ ] **m4a transcoding** — set `m4a` in transcoding settings; play a track; URL contains `tformat=m4a`
- [ ] **Gapless playback** — play 2 consecutive tracks of a gapless album; no audible gap

## 3 — Phase 3: Structural refactor (Kodi runtime)

- [ ] **Addon loads on Kodi 21** — root menu renders, no errors in `kodi.log`
- [ ] **Browse and play** — Albums → Newest → album → track plays; no `NameError`/`AttributeError` in log
- [ ] **No setInfo deprecation warnings** — `grep DEPRECATED ~/.kodi/temp/kodi.log` is empty after browsing
- [ ] **Star icon refresh (BUG-05)** — context-menu star/unstar; icon updates in current list without manual refresh
- [ ] **Last-page pagination (BUG-04)** — last page of any list view returns < page_size items; "Next Page" is absent

## 4 — Phase 4: Auth modernization (Kodi runtime)

- [ ] **Salt+token round-trip (Navidrome)** — with `legacyauth=false`, requests use `t=...&s=...` not `p=...` (verify in Navidrome logs or network capture)
- [ ] **Legacy fallback (LDAP-Airsonic)** — with `legacyauth=true`, LDAP-authenticated user can still connect
- [ ] **OpenSubsonic probe caching (Navidrome)** — first connect triggers `getOpenSubsonicExtensions`; subsequent requests don't re-probe
- [ ] **API-key auth (Navidrome)** — set `subsonic_api_key`; URLs contain `apiKey=` and NOT `u/t/s/p`
- [ ] **Insecure-SSL dialog** — toggle `insecure_ssl=true`; warning dialog fires; Cancel reverts, Accept persists `acknowledged=true`

## 5 — Phase 5: Feature expansion (Kodi runtime)

- [ ] **Genre browsing (FEAT-01)** — root → Genres → list of genres → drill into one → tracks load
- [ ] **search3 metadata (FEAT-02)** — Search returns richer metadata; tracks have MusicBrainz IDs visible in info dialog
- [ ] **5-star rating (FEAT-03)** — track context menu → Rate → 1-5 stars; server confirms via `setRating`
- [ ] **Internet radio (FEAT-04)** — root → Internet Radio → list shows; selecting a station plays the stream
- [ ] **MusicBrainz IDs (FEAT-05)** — Kodi info dialog on a track/album/artist shows MusicBrainz IDs (when server provides them)

## 6 — Phase 6: Cross-server verification

### Subsonic + Airsonic (COMPAT-07)
- [ ] Browse, play, star, search work
- [ ] Bonus: legacyauth toggle works for LDAP-Airsonic

### Navidrome (COMPAT-08)
- [ ] Browse, play, star, search work
- [ ] OpenSubsonic-specific paths exercised:
  - [ ] Probe response contains expected extensions
  - [ ] search3 returns MusicBrainz IDs
  - [ ] API-key auth functional (if API key provided)

### gonic and LMS (COMPAT-09)
- [ ] gonic: browse + play work
- [ ] gonic: star + search best effort
- [ ] LMS: browse + play work

## Summary

total: 28
passed: 0
issues: 0
pending: 28
skipped: 0
blocked: 0

## Failure handling

For each failure, decide:
1. **Hotfix in v1.x** — quick fix, redo affected phase's plan-phase --gaps cycle
2. **v2 backlog** — file as v2 issue (or `.planning/backlog/` entry); ship v1 with documented limitation
3. **Server-specific quirk** — document the limitation in CHANGELOG / README and move on

After all checks complete, update Summary block above and the frontmatter `status:` to `passed` or `partial-with-known-issues`.
