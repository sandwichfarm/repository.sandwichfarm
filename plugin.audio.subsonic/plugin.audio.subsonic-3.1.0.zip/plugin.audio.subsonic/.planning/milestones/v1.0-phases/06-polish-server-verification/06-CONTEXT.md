# Phase 6: Polish + Server Verification - Context

**Gathered:** 2026-04-28
**Status:** Ready for planning
**Mode:** Auto-generated (verification phase — no production code changes expected)

<domain>
## Phase Boundary

Phase 6 is the final v1 milestone phase. It does NOT add new features or refactor code. Instead, it:

1. **Aggregates all deferred HUMAN-UAT items** from Phases 1, 2, 3, 4, and 5 into a single test plan that the user can work through with a real Kodi install pointing at real Subsonic-compatible servers.

2. **Closes the three explicit Phase 6 requirements:**
   - **COMPAT-07** — Plugin verified against Subsonic and Airsonic (legacy servers)
   - **COMPAT-08** — Plugin verified against Navidrome (current FOSS dominant)
   - **COMPAT-09** — Plugin verified against gonic and LMS (other modern Subsonic-API servers)

3. **Produces a release-readiness report** summarizing what works, what doesn't, and what should be filed as v2 backlog.

4. **Optionally** packages a v1 release zip (pure git archive, no signing in v1) for users to install directly from GitHub. The DIST-V2-* items remain v2 — Phase 6 just makes the addon installable from a GitHub release zip.

5. **Final cleanup**: stop importing from `lib/simpleplugin/` (already true after Phase 3) — the directory remains on disk for users who upgraded but is dormant. NO removal of the directory in v1 (defer to v2 cleanup).

Out of scope: New features, new bug fixes that surface during verification (those go to v1.1 or v2), DIST-V2-* tasks (official Kodi repo submission, custom Kodi repo, signed releases), removing the vendored simpleplugin from disk.

</domain>

<decisions>
## Implementation Decisions

### Phase 6 has no autonomous executor work — it's a UAT consolidation phase

The work is:
1. Read all `*-HUMAN-UAT.md` files from prior phases
2. Compile them into a single `06-MASTER-UAT.md` checklist organized by feature area
3. Optionally produce a release-zip artifact via `git archive`
4. The user works through the master UAT against real servers and updates the checklist
5. Any failures discovered → file as v2/v1.1 backlog or fix in a hotfix loop

Because of this nature, Phase 6 is INHERENTLY non-autonomous. Most of the "execution" is human verification.

### What automated work IS in scope

- **Compile master UAT** — script/manual creation of `06-MASTER-UAT.md` aggregating all prior `*-HUMAN-UAT.md` items. Group by server-target (Subsonic/Airsonic/Navidrome/gonic/LMS) and by feature surface.
- **Release zip artifact** — `git archive --prefix=plugin.audio.subsonic/ HEAD | gzip > plugin.audio.subsonic-v1.0.zip`. Output goes to `.planning/release/` (gitignored or out-of-tree). NOT committed.
- **`.gitattributes` `export-ignore` configuration** — so the zip excludes `tests/`, `.github/`, `.planning/`, `pyproject.toml`, etc. (Kodi addon zips should contain only what Kodi loads.)
- **Release notes / CHANGELOG** — append a v3.1.0 entry summarizing all 5 phases' work (existing CHANGELOG.md format).

### What human work is in scope

- Install zip in a Kodi 21 Omega instance (and optionally Kodi 20 Nexus)
- Configure addon for each target server (Subsonic, Airsonic, Navidrome, gonic, LMS)
- Walk through the master UAT for each server
- Mark each test pass/fail/skip
- File any discovered issues in GitHub issues (or as v2 backlog)

### COMPAT-07/08/09 acceptance criteria

- **COMPAT-07 (Subsonic + Airsonic)**: Browse + play + star + search work. Bonus: legacyauth toggle works for LDAP-Airsonic.
- **COMPAT-08 (Navidrome)**: Browse + play + star + search work AND OpenSubsonic-specific paths exercised — `getOpenSubsonicExtensions` probe returns expected extensions, search3 yields MusicBrainz IDs, API-key auth (if user provides a Navidrome API key) functions.
- **COMPAT-09 (gonic and LMS)**: Browse + play work. Star, search, ratings best-effort.

### Release scope

- Bump `addon.xml` version: `3.0.2` → `3.1.0` (semver: minor since features added; no breaking config changes)
- Bump `CHANGELOG.md`
- Tag the commit on master

### Claude's Discretion

- Exact release version number — `3.1.0` is the recommendation but user may prefer `4.0.0` to signal the major refactor
- Whether the master UAT lives at `.planning/phases/06.../06-MASTER-UAT.md` or `.planning/UAT.md` (top level) — pick what's discoverable
- Whether to commit the release zip into a `.planning/release/` dir or just leave it as a transient artifact — recommend transient (git archive is reproducible)

</decisions>

<code_context>
## Existing Code Insights

### Reusable Assets

- All prior `*-HUMAN-UAT.md` files contain the testable items
- Phase 3 SUMMARY.md notes the addon structure
- `addon.xml` exists and version is currently `3.0.2`
- `CHANGELOG.md` exists at repo root

### Established Patterns

- HUMAN-UAT.md frontmatter pattern (status, phase, source, started, updated)
- pytest + ruff + mypy CI (Phase 1 — should still be green)

### Files NOT modified

- `main.py`, `service.py` — already at 19 lines each
- `resources/lib/subsonic/` — frozen for v1
- `resources/settings.xml` — frozen

### Files possibly modified

- `addon.xml` — version bump
- `CHANGELOG.md` — v3.1.0 release notes
- `.gitattributes` — `export-ignore` rules so the addon zip is clean
- `.planning/phases/06-polish-server-verification/06-MASTER-UAT.md` — new aggregated UAT
- `.planning/UAT.md` (or similar release-readiness summary) — optional

</code_context>

<specifics>
## Specific Ideas

### Aggregated UAT structure

```markdown
# Master UAT — plugin.audio.subsonic v3.1.0 / v1.0 Milestone

## Server matrix

| Server | Auth modes to test | Expected pass rate |
|--------|-------------------|---------------------|
| Subsonic | legacy, salt+token | All non-OpenSubsonic features |
| Airsonic | legacy (LDAP), salt+token | All non-OpenSubsonic |
| Navidrome | salt+token, API-key | All features incl. OpenSubsonic |
| gonic | salt+token, API-key | Browse, play, star (best effort) |
| LMS | salt+token | Browse, play (best effort) |

## Test areas
1. Foundation (from Phase 1): CI matrix green, no crash on launch
2. Community PRs (Phase 2): Favorite Albums, m4a transcoding, gapless
3. Refactor (Phase 3): Star icon refresh, last-page pagination, no DEPRECATED
4. Auth (Phase 4): salt+token, legacy fallback, API-key, insecure-SSL dialog
5. Features (Phase 5): genres, search3, rating, internet radio, MusicBrainz IDs
```

Each item lifted from prior HUMAN-UAT.md files.

### .gitattributes for clean addon zip

```
/tests/ export-ignore
/.github/ export-ignore
/.planning/ export-ignore
/.gitattributes export-ignore
/.gitignore export-ignore
/pyproject.toml export-ignore
/CHANGELOG.md export-ignore
```
(CHANGELOG arguably should be IN the zip — Kodi shows it. Decide based on Kodi addon-store convention; recommend keeping CHANGELOG in the zip.)

### addon.xml version bump

```diff
-<addon id="plugin.audio.subsonic" name="Subsonic" version="3.0.2" provider-name="...">
+<addon id="plugin.audio.subsonic" name="Subsonic" version="3.1.0" provider-name="...">
```

</specifics>

<deferred>
## Deferred Ideas

- **DIST-V2-01**: Submit to xbmc/repo-plugins official repo (v2)
- **DIST-V2-02**: Custom Kodi repo (v2)
- **DIST-V2-03**: GitHub Actions release automation (v2)
- **TEST-V2-01**: Integration tests against Navidrome Docker (v2)
- **TEST-V2-02**: Smoke harness in headless Kodi (v2)
- **FEAT-V2-01..05**: lyrics, ReplayGain, play queue, reportPlayback, sonic similarity (v2)
- **AUTH-V2-01**: Per-server credential storage (v2)
- **ARCH-V2-01**: Replace pickle storage entirely (v2)
- Removing `lib/simpleplugin/` directory from disk (v2 cleanup pass)

</deferred>
