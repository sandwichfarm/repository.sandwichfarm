---
phase: 04-auth-modernization
plan: 01
type: execute
wave: 1
depends_on: []
files_modified:
  - resources/settings.xml
  - resources/language/English/strings.po
  - resources/language/German/strings.po
  - resources/language/French/strings.po
  - resources/lib/subsonic/settings.py
  - tests/test_settings.py
autonomous: true
requirements:
  - AUTH-04
  - AUTH-07

must_haves:
  truths:
    - "Settings.subsonic_api_key returns the api key string from settings"
    - "Settings.insecure_ssl_acknowledged returns bool from the hidden setting"
    - "Settings.set_insecure_ssl_acknowledged(True) persists True via setSetting"
    - "Settings.set_insecure_ssl(False) persists False via setSetting"
    - "resources/settings.xml declares both new settings without removing any existing id= attribute"
    - "strings.po declares label 30050 as 'API Key (OpenSubsonic)'"
  artifacts:
    - path: "resources/settings.xml"
      provides: "Two new settings: subsonic_api_key (text) and insecure_ssl_acknowledged (bool hidden)"
      contains: "subsonic_api_key"
    - path: "resources/lib/subsonic/settings.py"
      provides: "New typed properties + setters for the two new settings"
      contains: "subsonic_api_key"
    - path: "resources/language/English/strings.po"
      provides: "Label #30050 = 'API Key (OpenSubsonic)'"
      contains: "30050"
    - path: "tests/test_settings.py"
      provides: "Tests for the four new settings members; updated verbatim-ids test"
      contains: "test_subsonic_api_key"
  key_links:
    - from: "resources/settings.xml"
      to: "resources/lib/subsonic/settings.py"
      via: "getSetting('subsonic_api_key') / getSetting('insecure_ssl_acknowledged')"
      pattern: "getSetting.*subsonic_api_key"
    - from: "resources/lib/subsonic/settings.py"
      to: "resources/lib/subsonic/bootstrap.py"
      via: "_check_insecure_ssl_acknowledgement(settings) reads insecure + acknowledged"
      pattern: "insecure_ssl_acknowledged"
---

<objective>
Add two new settings — `subsonic_api_key` (text, General tab) and `insecure_ssl_acknowledged`
(bool, hidden) — to settings.xml, the Settings typed facade, and strings.po. Add setters
`set_insecure_ssl_acknowledged` and `set_insecure_ssl` for the bootstrap dialog to call.
Extend test_settings.py to cover the new members and update the verbatim-ids assertion.

Purpose: 04-02 (auth-mode selection) reads `subsonic_api_key`; 04-03 (insecure-SSL dialog)
reads and writes `insecure_ssl_acknowledged` and `insecure`. Both plans depend on this one.

Output: Updated settings.xml, settings.py, strings.po (all three languages), test_settings.py.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/ROADMAP.md
@.planning/STATE.md
@.planning/phases/04-auth-modernization/04-CONTEXT.md

@resources/settings.xml
@resources/language/English/strings.po
@resources/lib/subsonic/settings.py
@tests/test_settings.py
</context>

<interfaces>
<!-- Existing Settings class constructor (for reference) -->
<!-- resources/lib/subsonic/settings.py -->
```python
class Settings:
    def __init__(self, addon: xbmcaddon.Addon | None = None) -> None:
        self._addon: xbmcaddon.Addon = addon if addon is not None else xbmcaddon.Addon()
    # existing properties: server_url, port, username, password, insecure,
    # legacy_auth, use_get, api_version, albums_per_page, tracks_per_page,
    # download_folder, transcode_format, bitrate, cache_time, merge, scrobble_enabled
```

<!-- xbmcaddon.Addon mock interface (from tests/conftest.py) -->
```python
# conftest.py sets:
sys.modules["xbmcaddon"].Addon.return_value.getSetting.return_value = "0"
# In tests, inject a custom mock:
addon = MagicMock()
addon.getSetting.side_effect = lambda k: defaults.get(k, "")
addon.setSetting = MagicMock()
Settings(addon=addon)
```
</interfaces>

<tasks>

<task type="auto" tdd="true">
  <name>Task 1: Add two new settings to settings.xml and strings.po</name>
  <files>resources/settings.xml, resources/language/English/strings.po, resources/language/German/strings.po, resources/language/French/strings.po</files>
  <behavior>
    - settings.xml: `subsonic_api_key` text setting with label="30050" added inside `<!-- ADVANCED -->` category, after the `legacyauth` bool setting (before the lsep at 30017)
    - settings.xml: `insecure_ssl_acknowledged` bool setting with no label, default="false", visible="false" added in ADVANCED category (hidden — users never see it; it persists whether they acknowledged the insecure-SSL dialog)
    - English strings.po: new entry `msgctxt "#30050"` / `msgid "API Key (OpenSubsonic)"` / `msgstr ""`
    - German strings.po: same entry with empty msgstr
    - French strings.po: same entry with empty msgstr
    - No existing setting id= attributes are renamed or removed (COMPAT-06)
  </behavior>
  <action>
Edit resources/settings.xml — ADVANCED category section. After the `legacyauth` line and before
the `30017` lsep, INSERT these two lines:

```xml
<setting label="30050" id="subsonic_api_key" type="text" default="" />
<setting id="insecure_ssl_acknowledged" type="bool" default="false" visible="false" />
```

Edit all three strings.po files — append at the end (after the last msgctxt block, before EOF):

```
msgctxt "#30050"
msgid "API Key (OpenSubsonic)"
msgstr ""
```

German and French get the same block with empty msgstr (translation deferred).
  </action>
  <read_first>
    - resources/settings.xml — full file; identify exact insertion point after legacyauth line
    - resources/language/English/strings.po — find last msgctxt number to append after it
    - .planning/phases/04-auth-modernization/04-CONTEXT.md §"Settings.xml additions"
  </read_first>
  <verify>
    <automated>grep -q 'subsonic_api_key' resources/settings.xml &amp;&amp; grep -q 'insecure_ssl_acknowledged' resources/settings.xml &amp;&amp; grep -q '30050' resources/language/English/strings.po</automated>
  </verify>
  <acceptance_criteria>
    - `grep -q 'id="subsonic_api_key"' resources/settings.xml` exits 0
    - `grep -q 'id="insecure_ssl_acknowledged"' resources/settings.xml` exits 0
    - `grep -q 'visible="false"' resources/settings.xml` exits 0 (for insecure_ssl_acknowledged)
    - `grep -q 'msgctxt "#30050"' resources/language/English/strings.po` exits 0
    - `grep -q 'msgctxt "#30050"' resources/language/German/strings.po` exits 0
    - `grep -q 'msgctxt "#30050"' resources/language/French/strings.po` exits 0
    - No existing id= attribute is renamed: `grep -q 'id="legacyauth"' resources/settings.xml` still exits 0
  </acceptance_criteria>
  <done>settings.xml has both new settings; all three strings.po files declare #30050; no existing id= attribute is missing</done>
</task>

<task type="auto" tdd="true">
  <name>Task 2: Extend Settings facade with new properties and setters</name>
  <files>resources/lib/subsonic/settings.py, tests/test_settings.py</files>
  <behavior>
    - `subsonic_api_key` property: returns `str(self._addon.getSetting("subsonic_api_key"))`
    - `insecure_ssl_acknowledged` property: returns `True` when `getSetting("insecure_ssl_acknowledged").lower() == "true"`
    - `set_insecure_ssl_acknowledged(value: bool) -> None`: calls `self._addon.setSetting("insecure_ssl_acknowledged", "true" if value else "false")`
    - `set_insecure_ssl(value: bool) -> None`: calls `self._addon.setSetting("insecure", "true" if value else "false")`
    - All four are type-hinted, mypy --strict clean
    - test_settings.py: add tests for all four; update `test_settings_ids_verbatim` to include the two new read ids
    - The verbatim-ids test should also assert that setSetting is called with correct id strings for the two setters
  </behavior>
  <action>
In resources/lib/subsonic/settings.py, add to the `# Advanced / auth settings` section:

```python
@property
def subsonic_api_key(self) -> str:
    """OpenSubsonic API key (id: subsonic_api_key). Empty string if not set."""
    return str(self._addon.getSetting("subsonic_api_key"))

@property
def insecure_ssl_acknowledged(self) -> bool:
    """True once user has acknowledged the insecure-SSL dialog (id: insecure_ssl_acknowledged)."""
    return self._addon.getSetting("insecure_ssl_acknowledged").lower() == "true"

def set_insecure_ssl_acknowledged(self, value: bool) -> None:
    """Persist insecure_ssl_acknowledged setting (id: insecure_ssl_acknowledged)."""
    self._addon.setSetting("insecure_ssl_acknowledged", "true" if value else "false")

def set_insecure_ssl(self, value: bool) -> None:
    """Persist insecure setting (id: insecure). Used by dialog gate to revert to false."""
    self._addon.setSetting("insecure", "true" if value else "false")
```

In tests/test_settings.py, add:

```python
def test_subsonic_api_key_returns_value() -> None:
    s = _make_settings(subsonic_api_key="mykey123")
    assert s.subsonic_api_key == "mykey123"

def test_subsonic_api_key_returns_empty_when_not_set() -> None:
    s = _make_settings(subsonic_api_key="")
    assert s.subsonic_api_key == ""

def test_insecure_ssl_acknowledged_false() -> None:
    s = _make_settings(insecure_ssl_acknowledged="false")
    assert s.insecure_ssl_acknowledged is False

def test_insecure_ssl_acknowledged_true() -> None:
    s = _make_settings(insecure_ssl_acknowledged="true")
    assert s.insecure_ssl_acknowledged is True

def test_set_insecure_ssl_acknowledged_true() -> None:
    addon = MagicMock()
    addon.getSetting.return_value = "0"
    addon.setSetting = MagicMock()
    s = Settings(addon=addon)
    s.set_insecure_ssl_acknowledged(True)
    addon.setSetting.assert_called_once_with("insecure_ssl_acknowledged", "true")

def test_set_insecure_ssl_acknowledged_false() -> None:
    addon = MagicMock()
    addon.getSetting.return_value = "0"
    addon.setSetting = MagicMock()
    s = Settings(addon=addon)
    s.set_insecure_ssl_acknowledged(False)
    addon.setSetting.assert_called_once_with("insecure_ssl_acknowledged", "false")

def test_set_insecure_ssl_false() -> None:
    addon = MagicMock()
    addon.getSetting.return_value = "0"
    addon.setSetting = MagicMock()
    s = Settings(addon=addon)
    s.set_insecure_ssl(False)
    addon.setSetting.assert_called_once_with("insecure", "false")
```

Also update `test_settings_ids_verbatim`: add `"subsonic_api_key"` and `"insecure_ssl_acknowledged"` to `expected_ids`, add `s.subsonic_api_key` and `s.insecure_ssl_acknowledged` to the property trigger tuple.

Run RED: `python3 -m pytest tests/test_settings.py -x -q` — new tests fail (properties don't exist yet).
Add properties/setters to settings.py.
Run GREEN: same command — all tests pass.
  </action>
  <read_first>
    - resources/lib/subsonic/settings.py — full file; find correct insertion point
    - tests/test_settings.py — full file; update verbatim-ids test + append new tests
    - .planning/phases/04-auth-modernization/04-CONTEXT.md §"Settings preservation note" and §"Insecure SSL confirmation"
  </read_first>
  <verify>
    <automated>cd /home/sandwich/Develop/plugin.audio.subsonic &amp;&amp; .venv/bin/python -m pytest tests/test_settings.py -v -q 2&gt;&amp;1 | tail -5</automated>
  </verify>
  <acceptance_criteria>
    - `grep -q 'def subsonic_api_key' resources/lib/subsonic/settings.py` exits 0
    - `grep -q 'def insecure_ssl_acknowledged' resources/lib/subsonic/settings.py` exits 0
    - `grep -q 'def set_insecure_ssl_acknowledged' resources/lib/subsonic/settings.py` exits 0
    - `grep -q 'def set_insecure_ssl' resources/lib/subsonic/settings.py` exits 0
    - `python3 -m pytest tests/test_settings.py -v` exits 0 — all tests pass including new ones
    - `grep -q 'getSetting.*subsonic_api_key' resources/lib/subsonic/settings.py` exits 0
    - `grep -q 'getSetting.*insecure_ssl_acknowledged' resources/lib/subsonic/settings.py` exits 0
  </acceptance_criteria>
  <done>Settings facade has 2 new read properties and 2 setters; all test_settings.py tests pass; verbatim-ids test covers the new ids</done>
</task>

</tasks>

<verification>
After both tasks:
1. `grep -q 'id="subsonic_api_key"' resources/settings.xml` exits 0
2. `grep -q 'id="insecure_ssl_acknowledged"' resources/settings.xml` exits 0
3. `grep -q 'visible="false"' resources/settings.xml` exits 0
4. `grep -q 'msgctxt "#30050"' resources/language/English/strings.po` exits 0
5. `python3 -m pytest tests/test_settings.py -v` exits 0 (all pass)
6. `ruff check resources/lib/subsonic/settings.py` exits 0
7. `mypy resources/lib/subsonic/settings.py --strict --ignore-missing-imports` exits 0
</verification>

<success_criteria>
- settings.xml has `subsonic_api_key` text setting (label 30050, ADVANCED tab) and `insecure_ssl_acknowledged` hidden bool setting
- All three strings.po files declare label #30050
- Settings facade exposes `.subsonic_api_key`, `.insecure_ssl_acknowledged`, `.set_insecure_ssl_acknowledged()`, `.set_insecure_ssl()`
- No existing setting id= renamed or removed
- All test_settings.py tests pass including the verbatim-ids assertion
</success_criteria>

<output>
After completion, create `.planning/phases/04-auth-modernization/04-01-SUMMARY.md`
</output>
