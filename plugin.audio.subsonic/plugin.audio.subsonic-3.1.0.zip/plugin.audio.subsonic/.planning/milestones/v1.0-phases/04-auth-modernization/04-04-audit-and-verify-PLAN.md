---
phase: 04-auth-modernization
plan: 04
type: execute
wave: 3
depends_on:
  - 04-02
  - 04-03
files_modified:
  - lib/libsonic/connection.py
  - resources/lib/subsonic/api/client.py
  - resources/lib/subsonic/logging.py
  - tests/test_logging.py
autonomous: false
requirements:
  - AUTH-06

must_haves:
  truths:
    - "No xbmc.log() call in any addon file passes a URL string that contains p=, t=, s=, password=, token=, salt=, or apiKey= with a real value"
    - "The insecure URL debug log in libsonic/connection.py:streamUrl is guarded or sanitized"
    - "All log calls in libsonic that touch URLs route through safe_log or are at LOGDEBUG only"
    - "Full pytest run exits 0 — all existing and new tests pass together"
    - "ruff check exits 0 on all changed files"
    - "mypy --strict exits 0 on all addon modules"
    - "Human has confirmed the audit grep produces zero unsanitized auth param lines"
  artifacts:
    - path: "lib/libsonic/connection.py"
      provides: "No live debug xbmc.log calls with auth-bearing URLs"
      contains: "LOGDEBUG"
    - path: "tests/test_logging.py"
      provides: "Extended tests covering apiKey= redaction and the insecure URL log pattern"
      contains: "test_safe_log_redacts_apikey"
  key_links:
    - from: "lib/libsonic/connection.py"
      to: "subsonic.logging.safe_log"
      via: "Any remaining xbmc.log call that might log a URL must route through safe_log"
      pattern: "safe_log"
---

<objective>
Repo-wide credential leak audit (AUTH-06): find every callsite that logs a URL or auth
parameter, sanitize it or confirm it is already safe. Then run the full test suite, ruff,
and mypy. Close with a human verification checkpoint where the user runs the audit grep
command and confirms zero unsanitized auth param lines in the output.

This plan has no new feature code — it is a sweep + verification plan.

Output: Sanitized libsonic log call; extended test_logging.py; checkpoint: human sign-off.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/ROADMAP.md
@.planning/STATE.md
@.planning/phases/04-auth-modernization/04-CONTEXT.md

@resources/lib/subsonic/logging.py
@lib/libsonic/connection.py
@tests/test_logging.py
</context>

<interfaces>
<!-- safe_log and _AUTH_RE from Phase 3 logging.py -->
```python
_AUTH_RE = re.compile(r"\b(p|t|s|password|token|salt|apiKey)=[^&\s]*")

def safe_log(msg: str, level: int = xbmc.LOGINFO) -> None:
    sanitized = _AUTH_RE.sub(r"\1=REDACTED", msg)
    xbmc.log("Subsonic: " + sanitized, level)
```

<!-- Known risky line in libsonic/connection.py (streamUrl, line ~911) -->
```python
xbmc.log("Request is insecure %s"%return_url, level=xbmc.LOGDEBUG)
```
<!-- return_url contains the full auth params (t=, s= or p=) from _getBaseQdict -->
```

<!-- The commented-out lines (already safe — commented out) -->
```python
#xbmc.log("Standard URL %s"%url, level=xbmc.LOGDEBUG)
#xbmc.log("Qdict %s"%str(qdict), level=xbmc.LOGDEBUG)
#xbmc.log("UseGET URL %s"%(url), xbmc.LOGDEBUG)
#xbmc.log("Requesting %s"%str(req.full_url), xbmc.LOGDEBUG)
```
</interfaces>

<tasks>

<task type="auto">
  <name>Task 1: Sanitize live credential-bearing log call in libsonic + extend test_logging.py</name>
  <files>lib/libsonic/connection.py, resources/lib/subsonic/logging.py, tests/test_logging.py</files>
  <action>
STEP 1 — Audit grep (run this first, read the output):

```bash
grep -rn "xbmc\.log\|safe_log" main.py service.py resources/lib/ lib/libsonic/ 2>/dev/null
```

For each live (non-commented) `xbmc.log(...)` line found:
- If the message can contain a URL with auth params → either replace with `safe_log()` or
  ensure the message is stripped of the URL entirely.

STEP 2 — The known offender in lib/libsonic/connection.py:

Line ~911 in `streamUrl()`:
```python
xbmc.log("Request is insecure %s"%return_url, level=xbmc.LOGDEBUG)
```

`return_url` is the full stream URL including `t=<token>&s=<salt>` (or `p=<pass>` in legacy
mode). Replace this line with a safe version that logs only a redacted URL:

```python
# Import safe_log is not available inside libsonic (it's in the addon layer).
# Instead, log only the URL scheme+host without the query string.
import urllib.parse as _urlparse
_parsed = _urlparse.urlparse(return_url)
xbmc.log(
    "Subsonic: insecure SSL connection to %s://%s (auth params redacted)" % (
        _parsed.scheme, _parsed.hostname
    ),
    level=xbmc.LOGDEBUG,
)
```

OR — simpler — just remove the `return_url` from the log. The hostname is already
available as `self._hostname`. Preferred approach (less coupling):

```python
xbmc.log(
    "Subsonic: insecure SSL enabled for connection to %s" % self._hostname,
    level=xbmc.LOGDEBUG,
)
```

Use the simpler form. `self._hostname` does not contain credentials.

STEP 3 — Check addon modules for any direct xbmc.log calls:

```bash
grep -rn "xbmc\.log(" main.py service.py resources/lib/ 2>/dev/null | grep -v "safe_log\|# "
```

All `xbmc.log(` calls in addon modules should have been routed to `safe_log()` in Phase 3.
Confirm there are none, or sanitize any survivors found.

STEP 4 — Verify _AUTH_RE covers apiKey=:

```python
# logging.py already has: _AUTH_RE = re.compile(r"\b(p|t|s|password|token|salt|apiKey)=[^&\s]*")
# apiKey= IS covered. No change needed.
```

STEP 5 — Extend tests/test_logging.py with at least 2 new tests:

```python
def test_safe_log_redacts_apikey_param():
    """apiKey= values must be redacted — they are auth credentials."""
    import xbmc
    from subsonic.logging import safe_log
    calls = []
    xbmc.log = lambda msg, level=xbmc.LOGINFO: calls.append(msg)
    safe_log("request: https://server/rest/ping.view?u=user&apiKey=supersecret123")
    assert "supersecret123" not in calls[0]
    assert "apiKey=REDACTED" in calls[0]

def test_safe_log_redacts_token_and_salt():
    """t= and s= (salt+token) must be redacted."""
    import xbmc
    from subsonic.logging import safe_log
    calls = []
    xbmc.log = lambda msg, level=xbmc.LOGINFO: calls.append(msg)
    safe_log("url: http://s/rest/getAlbums.view?u=admin&t=abc123&s=xyz456")
    assert "abc123" not in calls[0]
    assert "xyz456" not in calls[0]
    assert "t=REDACTED" in calls[0]
    assert "s=REDACTED" in calls[0]
```

Note: test_logging.py likely already has similar tests from Phase 3. Check before adding
duplicates — add only if the specific param is not already covered.
  </action>
  <read_first>
    - lib/libsonic/connection.py — search for ALL live xbmc.log calls (lines ~907-911 for the known one)
    - resources/lib/subsonic/logging.py — verify _AUTH_RE covers apiKey=
    - tests/test_logging.py — see what Phase 3 already tests to avoid duplicates
    - .planning/phases/04-auth-modernization/04-CONTEXT.md §"Credential leak audit"
    - .planning/research/PITFALLS.md §"Pitfall 9: Credential Leak in xbmc.log via URL Logging"
  </read_first>
  <verify>
    <automated>! grep -rEn "xbmc\.log\([^)]*[?&](p|t|s|password|token|salt|apiKey)=" main.py service.py resources/lib/ lib/libsonic/connection.py 2>/dev/null | grep -v "REDACTED\|#"</automated>
  </verify>
  <acceptance_criteria>
    - `! grep -rEn "xbmc\.log\b.*[?&](p|t|s|apiKey)=[^R]" lib/libsonic/connection.py` exits 0 (no live auth params in xbmc.log)
    - `grep -q 'self._hostname' lib/libsonic/connection.py` exits 0 in the insecure log line (URL replaced by hostname)
    - `python3 -m pytest tests/test_logging.py -v` exits 0
    - `grep -q "apiKey=REDACTED" tests/test_logging.py` exits 0 OR existing test covers it (check manually)
  </acceptance_criteria>
  <done>No live xbmc.log calls in any file expose raw auth params; test_logging.py extended</done>
</task>

<task type="auto">
  <name>Task 2: Full pytest + ruff + mypy sweep</name>
  <files></files>
  <action>
Run the full test suite and linting tools against all Phase 4 changes. Fix any failures
before proceeding to the checkpoint.

```bash
# Full test suite
cd /path/to/repo
.venv/bin/python -m pytest tests/ -v

# Ruff on all modified Phase 4 files
ruff check resources/lib/subsonic/settings.py \
         resources/lib/subsonic/api/client.py \
         resources/lib/subsonic/bootstrap.py \
         resources/lib/subsonic/logging.py

# mypy on all modified Phase 4 addon modules
mypy resources/lib/subsonic/settings.py \
     resources/lib/subsonic/api/client.py \
     resources/lib/subsonic/bootstrap.py \
     resources/lib/subsonic/logging.py \
     --strict --ignore-missing-imports
```

Fix any failures. Common issues to watch for:
- `set[str] | None` type annotation requires Python 3.10+ — use `Optional[Set[str]]` or
  `from __future__ import annotations` (already present in Phase 3 files via `from __future__`)
- `Literal["apikey", "token", "legacy"]` import — needs `from typing import Literal`
- mypy may flag `xbmcgui.Dialog().yesno()` return type as Any → acceptable with `--ignore-missing-imports`
  </action>
  <read_first>
    - (none needed — this task runs commands on already-modified files)
  </read_first>
  <verify>
    <automated>cd /home/sandwich/Develop/plugin.audio.subsonic &amp;&amp; .venv/bin/python -m pytest tests/ -q 2&gt;&amp;1 | tail -5</automated>
  </verify>
  <acceptance_criteria>
    - `python3 -m pytest tests/ -v` exits 0 — zero failures, zero errors
    - `ruff check resources/lib/subsonic/settings.py resources/lib/subsonic/api/client.py resources/lib/subsonic/bootstrap.py` exits 0
    - `mypy resources/lib/subsonic/api/client.py resources/lib/subsonic/settings.py resources/lib/subsonic/bootstrap.py --strict --ignore-missing-imports` exits 0
  </acceptance_criteria>
  <done>Full test suite green; ruff and mypy clean on all Phase 4 files</done>
</task>

<task type="checkpoint:human-verify" gate="blocking">
  <what-built>
    Phase 4 auth modernization complete:
    - settings.xml: subsonic_api_key + insecure_ssl_acknowledged settings added
    - Settings facade: 2 new properties + 2 setters
    - libsonic._getSalt: now uses secrets.token_hex (cryptographically secure)
    - libsonic.Connection: getOpenSubsonicExtensions() method added
    - ApiClient: make_token_auth, probe_extensions (lazy+cached), choose_auth_mode, build_auth_params
    - bootstrap.py: insecure-SSL confirmation dialog gate
    - Credential audit: all live xbmc.log calls with auth-bearing URLs sanitized
    - Tests: test_settings.py extended, test_api_client.py +10 tests, test_bootstrap.py new (4 tests)
  </what-built>
  <how-to-verify>
    Run these commands in the repo root and confirm all pass:

    1. Full test suite (must be all green):
       ```
       .venv/bin/python -m pytest tests/ -v
       ```

    2. Credential leak audit (must produce ZERO output lines):
       ```
       grep -rEn "xbmc\.log\([^)]*[?&](p|t|s|password|token|salt|apiKey)=" \
           main.py service.py resources/lib/ lib/libsonic/connection.py 2>/dev/null \
           | grep -v "REDACTED\|#"
       ```
       An empty result means no credential-bearing log lines exist.

    3. Confirm secrets.token_hex is used (not random/os.urandom):
       ```
       grep -rn "secrets\.token_hex" lib/libsonic/connection.py resources/lib/subsonic/api/client.py
       ```
       Should show at least 2 hits (one per file).

    4. Confirm apikey mode exclusivity:
       ```
       grep -A8 "def build_auth_params" resources/lib/subsonic/api/client.py
       ```
       In the apikey branch, only `apiKey` key must appear — no u/t/s/p.

    5. Confirm insecure-SSL gate in bootstrap:
       ```
       grep -n "_check_insecure_ssl_acknowledgement" resources/lib/subsonic/bootstrap.py
       ```
       Should show 2 hits: function definition + call in run_plugin.
  </how-to-verify>
  <resume-signal>Type "approved" if all checks pass, or describe any failures found</resume-signal>
</task>

</tasks>

<verification>
Overall Phase 4 completion checks:
1. `grep -q 'secrets\.token_hex' resources/lib/subsonic/api/client.py` exits 0
2. `grep -q 'secrets\.token_hex' lib/libsonic/connection.py` exits 0
3. `grep -q 'def probe_extensions' resources/lib/subsonic/api/client.py` exits 0
4. `grep -q '_check_insecure_ssl_acknowledgement' resources/lib/subsonic/bootstrap.py` exits 0
5. `grep -q 'id="subsonic_api_key"' resources/settings.xml` exits 0
6. `python3 -m pytest tests/ -v` exits 0
7. Credential audit grep produces zero output
</verification>

<success_criteria>
- Zero credential-bearing lines in any xbmc.log call across all addon files and libsonic
- Full pytest suite passes (all existing + new Phase 4 tests)
- ruff + mypy clean on all Phase 4 files
- Human has verified all 5 audit commands in the checkpoint
- Phase 4 AUTH-01..07 all implemented and testable
</success_criteria>

<output>
After completion, create `.planning/phases/04-auth-modernization/04-04-SUMMARY.md`
</output>
