---
phase: 04-auth-modernization
plan: 03
subsystem: bootstrap
tags: [auth, dialog, ssl, tdd]
dependency_graph:
  requires: [04-01]
  provides: [insecure-ssl-dialog-gate]
  affects: [bootstrap.run_plugin]
tech_stack:
  added: []
  patterns: [TDD red-green, xbmcgui.Dialog().yesno startup gate, Settings facade setters]
key_files:
  created:
    - tests/test_bootstrap.py
  modified:
    - resources/lib/subsonic/bootstrap.py
decisions:
  - "Gate implemented as a standalone _check_insecure_ssl_acknowledgement function called from run_plugin, not inline"
  - "xbmcgui imported at module level in bootstrap.py per ARCH-05 pattern"
  - "On Cancel: set_insecure_ssl(False) only; on Accept: set_insecure_ssl_acknowledged(True) only"
metrics:
  duration_minutes: 1
  completed_date: "2026-04-28"
  tasks_completed: 1
  files_modified: 2
---

# Phase 4 Plan 3: Insecure-SSL Dialog Gate Summary

**One-liner:** TDD-implemented `_check_insecure_ssl_acknowledgement` startup gate in `bootstrap.py` — shows a `xbmcgui.Dialog().yesno` warning on first insecure-SSL enable, reverts setting on Cancel, persists acknowledgement on Accept.

## Tasks Completed

| # | Task | Commit | Files |
|---|------|--------|-------|
| 1 | Add insecure-SSL dialog gate to bootstrap.py + tests | 009eacc | resources/lib/subsonic/bootstrap.py, tests/test_bootstrap.py |

## What Was Built

Added `_check_insecure_ssl_acknowledgement(settings: Settings) -> None` to `bootstrap.py`. The function implements a three-case decision tree:

1. `insecure=false` → return immediately, no dialog.
2. `insecure=true, acknowledged=true` → return immediately, no dialog.
3. `insecure=true, acknowledged=false` → show `xbmcgui.Dialog().yesno(...)` with title "Insecure SSL warning", body explaining the risk, `nolabel="Cancel"`, `yeslabel="I understand"`.
   - Accept → `set_insecure_ssl_acknowledged(True)` persists acknowledgement.
   - Cancel → `set_insecure_ssl(False)` reverts the setting.

The gate is called in `run_plugin` after `Settings()` construction and before `ApiClient(settings)`, so a Cancel revert is visible to the `ApiClient` on the same launch.

`import xbmcgui` added to bootstrap.py (ARCH-05: bootstrap is the one permitted place outside listings.py to call xbmcgui directly at startup).

### Test Coverage (tests/test_bootstrap.py — 4 tests, all pass)

- `test_insecure_ssl_gate_no_dialog_when_insecure_false`
- `test_insecure_ssl_gate_no_dialog_when_already_acknowledged`
- `test_insecure_ssl_first_enable_shows_dialog_accept`
- `test_insecure_ssl_first_enable_shows_dialog_decline`

## Deviations from Plan

None — plan executed exactly as written.

## Known Stubs

None.

## Self-Check: PASSED

- `resources/lib/subsonic/bootstrap.py` — exists, contains `_check_insecure_ssl_acknowledgement`
- `tests/test_bootstrap.py` — exists, 4 tests pass
- Commit `009eacc` — verified in git log
