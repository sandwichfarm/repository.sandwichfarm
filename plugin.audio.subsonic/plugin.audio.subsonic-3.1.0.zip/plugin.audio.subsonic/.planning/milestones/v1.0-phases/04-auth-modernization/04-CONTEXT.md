# Phase 4: Auth Modernization - Context

**Gathered:** 2026-04-28
**Status:** Ready for planning
**Mode:** Auto-generated (locked decisions from research; minimal grey area)

<domain>
## Phase Boundary

Phase 4 modernizes the addon's auth layer on top of the Phase 3 boundary. The legacy plaintext-password mode (`u=...&p=plaintext`) is no longer the default — `salt+token` (`u=...&t=md5(password+salt)&s=salt`, Subsonic API ≥ 1.13) takes its place. A `legacyauth` setting toggle remains for LDAP-backed Airsonic and pre-1.13 servers. The OpenSubsonic capability probe (`getOpenSubsonicExtensions`) runs once on first connect per session and is cached; when the server advertises `apiKeyAuthentication`, the addon uses `apiKey=...` instead of `u/t/s`. Salts are generated with `secrets.token_hex` (not `random`). A repo-wide audit ensures no credentials, tokens, or salts ever appear in `xbmc.log` (every log call routes through `subsonic.logging.safe_log` from Phase 3, and any direct `xbmc.log()` callsites that build URLs are sanitized). The `insecure=True` SSL bypass setting is retained but defaults to off; first-time enablement triggers a `xbmcgui.Dialog().yesno()` confirmation explaining the risk.

Out of scope: New features (genre browsing, search3, rating, radio, MusicBrainz IDs — all Phase 5). Live server verification against actual Navidrome / gonic / LMS / Airsonic — Phase 6. Removing the `legacyauth` toggle entirely — keep the escape hatch.

</domain>

<decisions>
## Implementation Decisions

### Auth-mode selection (locked by research + AUTH-01..04)

ApiClient.choose_auth_mode() returns one of:
- `apikey` — when OpenSubsonic probe response contains `apiKeyAuthentication` extension AND the user has set an API key in settings
- `token` — default for API ≥ 1.13 (which is everything modern: Subsonic, Airsonic, Navidrome, gonic, LMS)
- `legacy` — when `legacyauth` setting is `true` (Airsonic LDAP fallback) OR when API < 1.13

The mode selection happens once per `ApiClient` instance and is cached. Re-construction (re-entry into `run_plugin`) re-evaluates.

### Salt+token mechanics (locked — AUTH-01, AUTH-05)

```python
import secrets
import hashlib

def make_token_auth(password: str) -> tuple[str, str]:
    salt = secrets.token_hex(8)  # 16 hex chars per Subsonic spec recommendation
    token = hashlib.md5((password + salt).encode("utf-8")).hexdigest()
    return token, salt
```

The salt is regenerated on every request (not once per session) so a leaked salt doesn't compromise other requests. NEVER log the password, token, or salt.

### OpenSubsonic capability probe (locked — AUTH-03)

`ApiClient.probe_extensions()` calls `getOpenSubsonicExtensions` once on first connect. The response is cached on the `ApiClient` instance for the rest of the session. Probe runs unauthenticated (or with the lightest available auth — falls back to plaintext just for the probe). On non-OpenSubsonic servers (legacy Subsonic, Airsonic without OpenSubsonic), the call returns 4xx/5xx or an empty extension list — the addon then assumes "no extensions" for the whole session.

Probe trigger: first call to any method that can use an extension (`apikey` mode lookup, search3 in Phase 5, lyrics in v2). The probe is lazy — if the user only browses albums, the probe never fires.

### API-key auth (locked — AUTH-04)

When `apikey` mode is active:
- All requests include `apiKey=<key>` query param
- `u`, `t`, `s`, `p` params are ALL suppressed (mutually exclusive per OpenSubsonic spec)
- The setting `subsonic_api_key` is added to `resources/settings.xml` (NEW — AUTH-04 needs this; see Settings preservation note below)

### Settings preservation note (COMPAT-06 nuance for Phase 4)

Phase 4 ADDS one new setting: `subsonic_api_key` (string). It does NOT rename or remove any existing `id=` attribute. ADD-only schema change is safe — existing user installs default the new setting to empty string. The `legacyauth` setting already exists.

### Insecure SSL confirmation (locked — AUTH-07)

When `insecure_ssl` setting transitions from `false` → `true`, the addon shows a `xbmcgui.Dialog().yesno()` modal:
- title: "Insecure SSL warning"
- body: "Disabling SSL certificate verification leaves traffic vulnerable to interception. Only enable this for self-signed homelab servers you control. Continue?"
- yes button: "I understand"
- no button: "Cancel"

If user picks "Cancel", the setting reverts to `false`. Implementation: hooked from settings module (Phase 3 has `Settings` typed facade — extend with a transition-aware setter).

Actually — settings changes happen through Kodi's settings UI, not through addon code. The dialog must be shown the FIRST TIME the addon detects `insecure_ssl=true` after a settings change. Implementation lives in `bootstrap.run_plugin` (or `api/client.ApiClient.__init__`) — when `insecure_ssl` is true and `insecure_ssl_acknowledged` (a new internal-only setting) is false, show the dialog; if user accepts, set acknowledged=true; if cancels, force insecure_ssl back to false via `Addon().setSetting`.

### Credential leak audit (locked — AUTH-06)

Repo-wide grep for any `xbmc.log(...)` callsite that interpolates a URL string. Each callsite must either:
- Use `subsonic.logging.safe_log` (Phase 3 helper) — preferred
- OR explicitly construct a sanitized URL before logging

The Phase 3 logging module already has the regex; this phase's audit ensures every log site uses it. The audit:
- `grep -rn "xbmc\.log\|safe_log" main.py service.py resources/lib/subsonic/`
- For every `xbmc.log(...)` direct callsite: sanitize the message OR replace with safe_log
- For every `safe_log(...)`: confirm the message is parameterized through the redaction regex

Vendored `lib/libsonic/connection.py` is included in the audit — if it logs URLs (e.g. for debug), the log site must be sanitized too. (Note: Phase 3 already removed debug prints, but verify.)

### Test coverage (locked — extends TEST-02 from Phase 3)

`tests/test_api_client.py` extended with:
- `test_choose_auth_mode_returns_apikey_when_extension_advertised`
- `test_choose_auth_mode_returns_token_default`
- `test_choose_auth_mode_returns_legacy_when_setting_enabled`
- `test_make_token_auth_uses_secrets_token_hex`
- `test_make_token_auth_token_matches_md5_password_plus_salt`
- `test_probe_extensions_caches_result_per_session`
- `test_probe_extensions_handles_404_as_no_extensions`
- `test_apikey_mode_omits_user_token_salt_password_params`
- `test_legacy_mode_includes_password_param`
- `test_token_mode_includes_token_and_salt_omits_password`

`tests/test_logging.py` already covers the redaction regex (Phase 3) — extend to cover the new params (`apiKey=` is already in the regex).

`tests/test_bootstrap.py` (NEW — or extend test_scrobbler.py if there's a shared module): `test_insecure_ssl_first_enable_shows_dialog` (mocks `xbmcgui.Dialog().yesno()` and asserts it's called with the warning title/body when `insecure_ssl=true && insecure_ssl_acknowledged=false`).

### Claude's Discretion

- Exact wording of the insecure-SSL dialog — adapt to fit Kodi's button-label conventions
- Whether the OpenSubsonic probe error fallback uses `404` specifically or any non-200 — pick what's safer; default to "any error → no extensions"
- Whether the `Settings` facade exposes a setter for `insecure_ssl_acknowledged` or whether the bootstrap module reads/writes it directly — pick what tests cleaner
- Whether `subsonic_api_key` lives in the General settings tab or a new "OpenSubsonic" tab — pick whichever the existing settings.xml structure supports without renaming categories

</decisions>

<code_context>
## Existing Code Insights

### Reusable Assets

- `resources/lib/subsonic/api/client.py` (Phase 3) — has the `ApiClient` boundary; auth-mode selection plugs into its constructor or a method
- `resources/lib/subsonic/settings.py` (Phase 3) — typed facade; extend with `subsonic_api_key`, `insecure_ssl_acknowledged` properties
- `resources/lib/subsonic/logging.py` (Phase 3) — `safe_log` and the `_AUTH_RE` regex already include `apiKey=` per Phase 3 implementation
- `lib/libsonic/connection.py` — modernized in Phase 3 (urllib2 gone, ssl branches cleaned). The actual auth params get passed in here. Either modify libsonic's signature OR the ApiClient builds the param dict and libsonic just sends it.
- `tests/conftest.py` — has Kodi mocks; `xbmcgui.Dialog().yesno` will need configurable return value for testing

### Established Patterns

- Type-hinted everything (carry forward from Phase 3)
- Per-module unit tests
- mypy --strict + ruff clean
- Settings reads ALWAYS through `Settings` facade

### Integration Points

- `resources/settings.xml` — schema-additive change: new `<setting id="subsonic_api_key" type="text">` and `<setting id="insecure_ssl_acknowledged" type="bool" visible="false">`
- `addon.xml` — no change expected
- The Phase 3 `bootstrap.py.run_plugin` may need a one-line addition to invoke the insecure-SSL dialog gate before constructing the ApiClient

### Files modified (planning level, predicted)

- `resources/lib/subsonic/api/client.py` — auth-mode selection, salt+token impl, probe, apikey path
- `resources/lib/subsonic/settings.py` — add API-key + acknowledged properties
- `resources/lib/subsonic/bootstrap.py` — insecure-SSL dialog gate
- `resources/lib/subsonic/logging.py` — verify regex covers all params (probably no change needed)
- `lib/libsonic/connection.py` — accept a generic auth-params dict from caller (signature may change)
- `resources/settings.xml` — ADD two settings (no rename, no remove)
- `tests/test_api_client.py` — 10 new auth tests
- `tests/test_settings.py` — assert new settings preserved
- `tests/test_bootstrap.py` — insecure-SSL dialog test
- `tests/test_logging.py` — extend if needed for new param patterns

</code_context>

<specifics>
## Specific Ideas

### Auth params builder

```python
# api/client.py
def build_auth_params(self) -> dict[str, str]:
    if self._auth_mode == "apikey":
        return {"apiKey": self._settings.subsonic_api_key}
    elif self._auth_mode == "token":
        token, salt = make_token_auth(self._settings.subsonic_password)
        return {"u": self._settings.subsonic_username, "t": token, "s": salt}
    else:  # legacy
        return {"u": self._settings.subsonic_username, "p": self._settings.subsonic_password}
```

### Probe handler

```python
def probe_extensions(self) -> set[str]:
    if self._extensions_cached is not None:
        return self._extensions_cached
    try:
        response = self._connection.getOpenSubsonicExtensions()
        # response shape per OpenSubsonic spec
        extensions = {ext["name"] for ext in response.get("openSubsonicExtensions", [])}
    except Exception:
        # any error → no extensions advertised
        extensions = set()
    self._extensions_cached = extensions
    return extensions

def supports(self, extension: str) -> bool:
    return extension in self.probe_extensions()
```

### Insecure SSL dialog gate (in bootstrap)

```python
# bootstrap.py
def _check_insecure_ssl_acknowledgement(settings: Settings) -> None:
    if not settings.insecure_ssl:
        return
    if settings.insecure_ssl_acknowledged:
        return
    confirmed = xbmcgui.Dialog().yesno(
        "Insecure SSL warning",
        "Disabling SSL certificate verification leaves traffic vulnerable to interception. Only enable this for self-signed homelab servers you control. Continue?",
        nolabel="Cancel",
        yeslabel="I understand",
    )
    if confirmed:
        settings.set_insecure_ssl_acknowledged(True)
    else:
        settings.set_insecure_ssl(False)
```

(Phase 4's `Settings` extension needs `set_insecure_ssl_acknowledged` and `set_insecure_ssl` setters.)

### Settings.xml additions

```xml
<!-- Inside the appropriate <category> -->
<setting label="30050" id="subsonic_api_key" type="text" default="" />
<setting id="insecure_ssl_acknowledged" type="bool" default="false" visible="false" />
```

The label `30050` needs corresponding entries in strings.po files (English at minimum):
```
msgctxt "#30050"
msgid "API Key (OpenSubsonic)"
msgstr ""
```

</specifics>

<deferred>
## Deferred Ideas

- New features that USE the OpenSubsonic probe (search3, rating, radio, MusicBrainz IDs, lyrics, ReplayGain) — Phase 5 + v2
- Live server verification against real Navidrome/gonic/LMS/Airsonic — Phase 6
- Removing the legacyauth toggle — never; keep the escape hatch
- Per-server credential storage (multiple servers) — v2 (FEAT-V2-01)

</deferred>
