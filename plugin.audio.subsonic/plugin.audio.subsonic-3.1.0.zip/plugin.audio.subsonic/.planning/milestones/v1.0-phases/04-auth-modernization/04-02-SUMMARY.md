---
phase: 04-auth-modernization
plan: "02"
subsystem: api/auth
tags: [auth, salt-token, opensubsonic, probe, apikey, security]
dependency_graph:
  requires: [04-01]
  provides: [make_token_auth, probe_extensions, choose_auth_mode, build_auth_params, getOpenSubsonicExtensions]
  affects: [resources/lib/subsonic/api/client.py, lib/libsonic/connection.py, tests/test_api_client.py]
tech_stack:
  added: [secrets.token_hex, hashlib.md5, typing.Literal]
  patterns: [lazy-cached-probe, auth-mode-selection, mutual-exclusion-params]
key_files:
  created: []
  modified:
    - resources/lib/subsonic/api/client.py
    - lib/libsonic/connection.py
    - tests/test_api_client.py
decisions:
  - "legacy auth checked first in choose_auth_mode priority chain — LDAP escape hatch always wins"
  - "probe_extensions caches empty set on error — non-OpenSubsonic servers never retry probe"
  - "get_open_subsonic_extensions() Phase 3 stub now delegates to probe_extensions() for cache coherence"
  - "bool() cast applied to star/unstar/scrobble returns to satisfy mypy --strict no-any-return"
metrics:
  duration: "~10 minutes"
  completed: "2026-04-28"
  tasks: 2
  files_modified: 3
requirements:
  - AUTH-01
  - AUTH-02
  - AUTH-03
  - AUTH-04
  - AUTH-05
---

# Phase 4 Plan 02: Auth Implementation Summary

**One-liner:** JWT-free salt+token auth with lazy OpenSubsonic extension probe and apikey/token/legacy mode selection using `secrets.token_hex(8)` + `hashlib.md5`.

## What Was Built

### Task 1: libsonic.Connection additions (`lib/libsonic/connection.py`)

- Added `getOpenSubsonicExtensions()` method following the existing `_getRequest`/`_doInfoReq` pattern used by all other no-arg GET endpoints.
- Replaced `_getSalt()` body (`md5(os.urandom(100)).hexdigest()[:12]`) with `secrets.token_hex(length // 2)` — 16 hex chars (8 bytes entropy) by default, matching the Subsonic spec recommendation.
- Added `import secrets` at module level.

### Task 2: ApiClient auth machinery (`resources/lib/subsonic/api/client.py`)

- **`make_token_auth(password)`** — module-level function; calls `secrets.token_hex(8)`, computes `md5(password+salt).hexdigest()`, returns `(token, salt)`. Fresh salt per call (no session caching).
- **`probe_extensions()`** — lazy+cached OpenSubsonic probe. First call hits `self._conn.getOpenSubsonicExtensions()`; result stored in `self._extensions_cached`. Any exception → caches empty set. Second call returns cache with no network round-trip.
- **`supports(extension)`** — thin wrapper over `probe_extensions()`.
- **`choose_auth_mode()`** — returns `Literal["apikey", "token", "legacy"]`. Priority: `legacy` (settings flag) > `apikey` (server advertises + api_key non-empty) > `token` (default).
- **`build_auth_params()`** — returns correct dict per mode. apikey mode returns `{"apiKey": key}` only — `u`, `t`, `s`, `p` are all absent. token mode returns `{"u", "t", "s"}`. legacy mode returns `{"u", "p"}`.
- **`get_open_subsonic_extensions()`** Phase 3 stub now delegates to `probe_extensions()` for cache coherence rather than independently calling the conn.

### Tests (`tests/test_api_client.py`)

11 new auth tests added (plan called for 10; one extra test added for probe caching after error):

1. `test_make_token_auth_uses_secrets_token_hex` — patches `secrets.token_hex`, asserts called with `8`
2. `test_make_token_auth_token_matches_md5_password_plus_salt` — asserts `md5(pass+salt) == token`
3. `test_choose_auth_mode_returns_token_default` — no legacy, no api_key → "token"
4. `test_choose_auth_mode_returns_legacy_when_setting_enabled` — `legacyauth=true` → "legacy"
5. `test_choose_auth_mode_returns_apikey_when_extension_advertised` — probe returns ext + key set → "apikey"
6. `test_choose_auth_mode_returns_token_when_apikey_empty` — ext advertised but key="" → "token"
7. `test_probe_extensions_caches_result_per_session` — call twice; conn called only once
8. `test_probe_extensions_handles_any_error_as_no_extensions` — exception → empty set, cached
9. `test_apikey_mode_omits_user_token_salt_password_params` — `apiKey` only; no u/t/s/p
10. `test_token_mode_includes_token_and_salt_omits_password` — u/t/s present; no p/apiKey
11. `test_legacy_mode_includes_password_param` — u/p present; no t/s/apiKey

Total test count: 37 (all pass).

## Deviations from Plan

### Auto-fixed Issues

**1. [Rule 1 - Bug] Fixed mypy --strict no-any-return in star/unstar/scrobble**
- **Found during:** Task 2 (mypy --strict run)
- **Issue:** `resp.get("status") == "ok"` returns `bool | Any` which mypy rejects as `no-any-return` when the function return type is `bool`
- **Fix:** Wrapped comparisons in `bool()` cast: `return bool(resp.get("status") == "ok")`
- **Files modified:** `resources/lib/subsonic/api/client.py`
- **Commit:** `04e3988` (included in Task 2 commit)

## Known Stubs

None. All auth methods are fully implemented and wired. `build_auth_params()` returns real dicts; the probe uses the live conn method added in Task 1.

## Commits

| Task | Commit | Description |
|------|--------|-------------|
| Task 1 | `c7b1337` | feat(04-02): add getOpenSubsonicExtensions and update _getSalt to secrets.token_hex |
| Task 2 | `04e3988` | feat(04-02): implement auth-mode selection, probe_extensions, build_auth_params in ApiClient |

## Self-Check: PASSED

- [x] `resources/lib/subsonic/api/client.py` exists and contains all 5 new symbols
- [x] `lib/libsonic/connection.py` contains `getOpenSubsonicExtensions` and `secrets.token_hex`
- [x] `tests/test_api_client.py` contains all new test functions
- [x] Commits `c7b1337` and `04e3988` exist in git log
- [x] 37 tests pass (`python -m pytest tests/test_api_client.py`)
- [x] `ruff check` clean
- [x] `mypy --strict --ignore-missing-imports` clean
