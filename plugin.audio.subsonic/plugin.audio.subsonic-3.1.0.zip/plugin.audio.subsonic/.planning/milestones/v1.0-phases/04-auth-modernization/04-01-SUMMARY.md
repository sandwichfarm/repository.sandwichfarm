---
phase: 04-auth-modernization
plan: "01"
subsystem: settings
tags: [auth, settings, opensubsonic, api-key, ssl]
dependency_graph:
  requires: []
  provides:
    - Settings.subsonic_api_key (str property)
    - Settings.insecure_ssl_acknowledged (bool property)
    - Settings.set_insecure_ssl_acknowledged(bool) setter
    - Settings.set_insecure_ssl(bool) setter
    - settings.xml subsonic_api_key text entry (label 30050)
    - settings.xml insecure_ssl_acknowledged hidden bool entry
    - strings.po label #30050 in EN/FR/DE
  affects:
    - 04-02 (reads subsonic_api_key for auth-mode selection)
    - 04-03 (reads/writes insecure_ssl_acknowledged for SSL dialog gate)
tech_stack:
  added: []
  patterns:
    - Settings facade injection pattern (Settings(addon=mock)) for test isolation
    - bool() cast on getSetting comparison to satisfy mypy --strict no-any-return
key_files:
  created: []
  modified:
    - resources/settings.xml
    - resources/language/English/strings.po
    - resources/language/French/strings.po
    - resources/language/German/strings.po
    - resources/lib/subsonic/settings.py
    - tests/test_settings.py
decisions:
  - subsonic_api_key placed in ADVANCED tab (after legacyauth) — consistent with other auth settings; no new category needed
  - insecure_ssl_acknowledged placed in ADVANCED tab with visible="false" — hidden from user, persists dialog acknowledgement state
  - bool() cast applied to all getSetting comparisons in Settings — pre-existing mypy no-any-return errors fixed as part of this plan (Rule 1 auto-fix, same pattern throughout file)
metrics:
  duration: "147s"
  completed: "2026-04-28T18:31:21Z"
  tasks_completed: 2
  files_modified: 6
---

# Phase 4 Plan 1: Settings Extensions Summary

Settings extensions for OpenSubsonic API key and insecure-SSL acknowledgement: two new typed properties + two setters added to the Settings facade, backed by new settings.xml entries and strings.po labels.

## What Was Built

**Task 1 (4d26709):** Added `subsonic_api_key` (text, label 30050) and `insecure_ssl_acknowledged` (hidden bool) to `resources/settings.xml`. Added msgctxt "#30050" / "API Key (OpenSubsonic)" to all three strings.po files (English, French, German). No existing `id=` attributes renamed or removed (COMPAT-06 preserved).

**Task 2 (ed381eb):** Extended `resources/lib/subsonic/settings.py` with:
- `subsonic_api_key: str` property (getSetting "subsonic_api_key")
- `insecure_ssl_acknowledged: bool` property (getSetting "insecure_ssl_acknowledged")
- `set_insecure_ssl_acknowledged(value: bool) -> None` setter
- `set_insecure_ssl(value: bool) -> None` setter

Extended `tests/test_settings.py` with 7 new tests covering all four new members. Updated `test_settings_ids_verbatim` to include both new ids (18 total). All 35 tests pass.

## Deviations from Plan

### Auto-fixed Issues

**1. [Rule 1 - Bug] Fixed pre-existing mypy --strict no-any-return errors in Settings**

- **Found during:** Task 2, running mypy --strict as required by success criteria
- **Issue:** Five pre-existing bool properties returned `self._addon.getSetting(...).lower() == "true"` which mypy --strict flags as `Returning Any from function declared to return "bool"`. My new `insecure_ssl_acknowledged` property introduced a 6th instance of the same pattern.
- **Fix:** Wrapped all six bool comparisons in `bool(...)` cast throughout settings.py — `insecure`, `use_get`, `legacy_auth`, `insecure_ssl_acknowledged`, `merge`, `scrobble_enabled`
- **Files modified:** `resources/lib/subsonic/settings.py`
- **Commit:** ed381eb (included in Task 2 commit)

## Commits

| Task | Commit | Message |
|------|--------|---------|
| 1 | 4d26709 | feat(04-01): add subsonic_api_key and insecure_ssl_acknowledged settings |
| 2 | ed381eb | feat(04-01): extend Settings facade with api_key and ssl_acknowledged members |

## Verification Results

| Check | Result |
|-------|--------|
| `id="subsonic_api_key"` in settings.xml | PASS |
| `id="insecure_ssl_acknowledged"` in settings.xml | PASS |
| `visible="false"` in settings.xml | PASS |
| `msgctxt "#30050"` in English strings.po | PASS |
| `msgctxt "#30050"` in French strings.po | PASS |
| `msgctxt "#30050"` in German strings.po | PASS |
| `legacyauth` still present (COMPAT-06) | PASS |
| pytest tests/test_settings.py (35 tests) | PASS |
| ruff check settings.py | PASS |
| mypy --strict settings.py | PASS |

## Self-Check: PASSED
