---
phase: 04-auth-modernization
plan: 02
type: execute
wave: 2
depends_on:
  - 04-01
files_modified:
  - resources/lib/subsonic/api/client.py
  - lib/libsonic/connection.py
  - tests/test_api_client.py
autonomous: true
requirements:
  - AUTH-01
  - AUTH-02
  - AUTH-03
  - AUTH-04
  - AUTH-05

must_haves:
  truths:
    - "Salt is generated with secrets.token_hex(8) — not random, not os.urandom+md5"
    - "ApiClient.choose_auth_mode() returns 'token' by default"
    - "ApiClient.choose_auth_mode() returns 'legacy' when settings.legacy_auth is True"
    - "ApiClient.choose_auth_mode() returns 'apikey' when server advertises apiKeyAuthentication AND settings.subsonic_api_key is non-empty"
    - "In apikey mode, build_auth_params() omits u, t, s, p entirely"
    - "In token mode, build_auth_params() includes u, t, s; no p"
    - "In legacy mode, build_auth_params() includes u, p; no t, s"
    - "probe_extensions() result is cached on the ApiClient instance — second call does NOT hit the network"
    - "probe_extensions() returns empty set on any exception (404, 501, parse error)"
    - "libsonic.Connection has a getOpenSubsonicExtensions() method that calls the endpoint"
  artifacts:
    - path: "resources/lib/subsonic/api/client.py"
      provides: "make_token_auth, choose_auth_mode, probe_extensions, supports, build_auth_params"
      min_lines: 120
    - path: "lib/libsonic/connection.py"
      provides: "getOpenSubsonicExtensions() method"
      contains: "getOpenSubsonicExtensions"
    - path: "tests/test_api_client.py"
      provides: "10 new auth tests covering all modes, probe caching, apikey exclusivity"
      contains: "test_choose_auth_mode_returns_apikey"
  key_links:
    - from: "resources/lib/subsonic/api/client.py"
      to: "lib/libsonic/connection.py"
      via: "self._conn.getOpenSubsonicExtensions()"
      pattern: "getOpenSubsonicExtensions"
    - from: "resources/lib/subsonic/api/client.py"
      to: "resources/lib/subsonic/settings.py"
      via: "self._settings.subsonic_api_key / self._settings.legacy_auth"
      pattern: "self._settings.subsonic_api_key"
---

<objective>
Implement auth-mode selection and salt+token auth in ApiClient. Three new responsibilities:

1. `make_token_auth(password)` — generates salt via `secrets.token_hex(8)`, computes
   `md5(password+salt)`, returns `(token, salt)` (AUTH-01, AUTH-05)
2. `probe_extensions()` / `supports(ext)` — lazy OpenSubsonic probe, cached per instance,
   any error → empty set (AUTH-03)
3. `choose_auth_mode()` / `build_auth_params()` — selects apikey/token/legacy mode based
   on settings + probe result; apikey mode omits ALL of u/t/s/p (AUTH-02, AUTH-04)

Also adds `getOpenSubsonicExtensions()` to libsonic.Connection so the probe can call it.

NOTE: Phase 3's `get_open_subsonic_extensions()` method (plural, public) stays for backward
compat but the new `probe_extensions()` is the auth-time caching version. The Phase 3 stub
is superseded by this plan's implementation.

Output: Updated api/client.py with auth machinery; libsonic addition; 10 new test cases.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/ROADMAP.md
@.planning/STATE.md
@.planning/phases/04-auth-modernization/04-CONTEXT.md
@.planning/research/PITFALLS.md

@resources/lib/subsonic/api/client.py
@resources/lib/subsonic/settings.py
@lib/libsonic/connection.py
@tests/test_api_client.py
</context>

<interfaces>
<!-- Key existing interfaces in api/client.py (Phase 3) -->
```python
class ApiClient:
    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._conn = libsonic.Connection(
            baseUrl=settings.server_url,
            username=settings.username,
            password=settings.password,
            port=settings.port,
            apiVersion=settings.api_version,
            insecure=settings.insecure,
            legacyAuth=settings.legacy_auth,
            useGET=settings.use_get,
        )

    def get_open_subsonic_extensions(self) -> list[str]:
        """Phase 3 stub — Phase 4 supersedes with probe_extensions()."""
        try:
            resp = self._conn.getOpenSubsonicExtensions()
            exts = resp.get("openSubsonicExtensions") or []
            return [e.get("name", "") for e in exts]
        except Exception:
            return []
```

<!-- libsonic _getBaseQdict (connection.py:2794) — auth params are built here -->
```python
def _getBaseQdict(self):
    qdict = {
        'f': 'json',
        'v': self._apiVersion,
        'c': self._appName,
        'u': self._username,
    }
    if self._legacyAuth:
        qdict['p'] = 'enc:%s' % self._hexEnc(self._rawPass)
    else:
        salt = self._getSalt()
        token = md5((self._rawPass + salt).encode('utf-8')).hexdigest()
        qdict.update({'s': salt, 't': token})
    return qdict

def _getSalt(self, length=12):
    salt = md5(os.urandom(100)).hexdigest()
    return salt[:length]
```

<!-- New Settings properties from 04-01 (already available in Wave 2) -->
```python
@property
def subsonic_api_key(self) -> str: ...
@property
def insecure_ssl_acknowledged(self) -> bool: ...
def set_insecure_ssl_acknowledged(self, value: bool) -> None: ...
def set_insecure_ssl(self, value: bool) -> None: ...
```
</interfaces>

<tasks>

<task type="auto">
  <name>Task 1: Add getOpenSubsonicExtensions to libsonic.Connection</name>
  <files>lib/libsonic/connection.py</files>
  <action>
The Phase 3 ApiClient calls `self._conn.getOpenSubsonicExtensions()` but the method does not
exist in lib/libsonic/connection.py. Add it.

Find the `ping()` method (line ~231). Add the new method nearby, after the ping block.
The method uses `_getRequest` + `_doInfoReq` like other simple no-arg GET endpoints:

```python
def getOpenSubsonicExtensions(self):
    """
    since: OpenSubsonic extension

    Returns the list of OpenSubsonic extensions supported by the server.
    On legacy Subsonic servers this call returns a Subsonic error or HTTP error.

    Returns a dict with subsonic-response including 'openSubsonicExtensions'.
    """
    methodName = 'getOpenSubsonicExtensions'
    viewName = '%s.view' % methodName
    req = self._getRequest(viewName)
    return self._doInfoReq(req)
```

Also replace the `_getSalt` method body to use `secrets.token_hex` instead of
`md5(os.urandom(100))` (AUTH-05). The existing `_getSalt` ignores its `length` param in
practice (always called with default 12 which yields 12 chars from a 32-char hex digest).
The replacement produces a 16-char hex string (`secrets.token_hex(8)` = 8 bytes = 16 hex
chars). Update the method:

```python
def _getSalt(self, length: int = 16) -> str:
    import secrets
    return secrets.token_hex(length // 2)
```

The `length` param is kept for signature compat but now means "number of hex chars"
(token_hex(length//2) produces `length` hex chars). Default 16 chars (8 bytes entropy)
matches the Subsonic spec recommendation.

NOTE: Do NOT modify `_getBaseQdict` here — auth-mode override happens in ApiClient
(the addon layer), not in libsonic. libsonic's token path remains as fallback.
  </action>
  <read_first>
    - lib/libsonic/connection.py lines 230-260 (ping method area — add after it)
    - lib/libsonic/connection.py lines 2978-2981 (_getSalt — replace)
    - .planning/research/PITFALLS.md §"Pitfall 8" (LDAP token auth), §"Security Mistakes"
    - .planning/phases/04-auth-modernization/04-CONTEXT.md §"Salt+token mechanics"
  </read_first>
  <verify>
    <automated>grep -q 'def getOpenSubsonicExtensions' lib/libsonic/connection.py &amp;&amp; grep -q 'secrets.token_hex' lib/libsonic/connection.py</automated>
  </verify>
  <acceptance_criteria>
    - `grep -q 'def getOpenSubsonicExtensions' lib/libsonic/connection.py` exits 0
    - `grep -q 'secrets.token_hex' lib/libsonic/connection.py` exits 0
    - `grep -q 'import secrets' lib/libsonic/connection.py` exits 0
    - `! grep -q 'md5(os.urandom' lib/libsonic/connection.py` exits 0 (old _getSalt body gone)
  </acceptance_criteria>
  <done>libsonic.Connection has getOpenSubsonicExtensions(); _getSalt uses secrets.token_hex</done>
</task>

<task type="auto" tdd="true">
  <name>Task 2: Auth-mode selection + probe + build_auth_params in ApiClient</name>
  <files>resources/lib/subsonic/api/client.py, tests/test_api_client.py</files>
  <behavior>
    - `make_token_auth(password: str) -> tuple[str, str]` module-level function:
        - `salt = secrets.token_hex(8)` (16 hex chars)
        - `token = hashlib.md5((password + salt).encode("utf-8")).hexdigest()`
        - returns `(token, salt)`
    - `ApiClient.__init__` adds `self._extensions_cached: set[str] | None = None`
    - `ApiClient.probe_extensions() -> set[str]`:
        - if `self._extensions_cached is not None`: return it (cache hit — no network call)
        - try `self._conn.getOpenSubsonicExtensions()`, extract `{e["name"] for e in resp.get("openSubsonicExtensions") or []}`
        - except any Exception: `extensions = set()`
        - stores `self._extensions_cached = extensions`
        - returns it
    - `ApiClient.supports(extension: str) -> bool`: `return extension in self.probe_extensions()`
    - `ApiClient.choose_auth_mode() -> str`:
        - if `self._settings.legacy_auth`: return `"legacy"`
        - if `self._settings.subsonic_api_key` and `self.supports("apiKeyAuthentication")`: return `"apikey"`
        - return `"token"` (default — API ≥ 1.13)
    - `ApiClient.build_auth_params() -> dict[str, str]`:
        - mode = `self.choose_auth_mode()`
        - if `"apikey"`: `return {"apiKey": self._settings.subsonic_api_key}`  (no u/t/s/p)
        - if `"token"`: `token, salt = make_token_auth(self._settings.password)` → return `{"u": self._settings.username, "t": token, "s": salt}`
        - if `"legacy"`: return `{"u": self._settings.username, "p": self._settings.password}`
    - Tests (10 new tests):
        1. `test_choose_auth_mode_returns_token_default` — no legacy_auth, no api_key → "token"
        2. `test_choose_auth_mode_returns_legacy_when_setting_enabled` — legacy_auth=True → "legacy"
        3. `test_choose_auth_mode_returns_apikey_when_extension_advertised` — probe returns apiKeyAuthentication, api_key set → "apikey"
        4. `test_choose_auth_mode_returns_token_when_apikey_empty` — probe advertises ext but api_key="" → "token"
        5. `test_make_token_auth_uses_secrets_token_hex` — patch secrets.token_hex, assert it's called
        6. `test_make_token_auth_token_matches_md5_password_plus_salt` — assert md5(pass+salt)==token
        7. `test_probe_extensions_caches_result_per_session` — call probe twice; conn.getOpenSubsonicExtensions called only once
        8. `test_probe_extensions_handles_any_error_as_no_extensions` — conn raises Exception → returns empty set, caches it
        9. `test_apikey_mode_omits_user_token_salt_password_params` — build_auth_params() in apikey mode has no u/t/s/p keys
        10. `test_token_mode_includes_token_and_salt_omits_password` — build_auth_params() token mode has u/t/s but no p
        11. `test_legacy_mode_includes_password_param` — build_auth_params() legacy mode has u/p but no t/s
  </behavior>
  <action>
TDD cycle:

RED: Add 10 test functions to tests/test_api_client.py. Run `python3 -m pytest tests/test_api_client.py -x -q` — new tests fail (functions don't exist).

GREEN: In resources/lib/subsonic/api/client.py:

1. Add imports at top:
```python
import hashlib
import secrets
from typing import Literal
```

2. Add module-level function before the class:
```python
def make_token_auth(password: str) -> tuple[str, str]:
    """Return (token, salt) for Subsonic salt+token auth (AUTH-01, AUTH-05).

    salt is generated fresh per call via secrets.token_hex(8) — 8 bytes of
    cryptographic entropy, 16 hex chars. Token = md5(password + salt).hexdigest().
    Never log either value.
    """
    salt = secrets.token_hex(8)
    token = hashlib.md5((password + salt).encode("utf-8")).hexdigest()
    return token, salt
```

3. Update `__init__`:
```python
def __init__(self, settings: Settings) -> None:
    self._settings = settings
    self._extensions_cached: set[str] | None = None
    self._conn = libsonic.Connection(
        baseUrl=settings.server_url,
        username=settings.username,
        password=settings.password,
        port=settings.port,
        apiVersion=settings.api_version,
        insecure=settings.insecure,
        legacyAuth=settings.legacy_auth,
        useGET=settings.use_get,
    )
```

4. Add after `__init__`:
```python
# ------------------------------------------------------------------
# Auth-mode selection (AUTH-01..05)
# ------------------------------------------------------------------

def probe_extensions(self) -> set[str]:
    """Probe for OpenSubsonic extensions. Lazy — called only when needed.

    Result is cached for this ApiClient instance lifetime (per-session).
    Any error (404, 501, parse failure, network) → empty set, cached.
    Subsequent calls always return the cached result without a network round-trip
    (AUTH-03).
    """
    if self._extensions_cached is not None:
        return self._extensions_cached
    try:
        resp = self._conn.getOpenSubsonicExtensions()
        extensions: set[str] = {
            e["name"]
            for e in (resp.get("openSubsonicExtensions") or [])
            if isinstance(e, dict) and "name" in e
        }
    except Exception:
        extensions = set()
    self._extensions_cached = extensions
    return extensions

def supports(self, extension: str) -> bool:
    """Return True if the server advertises the named OpenSubsonic extension."""
    return extension in self.probe_extensions()

def choose_auth_mode(self) -> Literal["apikey", "token", "legacy"]:
    """Select the auth mode for this session (AUTH-01..04).

    Priority:
    1. legacy — explicit user opt-in (LDAP / pre-1.13 escape hatch, AUTH-02)
    2. apikey — server advertises apiKeyAuthentication AND user has set an API key
    3. token — default for modern servers (Subsonic API >= 1.13)
    """
    if self._settings.legacy_auth:
        return "legacy"
    if self._settings.subsonic_api_key and self.supports("apiKeyAuthentication"):
        return "apikey"
    return "token"

def build_auth_params(self) -> dict[str, str]:
    """Return the auth query-param dict for the current auth mode (AUTH-04).

    apikey mode: {"apiKey": key}            — u/t/s/p ALL suppressed (OpenSubsonic spec)
    token  mode: {"u": ..., "t": ..., "s": ...}   — fresh salt per call (AUTH-01)
    legacy mode: {"u": ..., "p": ...}       — plaintext fallback (AUTH-02)
    """
    mode = self.choose_auth_mode()
    if mode == "apikey":
        return {"apiKey": self._settings.subsonic_api_key}
    if mode == "token":
        token, salt = make_token_auth(self._settings.password)
        return {
            "u": self._settings.username,
            "t": token,
            "s": salt,
        }
    # legacy
    return {
        "u": self._settings.username,
        "p": self._settings.password,
    }
```

5. Update the Phase 3 stub `get_open_subsonic_extensions()` to delegate to `probe_extensions()`:
```python
def get_open_subsonic_extensions(self) -> list[str]:
    """Return extension names. Delegates to probe_extensions() (Phase 4 upgrade)."""
    return list(self.probe_extensions())
```

Test helper for probe_extensions tests — mock conn.getOpenSubsonicExtensions:
```python
def test_probe_extensions_caches_result_per_session():
    mock_conn = MagicMock()
    mock_conn.getOpenSubsonicExtensions.return_value = {
        "openSubsonicExtensions": [{"name": "apiKeyAuthentication", "versions": [1]}]
    }
    client = _make_client(mock_conn)
    result1 = client.probe_extensions()
    result2 = client.probe_extensions()
    assert result1 == result2 == {"apiKeyAuthentication"}
    assert mock_conn.getOpenSubsonicExtensions.call_count == 1  # cached
```

For choose_auth_mode tests, use `_make_client` and patch `client.probe_extensions`:
```python
from unittest.mock import patch

def test_choose_auth_mode_returns_apikey_when_extension_advertised():
    mock_conn = MagicMock()
    client = _make_client(mock_conn, subsonic_api_key="mykey")
    with patch.object(client, "probe_extensions", return_value={"apiKeyAuthentication"}):
        assert client.choose_auth_mode() == "apikey"
```

NOTE: `_make_settings` helper in test_api_client.py must be updated to add
`subsonic_api_key` and `insecure_ssl_acknowledged` to its defaults dict (with empty
string defaults) so the new settings don't raise KeyError.
  </action>
  <read_first>
    - resources/lib/subsonic/api/client.py — full file; understand Phase 3 structure
    - tests/test_api_client.py — full file; find _make_settings helper to update defaults
    - .planning/phases/04-auth-modernization/04-CONTEXT.md §"Auth-mode selection", §"Salt+token mechanics", §"API-key auth", §"OpenSubsonic capability probe", §"Test coverage"
    - .planning/research/PITFALLS.md §"OpenSubsonic API-key auth gotcha" (u/t/s must be absent)
  </read_first>
  <verify>
    <automated>cd /home/sandwich/Develop/plugin.audio.subsonic &amp;&amp; .venv/bin/python -m pytest tests/test_api_client.py -v -q 2&gt;&amp;1 | tail -10</automated>
  </verify>
  <acceptance_criteria>
    - `grep -q 'def make_token_auth' resources/lib/subsonic/api/client.py` exits 0
    - `grep -q 'secrets\.token_hex' resources/lib/subsonic/api/client.py` exits 0
    - `grep -q 'def probe_extensions' resources/lib/subsonic/api/client.py` exits 0
    - `grep -q 'def choose_auth_mode' resources/lib/subsonic/api/client.py` exits 0
    - `grep -q 'def build_auth_params' resources/lib/subsonic/api/client.py` exits 0
    - `grep -q 'test_choose_auth_mode_returns_apikey' tests/test_api_client.py` exits 0
    - `grep -q 'test_probe_extensions_caches_result' tests/test_api_client.py` exits 0
    - `python3 -m pytest tests/test_api_client.py -v` exits 0
    - In apikey mode: `build_auth_params()` result has no keys matching `u|t|s|p`
    - `grep -q 'apiKey' resources/lib/subsonic/api/client.py` exits 0
  </acceptance_criteria>
  <done>ApiClient has full auth-mode selection; 10+ new tests all pass; probe cached; apikey mode omits u/t/s/p</done>
</task>

</tasks>

<verification>
After both tasks:
1. `grep -q 'def getOpenSubsonicExtensions' lib/libsonic/connection.py` exits 0
2. `grep -q 'secrets.token_hex' lib/libsonic/connection.py` exits 0
3. `grep -q 'def make_token_auth' resources/lib/subsonic/api/client.py` exits 0
4. `grep -q 'def probe_extensions' resources/lib/subsonic/api/client.py` exits 0
5. `python3 -m pytest tests/test_api_client.py -v` exits 0
6. `ruff check resources/lib/subsonic/api/client.py` exits 0
7. `mypy resources/lib/subsonic/api/client.py --strict --ignore-missing-imports` exits 0
</verification>

<success_criteria>
- libsonic.Connection.getOpenSubsonicExtensions() exists and calls the endpoint
- libsonic._getSalt uses secrets.token_hex (AUTH-05 in libsonic layer)
- ApiClient.make_token_auth() uses secrets.token_hex(8) (AUTH-05 in addon layer)
- probe_extensions() is lazy and cached — second call never hits the network (AUTH-03)
- Any error during probe → empty set, NOT an exception (AUTH-03)
- choose_auth_mode() correctly prioritizes: legacy > apikey > token (AUTH-01/02/04)
- build_auth_params() in apikey mode has ONLY apiKey — no u/t/s/p at all (AUTH-04)
- All tests pass
</success_criteria>

<output>
After completion, create `.planning/phases/04-auth-modernization/04-02-SUMMARY.md`
</output>
