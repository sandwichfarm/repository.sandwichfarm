---
status: partial
phase: 04-auth-modernization
source: [04-VERIFICATION.md]
started: 2026-04-28T19:00:00Z
updated: 2026-04-28T19:00:00Z
---

## Current Test

[awaiting human testing — runtime checks for Phase 6 server-verification]

## Tests

### 1. Salt+token auth round-trip
expected: With `legacyauth=false` (default), connect to a Navidrome instance. Network capture or Navidrome logs confirm requests include `t=...` and `s=...` params, NOT `p=...`.
result: [pending]

### 2. Legacyauth fallback for LDAP-backed servers
expected: With `legacyauth=true`, connect to an Airsonic instance with LDAP-authenticated users. Auth succeeds (the LDAP server can't verify the salt+token form, but plaintext works).
result: [pending]

### 3. OpenSubsonic probe caching
expected: First request triggers `getOpenSubsonicExtensions`; subsequent requests within the same session do NOT re-probe (verify via Navidrome request logs).
result: [pending]

### 4. API-key auth mode
expected: Set `subsonic_api_key` in settings to a Navidrome-issued key. The addon's request URLs contain `apiKey=...` and DO NOT contain `u=`, `t=`, `s=`, or `p=`.
result: [pending]

### 5. Insecure-SSL dialog gate
expected: With `insecure_ssl=false` (default), no dialog. Toggle to true via Kodi settings UI; on next addon launch, the warning dialog fires with the expected text. Cancel reverts setting to false. Accept persists `insecure_ssl_acknowledged=true` and dialog never re-fires.
result: [pending]

## Summary

total: 5
passed: 0
issues: 0
pending: 5
skipped: 0
blocked: 0

## Gaps

None automated. All 5 items are runtime concerns deferred to Phase 6 server verification.
