---
phase: 04-auth-modernization
plan: 03
type: execute
wave: 2
depends_on:
  - 04-01
files_modified:
  - resources/lib/subsonic/bootstrap.py
  - tests/test_bootstrap.py
autonomous: true
requirements:
  - AUTH-07

must_haves:
  truths:
    - "When insecure_ssl=true AND insecure_ssl_acknowledged=false, a yesno dialog is shown before proceeding"
    - "If user clicks Cancel (yesno returns False), insecure setting is reverted to false"
    - "If user clicks I understand (yesno returns True), insecure_ssl_acknowledged is set to true"
    - "When insecure_ssl=false, the dialog is never shown"
    - "When insecure_ssl=true AND acknowledged=true, the dialog is not shown again"
    - "bootstrap.run_plugin calls _check_insecure_ssl_acknowledgement before ApiClient construction"
  artifacts:
    - path: "resources/lib/subsonic/bootstrap.py"
      provides: "_check_insecure_ssl_acknowledgement function + call in run_plugin"
      contains: "_check_insecure_ssl_acknowledgement"
    - path: "tests/test_bootstrap.py"
      provides: "Tests for all 4 dialog gate scenarios"
      contains: "test_insecure_ssl_first_enable_shows_dialog"
  key_links:
    - from: "resources/lib/subsonic/bootstrap.py"
      to: "resources/lib/subsonic/settings.py"
      via: "_check_insecure_ssl_acknowledgement(settings) reads insecure + acknowledged; calls setters"
      pattern: "set_insecure_ssl_acknowledged"
    - from: "resources/lib/subsonic/bootstrap.py"
      to: "xbmcgui.Dialog().yesno"
      via: "confirmed = xbmcgui.Dialog().yesno(...)"
      pattern: "xbmcgui.Dialog.*yesno"
---

<objective>
Add the insecure-SSL confirmation dialog gate to bootstrap.py. When the addon detects
`insecure_ssl=true` but `insecure_ssl_acknowledged=false`, it shows a yesno dialog.
If accepted → mark acknowledged; if declined → revert insecure to false.

This gate runs before `ApiClient` is constructed in `run_plugin`, so a declined dialog
means the ApiClient is constructed with `insecure=false` (the reverted value).

Output: Updated bootstrap.py with `_check_insecure_ssl_acknowledgement`; new test_bootstrap.py.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/ROADMAP.md
@.planning/STATE.md
@.planning/phases/04-auth-modernization/04-CONTEXT.md

@resources/lib/subsonic/bootstrap.py
@resources/lib/subsonic/settings.py
@tests/conftest.py
</context>

<interfaces>
<!-- bootstrap.run_plugin (Phase 3) — add gate before ApiClient construction -->
```python
def run_plugin(argv: list[str]) -> None:
    try:
        settings = Settings()
        # Phase 4: ADD _check_insecure_ssl_acknowledgement(settings) HERE
        client = ApiClient(settings)
        cache = Cache(cache_dir=_get_cache_dir())
        _patch_routes_with_context(client, settings, cache, int(argv[1]))
        dispatch(argv)
    except Exception:
        log_exception("run_plugin: unhandled error in plugin dispatch")
```

<!-- New Settings setters from 04-01 -->
```python
def set_insecure_ssl_acknowledged(self, value: bool) -> None: ...
def set_insecure_ssl(self, value: bool) -> None: ...

@property
def insecure(self) -> bool: ...
@property
def insecure_ssl_acknowledged(self) -> bool: ...
```

<!-- xbmcgui.Dialog mock (from conftest.py) -->
```python
# sys.modules["xbmcgui"] is a MagicMock
# In tests configure: sys.modules["xbmcgui"].Dialog.return_value.yesno.return_value = True/False
```
</interfaces>

<tasks>

<task type="auto" tdd="true">
  <name>Task 1: Add insecure-SSL dialog gate to bootstrap.py + tests</name>
  <files>resources/lib/subsonic/bootstrap.py, tests/test_bootstrap.py</files>
  <behavior>
    - `_check_insecure_ssl_acknowledgement(settings: Settings) -> None`:
        - if `not settings.insecure`: return immediately (no dialog)
        - if `settings.insecure_ssl_acknowledged`: return immediately (already accepted)
        - call `xbmcgui.Dialog().yesno(...)` with title, message, nolabel, yeslabel
        - if `confirmed` (True): `settings.set_insecure_ssl_acknowledged(True)` — persist acknowledgement
        - if `not confirmed` (False): `settings.set_insecure_ssl(False)` — revert the setting
    - `run_plugin` calls `_check_insecure_ssl_acknowledgement(settings)` after `settings = Settings()` and before `client = ApiClient(settings)`
    - Dialog title: `"Insecure SSL warning"`
    - Dialog body: `"Disabling SSL certificate verification leaves traffic vulnerable to interception. Only enable this for self-signed homelab servers you control. Continue?"`
    - nolabel: `"Cancel"`, yeslabel: `"I understand"`
    - 4 test cases in tests/test_bootstrap.py:
        1. `test_insecure_ssl_gate_no_dialog_when_insecure_false` — insecure=False → yesno never called
        2. `test_insecure_ssl_gate_no_dialog_when_already_acknowledged` — insecure=True, acknowledged=True → yesno never called
        3. `test_insecure_ssl_first_enable_shows_dialog_accept` — insecure=True, acknowledged=False, yesno→True → set_acknowledged(True) called; insecure NOT reverted
        4. `test_insecure_ssl_first_enable_shows_dialog_decline` — insecure=True, acknowledged=False, yesno→False → set_insecure_ssl(False) called; acknowledged NOT set
  </behavior>
  <action>
TDD cycle:

RED: Create tests/test_bootstrap.py with 4 test functions. Run `python3 -m pytest tests/test_bootstrap.py -x -q` — ImportError or all fail.

GREEN: Implement in resources/lib/subsonic/bootstrap.py.

Add import `import xbmcgui` to bootstrap.py (it already imports xbmcaddon and xbmcvfs).

Add the gate function BEFORE `run_plugin`:

```python
def _check_insecure_ssl_acknowledgement(settings: Settings) -> None:
    """Show a warning dialog the first time insecure SSL is detected enabled.

    If the user accepts, persists the acknowledgement so the dialog is not
    shown again on the next invocation. If the user declines, reverts the
    insecure setting to False.

    No-op when insecure is disabled or already acknowledged. (AUTH-07)
    """
    if not settings.insecure:
        return
    if settings.insecure_ssl_acknowledged:
        return
    confirmed: bool = xbmcgui.Dialog().yesno(
        "Insecure SSL warning",
        "Disabling SSL certificate verification leaves traffic vulnerable to "
        "interception. Only enable this for self-signed homelab servers you "
        "control. Continue?",
        nolabel="Cancel",
        yeslabel="I understand",
    )
    if confirmed:
        settings.set_insecure_ssl_acknowledged(True)
    else:
        settings.set_insecure_ssl(False)
```

In `run_plugin`, insert the gate call:

```python
def run_plugin(argv: list[str]) -> None:
    try:
        settings = Settings()
        _check_insecure_ssl_acknowledgement(settings)  # AUTH-07
        client = ApiClient(settings)
        cache = Cache(cache_dir=_get_cache_dir())
        _patch_routes_with_context(client, settings, cache, int(argv[1]))
        dispatch(argv)
    except Exception:
        log_exception("run_plugin: unhandled error in plugin dispatch")
```

Test scaffold (tests/test_bootstrap.py):

```python
"""Tests for subsonic.bootstrap._check_insecure_ssl_acknowledgement (AUTH-07)."""
from __future__ import annotations
import sys
import os
from unittest.mock import MagicMock, patch

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for p in (os.path.join(_REPO, "resources", "lib"), os.path.join(_REPO, "lib")):
    if p not in sys.path:
        sys.path.insert(0, p)

from subsonic.settings import Settings
from subsonic.bootstrap import _check_insecure_ssl_acknowledgement


def _make_settings(insecure: str = "false", acknowledged: str = "false") -> Settings:
    addon = MagicMock()
    store: dict[str, str] = {"insecure": insecure, "insecure_ssl_acknowledged": acknowledged}
    addon.getSetting.side_effect = lambda k: store.get(k, "false")
    addon.setSetting = MagicMock()
    return Settings(addon=addon)


def test_insecure_ssl_gate_no_dialog_when_insecure_false():
    settings = _make_settings(insecure="false", acknowledged="false")
    with patch("subsonic.bootstrap.xbmcgui") as mock_gui:
        _check_insecure_ssl_acknowledgement(settings)
        mock_gui.Dialog.return_value.yesno.assert_not_called()


def test_insecure_ssl_gate_no_dialog_when_already_acknowledged():
    settings = _make_settings(insecure="true", acknowledged="true")
    with patch("subsonic.bootstrap.xbmcgui") as mock_gui:
        _check_insecure_ssl_acknowledgement(settings)
        mock_gui.Dialog.return_value.yesno.assert_not_called()


def test_insecure_ssl_first_enable_shows_dialog_accept():
    settings = _make_settings(insecure="true", acknowledged="false")
    with patch("subsonic.bootstrap.xbmcgui") as mock_gui:
        mock_gui.Dialog.return_value.yesno.return_value = True
        _check_insecure_ssl_acknowledgement(settings)
        mock_gui.Dialog.return_value.yesno.assert_called_once()
        # Should have persisted acknowledged=True
        call_args = settings._addon.setSetting.call_args_list
        ids_set = {c.args[0] for c in call_args}
        assert "insecure_ssl_acknowledged" in ids_set
        # Should NOT have reverted insecure
        assert "insecure" not in ids_set


def test_insecure_ssl_first_enable_shows_dialog_decline():
    settings = _make_settings(insecure="true", acknowledged="false")
    with patch("subsonic.bootstrap.xbmcgui") as mock_gui:
        mock_gui.Dialog.return_value.yesno.return_value = False
        _check_insecure_ssl_acknowledgement(settings)
        mock_gui.Dialog.return_value.yesno.assert_called_once()
        # Should have reverted insecure to False
        call_args = settings._addon.setSetting.call_args_list
        ids_set = {c.args[0] for c in call_args}
        assert "insecure" in ids_set
        # Should NOT have set acknowledged
        assert "insecure_ssl_acknowledged" not in ids_set
```
  </action>
  <read_first>
    - resources/lib/subsonic/bootstrap.py — full file; find import block and run_plugin body
    - resources/lib/subsonic/settings.py — confirm set_insecure_ssl_acknowledged and set_insecure_ssl exist (from 04-01)
    - tests/conftest.py — understand xbmcgui mock setup for Dialog
    - .planning/phases/04-auth-modernization/04-CONTEXT.md §"Insecure SSL confirmation"
  </read_first>
  <verify>
    <automated>cd /home/sandwich/Develop/plugin.audio.subsonic &amp;&amp; .venv/bin/python -m pytest tests/test_bootstrap.py -v -q 2&gt;&amp;1 | tail -10</automated>
  </verify>
  <acceptance_criteria>
    - `grep -q '_check_insecure_ssl_acknowledgement' resources/lib/subsonic/bootstrap.py` exits 0
    - `grep -q '_check_insecure_ssl_acknowledgement(settings)' resources/lib/subsonic/bootstrap.py` exits 0 (called in run_plugin)
    - `grep -q 'Insecure SSL warning' resources/lib/subsonic/bootstrap.py` exits 0
    - `grep -q 'I understand' resources/lib/subsonic/bootstrap.py` exits 0
    - `python3 -m pytest tests/test_bootstrap.py -v` exits 0 (all 4 tests pass)
    - `ruff check resources/lib/subsonic/bootstrap.py` exits 0
    - `mypy resources/lib/subsonic/bootstrap.py --strict --ignore-missing-imports` exits 0
  </acceptance_criteria>
  <done>Dialog gate implemented; gate is called in run_plugin before ApiClient construction; all 4 tests pass</done>
</task>

</tasks>

<verification>
1. `grep -q '_check_insecure_ssl_acknowledgement' resources/lib/subsonic/bootstrap.py` exits 0
2. `python3 -m pytest tests/test_bootstrap.py -v` exits 0
3. `ruff check resources/lib/subsonic/bootstrap.py` exits 0
</verification>

<success_criteria>
- bootstrap._check_insecure_ssl_acknowledgement correctly implements the three-case logic (disabled / acknowledged / first-enable)
- Dialog is shown ONLY when insecure=true AND acknowledged=false
- Decline reverts insecure to false; Accept persists acknowledged=true
- gate is wired into run_plugin before ApiClient construction
- All 4 tests pass
</success_criteria>

<output>
After completion, create `.planning/phases/04-auth-modernization/04-03-SUMMARY.md`
</output>
