---
status: human_needed
phase: 04-auth-modernization
verified: 2026-04-28
---

# Phase 4 Verification

## Phase Goal

The addon defaults to secure salt+token auth, supports OpenSubsonic API-key auth when the server offers it, and never leaks credentials to xbmc.log.

## Requirements Coverage (7/7)

| REQ | Plan(s) | Status |
|-----|---------|--------|
| AUTH-01 (salt+token default for API ≥ 1.13) | 04-02 | ✅ Code shipped — runtime gate Phase 6 |
| AUTH-02 (legacyauth fallback for LDAP) | 04-02 | ✅ Code shipped — runtime gate Phase 6 |
| AUTH-03 (OpenSubsonic probe lazy + cached) | 04-02 | ✅ Code shipped — runtime gate Phase 6 |
| AUTH-04 (API-key mode mutually exclusive with u/t/s/p) | 04-01 + 04-02 | ✅ Code + tests confirm exclusion |
| AUTH-05 (`secrets.token_hex` for salt) | 04-02 | ✅ Confirmed via grep + tests |
| AUTH-06 (no credentials in xbmc.log) | 04-04 | ✅ Audit clean, 5 active leaks fixed |
| AUTH-07 (insecure-SSL dialog) | 04-01 + 04-03 | ✅ Code shipped — runtime gate Phase 6 |

## Automated Checks (all PASS)

- `pytest tests/`: **195 passed** (37 in test_api_client.py, 35 in test_settings.py, 4 in test_bootstrap.py)
- `ruff check resources/lib/subsonic/`: clean
- `mypy --strict resources/lib/subsonic/`: 15 files, 0 errors
- AUTH-06 audit greps: 0 active hits (3 fixes landed in commit ad27be8)
- `grep -q 'secrets\.token_hex' resources/lib/subsonic/api/client.py`: present
- `grep -q 'apiKey' resources/lib/subsonic/api/client.py`: present
- `grep -q 'subsonic_api_key' resources/settings.xml`: present

## Human Verification Required (5 items, deferred to Phase 6)

1. Salt+token auth round-trip against a real Subsonic-API ≥ 1.13 server (Navidrome)
2. Legacyauth fallback works for an LDAP-backed Airsonic
3. OpenSubsonic capability probe response cached per session
4. API-key auth mode (test against Navidrome's `apiKeyAuthentication` extension)
5. Insecure-SSL dialog fires correctly when toggling the setting

## Conclusion

Phase 4 code is complete, tested, and credential-clean. The remaining items are runtime confirmations against live servers — out of scope for v1 unit testing, in scope for Phase 6 server verification.
