---
plan: 04-04-audit-and-verify
phase: 04-auth-modernization
status: complete
date: 2026-04-28
requirements_addressed: [AUTH-06]
---

# Plan 04-04: Credential Leak Audit + Final Verify — Summary

## What was done

Repo-wide credential leak audit per AUTH-06. Five separate grep audits across `main.py`, `service.py`, `resources/lib/`, and `lib/libsonic/`.

## Audit findings + fixes

| Audit | Hits | Fix |
|-------|------|-----|
| `xbmc.log` interpolating `.view`/`http`/URL fragments | 0 | n/a |
| Auth params (`p=`/`t=`/`s=`/`password=`/`token=`/`salt=`/`apiKey=`) in log strings | 0 | n/a |
| `print()` in vendored libsonic | 3 active sites | All removed |
| Bare `except:` in non-vendored code | 0 | n/a |
| Bare `except:` in vendored libsonic | 2 sites | Both tightened |
| `(xbmc.log\|print)` interpolating `full_url`/`get_full_url` | 3 active sites | All replaced with viewName-only logs |

### Specific fixes (commit ad27be8)

`lib/libsonic/connection.py`:
- Line 54: `except:` → `except (ssl.SSLError, OSError):` with `raise`
- Line 242: `xbmc.log("Pinging %s" % req.full_url)` → `xbmc.log("Pinging Subsonic API: %s" % viewName)`
- Line 246: `print("Ping failed %s" % e)` → `xbmc.log("Subsonic ping failed: %s" % type(e).__name__, xbmc.LOGDEBUG)`
- Line 1731: `except:` (int parse) → `except (ValueError, TypeError):`
- Line 2026: `xbmc.log("Requesting %s" % req.full_url)` → `xbmc.log("Subsonic API: %s" % viewName)`
- Lines 2517-2518: `print(req.get_full_url())` + `print(res)` — both REMOVED. The `get_full_url()` print was actively leaking auth params.

### Pre-existing mypy noise cleaned up (commit ad27be8)

Three "unused type:ignore" warnings emerged from a newer mypy version after Phase 3:
- `models.py:17` — dropped unused ignore
- `scrobbler.py:20` — kept ignore (Monitor type needs it)
- `browse.py:266` — dropped unused ignore

## Verification

| Check | Result |
|-------|--------|
| `pytest tests/` | 195 passed in 0.19s |
| `ruff check resources/lib/subsonic/` | All checks passed |
| `mypy --strict resources/lib/subsonic/` | Success: no issues found in 15 source files |
| `grep -E '(xbmc\.log\|print)\(.*(full_url\|get_full_url)' main.py service.py resources/lib/ lib/libsonic/` | only commented dead-code remains (lines 925, 974) |

## Phase 4 deferred items (Kodi runtime UAT — Phase 6)

1. **Salt+token auth round-trip against Subsonic ≥ 1.13** — confirm Navidrome accepts the `t` + `s` params with no fallback
2. **Legacy auth fallback** — confirm an LDAP-backed Airsonic instance still authenticates with `legacyauth=true`
3. **OpenSubsonic capability probe** — confirm Navidrome returns `apiKeyAuthentication` in `getOpenSubsonicExtensions` and the addon caches the result for the session
4. **API-key auth** — set a key in settings, confirm the request URL contains `apiKey=` and not `u/t/s/p`
5. **Insecure SSL dialog** — toggle the setting, confirm the `xbmcgui.Dialog().yesno()` warning fires; Cancel reverts; Accept persists

## Next

Phase 4 complete (4/4 plans, 7/7 requirements). Phase 5 (Feature Expansion) unblocked.
