---
phase: 05-feature-expansion
plan: "03"
subsystem: handlers
tags: [browse, search, playback, actions, genres, radio, rating, feat-01, feat-02, feat-03, feat-04]
dependency_graph:
  requires: [05-01-api-layer, 05-02-listings-extensions]
  provides: [list_genres, list_genre_tracks, list_radio_stations, play_radio, rate_track, search3-migration]
  affects: [bootstrap.py (route registration), root menu (Genres + Internet Radio entries)]
tech_stack:
  added: []
  patterns: [show_rating_select ARCH-05 wrapper, direct setResolvedUrl for radio stream, from-import patching via subsonic.actions module ref]
key_files:
  created:
    - tests/test_playback.py
  modified:
    - resources/lib/subsonic/browse.py
    - resources/lib/subsonic/playback.py
    - resources/lib/subsonic/actions.py
    - resources/lib/subsonic/search.py
    - tests/test_browse.py
    - tests/test_actions.py
    - tests/test_search.py
decisions:
  - Patched show_rating_select via subsonic.actions module ref (not subsonic.listings) because from-import binds directly in actions namespace
  - song_count in search() raised from 20 to 40 (plan spec: search3 uses 40 for richer results)
  - list_genre_tracks passes hide_artist=False so cross-genre tracks show artist name
  - list_radio_stations skips stations missing streamUrl (empty string or absent key)
metrics:
  duration: "231s"
  completed: "2026-04-28T21:45:23Z"
  tasks_completed: 2
  files_modified: 7
  commits: 2
---

# Phase 05 Plan 03: Handlers Summary

**One-liner:** Five feature handlers wired (list_genres, list_genre_tracks, list_radio_stations, play_radio, rate_track) + search migrated from search2 to search3, with 49 new/updated tests passing.

## Tasks Completed

| Task | Name | Commit | Files |
|------|------|--------|-------|
| 1 | Genre/radio browse handlers, play_radio, rate_track | 424cacf | browse.py, playback.py, actions.py |
| 2 | Migrate search to search3 + write all handler tests | 4b31ce8 | search.py, test_browse.py, test_playback.py, test_actions.py, test_search.py |

## What Was Built

### browse.py additions

- **`list_genres` (`@route("genres")`** — Calls `client.get_genres()`, skips genres with empty `value`, builds directory items via `build_genre_item`. Content type `"genres"`.

- **`list_genre_tracks` (`@route("genre_tracks")`** — Accepts `genre=""` param; returns `succeeded=False` early when empty; calls `client.get_songs_by_genre(genre, count=100)`, builds items via `build_track_item` with `hide_artist=False`. Content type `"songs"`.

- **`list_radio_stations` (`@route("radio")`** — Calls `client.get_internet_radio_stations()`; skips stations without `streamUrl`; builds nav items routing to `play_radio`. Empty list handled gracefully (empty directory). Content type `"songs"`.

- **Root menu update** — Appended `"Genres"` and `"Internet Radio"` entries after `"Search Albums"`.

- **`menu_albums` by_genre stub replaced** — Was `"(Genre browsing in Phase 5)"` routing to root; now routes to `url_for("genres")` with label `"Browse by Genre"`.

### playback.py additions

- **`play_radio` (`@route("play_radio")`** — Accepts `id=""` and `stream_url=""` params. On empty `stream_url`: logs error + `setResolvedUrl(handle, False, ...)`. On valid URL: creates `xbmcgui.ListItem(path=stream_url)` and calls `setResolvedUrl(handle, True, li)`. No Subsonic transcoding — direct radio stream URL.

### actions.py additions

- **`rate_track` (`@route("rate_track")`** — Accepts `id=""`. Guards on empty id (early return). Calls `show_rating_select(id)` from `subsonic.listings` (ARCH-05 preserved — no xbmcgui import in actions.py). Returns early on `None` (user cancelled). Calls `client.set_rating(item_id=id, rating=rating)`. On success: `cache.invalidate("starred")` + `xbmc.executebuiltin("Container.Refresh")`.

### search.py migration (FEAT-02)

- Both `search()` and `search_album()` now call `client.search3()` instead of `client.search()`.
- `song_count` in `search()` raised from 20 → 40 for richer results.
- Result key access (`"artist"`, `"album"`, `"song"`) unchanged — search3 returns the same shape.

## Test Coverage

Full suite: **240 passed**.

New/updated tests in this plan:

| File | Tests Added | Description |
|------|------------|-------------|
| test_browse.py | +9 | list_genres (3), list_genre_tracks (2), list_radio_stations (3), root menu check (1) |
| test_playback.py | +3 (new file) | play_radio success, failure, stream_url passthrough |
| test_actions.py | +7 | rate_track: set_rating, cancel, no-id, cache invalidate, refresh, failure, ARCH-05 |
| test_search.py | updated 4 | Assertions changed from client.search → client.search3 |

## Deviations from Plan

### Auto-fixed Issues

**1. [Rule 1 - Bug] Test patching target for show_rating_select**

- **Found during:** Task 2 — 5 test failures with `TypeError: '<' not supported between instances of 'MagicMock' and 'int'`
- **Issue:** `monkeypatch.setattr(subsonic.listings, "show_rating_select", ...)` patches the name in `listings` module but `actions.py` imports it via `from subsonic.listings import show_rating_select` — binding it directly in the `actions` namespace. The patch didn't reach the bound reference.
- **Fix:** Changed patch target to `monkeypatch.setattr(_actions_mod, "show_rating_select", ...)` where `_actions_mod = subsonic.actions` — patches the name where it's actually called.
- **Files modified:** `tests/test_actions.py`
- **Commit:** 4b31ce8

**2. [Rule 2 - Lint] Ruff import ordering in playback.py**

- **Found during:** Task 2 verification — `ruff check` flagged unsorted import block in playback.py (I001)
- **Fix:** `ruff check --fix` auto-sorted imports
- **Files modified:** `resources/lib/subsonic/playback.py`
- **Commit:** 4b31ce8

## Known Stubs

None. All five handlers are fully implemented and wired.

## Self-Check: PASSED

- `resources/lib/subsonic/browse.py`: FOUND — contains `list_genres`, `list_genre_tracks`, `list_radio_stations`
- `resources/lib/subsonic/playback.py`: FOUND — contains `play_radio`
- `resources/lib/subsonic/actions.py`: FOUND — contains `rate_track`, imports `show_rating_select`
- `resources/lib/subsonic/search.py`: FOUND — contains `client.search3` calls
- `tests/test_playback.py`: FOUND — 3 tests
- Commit 424cacf: FOUND
- Commit 4b31ce8: FOUND
- 240 total tests pass
