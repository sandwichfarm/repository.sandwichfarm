---
phase: 05-feature-expansion
plan: 03
type: execute
wave: 2
depends_on: [05-01-api-layer-PLAN.md, 05-02-listings-extensions-PLAN.md]
files_modified:
  - resources/lib/subsonic/browse.py
  - resources/lib/subsonic/playback.py
  - resources/lib/subsonic/actions.py
  - resources/lib/subsonic/search.py
  - tests/test_browse.py
  - tests/test_playback.py
  - tests/test_actions.py
  - tests/test_search.py
autonomous: true
requirements: [FEAT-01, FEAT-02, FEAT-03, FEAT-04]

must_haves:
  truths:
    - "A user can browse a Genres menu in the root that routes to @route('genres')"
    - "A user selecting a genre sees tracks filtered by that genre via @route('genre_tracks')"
    - "A user can browse Internet Radio stations via @route('radio') and play one via @route('play_radio')"
    - "A user can rate a track (1-5 or clear) via @route('rate_track') context menu action"
    - "Search uses search3 instead of search2; result keys are 'artist', 'album', 'song'"
    - "The root menu has 'Genres' and 'Internet Radio' entries appended after Search Albums"
    - "browse.py has no xbmcplugin or xbmcgui imports (ARCH-05)"
    - "actions.py rate_track uses show_rating_select from listings.py (ARCH-05)"
  artifacts:
    - path: resources/lib/subsonic/browse.py
      provides: "list_genres, list_genre_tracks, list_radio_stations handlers + updated root"
      exports: [list_genres, list_genre_tracks, list_radio_stations]
    - path: resources/lib/subsonic/playback.py
      provides: "play_radio handler"
      exports: [play_radio]
    - path: resources/lib/subsonic/actions.py
      provides: "rate_track handler"
      exports: [rate_track]
    - path: resources/lib/subsonic/search.py
      provides: "search and search_album using search3 / compatible keys"
    - path: tests/test_browse.py
      provides: "tests for 3 new handlers"
    - path: tests/test_playback.py
      provides: "test for play_radio"
    - path: tests/test_actions.py
      provides: "test for rate_track"
    - path: tests/test_search.py
      provides: "updated tests for search3"
  key_links:
    - from: resources/lib/subsonic/browse.py
      to: resources/lib/subsonic/listings.py
      via: "from subsonic.listings import build_genre_item"
      pattern: "build_genre_item"
    - from: resources/lib/subsonic/actions.py
      to: resources/lib/subsonic/listings.py
      via: "from subsonic.listings import show_rating_select"
      pattern: "show_rating_select"
    - from: resources/lib/subsonic/playback.py
      to: xbmcplugin.setResolvedUrl
      via: "direct stream URL for radio stations"
      pattern: "setResolvedUrl"
    - from: resources/lib/subsonic/search.py
      to: resources/lib/subsonic/api/client.py
      via: "client.search3()"
      pattern: "client\\.search3"
---

<objective>
Wire all 5 new feature handlers into browse.py, playback.py, actions.py, and search.py. Add the Genres and Internet Radio entries to the root menu. Migrate search to search3.

Purpose: This is the integration plan — it connects the API layer (Plan 01) and UI layer (Plan 02) into user-visible handlers that Kodi dispatches via the router.

Output: 3 new browse handlers, 1 new playback handler, 1 new actions handler, search3 migration, and tests for all of them.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/phases/05-feature-expansion/05-CONTEXT.md
@.planning/phases/05-feature-expansion/05-01-api-layer-SUMMARY.md
@.planning/phases/05-feature-expansion/05-02-listings-extensions-SUMMARY.md

<interfaces>
<!-- Contracts from Wave 1 plans. Executor uses these directly — no codebase exploration needed. -->

From resources/lib/subsonic/api/client.py (added by Plan 05-01):
```python
def get_genres(self) -> list[dict[str, Any]]: ...
    # returns [{"value": "Rock", "songCount": 5, "albumCount": 2}, ...]

def get_songs_by_genre(self, genre: str, count: int = 100, offset: int = 0) -> list[dict[str, Any]]: ...
    # returns list of SubsonicTrack dicts

def search3(self, query: str, artist_count: int = 20, album_count: int = 20,
            song_count: int = 40) -> dict[str, list[dict[str, Any]]]: ...
    # returns {"artist": [...], "album": [...], "song": [...]}

def set_rating(self, item_id: str, rating: int) -> bool: ...
    # rating 1-5 to set, 0 to clear

def get_internet_radio_stations(self) -> list[dict[str, Any]]: ...
    # returns [{"id": "1", "name": "Radio X", "streamUrl": "http://...", "homePageUrl": "http://..."}, ...]
    # returns [] if server does not support or returns none
```

From resources/lib/subsonic/listings.py (added by Plan 05-02):
```python
def build_genre_item(genre: SubsonicGenre, url: str) -> tuple[str, xbmcgui.ListItem, bool]: ...
    # label = "{genre['value']} ({songCount} songs)", is_folder=True

def show_rating_select(track_id: str) -> int | None: ...
    # returns 1-5 (set rating), 0 (clear rating), None (cancelled)
```

From resources/lib/subsonic/browse.py (existing patterns to follow):
```python
@route("root")
def root(client, settings, handle, **params) -> None:
    items = [
        build_nav_item("Artists", url_for("list_artists")),
        ...
        build_nav_item("Search Albums", url_for("search_album")),
        # ADD HERE: Genres and Internet Radio
    ]

@route("list_tracks")
def list_tracks(client, settings, handle, menu_id="", album_id="", ...):
    # existing handler for track listing — reuse for genre_tracks

# browse.py imports:
from subsonic.listings import (
    add_items, build_album_item, build_artist_item, build_nav_item,
    build_playlist_item, build_track_item, end_directory,
    # ADD: build_genre_item
)
```

From resources/lib/subsonic/playback.py (existing pattern):
```python
@route("play_track")
def play_track(client, settings, handle, id="", **params):
    stream_url = client.stream_url(track_id=id, ...)
    li = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(handle, True, li)
```

From resources/lib/subsonic/actions.py (existing pattern):
```python
@route("star_item")
def star_item(client, settings, handle, cache, id="", type="track", unstar="false", **params):
    ...
    cache.invalidate("starred")
    xbmc.executebuiltin("Container.Refresh")
```

From resources/lib/subsonic/search.py (existing, to be updated):
```python
results = client.search(query=query, artist_count=20, album_count=20, song_count=20)
# results keys: "artist", "album", "song"
# Change to: client.search3(query=query, artist_count=20, album_count=20, song_count=40)
# search3 returns same key structure: {"artist": [...], "album": [...], "song": [...]}
```
</interfaces>
</context>

<tasks>

<task type="auto" tdd="true">
  <name>Task 1: Genre + Radio browse handlers, root menu entries, play_radio, rate_track</name>
  <files>resources/lib/subsonic/browse.py, resources/lib/subsonic/playback.py, resources/lib/subsonic/actions.py</files>
  <behavior>
    browse.py — list_genres handler:
    - @route("genres"): calls client.get_genres(), builds items with build_genre_item(genre, url_for("genre_tracks", genre=genre["value"])), calls add_items + end_directory(content="genres")

    browse.py — list_genre_tracks handler:
    - @route("genre_tracks"): accepts genre="Rock", calls client.get_songs_by_genre(genre, count=100), builds items with build_track_item, calls add_items + end_directory(content="songs")

    browse.py — list_radio_stations handler:
    - @route("radio"): calls client.get_internet_radio_stations(), if empty list → add_items with [] + end_directory(content="songs"), else builds items with build_nav_item(station["name"], url_for("play_radio", id=station["id"], stream_url=station.get("streamUrl","")))

    browse.py — root:
    - Append build_nav_item("Genres", url_for("genres")) and build_nav_item("Internet Radio", url_for("radio")) after "Search Albums" entry

    browse.py — menu_albums by_genre branch:
    - Replace the placeholder stub with build_nav_item("Browse by Genre", url_for("genres")) so the existing "Albums — By Genre" menu entry works too

    playback.py — play_radio:
    - @route("play_radio"): accepts id="", stream_url=""; resolves stream_url directly via setResolvedUrl (no Subsonic transcoding — it's an external radio URL); log_info the station id; on error call setResolvedUrl(handle, False, ...)

    actions.py — rate_track:
    - @route("rate_track"): accepts id=""; calls show_rating_select(id) from listings (import it); if None → return early; calls client.set_rating(id, rating); on success calls cache.invalidate("starred") + xbmc.executebuiltin("Container.Refresh"); log result
    - Import show_rating_select from subsonic.listings (ARCH-05)
    - actions.py must NOT import xbmcgui directly for the dialog
  </behavior>
  <action>
    In resources/lib/subsonic/browse.py:

    1. Update the import from subsonic.listings to add build_genre_item:
       ```python
       from subsonic.listings import (
           add_items,
           build_album_item,
           build_artist_item,
           build_genre_item,
           build_nav_item,
           build_playlist_item,
           build_track_item,
           end_directory,
       )
       ```

    2. Update root() to append after "Search Albums":
       ```python
       build_nav_item("Genres", url_for("genres")),
       build_nav_item("Internet Radio", url_for("radio")),
       ```

    3. Update menu_albums by_genre branch:
       ```python
       elif menu_id == "by_genre":
           items.append(
               build_nav_item("Browse by Genre", url_for("genres"))
           )
       ```

    4. Add list_genres handler after menu_albums:
       ```python
       @route("genres")
       def list_genres(client: Any, settings: Any, handle: int, **params: str) -> None:
           """List all genres from getGenres (FEAT-01)."""
           genres = client.get_genres()
           items: list[Any] = []
           for genre in genres:
               name = genre.get("value") or ""
               if not name:
                   continue
               items.append(
                   build_genre_item(
                       genre,
                       url=url_for("genre_tracks", genre=name),
                   )
               )
           add_items(handle, items)
           end_directory(handle, content="genres")
       ```

    5. Add list_genre_tracks handler after list_genres:
       ```python
       @route("genre_tracks")
       def list_genre_tracks(
           client: Any,
           settings: Any,
           handle: int,
           genre: str = "",
           **params: str,
       ) -> None:
           """List tracks for a specific genre (FEAT-01)."""
           if not genre:
               end_directory(handle, content="songs", succeeded=False)
               return
           tracks = client.get_songs_by_genre(genre, count=100)
           items: list[Any] = []
           for track in tracks:
               cover_url = ""
               if track.get("coverArt"):
                   cover_url = client.get_cover_art_url(track["coverArt"], size=512)
               items.append(
                   build_track_item(
                       track,
                       url=url_for("play_track", id=track.get("id", "")),
                       cover_url=cover_url,
                       hide_artist=False,
                   )
               )
           add_items(handle, items)
           end_directory(handle, content="songs")
       ```

    6. Add list_radio_stations handler at the end of browse.py:
       ```python
       @route("radio")
       def list_radio_stations(
           client: Any,
           settings: Any,
           handle: int,
           **params: str,
       ) -> None:
           """List internet radio stations (FEAT-04)."""
           stations = client.get_internet_radio_stations()
           items: list[Any] = []
           for station in stations:
               name = station.get("name") or "<Unknown Station>"
               stream_url = station.get("streamUrl") or ""
               station_id = station.get("id") or ""
               if not stream_url:
                   continue
               items.append(
                   build_nav_item(
                       name,
                       url_for("play_radio", id=station_id, stream_url=stream_url),
                   )
               )
           add_items(handle, items)
           end_directory(handle, content="songs")
       ```

    In resources/lib/subsonic/playback.py, add play_radio after play_track:
    ```python
    @route("play_radio")
    def play_radio(
        client: Any,
        settings: Any,
        handle: int,
        id: str = "",
        stream_url: str = "",
        **params: str,
    ) -> None:
        """Resolve the direct stream URL for an internet radio station (FEAT-04).

        Radio stations use their streamUrl directly — no Subsonic transcoding.
        """
        if not stream_url:
            log_error(f"play_radio called without stream_url param (id={id})")
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        log_info(f"Playing radio station id={id} via setResolvedUrl")
        li = xbmcgui.ListItem(path=stream_url)
        xbmcplugin.setResolvedUrl(handle, True, li)
    ```

    In resources/lib/subsonic/actions.py:
    - Add import at top: `from subsonic.listings import show_rating_select`
    - Add rate_track handler at the end:
    ```python
    @route("rate_track")
    def rate_track(
        client: Any,
        settings: Any,
        handle: int,
        cache: Any,
        id: str = "",
        **params: str,
    ) -> None:
        """Set a 1-5 star rating on a track via context menu (FEAT-03).

        Opens a selection dialog (via show_rating_select from listings — no
        xbmcgui import in actions.py per ARCH-05). Invalidates cache on success.
        """
        if not id:
            log_error("rate_track called without id param")
            return
        rating = show_rating_select(id)
        if rating is None:
            return  # user cancelled
        try:
            success = client.set_rating(item_id=id, rating=rating)
        except Exception:
            log_exception(f"rate_track failed for id={id}")
            return
        if success:
            log_info(f"Rated track id={id} with {rating} stars")
            if cache is not None:
                cache.invalidate("starred")
            xbmc.executebuiltin("Container.Refresh")
        else:
            log_error(f"Failed to rate track id={id}")
    ```
  </action>
  <verify>
    <automated>grep -q "def list_genres\|def list_genre_tracks\|def list_radio_stations" /home/sandwich/Develop/plugin.audio.subsonic/resources/lib/subsonic/browse.py && grep -q "def play_radio" /home/sandwich/Develop/plugin.audio.subsonic/resources/lib/subsonic/playback.py && grep -q "def rate_track" /home/sandwich/Develop/plugin.audio.subsonic/resources/lib/subsonic/actions.py && grep -q "show_rating_select" /home/sandwich/Develop/plugin.audio.subsonic/resources/lib/subsonic/actions.py && ! grep -q "import xbmcgui" /home/sandwich/Develop/plugin.audio.subsonic/resources/lib/subsonic/browse.py && ! grep -q "xbmcgui" /home/sandwich/Develop/plugin.audio.subsonic/resources/lib/subsonic/actions.py</automated>
  </verify>
  <done>All 5 new handlers exist; browse.py + actions.py have no xbmcgui imports; root menu has Genres and Internet Radio entries; ARCH-05 preserved throughout</done>
</task>

<task type="auto" tdd="true">
  <name>Task 2: Migrate search.py to search3 + write all handler tests</name>
  <files>resources/lib/subsonic/search.py, tests/test_browse.py, tests/test_playback.py, tests/test_actions.py, tests/test_search.py</files>
  <behavior>
    search.py migration (FEAT-02):
    - search() now calls client.search3() instead of client.search()
    - search_album() also calls client.search3() with artist_count=0, song_count=0
    - Result keys are the same: "artist", "album", "song" — no other changes to result handling needed

    test_browse.py additions:
    - test_list_genres_calls_get_genres: mock client.get_genres returns [{"value":"Rock","songCount":5}] → build_genre_item called, add_items called
    - test_list_genres_skips_empty_value: genre with no "value" key → skipped from items
    - test_list_genre_tracks_calls_client: mock client.get_songs_by_genre returns [{...}] → add_items called
    - test_list_genre_tracks_empty_genre_fails: genre="" → end_directory called with succeeded=False
    - test_list_radio_stations_builds_nav_items: mock returns [{"id":"1","name":"X","streamUrl":"http://x"}] → add_items called with 1 item
    - test_list_radio_stations_skips_missing_url: station without streamUrl → skipped
    - test_browse_module_has_no_xbmcgui_import: assert "xbmcgui" not in open("browse.py").read()

    tests/test_playback.py (new file):
    - test_play_radio_calls_setResolvedUrl_true: stream_url="http://x" → setResolvedUrl(handle, True, ...) called
    - test_play_radio_missing_url_calls_setResolvedUrl_false: stream_url="" → setResolvedUrl(handle, False, ...) called

    test_actions.py additions:
    - test_rate_track_calls_set_rating: mock show_rating_select returns 3 → client.set_rating called with ("id", 3)
    - test_rate_track_cancelled_is_noop: mock show_rating_select returns None → client.set_rating NOT called
    - test_rate_track_no_id_is_noop: id="" → show_rating_select NOT called
    - test_rate_track_success_invalidates_cache: set_rating returns True → cache.invalidate("starred") called
    - test_rate_track_success_refreshes_container: set_rating returns True → xbmc.executebuiltin("Container.Refresh") called

    test_search.py updates:
    - Change test_search_calls_client_search_with_query to use client.search3 not client.search
    - Change test_search_album_passes_zero_counts_for_artist_and_song to use client.search3
  </behavior>
  <action>
    In resources/lib/subsonic/search.py:
    - Replace `results = client.search(...)` in search() with `results = client.search3(...)`
    - Replace `results = client.search(...)` in search_album() with `results = client.search3(...)`
    - Keep all result key access as-is: results.get("artist"), results.get("album"), results.get("song")
    - search3 result shape is identical for these keys

    Update search_album song_count explicitly:
    ```python
    results = client.search3(
        query=query, artist_count=0, album_count=50, song_count=0
    )
    ```

    Create tests/test_playback.py (new file). Follow the conftest.py mock pattern from existing tests.
    Import xbmcplugin and xbmcgui at top (they are mocked in conftest.py).

    For test_browse.py additions, follow the existing handler test pattern:
    - Mock client as MagicMock()
    - Mock listings functions (add_items, end_directory, build_genre_item) with monkeypatch
    - Call handler directly with (client, settings, handle=0)

    For test_actions.py rate_track tests, follow test_star_item pattern:
    - monkeypatch subsonic.listings.show_rating_select
    - Mock client.set_rating
    - Mock cache, xbmc.executebuiltin

    For test_search.py updates: rename/update the existing assertions from client.search to client.search3.
  </action>
  <verify>
    <automated>cd /home/sandwich/Develop/plugin.audio.subsonic && .venv/bin/python -m pytest tests/test_browse.py tests/test_playback.py tests/test_actions.py tests/test_search.py -v 2>&1 | tail -30</automated>
  </verify>
  <done>All handler tests pass; search.py calls client.search3; `grep -q "client\.search3" resources/lib/subsonic/search.py` exits 0; ruff + mypy clean on all modified files</done>
</task>

</tasks>

<verification>
```bash
cd /home/sandwich/Develop/plugin.audio.subsonic
.venv/bin/python -m pytest tests/test_browse.py tests/test_playback.py tests/test_actions.py tests/test_search.py -v
.venv/bin/python -m mypy resources/lib/subsonic/browse.py resources/lib/subsonic/playback.py resources/lib/subsonic/actions.py resources/lib/subsonic/search.py --strict 2>&1 | tail -10
.venv/bin/python -m ruff check resources/lib/subsonic/browse.py resources/lib/subsonic/playback.py resources/lib/subsonic/actions.py resources/lib/subsonic/search.py
# Confirm ARCH-05:
! grep -q "import xbmcgui\|import xbmcplugin" /home/sandwich/Develop/plugin.audio.subsonic/resources/lib/subsonic/browse.py
! grep -q "xbmcgui" /home/sandwich/Develop/plugin.audio.subsonic/resources/lib/subsonic/actions.py
```
</verification>

<success_criteria>
- `grep -q "def list_genres" resources/lib/subsonic/browse.py` exits 0
- `grep -q "def list_genre_tracks" resources/lib/subsonic/browse.py` exits 0
- `grep -q "def list_radio_stations" resources/lib/subsonic/browse.py` exits 0
- `grep -q "def play_radio" resources/lib/subsonic/playback.py` exits 0
- `grep -q "def rate_track" resources/lib/subsonic/actions.py` exits 0
- `grep -q "client\.search3" resources/lib/subsonic/search.py` exits 0
- `grep -q "Genres\|Internet Radio" resources/lib/subsonic/browse.py` exits 0 (root menu entries)
- All tests in test_browse.py, test_playback.py, test_actions.py, test_search.py pass
- browse.py has no xbmcgui/xbmcplugin imports (ARCH-05)
- actions.py has no xbmcgui import (ARCH-05)
- mypy + ruff clean on all 4 modules
</success_criteria>

<output>
After completion, create `.planning/phases/05-feature-expansion/05-03-handlers-SUMMARY.md`
</output>
