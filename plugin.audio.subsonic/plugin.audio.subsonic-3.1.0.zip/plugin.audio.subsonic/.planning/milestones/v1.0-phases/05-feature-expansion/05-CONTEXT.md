# Phase 5: Feature Expansion - Context

**Gathered:** 2026-04-28
**Status:** Ready for planning
**Mode:** Auto-generated (5 well-bounded feature additions, all gated on Phase 4 OpenSubsonic probe)

<domain>
## Phase Boundary

Phase 5 adds 5 table-stakes features identified by the FEATURES research. All hook into the post-Phase-3 module structure cleanly:

- **FEAT-01 Genre browsing** — `getGenres` + `getSongsByGenre` API methods, new `genres` menu, new browse handler. Standard Subsonic API, available on all servers since 1.9.0.
- **FEAT-02 search3** — Replace the existing `search2` calls with `search3` (richer metadata, MusicBrainz IDs in track responses). Gated on `searchAutocomplete` OpenSubsonic extension OR fall back to `search2` if probe says no extensions.
- **FEAT-03 5-star rating** — `setRating` API method (Subsonic 1.6+), wired as a context-menu action on tracks. Gated on `userRating` OpenSubsonic extension or always-available since 1.6.
- **FEAT-04 Internet radio stations** — `getInternetRadioStations` API method (Subsonic 1.16+), new menu entry, browse handler that resolves a `streamUrl` for the station's homepage URL.
- **FEAT-05 MusicBrainz ID passthrough** — Whenever a Subsonic API response includes `musicBrainzId` (album, track, or artist), pass it through to `InfoTagMusic.setMusicBrainzAlbumID/setMusicBrainzTrackID/setMusicBrainzArtistID` in `listings.py`.

Out of scope: lyrics, ReplayGain, play queue resume, sonic similarity, podcast browser, jukebox mode (all v2). Live server verification of these features against Navidrome / gonic / LMS — Phase 6.

</domain>

<decisions>
## Implementation Decisions

### Gating on OpenSubsonic probe (locked)

`api/client.ApiClient.supports(extension_name)` from Phase 4 is the gate. When a feature requires an OpenSubsonic extension that the server doesn't advertise, the addon either:
- Falls back to the legacy method (search3 → search2; userRating → unavailable, hide context menu item)
- OR shows the menu entry but the handler shows a friendly notice

For Phase 5:
- **search3**: Always available (Subsonic ≥ 1.8 standard endpoint). NOT gated. The richer return shape just has more fields; older servers return the lean form.
- **getRating / setRating**: Standard since Subsonic 1.6 — NOT gated either. Always wire it.
- **getInternetRadioStations**: Subsonic 1.16+ standard. Most modern servers support it. Add a `try/except` guard; if 4xx/5xx, hide the menu entry (or show "Not supported" notice).
- **getGenres + getSongsByGenre**: Standard since 1.9.0. Always available.
- **MusicBrainz IDs**: passthrough only — no API change. Just plumbs existing response fields into `InfoTagMusic`.

So actually NONE of the 5 features in Phase 5 needs the OpenSubsonic probe gate — they're all standard Subsonic API methods. The probe lives in client (Phase 4 work) and is consumed by Phase 6 lyrics/ReplayGain (deferred to v2).

### FEAT-01 Genre browsing (locked)

- New `ApiClient.get_genres() -> list[SubsonicGenre]` — wraps `getGenres`
- New `ApiClient.get_songs_by_genre(genre: str, count: int = 100, offset: int = 0) -> list[SubsonicTrack]` — wraps `getSongsByGenre`
- New `subsonic.models.SubsonicGenre` TypedDict (already added in Phase 3, verify) with `value: str`, `songCount: int`, `albumCount: int`
- New `browse.list_genres` handler — registers as `@route("genres")`, calls `client.get_genres()`, renders via `listings.build_genre_item`. NEW: `listings.build_genre_item` takes `name + songCount + albumCount`, builds a directory item that routes to `genre_tracks` with the genre name as a query param.
- New `browse.list_genre_tracks` handler — registers as `@route("genre_tracks")`, accepts `genre` param, calls `client.get_songs_by_genre`, renders via existing `listings.build_track_item`.
- Add to root menu (`browse.root` or wherever the top-level menu lives): "Genres" entry routing to `genres`.

### FEAT-02 search3 adoption (locked)

- Replace `client.search` (currently calls `search2`) with `client.search3` returning a richer `SubsonicSearchResult3` TypedDict.
- The TypedDict contains `artists: list[SubsonicArtist]`, `albums: list[SubsonicAlbum]`, `songs: list[SubsonicTrack]` — same shape as before, but the inner items now include `musicBrainzId` and `genre` fields when the server provides them.
- Update `search.search` handler to call `client.search3` and pass results through to listings.
- Add a Settings property `search_count_artists`, `search_count_albums`, `search_count_songs` (or hard-code reasonable defaults: 20/20/40). Use Settings facade.
- libsonic doesn't expose `search3` natively — add a `Connection.search3()` method that builds the right URL, OR call `Connection._doInfoReq` with the `search3.view` viewName directly through the new boundary. CONTEXT: keep this in `api/client.py` so libsonic stays minimally touched.

### FEAT-03 5-star rating (locked)

- New `ApiClient.set_rating(item_id: str, rating: int) -> bool` — wraps `setRating` (rating 0 to clear, 1-5 to set)
- New `actions.rate_track` handler — registers as `@route("rate_track")`, accepts `id` and `rating` params, calls `client.set_rating`, calls `cache.invalidate('starred')` (in case rating affects sort order on some servers), `xbmc.executebuiltin('Container.Refresh')`.
- New context-menu entry on track list items: "Rate (1-5)" — opens a `xbmcgui.Dialog().select(["1 star", "2 stars", "3 stars", "4 stars", "5 stars", "Clear rating"])` and routes to `rate_track`.
- The select dialog goes in `listings.show_rating_select(track_id) -> Optional[int]` (preserving ARCH-05: all UI calls in listings.py).

### FEAT-04 Internet radio stations (locked)

- New `ApiClient.get_internet_radio_stations() -> list[InternetRadioStation]` — wraps `getInternetRadioStations`
- New `subsonic.models.InternetRadioStation` TypedDict: `id: str`, `name: str`, `streamUrl: str`, `homePageUrl: str | None` (added in Phase 5)
- New `browse.list_radio_stations` handler — registers as `@route("radio")`. Calls `client.get_internet_radio_stations()`. If the server returns 4xx/5xx OR an empty list, show a friendly notification and end-of-directory.
- New `playback.play_radio` handler — registers as `@route("play_radio")`. Resolves the station's `streamUrl` via `xbmcplugin.setResolvedUrl` (no Subsonic transcoding, just direct URL).
- Add to root menu: "Internet Radio" entry routing to `radio`.

### FEAT-05 MusicBrainz IDs (locked)

- `listings.build_track_item`: when the SubsonicTrack dict has `musicBrainzId`, call `tag.setMusicBrainzTrackID(value)`.
- `listings.build_album_item`: when the dict has `musicBrainzId`, call `tag.setMusicBrainzAlbumID(value)` and `tag.setMusicBrainzAlbumArtistID(artist_mbid)` if present.
- `listings.build_artist_item`: when the dict has `musicBrainzId`, call `tag.setMusicBrainzArtistID(value)`.
- Tests assert that when MBID is in the source dict, the corresponding setter is called.

### Settings preservation

NO changes to existing settings.xml `id=` attributes. May add 1-3 OPTIONAL settings:
- `search_count_artists` (int, default 20) — only if not hard-coded
- `search_count_albums` (int, default 20)
- `search_count_songs` (int, default 40)

Decision: HARD-CODE the search counts. Less UI clutter, can add later if users ask. So Phase 5 makes ZERO settings.xml changes.

### Test coverage

Each new module/method gets unit tests:
- `tests/test_api_client.py`: extend with `get_genres`, `get_songs_by_genre`, `search3`, `set_rating`, `get_internet_radio_stations` tests
- `tests/test_browse.py`: extend with `list_genres`, `list_genre_tracks`, `list_radio_stations` handler tests
- `tests/test_search.py`: update for search3 shape
- `tests/test_actions.py`: extend with `rate_track` handler test
- `tests/test_listings.py`: extend with MusicBrainz ID passthrough tests + `build_genre_item` + `show_rating_select`
- `tests/test_playback.py`: extend with `play_radio` test

### Claude's Discretion

- Exact menu position of "Genres" and "Internet Radio" in the root menu — append after existing entries
- Whether `set_rating` returns the new rating or just bool — pick what reads cleaner
- Exact label strings for context menu — use existing patterns in `actions.py`
- Internet radio when the response is empty: show a notification or just empty list — pick whichever is more user-friendly
- localized strings: add new msgctxt entries (#30060+ range to avoid collision) but English-only translations are fine for v1

</decisions>

<code_context>
## Existing Code Insights

### Reusable Assets

- All Phase 3 modules (`api/client.py`, `browse.py`, `search.py`, `playback.py`, `actions.py`, `listings.py`, `models.py`, `cache.py`)
- Phase 4 `Settings` facade with new properties + setters
- `tests/conftest.py` — Kodi mocks
- The `@route()` decorator from Phase 3 router

### Established Patterns

- Handler signature: `def handler(params: dict, client: ApiClient, cache: Cache, settings: Settings, handle: int) -> None`
- All Kodi UI calls in listings.py only
- TypedDict for API response shapes
- Per-module unit tests
- Type hints comprehensive; mypy --strict; ruff clean

### Integration Points

- Root menu: see `browse.root` in resources/lib/subsonic/browse.py — append new menu entries
- libsonic.Connection: may need new `search3()` and `getInternetRadioStations()` methods (verify if already present; add if not, modeled on existing methods)
- `resources/language/English/strings.po`: add new label strings (no other locale strictly needed for v1)
- `addon.xml`: no change

### Files modified (predicted)

- `resources/lib/subsonic/api/client.py` — 5 new methods
- `resources/lib/subsonic/browse.py` — 3 new handlers (list_genres, list_genre_tracks, list_radio_stations)
- `resources/lib/subsonic/search.py` — switch from search2 to search3
- `resources/lib/subsonic/actions.py` — 1 new handler (rate_track)
- `resources/lib/subsonic/playback.py` — 1 new handler (play_radio)
- `resources/lib/subsonic/listings.py` — `build_genre_item`, `show_rating_select`, MusicBrainz passthrough in track/album/artist builders
- `resources/lib/subsonic/models.py` — possibly add `InternetRadioStation` TypedDict, `SubsonicSearchResult3` if not generic enough
- `lib/libsonic/connection.py` — possibly add `search3()` and `getInternetRadioStations()` if not already there
- `resources/language/English/strings.po` — new labels for Genres / Internet Radio / Rate
- `tests/test_*.py` — extensions

### Files NOT modified

- `resources/settings.xml` — no schema changes
- `addon.xml` — no change
- `main.py` / `service.py` — bootstraps stay thin

</code_context>

<specifics>
## Specific Ideas

### Genre menu integration

Add to `browse.root`:
```python
{
    "name": Addon().get_localized_string(30060),  # "Genres"
    "url": url_for(list_genres),
    "thumb": None,
}
```
And similarly for Internet Radio (label 30061).

### Search3 transition

```python
# api/client.py
def search3(self, query: str, artist_count: int = 20,
            album_count: int = 20, song_count: int = 40) -> SubsonicSearchResult3:
    res = self._connection.search3(
        query=query,
        artistCount=artist_count,
        albumCount=album_count,
        songCount=song_count,
    )
    return res.get("searchResult3", {"artist": [], "album": [], "song": []})
```

### Rating context menu

```python
# listings.py — extend build_track_item
context_menu = [
    (Addon().get_localized_string(30070),  # "Rate"
     f"RunPlugin({url_for('rate_track', id=track['id'])})"),
    # ... existing entries
]
```

### MusicBrainz passthrough

```python
# listings.py — inside build_track_item
tag = li.getMusicInfoTag()
# ... existing setters ...
if mbid := track.get("musicBrainzId"):
    tag.setMusicBrainzTrackID(mbid)
```

</specifics>

<deferred>
## Deferred Ideas

- **Synchronized lyrics (`getLyricsBySongId` + OpenSubsonic `songLyrics` extension)** — v2 (Navidrome bugs #4631 and #4233 still open per research)
- **ReplayGain hints as ListItem properties** — v2 (needs empirical Kodi 21 testing)
- **Cross-device play queue resume (`savePlayQueue` / `getPlayQueue`)** — v2
- **`reportPlayback` (OpenSubsonic playbackReport extension)** — v2 (still in Navidrome `develop`)
- **Sonic similarity / radio mode** — v2
- **Podcast browser** — Out of scope (Navidrome doesn't support; Kodi has dedicated podcast addons)
- **Jukebox mode** — Out of scope (semantically inverts streaming model)
- **Live server verification of all Phase 5 features** — Phase 6
- **Translation of new labels to French/German** — out of scope for v1; English-only for #30060+

</deferred>
