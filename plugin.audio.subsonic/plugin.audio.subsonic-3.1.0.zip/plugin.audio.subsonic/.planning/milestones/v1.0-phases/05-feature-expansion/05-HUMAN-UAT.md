---
status: partial
phase: 05-feature-expansion
source: [05-VERIFICATION.md]
started: 2026-04-28T20:00:00Z
updated: 2026-04-28T20:00:00Z
---

## Current Test

[awaiting human testing — runtime checks for Phase 6 server-verification]

## Tests

### 1. Genre browsing (FEAT-01)
expected: From the addon root menu, select "Genres". The list shows genres from `getGenres` (each with songCount/albumCount). Selecting a genre opens a track list backed by `getSongsByGenre`. Pagination works the same way other handlers do (last page hides "Next").
result: [pending]

### 2. search3 richer metadata (FEAT-02)
expected: Run a search via "Search" or "Search Albums" against a Navidrome / OpenSubsonic-aware server. Results include richer metadata: when expanded, tracks show MusicBrainz IDs (visible via Kodi info dialog or in skin). The wire request is `search3.view`, not `search2.view`.
result: [pending]

### 3. 5-star rating context menu (FEAT-03)
expected: On a track list item, open the context menu, select "Rate". The select dialog shows 1–5 stars + Clear. Picking a value triggers a `setRating` API call. The list refreshes to show the new rating.
result: [pending]

### 4. Internet radio (FEAT-04)
expected: From root menu, select "Internet Radio". Stations from `getInternetRadioStations` appear. Selecting a station plays the station's stream URL directly (no Subsonic transcoding). Empty server returns an empty directory without error.
result: [pending]

### 5. MusicBrainz ID passthrough (FEAT-05)
expected: For tracks/albums/artists that have `musicBrainzId` in the Subsonic response, the addon passes them to `InfoTagMusic.setMusicBrainzTrackID/AlbumID/ArtistID`. Inspect a few items via Kodi info dialog or the JSON-RPC API to confirm the IDs are present.
result: [pending]

## Summary

total: 5
passed: 0
issues: 0
pending: 5
skipped: 0
blocked: 0

## Gaps

None automated. All 5 are runtime verifications deferred to Phase 6 server verification.
