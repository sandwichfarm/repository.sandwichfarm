---
phase: 05-feature-expansion
plan: 04
type: execute
wave: 3
depends_on: [05-01-api-layer-PLAN.md, 05-02-listings-extensions-PLAN.md, 05-03-handlers-PLAN.md]
files_modified: []
autonomous: false
requirements: [FEAT-01, FEAT-02, FEAT-03, FEAT-04, FEAT-05]

must_haves:
  truths:
    - "Full pytest suite passes (all test_*.py files)"
    - "ruff check produces zero warnings on all resources/lib/subsonic/ modules"
    - "mypy --strict produces zero errors on all resources/lib/subsonic/ modules"
    - "browse.py has no xbmcgui or xbmcplugin import"
    - "actions.py has no xbmcgui import"
    - "search.py calls client.search3 (not client.search)"
    - "All 5 new ApiClient methods exist"
    - "All 3 new browse routes exist (@route decorators present)"
    - "User confirms the root menu labels and feature wiring look correct"
  artifacts:
    - path: tests/
      provides: "full green test suite"
  key_links:
    - from: "root menu"
      to: "list_genres handler"
      via: "@route('genres')"
      pattern: "@route\\(\"genres\"\\)"
    - from: "root menu"
      to: "list_radio_stations handler"
      via: "@route('radio')"
      pattern: "@route\\(\"radio\"\\)"
---

<objective>
Run the full automated quality gate, fix any issues discovered, then pause for human approval.

Purpose: Confirms that all 5 features are correctly wired, all tests pass, and quality standards (ruff, mypy) are met before Phase 6 begins.

Output: Green pytest, clean lint/types, and human sign-off.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/ROADMAP.md
@.planning/phases/05-feature-expansion/05-01-api-layer-SUMMARY.md
@.planning/phases/05-feature-expansion/05-02-listings-extensions-SUMMARY.md
@.planning/phases/05-feature-expansion/05-03-handlers-SUMMARY.md
</context>

<tasks>

<task type="auto">
  <name>Task 1: Run full quality gate and fix any issues</name>
  <files></files>
  <action>
    Run all automated checks in sequence. Fix any failures before proceeding to the checkpoint.

    1. Full test suite:
       ```bash
       cd /home/sandwich/Develop/plugin.audio.subsonic
       .venv/bin/python -m pytest -v 2>&1 | tail -40
       ```

    2. Type check all Phase 5 modules:
       ```bash
       .venv/bin/python -m mypy \
           resources/lib/subsonic/api/client.py \
           resources/lib/subsonic/models.py \
           resources/lib/subsonic/listings.py \
           resources/lib/subsonic/browse.py \
           resources/lib/subsonic/playback.py \
           resources/lib/subsonic/actions.py \
           resources/lib/subsonic/search.py \
           --strict 2>&1 | grep -v "^Success"
       ```

    3. Lint check:
       ```bash
       .venv/bin/python -m ruff check resources/lib/subsonic/ tests/
       ```

    4. Spot-check ARCH-05 compliance:
       ```bash
       # browse.py must have no Kodi UI imports
       ! grep -n "import xbmcgui\|import xbmcplugin" resources/lib/subsonic/browse.py
       # actions.py must have no xbmcgui import
       ! grep -n "import xbmcgui" resources/lib/subsonic/actions.py
       # search.py must call search3 not search
       grep -n "client\.search3" resources/lib/subsonic/search.py
       ```

    5. Feature wiring spot-checks:
       ```bash
       grep -n "@route" resources/lib/subsonic/browse.py
       grep -q '"Genres"' resources/lib/subsonic/browse.py && echo "Genres in root: OK"
       grep -q '"Internet Radio"' resources/lib/subsonic/browse.py && echo "Radio in root: OK"
       grep -q "def rate_track" resources/lib/subsonic/actions.py && echo "rate_track: OK"
       grep -q "def play_radio" resources/lib/subsonic/playback.py && echo "play_radio: OK"
       grep -q "setMusicBrainzAlbumID" resources/lib/subsonic/listings.py && echo "MBID album: OK"
       grep -q "setMusicBrainzArtistID" resources/lib/subsonic/listings.py && echo "MBID artist: OK"
       grep -q "setMusicBrainzTrackID" resources/lib/subsonic/listings.py && echo "MBID track: OK"
       ```

    Fix any issues found: mypy errors, ruff warnings, failing tests. Re-run the failing check
    after each fix to confirm it passes before proceeding. Do not proceed to checkpoint with
    any red check.
  </action>
  <verify>
    <automated>cd /home/sandwich/Develop/plugin.audio.subsonic && .venv/bin/python -m pytest -v 2>&1 | grep -E "passed|failed|error" | tail -5</automated>
  </verify>
  <done>pytest exits 0, mypy exits 0, ruff exits 0, all spot-checks pass</done>
</task>

<task type="checkpoint:human-verify" gate="blocking">
  <what-built>
    Phase 5 complete: genre browsing (getGenres + getSongsByGenre), search3 migration,
    5-star rating context menu (setRating), internet radio stations
    (getInternetRadioStations), and MusicBrainz ID passthrough in all three item builders.

    Summary of changes:
    - api/client.py: 5 new methods (get_genres, get_songs_by_genre, search3, set_rating, get_internet_radio_stations)
    - models.py: InternetRadioStation TypedDict; SubsonicArtist gains musicBrainzId
    - listings.py: build_genre_item, show_rating_select; MBID passthrough in album + artist builders
    - browse.py: list_genres, list_genre_tracks, list_radio_stations routes; root menu entries for Genres + Internet Radio
    - playback.py: play_radio route
    - actions.py: rate_track route with show_rating_select dialog
    - search.py: search3 replaces search2
    - strings.po: #30060-#30064 labels added
    - tests: extended test_api_client, test_listings, test_browse, new test_playback, extended test_actions + test_search
  </what-built>
  <how-to-verify>
    These are code-only changes — no live Kodi server available in CI. Verify by inspection:

    1. Confirm the root menu in browse.py has "Genres" and "Internet Radio" entries:
       ```bash
       grep -A 20 "def root" resources/lib/subsonic/browse.py | grep -E "Genres|Internet Radio"
       ```

    2. Confirm ARCH-05 compliance:
       ```bash
       ! grep "xbmcgui\|xbmcplugin" resources/lib/subsonic/browse.py && echo "browse.py: OK"
       ! grep "xbmcgui" resources/lib/subsonic/actions.py && echo "actions.py: OK"
       ```

    3. Confirm all 3 MusicBrainz setters are wired:
       ```bash
       grep -n "setMusicBrainz" resources/lib/subsonic/listings.py
       ```
       Expected: 3 lines — setMusicBrainzTrackID, setMusicBrainzAlbumID, setMusicBrainzArtistID

    4. Confirm search3 migration:
       ```bash
       grep -n "search3\|search2" resources/lib/subsonic/search.py
       ```
       Expected: only search3 calls, no search2 calls

    5. Review test counts:
       ```bash
       .venv/bin/python -m pytest --collect-only -q 2>&1 | tail -5
       ```

    Type "approved" when the changes look correct, or describe any issue found.
  </how-to-verify>
  <resume-signal>Type "approved" or describe what needs fixing</resume-signal>
</task>

</tasks>

<verification>
Full suite exit 0:
```bash
cd /home/sandwich/Develop/plugin.audio.subsonic
.venv/bin/python -m pytest -v
.venv/bin/python -m ruff check resources/ tests/
.venv/bin/python -m mypy resources/lib/subsonic/ --strict 2>&1 | tail -3
```
</verification>

<success_criteria>
- pytest exits 0 with zero failures
- ruff exits 0 with zero warnings
- mypy exits 0 with zero errors on resources/lib/subsonic/
- Human approves the feature wiring review
- Phase 5 state updated to complete in STATE.md
</success_criteria>

<output>
After completion, create `.planning/phases/05-feature-expansion/05-04-verify-SUMMARY.md`

Also update:
- .planning/STATE.md: Phase 5 → complete; current focus → Phase 6
- .planning/ROADMAP.md: Phase 5 plans list populated, status updated
</output>
