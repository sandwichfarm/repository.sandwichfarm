---
phase: 05-feature-expansion
plan: "02"
subsystem: listings
tags: [listings, musicbrainz, genre, rating, ui, kodi]
dependency_graph:
  requires: []
  provides: [build_genre_item, show_rating_select, musicbrainz-passthrough-album, musicbrainz-passthrough-artist]
  affects: [browse.py (build_genre_item consumer), actions.py (show_rating_select consumer)]
tech_stack:
  added: []
  patterns: [getMusicInfoTag typed setters, xbmcgui.Dialog().select wrapper]
key_files:
  created: []
  modified:
    - resources/lib/subsonic/listings.py
    - resources/lib/subsonic/models.py
    - tests/test_listings.py
decisions:
  - show_rating_select does not use track_id internally (parameter reserved for caller dispatch)
  - build_genre_item uses no InfoTagMusic (genres are nav folders, not playable media)
  - SubsonicArtist.musicBrainzId typed as str | None matching SubsonicTrack pattern
metrics:
  duration: "2 minutes"
  completed: "2026-04-28T21:39:58Z"
  tasks_completed: 2
  files_modified: 3
  commits: 2
---

# Phase 05 Plan 02: Listings Extensions Summary

**One-liner:** Genre folder builder, 5-star rating select dialog, and MusicBrainz ID passthrough in album/artist builders — all wired in listings.py.

## Tasks Completed

| Task | Name | Commit | Files |
|------|------|--------|-------|
| 1 | build_genre_item + show_rating_select + SubsonicArtist.musicBrainzId | d9a9415 | listings.py, models.py, test_listings.py |
| 2 | MusicBrainz passthrough in build_album_item + build_artist_item + tests | 3f46547 | listings.py, test_listings.py |

## What Was Built

### listings.py additions

- **`show_rating_select(track_id: str) -> int | None`** — Wraps `xbmcgui.Dialog().select` with 6 options (1-5 stars + Clear). Maps indices 0-4 to ratings 1-5; index 5 maps to 0 (clear). Returns None on cancel. Keeps actions.py free of xbmcgui imports (ARCH-05).

- **`build_genre_item(genre: SubsonicGenre, url: str) -> tuple[str, xbmcgui.ListItem, bool]`** — Builds a navigation folder item labelled `"{name} ({songCount} songs)"`. Falls back to `<Unknown>` when `value` is absent. Returns `is_folder=True`.

- **`build_album_item` extension** — After existing setters, now calls `tag.setMusicBrainzAlbumID(mb_id)` when `musicBrainzId` is present in the album dict.

- **`build_artist_item` extension** — Calls `tag.setMusicBrainzArtistID(mb_id)` when `musicBrainzId` is present in the artist dict.

- **Verified**: `build_track_item` already calls `tag.setMusicBrainzTrackID` from Phase 3 (lines 119-121). No edit needed.

### models.py additions

- **`SubsonicArtist.musicBrainzId: str | None`** — Added to match the field returned by `search3 ArtistID3` responses and align with `SubsonicTrack.musicBrainzId` pattern.

- **`SubsonicGenre` import** — Added to listings.py imports for type annotation on `build_genre_item`.

### Import update

Updated the `from subsonic.models import ...` statement to multi-line form including `SubsonicGenre`.

## Test Coverage

29 tests pass in `tests/test_listings.py` (up from 16):

| New Test | Verifies |
|----------|----------|
| test_show_rating_select_returns_rating | idx 2 → rating 3 |
| test_show_rating_select_clear | idx 5 → rating 0 |
| test_show_rating_select_cancel | idx -1 → None |
| test_show_rating_select_first_star | idx 0 → rating 1 |
| test_build_genre_item_label | label format with songCount |
| test_build_genre_item_unknown_name | missing value → "<Unknown>" |
| test_build_genre_item_returns_url | url passthrough |
| test_build_track_mbid_calls_setter | setMusicBrainzTrackID called |
| test_build_track_no_mbid_no_setter | setMusicBrainzTrackID NOT called |
| test_build_album_mbid_calls_setter | setMusicBrainzAlbumID called |
| test_build_album_no_mbid_no_setter | setMusicBrainzAlbumID NOT called |
| test_build_artist_mbid_calls_setter | setMusicBrainzArtistID called |
| test_build_artist_no_mbid_no_setter | setMusicBrainzArtistID NOT called |

## Verification Results

```
pytest tests/test_listings.py     → 29 passed
mypy --strict listings.py models.py → Success: no issues found in 2 source files
ruff check listings.py            → All checks passed!
```

## Deviations from Plan

None — plan executed exactly as written.

## Known Stubs

None. All new functions are fully implemented and wired.

## Self-Check: PASSED

- `resources/lib/subsonic/listings.py`: FOUND — contains `build_genre_item` and `show_rating_select`
- `resources/lib/subsonic/models.py`: FOUND — `SubsonicArtist.musicBrainzId` present
- `tests/test_listings.py`: FOUND — 29 tests all pass
- Commit d9a9415: FOUND
- Commit 3f46547: FOUND
