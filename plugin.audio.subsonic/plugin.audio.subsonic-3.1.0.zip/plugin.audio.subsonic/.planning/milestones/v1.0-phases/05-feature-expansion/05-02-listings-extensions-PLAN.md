---
phase: 05-feature-expansion
plan: 02
type: execute
wave: 1
depends_on: []
files_modified:
  - resources/lib/subsonic/listings.py
  - tests/test_listings.py
autonomous: true
requirements: [FEAT-01, FEAT-03, FEAT-05]

must_haves:
  truths:
    - "build_genre_item() returns a folder ListItem whose label is 'GenreName (N songs)'"
    - "show_rating_select() shows a Dialog().select with 6 options and returns the chosen rating int (0-5)"
    - "build_album_item() calls tag.setMusicBrainzAlbumID when musicBrainzId is present"
    - "build_artist_item() calls tag.setMusicBrainzArtistID when musicBrainzId is present"
    - "build_track_item() already calls setMusicBrainzTrackID (verify it's there from Phase 3)"
  artifacts:
    - path: resources/lib/subsonic/listings.py
      provides: "build_genre_item + show_rating_select + MusicBrainz in album/artist builders"
      exports: [build_genre_item, show_rating_select]
    - path: tests/test_listings.py
      provides: "tests for new listings functions"
  key_links:
    - from: resources/lib/subsonic/browse.py
      to: resources/lib/subsonic/listings.py
      via: "from subsonic.listings import build_genre_item"
      pattern: "build_genre_item"
    - from: resources/lib/subsonic/actions.py
      to: resources/lib/subsonic/listings.py
      via: "from subsonic.listings import show_rating_select"
      pattern: "show_rating_select"
---

<objective>
Extend listings.py with: build_genre_item(), show_rating_select(), and MusicBrainz ID passthrough in build_album_item() and build_artist_item().

This plan owns ALL changes to listings.py so that the two Wave 2 plans (browse+radio+actions and search) never write to the same file in parallel.

Purpose: Satisfies ARCH-05 (all UI calls in listings.py) and FEAT-03/FEAT-05 requirements.
Output: Three new/extended functions in listings.py; test coverage for each.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/phases/05-feature-expansion/05-CONTEXT.md

<interfaces>
<!-- Current listings.py public surface for reference. Executor must NOT rewrite existing functions — only add to them. -->

From resources/lib/subsonic/listings.py (existing exports):
```python
# Already imported at top:
import xbmcgui
import xbmcplugin
from subsonic.models import SubsonicAlbum, SubsonicArtist, SubsonicPlaylist, SubsonicTrack

def show_search_dialog(prompt: str = "Search") -> str | None: ...
def build_track_item(track, url, cover_url, hide_artist) -> tuple[str, xbmcgui.ListItem, bool]:
    # Already has MusicBrainz passthrough at lines 119-121:
    #   mb_id = track.get("musicBrainzId")
    #   if mb_id:
    #       tag.setMusicBrainzTrackID(mb_id)

def build_album_item(album, url, cover_url, hide_artist) -> tuple[str, xbmcgui.ListItem, bool]:
    # MISSING musicBrainzId passthrough — add before the final return

def build_artist_item(artist, url, cover_url) -> tuple[str, xbmcgui.ListItem, bool]:
    # MISSING musicBrainzId passthrough — add before the final return

def build_playlist_item(...) -> ...: ...
def build_nav_item(label, url) -> tuple[str, xbmcgui.ListItem, bool]: ...
def add_items(handle, items) -> None: ...
def end_directory(handle, content, sort_methods, succeeded, update_listing, cache_to_disk) -> None: ...
```

From resources/lib/subsonic/models.py (existing TypedDicts):
```python
class SubsonicGenre(TypedDict, total=False):
    value: str
    songCount: int
    albumCount: int

class SubsonicArtist(TypedDict, total=False):
    id: str; name: str; albumCount: int; coverArt: str | None; starred: str | None
    # NOTE: musicBrainzId is NOT in SubsonicArtist yet — the field may come from
    # search3 ArtistID3 responses. Add it to SubsonicArtist as optional str | None.

class SubsonicAlbum(TypedDict, total=False):
    # Already has: musicBrainzId: str
    ...
```

From resources/lib/subsonic/api/client.py (Plan 05-01 adds):
```python
# Plan 05-01 adds InternetRadioStation to models.py — not used in listings.py
```
</interfaces>
</context>

<tasks>

<task type="auto" tdd="true">
  <name>Task 1: Add build_genre_item and show_rating_select to listings.py</name>
  <files>resources/lib/subsonic/listings.py, resources/lib/subsonic/models.py</files>
  <behavior>
    - build_genre_item(genre: SubsonicGenre, url: str) -> tuple[str, xbmcgui.ListItem, bool]:
      label is "{name} ({songCount} songs)" where name = genre.get("value") or "Unknown"
      songCount = genre.get("songCount") or 0
      Returns (url, li, True) — genres are navigation folders
      No InfoTagMusic needed (genres are nav items, not playable media)

    - show_rating_select(track_id: str) -> int | None:
      Opens xbmcgui.Dialog().select("Rate", ["1 Star", "2 Stars", "3 Stars", "4 Stars", "5 Stars", "Clear Rating"])
      Returns int based on selection: index 0→1, 1→2, 2→3, 3→4, 4→5, 5→0 (clear)
      Returns None if user cancels (select returns -1)

    - SubsonicArtist TypedDict gains musicBrainzId: str | None field
  </behavior>
  <action>
    In resources/lib/subsonic/models.py, add `musicBrainzId: str | None` to SubsonicArtist.

    In resources/lib/subsonic/listings.py:

    1. Update the import at the top to include SubsonicGenre:
       ```python
       from subsonic.models import (
           SubsonicAlbum, SubsonicArtist, SubsonicGenre,
           SubsonicPlaylist, SubsonicTrack,
       )
       ```

    2. After show_search_dialog, add show_rating_select:
       ```python
       def show_rating_select(track_id: str) -> int | None:
           """Show a rating selection dialog for the given track.

           Returns the selected rating (1-5), 0 to clear, or None if cancelled.
           Wraps xbmcgui.Dialog().select so that actions.py need not import
           xbmcgui directly (ARCH-05).
           """
           options = ["1 Star", "2 Stars", "3 Stars", "4 Stars", "5 Stars", "Clear Rating"]
           dialog = xbmcgui.Dialog()
           idx = dialog.select("Rate", options)
           if idx < 0:
               return None
           # Map index 0-4 → rating 1-5; index 5 → rating 0 (clear)
           return idx + 1 if idx < 5 else 0
       ```

    3. After build_playlist_item, add build_genre_item:
       ```python
       def build_genre_item(
           genre: SubsonicGenre,
           url: str,
       ) -> tuple[str, xbmcgui.ListItem, bool]:
           """Build a ``(url, ListItem, is_folder)`` tuple for a genre directory.

           Args:
               genre: Subsonic genre dict (value, songCount, albumCount).
               url:   Fully-qualified plugin URL for the genre-tracks action.

           Returns:
               ``(url, li, True)`` — genres are navigation folders.
           """
           name: str = genre.get("value") or "<Unknown>"
           song_count: int = genre.get("songCount") or 0
           label = f"{name} ({song_count} songs)"
           li = xbmcgui.ListItem(label=label, offscreen=True)
           return url, li, True
       ```
  </action>
  <verify>
    <automated>grep -q "def build_genre_item" /home/sandwich/Develop/plugin.audio.subsonic/resources/lib/subsonic/listings.py && grep -q "def show_rating_select" /home/sandwich/Develop/plugin.audio.subsonic/resources/lib/subsonic/listings.py</automated>
  </verify>
  <done>build_genre_item and show_rating_select exist in listings.py; SubsonicArtist has musicBrainzId; mypy --strict clean</done>
</task>

<task type="auto" tdd="true">
  <name>Task 2: MusicBrainz passthrough in build_album_item + build_artist_item + tests</name>
  <files>resources/lib/subsonic/listings.py, tests/test_listings.py</files>
  <behavior>
    - build_album_item: when album dict has musicBrainzId, call tag.setMusicBrainzAlbumID(value)
    - build_artist_item: when artist dict has musicBrainzId, call tag.setMusicBrainzArtistID(value)
    - test_build_track_mbid_calls_setter: build_track_item with {"musicBrainzId": "abc"} → tag.setMusicBrainzTrackID called with "abc"
    - test_build_album_mbid_calls_setter: build_album_item with {"musicBrainzId": "def"} → tag.setMusicBrainzAlbumID called with "def"
    - test_build_artist_mbid_calls_setter: build_artist_item with {"musicBrainzId": "ghi"} → tag.setMusicBrainzArtistID called with "ghi"
    - test_build_track_no_mbid_no_setter: build_track_item without musicBrainzId → setMusicBrainzTrackID NOT called
    - test_build_genre_item_label: build_genre_item({"value":"Rock","songCount":5}, "url") → label "Rock (5 songs)"
    - test_show_rating_select_returns_rating: mock Dialog().select returns 2 (index 2) → function returns 3 (rating 3)
    - test_show_rating_select_clear: mock Dialog().select returns 5 → function returns 0
    - test_show_rating_select_cancel: mock Dialog().select returns -1 → function returns None
  </behavior>
  <action>
    In resources/lib/subsonic/listings.py, in build_album_item, add before the final `return url, li, True`:
    ```python
    mb_id = album.get("musicBrainzId")
    if mb_id:
        tag.setMusicBrainzAlbumID(mb_id)
    ```

    In build_artist_item, add before the final `return url, li, True`:
    ```python
    mb_id = artist.get("musicBrainzId")
    if mb_id:
        tag.setMusicBrainzArtistID(mb_id)
    ```

    In tests/test_listings.py, add the new tests following the existing monkeypatch pattern.
    Look at test_build_track_uses_get_music_info_tag and test_end_directory_calls_set_content
    to understand the mock structure (MagicMock ListItem, tag = MagicMock()).

    Key pattern from existing test_listings.py:
    ```python
    def test_build_track_uses_get_music_info_tag(monkeypatch):
        mock_li = MagicMock()
        tag = MagicMock()
        mock_li.getMusicInfoTag.return_value = tag
        monkeypatch.setattr(xbmcgui, "ListItem", lambda **kw: mock_li)
        build_track_item({"title": "T", "id": "1"}, "url://")
        mock_li.getMusicInfoTag.assert_called()
    ```

    Follow this pattern for the new MusicBrainz tests and the build_genre_item / show_rating_select tests.
    For show_rating_select: monkeypatch xbmcgui.Dialog to return a mock whose select() returns the desired index.
  </action>
  <verify>
    <automated>cd /home/sandwich/Develop/plugin.audio.subsonic && .venv/bin/python -m pytest tests/test_listings.py -v 2>&1 | tail -20</automated>
  </verify>
  <done>All test_listings.py tests pass (including new ones); MusicBrainz passthrough added to album and artist builders; ruff + mypy clean on listings.py</done>
</task>

</tasks>

<verification>
```bash
cd /home/sandwich/Develop/plugin.audio.subsonic
.venv/bin/python -m pytest tests/test_listings.py -v
.venv/bin/python -m mypy resources/lib/subsonic/listings.py resources/lib/subsonic/models.py --strict 2>&1 | tail -10
.venv/bin/python -m ruff check resources/lib/subsonic/listings.py
```
</verification>

<success_criteria>
- `grep -q "def build_genre_item\|def show_rating_select" resources/lib/subsonic/listings.py` exits 0
- `grep -q "setMusicBrainzAlbumID" resources/lib/subsonic/listings.py` exits 0
- `grep -q "setMusicBrainzArtistID" resources/lib/subsonic/listings.py` exits 0
- All test_listings.py tests pass (pytest exits 0)
- mypy --strict clean on listings.py
</success_criteria>

<output>
After completion, create `.planning/phases/05-feature-expansion/05-02-listings-extensions-SUMMARY.md`
</output>
