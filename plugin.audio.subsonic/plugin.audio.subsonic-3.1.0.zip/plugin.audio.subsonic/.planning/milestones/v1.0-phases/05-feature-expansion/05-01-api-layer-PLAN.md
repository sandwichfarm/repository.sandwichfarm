---
phase: 05-feature-expansion
plan: 01
type: execute
wave: 1
depends_on: []
files_modified:
  - resources/lib/subsonic/api/client.py
  - resources/lib/subsonic/models.py
  - resources/language/English/strings.po
  - tests/test_api_client.py
autonomous: true
requirements: [FEAT-01, FEAT-02, FEAT-03, FEAT-04, FEAT-05]

must_haves:
  truths:
    - "ApiClient.get_genres() calls libsonic.getGenres and returns a list of genre dicts"
    - "ApiClient.get_songs_by_genre() calls libsonic.getSongsByGenre with count + offset"
    - "ApiClient.search3() calls libsonic.search3 and returns the searchResult3 dict"
    - "ApiClient.set_rating() calls libsonic.setRating and returns bool"
    - "ApiClient.get_internet_radio_stations() calls libsonic.getInternetRadioStations and returns a list"
    - "InternetRadioStation TypedDict exists in models.py"
    - "String IDs #30060-#30064 defined in strings.po"
  artifacts:
    - path: resources/lib/subsonic/api/client.py
      provides: "5 new ApiClient methods"
      exports: [get_genres, get_songs_by_genre, search3, set_rating, get_internet_radio_stations]
    - path: resources/lib/subsonic/models.py
      provides: "InternetRadioStation TypedDict"
      contains: "class InternetRadioStation"
    - path: resources/language/English/strings.po
      provides: "new label strings"
      contains: "#30060"
    - path: tests/test_api_client.py
      provides: "tests for all 5 new methods"
  key_links:
    - from: resources/lib/subsonic/api/client.py
      to: lib/libsonic/connection.py
      via: self._conn.getGenres / search3 / etc.
      pattern: "self._conn\\.getGenres\\|self._conn\\.search3\\|self._conn\\.setRating"
---

<objective>
Add 5 new ApiClient methods that wrap the corresponding libsonic calls, add the InternetRadioStation TypedDict to models.py, and add the new string labels to strings.po.

Purpose: Wave 2 plans (browse handlers, search, actions, playback, listings) all depend on these typed client methods. Building the API boundary first ensures type-safe interfaces are ready for parallel consumption.

Output: 5 new ApiClient methods, 1 new TypedDict, 5 new string IDs, tests for all new methods.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/ROADMAP.md
@.planning/STATE.md
@.planning/phases/05-feature-expansion/05-CONTEXT.md

<interfaces>
<!-- Key contracts the executor needs. Extracted from existing codebase. -->

From resources/lib/subsonic/api/client.py (existing pattern to match):
```python
def get_album_list(
    self,
    ltype: str = "newest",
    size: int = 50,
    offset: int = 0,
    **kwargs: Any,
) -> list[dict[str, Any]]:
    resp = self._conn.getAlbumList2(ltype=ltype, size=size, offset=offset, **kwargs)
    return resp.get("albumList2", {}).get("album") or []

def search(
    self,
    query: str,
    artist_count: int = 20,
    album_count: int = 20,
    song_count: int = 20,
) -> dict[str, list[dict[str, Any]]]:
    resp = self._conn.search2(query=query, artistCount=artist_count,
        albumCount=album_count, songCount=song_count)
    return resp.get("searchResult2") or {}
```

From lib/libsonic/connection.py (already present — just wrap these):
```python
def getGenres(self): ...
    # returns {"genres": {"genre": [{"value": str, "songCount": int, "albumCount": int}, ...]}}

def getSongsByGenre(self, genre, count=10, offset=0, musicFolderId=None): ...
    # returns {"songsByGenre": {"song": [...]}}

def search3(self, query, artistCount=20, artistOffset=0, albumCount=20,
            albumOffset=0, songCount=20, songOffset=0, musicFolderId=None): ...
    # returns {"searchResult3": {"artist": [...], "album": [...], "song": [...]}}

def setRating(self, id, rating): ...
    # returns {"status": "ok"} or error; rating 0 removes, 1-5 sets

def getInternetRadioStations(self): ...
    # returns {"internetRadioStations": {"internetRadioStation": [{"id": str, "name": str,
    #   "streamUrl": str, "homePageUrl": str}, ...]}}
```

From resources/lib/subsonic/models.py (existing TypedDicts for reference):
```python
class SubsonicGenre(TypedDict, total=False):
    value: str
    songCount: int
    albumCount: int
```

From resources/language/English/strings.po (last defined ID):
```
msgctxt "#30050"
msgid "API Key (OpenSubsonic)"
```
</interfaces>
</context>

<tasks>

<task type="auto" tdd="true">
  <name>Task 1: Add 5 ApiClient methods + InternetRadioStation TypedDict</name>
  <files>resources/lib/subsonic/api/client.py, resources/lib/subsonic/models.py</files>
  <behavior>
    - get_genres(): libsonic returns {"genres": {"genre": [...]}} — extract the list or []
    - get_songs_by_genre("Rock", count=100, offset=0): libsonic returns {"songsByGenre": {"song": [...]}} — extract list or []
    - search3("query", artist_count=20, album_count=20, song_count=40): libsonic returns {"searchResult3": {"artist": [...], "album": [...], "song": [...]}} — return the inner dict or {}
    - set_rating("123", 4): libsonic returns {"status": "ok"} on success — return True; returns {"status": "failed"} or raises on error — return False
    - get_internet_radio_stations(): libsonic returns {"internetRadioStations": {"internetRadioStation": [...]}} — extract list or []
    - InternetRadioStation TypedDict: id: str, name: str, streamUrl: str, homePageUrl: str | None
  </behavior>
  <action>
    In resources/lib/subsonic/models.py, add after SubsonicGenre:
    ```python
    class InternetRadioStation(TypedDict, total=False):
        """Shape of a radio station object returned by getInternetRadioStations."""
        id: str
        name: str
        streamUrl: str
        homePageUrl: str | None
    ```

    In resources/lib/subsonic/api/client.py, add 5 methods after the existing `search` method.
    Place under a new section comment `# ------------------------------------------------------------------`
    `# Phase 5: Genre, Radio, Rating methods`
    `# ------------------------------------------------------------------`

    ```python
    def get_genres(self) -> list[dict[str, Any]]:
        """Return a list of genre dicts from getGenres (Subsonic 1.9.0+)."""
        resp = self._conn.getGenres()
        return resp.get("genres", {}).get("genre") or []

    def get_songs_by_genre(
        self,
        genre: str,
        count: int = 100,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """Return a list of song dicts for the given genre (Subsonic 1.9.0+)."""
        resp = self._conn.getSongsByGenre(genre=genre, count=count, offset=offset)
        return resp.get("songsByGenre", {}).get("song") or []

    def search3(
        self,
        query: str,
        artist_count: int = 20,
        album_count: int = 20,
        song_count: int = 40,
    ) -> dict[str, list[dict[str, Any]]]:
        """Return search3 results dict with 'artist', 'album', 'song' keys.

        Uses ID3-based results (richer metadata including MusicBrainz IDs and
        genre fields) compared to search2. Replaces client.search() (FEAT-02).
        """
        resp = self._conn.search3(
            query=query,
            artistCount=artist_count,
            albumCount=album_count,
            songCount=song_count,
        )
        return resp.get("searchResult3") or {}

    def set_rating(self, item_id: str, rating: int) -> bool:
        """Set a 1-5 star rating on a track/album/artist. Pass 0 to clear.

        Returns True on success, False on failure (FEAT-03).
        """
        try:
            resp = self._conn.setRating(id=item_id, rating=rating)
            return bool(resp.get("status") == "ok")
        except Exception:
            return False

    def get_internet_radio_stations(self) -> list[dict[str, Any]]:
        """Return a list of internet radio station dicts (Subsonic 1.9.0+).

        Returns empty list if the server does not support this endpoint or
        returns no stations (FEAT-04).
        """
        try:
            resp = self._conn.getInternetRadioStations()
            return resp.get("internetRadioStations", {}).get("internetRadioStation") or []
        except Exception:
            return []
    ```

    Also add `search3` import to `client.py` update: the existing `search` method on ApiClient
    calls `search2` — leave it as-is for backward compat. The new `search3` method is the
    Phase 5 replacement called from search.py (Plan 05-03).
  </action>
  <verify>
    <automated>grep -q "def get_genres" /home/sandwich/Develop/plugin.audio.subsonic/resources/lib/subsonic/api/client.py && grep -q "def get_songs_by_genre" /home/sandwich/Develop/plugin.audio.subsonic/resources/lib/subsonic/api/client.py && grep -q "def search3" /home/sandwich/Develop/plugin.audio.subsonic/resources/lib/subsonic/api/client.py && grep -q "def set_rating" /home/sandwich/Develop/plugin.audio.subsonic/resources/lib/subsonic/api/client.py && grep -q "def get_internet_radio_stations" /home/sandwich/Develop/plugin.audio.subsonic/resources/lib/subsonic/api/client.py && grep -q "class InternetRadioStation" /home/sandwich/Develop/plugin.audio.subsonic/resources/lib/subsonic/models.py</automated>
  </verify>
  <done>All 5 methods exist on ApiClient; InternetRadioStation TypedDict in models.py; mypy --strict passes on both files</done>
</task>

<task type="auto" tdd="true">
  <name>Task 2: Add strings.po labels + extend test_api_client.py</name>
  <files>resources/language/English/strings.po, tests/test_api_client.py</files>
  <behavior>
    - strings.po gains 5 new entries after #30050: #30060="Genres", #30061="Internet Radio", #30062="Rate", #30063="Clear rating", #30064="Radio stations not available"
    - test_get_genres: mock conn.getGenres returns {"genres": {"genre": [{"value":"Rock","songCount":5,"albumCount":2}]}} → result is [{"value":"Rock",...}]
    - test_get_songs_by_genre: mock conn.getSongsByGenre returns {"songsByGenre": {"song": [{"id":"1"}]}} → result is [{"id":"1"}]
    - test_search3_returns_result_dict: mock conn.search3 returns {"searchResult3": {"artist": [], "album": [], "song": [{"id":"1"}]}} → result["song"] == [{"id":"1"}]
    - test_set_rating_returns_true_on_ok: mock conn.setRating returns {"status":"ok"} → True
    - test_set_rating_returns_false_on_fail: mock conn.setRating raises Exception → False
    - test_get_internet_radio_stations: mock returns {"internetRadioStations":{"internetRadioStation":[{"id":"1","name":"Radio X","streamUrl":"http://..."}]}} → list with 1 station
    - test_get_internet_radio_stations_empty_on_exception: mock raises → []
  </behavior>
  <action>
    In resources/language/English/strings.po, after the last `#30050` block, add:

    ```po
    msgctxt "#30060"
    msgid "Genres"
    msgstr ""

    msgctxt "#30061"
    msgid "Internet Radio"
    msgstr ""

    msgctxt "#30062"
    msgid "Rate"
    msgstr ""

    msgctxt "#30063"
    msgid "Clear rating"
    msgstr ""

    msgctxt "#30064"
    msgid "Radio stations not available"
    msgstr ""
    ```

    In tests/test_api_client.py, append a new section of tests (following existing MagicMock
    pattern — see existing test_get_album_list_returns_albums for reference):

    Each test: create mock settings → ApiClient(settings) → mock _conn method → call ApiClient
    method → assert result.

    Follow the existing pattern in the test file exactly (Mock settings object, patching
    self._conn on the constructed client instance, asserting return value shape).
  </action>
  <verify>
    <automated>cd /home/sandwich/Develop/plugin.audio.subsonic && .venv/bin/python -m pytest tests/test_api_client.py -v -k "genre or radio or rating or search3" 2>&1 | tail -20</automated>
  </verify>
  <done>All new test_api_client.py tests pass; strings.po has #30060–#30064 defined; ruff check passes on modified files</done>
</task>

</tasks>

<verification>
```bash
cd /home/sandwich/Develop/plugin.audio.subsonic
.venv/bin/python -m pytest tests/test_api_client.py -v
.venv/bin/python -m mypy resources/lib/subsonic/api/client.py resources/lib/subsonic/models.py --strict 2>&1 | tail -10
.venv/bin/python -m ruff check resources/lib/subsonic/api/client.py resources/lib/subsonic/models.py
```
</verification>

<success_criteria>
- `grep -q "def get_genres\|def get_songs_by_genre\|def search3\|def set_rating\|def get_internet_radio_stations" resources/lib/subsonic/api/client.py` exits 0
- `grep -q "class InternetRadioStation" resources/lib/subsonic/models.py` exits 0
- `grep -q "#30060" resources/language/English/strings.po` exits 0
- All new test_api_client.py tests pass (pytest exits 0)
- `mypy --strict` clean on client.py and models.py
- `ruff check` clean on both files
</success_criteria>

<output>
After completion, create `.planning/phases/05-feature-expansion/05-01-api-layer-SUMMARY.md`
</output>
