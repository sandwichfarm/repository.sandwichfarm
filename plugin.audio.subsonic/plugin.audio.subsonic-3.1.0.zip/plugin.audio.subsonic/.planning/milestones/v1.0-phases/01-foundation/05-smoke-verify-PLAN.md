---
phase: 01-foundation
plan: 05
type: execute
wave: 3
depends_on:
  - 01-foundation/01-crash-fixes-PLAN.md
  - 01-foundation/02-bare-excepts-PLAN.md
  - 01-foundation/03-test-scaffold-PLAN.md
  - 01-foundation/04-ci-workflow-PLAN.md
files_modified: []
autonomous: false
requirements:
  - COMPAT-01
  - COMPAT-02

must_haves:
  truths:
    - "pytest passes on Python 3.8"
    - "pytest passes on Python 3.11"
    - "No test imports crash with NameError or AttributeError"
  artifacts:
    - path: "tests/test_imports.py"
      provides: "Passing smoke tests — the runtime check that COMPAT-01 and COMPAT-02 hold"
      contains: "test_import_main"
  key_links:
    - from: "tests/test_imports.py"
      to: "import main, import service"
      via: "pytest run under both Python 3.8 and 3.11"
      pattern: "4 passed"
---

<objective>
Run the smoke tests under both Python 3.8 and 3.11 to verify COMPAT-01 and COMPAT-02. Checkpoint for human verification of any unexpected failures.

Purpose: This is the integration check — the Wave 1 crash fixes (plans 01, 02) and test scaffolding (plan 03) must all work together before the phase is complete. Running on two Python versions confirms the addon loads cleanly on both Kodi 20 (Nexus/3.8) and Kodi 21 (Omega/3.11).

Output: Confirmed pytest exit 0 on both Python versions. Human verifies the output and approves the phase.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/ROADMAP.md
@.planning/STATE.md
@.planning/phases/01-foundation/01-foundation-01-SUMMARY.md
@.planning/phases/01-foundation/01-foundation-02-SUMMARY.md
@.planning/phases/01-foundation/01-foundation-03-SUMMARY.md
</context>

<tasks>

<task type="auto">
  <name>Task 1: Run smoke tests on available Python versions</name>
  <files></files>
  <read_first>
    - tests/test_imports.py (confirm the 4 smoke tests exist as written in Plan 03)
    - tests/conftest.py (confirm mocks are in place)
  </read_first>
  <action>
    Run the test suite and capture results. Do the following:

    1. Check which Python versions are available:
       ```bash
       python3 --version
       python3.8 --version 2>/dev/null || echo "3.8 not installed separately"
       python3.11 --version 2>/dev/null || echo "3.11 not installed separately"
       ```

    2. Run pytest with the default python3:
       ```bash
       cd /home/sandwich/Develop/plugin.audio.subsonic
       python3 -m pytest tests/ -v
       ```

    3. If python3.8 is available separately, run:
       ```bash
       python3.8 -m pytest tests/ -v
       ```

    4. If python3.11 is available separately, run:
       ```bash
       python3.11 -m pytest tests/ -v
       ```

    5. Capture the full output from each run.

    If pytest is not installed, install it first:
    ```bash
    pip install pytest Kodistubs==21.0.0
    ```

    **Expected outcome for each run:**
    ```
    tests/test_imports.py::test_import_main PASSED
    tests/test_imports.py::test_import_service PASSED
    tests/test_imports.py::test_import_libsonic PASSED
    tests/test_imports.py::test_import_simpleplugin PASSED
    4 passed
    ```

    **If any test fails:**
    - Read the full error traceback
    - Identify which of the Wave 1 plans (01, 02, 03) needs a correction
    - Fix the root cause in the appropriate file
    - Re-run pytest until all 4 pass
    - Document the fix in the summary

    Do NOT proceed to the checkpoint task until all 4 tests pass.
  </action>
  <verify>
    <automated>cd /home/sandwich/Develop/plugin.audio.subsonic && python3 -m pytest tests/ -v 2>&1 | tail -10</automated>
  </verify>
  <acceptance_criteria>
    - `pytest tests/` exits with code 0
    - Output contains "4 passed"
    - No "ERROR" or "FAILED" lines in pytest output
  </acceptance_criteria>
  <done>pytest exits 0; all 4 smoke tests pass; output recorded in summary.</done>
</task>

<task type="checkpoint:human-verify" gate="blocking">
  <name>Task 2: Human approval — Phase 1 Foundation complete</name>
  <action>Human reviews the verification output from Task 1 and confirms all acceptance criteria are met.</action>
  <what-built>
    Phase 1 Foundation complete:
    - Plan 01: import sys added to service.py; urllib2 removed from libsonic; xbmc.translatePath removed from simpleplugin
    - Plan 02: Bare except in get_connection() (main.py and service.py) replaced with traceback-logging handlers
    - Plan 03: pyproject.toml, tests/conftest.py, tests/test_imports.py created
    - Plan 04: .github/workflows/ci.yml created with pytest matrix, ruff, mypy, kodi-addon-checker
    - Plan 05 Task 1: pytest runs and 4 smoke tests pass
  </what-built>
  <how-to-verify>
    Run the following and confirm all pass:

    ```bash
    cd /home/sandwich/Develop/plugin.audio.subsonic

    # 1. Crash fix verification
    grep -q '^import sys' service.py && echo "BUG-01 OK: import sys present"
    ! grep -q 'urllib2' lib/libsonic/connection.py && echo "COMPAT-03 OK: no urllib2"
    ! grep -rq 'xbmc\.translatePath' lib/ && echo "COMPAT-04 OK: no xbmc.translatePath"

    # 2. Bare except verification
    ! grep -q 'except:$' service.py && echo "BUG-02 service.py OK"
    grep -n 'except:$' main.py  # should show only 407, 472, 708

    # 3. Smoke tests
    python3 -m pytest tests/ -v

    # 4. CI workflow
    grep -E 'python-version|kodi-addon-checker|ruff|mypy' .github/workflows/ci.yml
    ```

    Expected: all checks pass, pytest shows "4 passed".
  </how-to-verify>
  <resume-signal>Type "approved" to mark Phase 1 complete, or describe any issues found.</resume-signal>
</task>

</tasks>

<verification>
```bash
cd /home/sandwich/Develop/plugin.audio.subsonic

# Full phase verification
python3 -m pytest tests/ -v
grep -q '^import sys' service.py && echo "BUG-01 PASS"
! grep -q 'urllib2' lib/libsonic/connection.py && echo "COMPAT-03 PASS"
! grep -rq 'xbmc\.translatePath' lib/ && echo "COMPAT-04 PASS"
! grep -q 'except:$' service.py && echo "BUG-02 service.py PASS"
ls .github/workflows/ci.yml && echo "CI workflow PASS"
grep -q 'testpaths' pyproject.toml && echo "pyproject.toml PASS"
```
</verification>

<success_criteria>
1. `pytest tests/` exits 0 with 4 passed
2. All Wave 1 acceptance criteria confirmed (BUG-01, COMPAT-03, COMPAT-04, BUG-02, TEST-01)
3. CI workflow file exists and contains correct structure
4. Human has approved the phase at the checkpoint
</success_criteria>

<output>
After completion, create `.planning/phases/01-foundation/01-foundation-05-SUMMARY.md`
</output>
