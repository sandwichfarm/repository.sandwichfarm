---
phase: 01-foundation
plan: 01
type: execute
wave: 1
depends_on: []
files_modified:
  - service.py
  - lib/libsonic/connection.py
  - lib/simpleplugin/simpleplugin.py
autonomous: true
requirements:
  - BUG-01
  - COMPAT-03
  - COMPAT-04

must_haves:
  truths:
    - "service.py can be imported without NameError on sys"
    - "No urllib2 references remain in lib/libsonic/connection.py"
    - "No xbmc.translatePath calls remain anywhere in the codebase"
  artifacts:
    - path: "service.py"
      provides: "Fixed scrobble service — import sys present, sys.path.append succeeds"
      contains: "import sys"
    - path: "lib/libsonic/connection.py"
      provides: "Py3-clean GET request helpers"
      contains: "urllib.request.Request"
    - path: "lib/simpleplugin/simpleplugin.py"
      provides: "Unconditional xbmcvfs.translatePath — no version guard"
      contains: "xbmcvfs.translatePath"
  key_links:
    - from: "service.py line 7"
      to: "sys.path.append"
      via: "import sys at top of file"
      pattern: "^import sys"
    - from: "lib/libsonic/connection.py _getRequestWithList/_getRequestWithLists"
      to: "urllib.request.Request"
      via: "useGET branch"
      pattern: "urllib\\.request\\.Request"
    - from: "lib/simpleplugin/simpleplugin.py translate_path"
      to: "xbmcvfs.translatePath"
      via: "unconditional call, no if/else version guard"
      pattern: "xbmcvfs\\.translatePath"
---

<objective>
Fix the three immediate Python 3 / Kodi 20+ crash bugs that prevent the addon from loading at all.

Purpose: These are hard crashes on every Kodi 20+ install. No user can scrobble (BUG-01), no user with useGET=True can star tracks or update playlists (COMPAT-03), and the version-guard string comparison in simpleplugin silently picks the wrong branch on Kodi 20+ because `'20' < '19'` is False but `'9' > '20'` is also False — unpredictable behaviour that can pick xbmc.translatePath which no longer exists (COMPAT-04).

Output: Three patched files. No structural changes — targeted surgical fixes only.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/ROADMAP.md
@.planning/STATE.md
@.planning/codebase/CONCERNS.md
@.planning/research/PITFALLS.md
</context>

<tasks>

<task type="auto" tdd="true">
  <name>Task 1: Add missing `import sys` to service.py (BUG-01)</name>
  <files>service.py</files>
  <read_first>
    - service.py (full file — understand current import order before editing)
    - .planning/codebase/CONCERNS.md (section "Missing sys Import in service.py")
  </read_first>
  <behavior>
    - Importing service.py in a test context must not raise NameError on 'sys'
    - `import sys` must appear before any use of sys (currently line 7: sys.path.append)
    - No other imports may be reordered or removed
  </behavior>
  <action>
    Read service.py. The file currently begins:

    ```python
    import re
    import xbmc
    import xbmcvfs
    import os
    import xbmcaddon
    # Add the /lib folder to sys
    sys.path.append(...)
    ```

    Insert `import sys` immediately after `import os` and before `import xbmcaddon` — or as the very first stdlib import at the top. The exact position must be before line 7 where sys.path.append is called.

    Result after fix (lines 1-8 area):
    ```python
    import re
    import sys
    import xbmc
    import xbmcvfs
    import os
    import xbmcaddon
    # Add the /lib folder to sys
    sys.path.append(...)
    ```

    No other changes to service.py in this task.
  </action>
  <verify>
    <automated>grep -q '^import sys' /home/sandwich/Develop/plugin.audio.subsonic/service.py && echo "PASS: import sys present" || echo "FAIL: import sys missing"</automated>
  </verify>
  <acceptance_criteria>
    - `grep -c '^import sys' service.py` returns 1
    - `import sys` appears before line 7 (sys.path.append call)
    - No other lines in service.py changed
  </acceptance_criteria>
  <done>service.py line ordering has `import sys` before `sys.path.append(...)`; grep confirms.</done>
</task>

<task type="auto">
  <name>Task 2: Replace urllib2.Request with urllib.request.Request in libsonic (COMPAT-03)</name>
  <files>lib/libsonic/connection.py</files>
  <read_first>
    - lib/libsonic/connection.py lines 2820-2880 (both _getRequestWithList and _getRequestWithLists methods)
    - .planning/codebase/CONCERNS.md (section "urllib2 reference in Python 3 code")
    - .planning/research/PITFALLS.md (Pitfall 2)
  </read_first>
  <action>
    Two lines need fixing — both in the `if self._useGET:` branch of their respective methods.

    **Fix at ~line 2848** (inside `_getRequestWithList`):
    Change:
    ```python
        if self._useGET:
            url += '?%s' % data.getvalue()
            req = urllib2.Request(url)
    ```
    To:
    ```python
        if self._useGET:
            url += '?%s' % data.getvalue()
            req = urllib.request.Request(url)
    ```

    **Fix at ~line 2875** (inside `_getRequestWithLists`):
    Change:
    ```python
        if self._useGET:
            url += '?%s' % data.getvalue()
            req = urllib2.Request(url)
    ```
    To:
    ```python
        if self._useGET:
            url += '?%s' % data.getvalue()
            req = urllib.request.Request(url)
    ```

    The file already imports `urllib.request` at the top (line 21: `import urllib.request`), so no new import is needed. Do NOT add `import urllib2` anywhere — that module does not exist in Python 3.

    These are the only two occurrences of `urllib2` in the file. No other changes.
  </action>
  <verify>
    <automated>grep -c 'urllib2' /home/sandwich/Develop/plugin.audio.subsonic/lib/libsonic/connection.py && echo "FAIL: urllib2 still present" || echo "PASS: no urllib2 references"</automated>
  </verify>
  <acceptance_criteria>
    - `grep -n 'urllib2' lib/libsonic/connection.py` returns no matches
    - `grep -n 'urllib.request.Request' lib/libsonic/connection.py` returns at least 3 matches (the existing POST path plus both GET fixes)
    - The file is valid Python syntax: `python3 -c "import ast; ast.parse(open('lib/libsonic/connection.py').read()); print('OK')"` prints OK
  </acceptance_criteria>
  <done>Both urllib2.Request occurrences in _getRequestWithList and _getRequestWithLists replaced with urllib.request.Request; no urllib2 references remain.</done>
</task>

<task type="auto">
  <name>Task 3: Drop xbmc.translatePath version guard in simpleplugin — use xbmcvfs unconditionally (COMPAT-04)</name>
  <files>lib/simpleplugin/simpleplugin.py</files>
  <read_first>
    - lib/simpleplugin/simpleplugin.py lines 69-80 (the _kodi_major_version and translate_path functions)
    - .planning/codebase/CONCERNS.md (section "Hardcoded Kodi version check")
    - .planning/research/PITFALLS.md (Pitfall 1)
  </read_first>
  <action>
    The current code (lines 69-77) is:

    ```python
    def _kodi_major_version():
        kodi_version = xbmc.getInfoLabel('System.BuildVersion').split(' ')[0]
        return kodi_version.split('.')[0]

    def translate_path(*args, **kwargs):
        if _kodi_major_version() < '19':
            return xbmc.translatePath(*args, **kwargs)
        else:
            return xbmcvfs.translatePath(*args, **kwargs)
    ```

    Replace the entire `translate_path` function (and the `_kodi_major_version` helper if it is only used by `translate_path`) with:

    ```python
    def translate_path(*args, **kwargs):
        # xbmc.translatePath was removed in Kodi 20; target is Kodi 20+ only
        return xbmcvfs.translatePath(*args, **kwargs)
    ```

    Before removing `_kodi_major_version`, grep the rest of the file to confirm it has no other callers:
    ```
    grep -n '_kodi_major_version' lib/simpleplugin/simpleplugin.py
    ```
    If it has other callers, only simplify `translate_path` and leave `_kodi_major_version` in place.

    Do NOT import `xbmc` if it is not already imported — check existing imports at the top of the file first. `xbmcvfs` must be imported; verify or add the import.

    After the edit, run a syntax check: `python3 -c "import ast; ast.parse(open('lib/simpleplugin/simpleplugin.py').read()); print('OK')"`.
  </action>
  <verify>
    <automated>grep -n 'xbmc\.translatePath' /home/sandwich/Develop/plugin.audio.subsonic/lib/simpleplugin/simpleplugin.py && echo "FAIL: xbmc.translatePath still present" || echo "PASS: no xbmc.translatePath"</automated>
  </verify>
  <acceptance_criteria>
    - `grep -rn 'xbmc\.translatePath' lib/ service.py main.py` returns zero hits
    - `grep -n 'xbmcvfs\.translatePath' lib/simpleplugin/simpleplugin.py` shows the translate_path function calling it
    - No version guard (no `if.*< '19'` or `if.*major_version`) in translate_path
    - `python3 -c "import ast; ast.parse(open('lib/simpleplugin/simpleplugin.py').read()); print('OK')"` prints OK
  </acceptance_criteria>
  <done>translate_path in simpleplugin.py calls xbmcvfs.translatePath unconditionally; no xbmc.translatePath exists in any lib/ or top-level file.</done>
</task>

</tasks>

<verification>
After all three tasks complete:

```bash
# BUG-01: sys import present
grep -q '^import sys' service.py && echo "BUG-01 PASS"

# COMPAT-03: no urllib2 in libsonic
! grep -q 'urllib2' lib/libsonic/connection.py && echo "COMPAT-03 PASS"

# COMPAT-04: no xbmc.translatePath anywhere
! grep -rq 'xbmc\.translatePath' lib/ service.py main.py && echo "COMPAT-04 PASS"

# Syntax validity
python3 -c "import ast; ast.parse(open('service.py').read()); print('service.py OK')"
python3 -c "import ast; ast.parse(open('lib/libsonic/connection.py').read()); print('connection.py OK')"
python3 -c "import ast; ast.parse(open('lib/simpleplugin/simpleplugin.py').read()); print('simpleplugin.py OK')"
```
</verification>

<success_criteria>
1. `grep -c '^import sys' service.py` == 1
2. `grep -c 'urllib2' lib/libsonic/connection.py` == 0
3. `grep -rn 'xbmc\.translatePath' .` returns zero hits outside comments
4. All three modified files parse without SyntaxError
</success_criteria>

<output>
After completion, create `.planning/phases/01-foundation/01-foundation-01-SUMMARY.md`
</output>
