---
phase: 01-foundation
plan: 04
type: execute
wave: 1
depends_on: []
files_modified:
  - .github/workflows/ci.yml
autonomous: true
requirements:
  - TEST-08
  - TEST-09
  - TEST-10

must_haves:
  truths:
    - "GitHub Actions runs pytest on Python 3.8 and 3.11 on every push and PR"
    - "GitHub Actions runs ruff check and mypy on every push and PR"
    - "GitHub Actions runs kodi-addon-checker on every push and PR"
    - "First green CI run shows pytest passing on both Python 3.8 AND 3.11 in the matrix job"
  artifacts:
    - path: ".github/workflows/ci.yml"
      provides: "CI pipeline with three jobs: test matrix, lint, addon-check"
      contains: "python-version: [\"3.8\", \"3.11\"]"
  key_links:
    - from: ".github/workflows/ci.yml test job"
      to: "pytest tests/"
      via: "matrix strategy on python-version 3.8 and 3.11"
      pattern: "python-version.*3\\.8.*3\\.11"
    - from: ".github/workflows/ci.yml lint job"
      to: "ruff check . && mypy"
      via: "separate job on Python 3.11 (mypy 1.20 requires Python 3.10+)"
      pattern: "ruff check"
    - from: ".github/workflows/ci.yml addon-check job"
      to: "xbmc/action-kodi-addon-checker@v1.2"
      via: "kodi-version: nexus, addon-id: plugin.audio.subsonic"
      pattern: "action-kodi-addon-checker"
---

<objective>
Create .github/workflows/ci.yml with three jobs that run on every push and pull_request to master: pytest matrix (Python 3.8 + 3.11), ruff + mypy lint, and kodi-addon-checker.

Purpose: Without CI, regressions are caught only by manual testing. This workflow gates every future change and is the primary evidence for TEST-08, TEST-09, TEST-10.

Output: .github/workflows/ci.yml — a single workflow file with three jobs.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/ROADMAP.md
@.planning/STATE.md
@.planning/research/STACK.md
</context>

<tasks>

<task type="auto">
  <name>Task 1: Create .github/workflows/ci.yml</name>
  <files>.github/workflows/ci.yml</files>
  <read_first>
    - .planning/research/STACK.md (section "GitHub Actions CI Matrix" — exact YAML structure, version notes, mypy run-on/target-for split)
    - addon.xml (confirm addon-id is plugin.audio.subsonic)
  </read_first>
  <action>
    Create the directory `.github/workflows/` and write `.github/workflows/ci.yml` with this exact content:

    ```yaml
    name: CI

    on:
      push:
        branches: [master]
      pull_request:
        branches: [master]

    jobs:
      test:
        name: pytest (Python ${{ matrix.python-version }})
        runs-on: ubuntu-latest
        strategy:
          fail-fast: false
          matrix:
            python-version: ["3.8", "3.11"]
        steps:
          - uses: actions/checkout@v4
          - uses: actions/setup-python@v5
            with:
              python-version: ${{ matrix.python-version }}
          - name: Install test dependencies
            run: pip install pytest==9.0.* Kodistubs==21.0.0
          - name: Run pytest
            run: pytest tests/ -v

      lint:
        name: Lint (ruff + mypy)
        runs-on: ubuntu-latest
        steps:
          - uses: actions/checkout@v4
          - uses: actions/setup-python@v5
            with:
              # mypy 1.20 requires Python 3.10+ to run (but targets Python 3.8 via pyproject.toml)
              python-version: "3.11"
          - name: Install lint dependencies
            run: pip install "ruff==0.15.*" "mypy==1.20.*" Kodistubs==21.0.0
          - name: ruff check
            run: ruff check .
          - name: ruff format check
            run: ruff format --check .
          - name: mypy
            run: mypy --ignore-missing-imports .

      addon-check:
        name: kodi-addon-checker
        runs-on: ubuntu-latest
        steps:
          - uses: actions/checkout@v4
          - uses: xbmc/action-kodi-addon-checker@v1.2
            with:
              kodi-version: nexus
              addon-id: plugin.audio.subsonic
    ```

    **Key decisions documented inline:**
    - `fail-fast: false` on the matrix: both Python versions run even if one fails, giving full failure info
    - `pytest==9.0.*` pins the major version; patch updates are fine
    - lint job runs on Python 3.11: mypy 1.20 dropped support for running on Python 3.9, so we run mypy itself on 3.11 but the `python_version = "3.8"` in pyproject.toml makes it check for 3.8 compatibility
    - `kodi-version: nexus` is the minimum target (Kodi 20); xbmc/action-kodi-addon-checker@v1.2 validates addon.xml against this baseline
    - `addon-id: plugin.audio.subsonic` must match `id=` attribute in addon.xml

    Create the `.github/workflows/` directory tree first:
    - `.github/` (directory)
    - `.github/workflows/` (directory)
    - `.github/workflows/ci.yml` (file with content above)
  </action>
  <verify>
    <automated>python3 -c "
import yaml, sys
with open('.github/workflows/ci.yml') as f:
    doc = yaml.safe_load(f)
jobs = doc.get('jobs', {})
assert 'test' in jobs, 'missing test job'
assert 'lint' in jobs, 'missing lint job'
assert 'addon-check' in jobs, 'missing addon-check job'
matrix = jobs['test']['strategy']['matrix']['python-version']
assert '3.8' in matrix and '3.11' in matrix, 'missing Python versions'
print('PASS: ci.yml valid')
" 2>/dev/null || (grep -q 'python-version' /home/sandwich/Develop/plugin.audio.subsonic/.github/workflows/ci.yml && grep -q 'action-kodi-addon-checker' /home/sandwich/Develop/plugin.audio.subsonic/.github/workflows/ci.yml && echo "PASS: key fields present")</automated>
  </verify>
  <acceptance_criteria>
    - `.github/workflows/ci.yml` exists
    - `grep -q 'python-version: \["3.8", "3.11"\]' .github/workflows/ci.yml`
    - `grep -q 'action-kodi-addon-checker@v1.2' .github/workflows/ci.yml`
    - `grep -q 'ruff check' .github/workflows/ci.yml`
    - `grep -q 'mypy' .github/workflows/ci.yml`
    - `grep -q 'Kodistubs==21.0.0' .github/workflows/ci.yml`
    - File is valid YAML (no tabs, correct indentation)
  </acceptance_criteria>
  <done>.github/workflows/ci.yml exists with test (3.8+3.11 matrix), lint (ruff+mypy on 3.11), and addon-check jobs.</done>
</task>

</tasks>

<verification>
```bash
# File exists
ls -la .github/workflows/ci.yml

# Required fields present
grep -q 'python-version: \["3.8", "3.11"\]' .github/workflows/ci.yml && echo "matrix OK"
grep -q 'action-kodi-addon-checker@v1.2' .github/workflows/ci.yml && echo "addon-check OK"
grep -q 'ruff check' .github/workflows/ci.yml && echo "ruff OK"
grep -q 'mypy' .github/workflows/ci.yml && echo "mypy OK"
```
</verification>

<success_criteria>
1. `.github/workflows/ci.yml` exists
2. Test job has matrix with "3.8" and "3.11"
3. Lint job runs ruff check and mypy
4. addon-check job uses xbmc/action-kodi-addon-checker@v1.2 with kodi-version: nexus
5. File is syntactically valid YAML
</success_criteria>

<output>
After completion, create `.planning/phases/01-foundation/01-foundation-04-SUMMARY.md`
</output>
