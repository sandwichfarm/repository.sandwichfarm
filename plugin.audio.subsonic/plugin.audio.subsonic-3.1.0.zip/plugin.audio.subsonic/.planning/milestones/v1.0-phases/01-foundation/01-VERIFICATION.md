---
phase: 01-foundation
verified: 2026-04-28T00:00:00Z
status: human_needed
score: 14/15 must-haves verified (1 requires live CI run)
human_verification:
  - test: "Push to master and observe the GitHub Actions CI run"
    expected: "All three jobs pass: pytest on Python 3.8 AND 3.11, ruff+mypy lint, kodi-addon-checker"
    why_human: "CI matrix correctness (both Python versions passing) can only be confirmed by an actual GitHub Actions run. Local venv runs Python 3.14 — not 3.8 or 3.11."
---

# Phase 01: Foundation Verification Report

**Phase Goal:** The addon loads without crashing on Kodi 20 and 21; CI runs tests and lint on every push.
**Verified:** 2026-04-28
**Status:** human_needed
**Re-verification:** No — initial verification

---

## Phase Goal

Success criteria from ROADMAP.md:
1. `service.py` starts without error on Kodi 20 and 21 — scrobbling is no longer silently dead for all users
2. A user with `useGET=True` can star or update playlists without hitting a `NameError` on `urllib2`
3. `xbmc.translatePath` is gone from all code paths; `xbmcvfs.translatePath` is called unconditionally
4. `pytest` runs on Python 3.8 and 3.11 in GitHub Actions and passes (zero or more passing tests)
5. `ruff check`, `mypy`, and `kodi-addon-checker` all pass in CI on every push

---

## Must-Haves Checked

### Plan 01 — Crash Fixes (BUG-01, COMPAT-03, COMPAT-04)

| # | Truth | Status | Evidence |
|---|-------|--------|----------|
| 1 | `service.py` can be imported without NameError on sys | passed | `import sys` on line 2, before `sys.path.append` on line 9; confirmed by grep and two TDD tests |
| 2 | No urllib2 references remain in `lib/libsonic/connection.py` | passed | `grep -q 'urllib2' lib/libsonic/connection.py` returns no matches; 8 occurrences of `urllib.request.Request` present |
| 3 | No `xbmc.translatePath` calls remain anywhere in the codebase | passed | `grep -rq 'xbmc\.translatePath' lib/ service.py main.py` returns no matches |

**Artifact verification:**

| Artifact | Expected content | Status | Detail |
|----------|-----------------|--------|--------|
| `service.py` | `import sys` | passed | Present on line 2; syntax valid |
| `lib/libsonic/connection.py` | `urllib.request.Request` | passed | 8 occurrences; no urllib2; syntax valid |
| `lib/simpleplugin/simpleplugin.py` | `xbmcvfs.translatePath` | passed | Line 75: `return xbmcvfs.translatePath(*args, **kwargs)`; no version guard in `translate_path`; `_kodi_major_version` retained only for `log_notice` caller at line 650 (expected per plan) |

**Key link verification:**

| From | To | Via | Status |
|------|----|-----|--------|
| `service.py` line 9 `sys.path.append` | `sys` module | `import sys` on line 2 | passed |
| `lib/libsonic/connection.py` `_getRequestWithList`/`_getRequestWithLists` | `urllib.request.Request` | `useGET` branch in each method | passed — 2 call sites fixed (lines 2848, 2875) |
| `lib/simpleplugin/simpleplugin.py` `translate_path` | `xbmcvfs.translatePath` | unconditional call, no version guard | passed |

---

### Plan 02 — Bare Excepts (BUG-02)

| # | Truth | Status | Evidence |
|---|-------|--------|----------|
| 1 | Connection errors produce a log message with traceback, not silent pass | passed | `service.py` has 2 `traceback.format_exc()` calls; `main.py` has 1 in `get_connection()` |
| 2 | `service.py` top-level settings read does not swallow all exceptions silently | passed | `grep -q 'except:$' service.py` returns no matches |
| 3 | `get_connection()` in both `main.py` and `service.py` catches specific exception types | passed | Both use `except Exception as exc:` with traceback logging |

**Artifact verification:**

| Artifact | Expected content | Status | Detail |
|----------|-----------------|--------|--------|
| `main.py` | `traceback.format_exc` | passed | Line 63 in `get_connection()`; syntax valid |
| `service.py` | `traceback.format_exc` | passed | Lines 23 and 52; `import traceback` on line 3 |

**Notes on remaining bare excepts in `main.py`:**
Lines 410, 475, 711 are the three "deferred" JSON-parsing and star-handler bare excepts the plan explicitly out-scoped to Phase 3. Line 1247 (download error handler) was also pre-existing before Phase 1 and was not mentioned in the plan's deferred list — it is outside Phase 1 scope. All four pre-date this phase per `git show e59b65d:main.py`.

---

### Plan 03 — Test Scaffold (TEST-01)

| # | Truth | Status | Evidence |
|---|-------|--------|----------|
| 1 | `pytest` can be run with no Kodi installed and tests pass | passed | 6 tests pass with venv Python (3.14); see output below |
| 2 | Importing `main` and `service` under mocks does not crash | passed | `test_import_main` and `test_import_service` both PASSED |
| 3 | `ruff` and `mypy` can read `pyproject.toml` configuration | passed | `target-version = "py38"` and `python_version = "3.8"` and `testpaths = ["tests"]` all present |

**Artifact verification:**

| Artifact | Expected content | Status | Detail |
|----------|-----------------|--------|--------|
| `pyproject.toml` | `target-version`, `python_version`, `testpaths` | passed | All three fields present with correct values |
| `tests/conftest.py` | `sys.modules["xbmc"]` injection | passed | Injects all 5 Kodi API mocks; sets `xbmc.getInfoLabel.return_value = "21.0.0"` so `_kodi_major_version()` string comparison works correctly |
| `tests/test_imports.py` | `import main` and 4 test functions | passed | 4 test functions present; all pass |

**Key link verification:**

| From | To | Via | Status |
|------|----|-----|--------|
| `tests/conftest.py` | `sys.modules["xbmc", "xbmcgui", "xbmcplugin", "xbmcaddon", "xbmcvfs"]` | MagicMock injection at module scope | passed |
| `tests/test_imports.py` | `import main`, `import service` | conftest.py loads first (pytest auto-discovery) | passed |

---

### Plan 04 — CI Workflow (TEST-08, TEST-09, TEST-10)

| # | Truth | Status | Evidence |
|---|-------|--------|----------|
| 1 | GitHub Actions runs pytest on Python 3.8 and 3.11 on every push and PR | passed (file) | `python-version: ["3.8", "3.11"]` matrix present in ci.yml |
| 2 | GitHub Actions runs `ruff check` and `mypy` on every push and PR | passed (file) | lint job with `ruff check .`, `ruff format --check .`, `mypy --ignore-missing-imports .` |
| 3 | GitHub Actions runs `kodi-addon-checker` on every push and PR | passed (file) | `addon-check` job uses `xbmc/action-kodi-addon-checker@v1.2` with `kodi-version: nexus` |
| 4 | First green CI run shows pytest passing on both Python 3.8 AND 3.11 | **human_needed** | Requires live GitHub Actions run — cannot verify locally (local venv uses Python 3.14) |

**Artifact verification:**

| Artifact | Expected content | Status | Detail |
|----------|-----------------|--------|--------|
| `.github/workflows/ci.yml` | `python-version: ["3.8", "3.11"]`, `action-kodi-addon-checker@v1.2`, `ruff check`, `mypy`, `Kodistubs==21.0.0` | passed | All 5 fields confirmed present |

**Key link verification:**

| From | To | Via | Status |
|------|----|-----|--------|
| ci.yml test job | `pytest tests/` | matrix strategy on python-version 3.8 and 3.11 | passed (file structure) |
| ci.yml lint job | `ruff check .` and `mypy` | separate job on Python 3.11 | passed (file structure) |
| ci.yml addon-check job | `xbmc/action-kodi-addon-checker@v1.2` | `kodi-version: nexus`, `addon-id: plugin.audio.subsonic` | passed (file structure) |

---

### Plan 05 — Smoke Verify (COMPAT-01, COMPAT-02)

| # | Truth | Status | Evidence |
|---|-------|--------|----------|
| 1 | pytest passes on Python 3.8 | **human_needed** | Python 3.8 not available locally; CI matrix will verify; local run uses Python 3.14 |
| 2 | pytest passes on Python 3.11 | **human_needed** | Python 3.11 not available locally; CI matrix will verify |
| 3 | No test imports crash with NameError or AttributeError | passed | All 6 tests pass on Python 3.14; conftest mocks all Kodi APIs correctly including `xbmc.getInfoLabel` return value fix |

---

## Requirements Coverage

| Requirement | Phase 1 Plan | Description | Status | Evidence |
|-------------|-------------|-------------|--------|----------|
| BUG-01 | 01-crash-fixes | `service.py` has `import sys`; scrobbling no longer crashes | satisfied | `^import sys` on line 2; before `sys.path.append` on line 9 |
| BUG-02 | 02-bare-excepts | Bare `except:` in get_connection() and service.py settings read replaced | satisfied | `service.py`: 0 bare excepts; `main.py` get_connection(): `except Exception as exc:` with traceback logging |
| COMPAT-03 | 01-crash-fixes | All `urllib2` references in libsonic replaced | satisfied | `grep 'urllib2'` returns 0 matches in connection.py |
| COMPAT-04 | 01-crash-fixes | `xbmc.translatePath` replaced by `xbmcvfs.translatePath` | satisfied | `grep -r 'xbmc\.translatePath' lib/ service.py main.py` returns 0 matches |
| COMPAT-01 | 05-smoke-verify | Plugin loads without crashing on Kodi 21 (Python 3.11) | needs_human | Structure verified locally; Python 3.11 run gates on CI |
| COMPAT-02 | 05-smoke-verify | Plugin loads without crashing on Kodi 20 (Python 3.8) | needs_human | Structure verified locally; Python 3.8 run gates on CI |
| TEST-01 | 03-test-scaffold | pytest infrastructure with Kodi API mocks | satisfied | 6 tests pass; conftest injects all 5 Kodi modules as MagicMock |
| TEST-08 | 04-ci-workflow | GitHub Actions matrix runs pytest on Python 3.8 and 3.11 | satisfied (file) | ci.yml matrix confirmed; live run is human_needed |
| TEST-09 | 04-ci-workflow | GitHub Actions runs `ruff check` and `mypy` | satisfied (file) | ci.yml lint job confirmed |
| TEST-10 | 04-ci-workflow | GitHub Actions runs `kodi-addon-checker` | satisfied (file) | ci.yml addon-check job confirmed |

All 10 Phase 1 requirement IDs are accounted for across the 5 plans. No orphaned requirements.

---

## Automated Verification Output

```
# BUG-01: sys import present
grep -q '^import sys' service.py && echo "BUG-01 PASS"
=> BUG-01 PASS

# COMPAT-03: no urllib2 in libsonic
grep -q 'urllib2' lib/libsonic/connection.py && echo "COMPAT-03 FAIL" || echo "COMPAT-03 PASS"
=> COMPAT-03 PASS

# COMPAT-04: no xbmc.translatePath anywhere
grep -rq 'xbmc\.translatePath' lib/ service.py main.py && echo "COMPAT-04 FAIL" || echo "COMPAT-04 PASS"
=> COMPAT-04 PASS

# BUG-02: no bare excepts in service.py
grep -q 'except:$' service.py && echo "FAIL" || echo "BUG-02 service.py PASS"
=> BUG-02 service.py PASS

# BUG-02: bare excepts in main.py (all pre-existing, outside Phase 1 scope)
grep -n 'except:$' main.py
=> 410:    except:   (JSON params parse — deferred to Phase 3)
=> 475:    except:   (JSON params parse — deferred to Phase 3)
=> 711:    except:   (star handler — deferred to Phase 3)
=> 1247:  except:   (download error handler — pre-existing, not mentioned in plan)

# traceback.format_exc in service.py (expected >= 2)
grep -c 'traceback.format_exc' service.py
=> 2

# traceback.format_exc in main.py get_connection (expected >= 1)
grep -c 'traceback.format_exc' main.py
=> 1

# pyproject.toml fields
grep -q 'target-version = "py38"' pyproject.toml      => OK
grep -q 'python_version = "3.8"' pyproject.toml       => OK
grep -q 'testpaths = ["tests"]' pyproject.toml        => OK

# CI workflow fields
grep -q 'python-version: ["3.8", "3.11"]' .github/workflows/ci.yml  => OK
grep -q 'action-kodi-addon-checker@v1.2' .github/workflows/ci.yml   => OK
grep -q 'ruff check' .github/workflows/ci.yml                        => OK
grep -q 'mypy' .github/workflows/ci.yml                              => OK
grep -q 'Kodistubs==21.0.0' .github/workflows/ci.yml                 => OK

# Syntax checks
python3 -c "import ast; ast.parse(open('service.py').read()); print('service.py OK')"
=> service.py OK
python3 -c "import ast; ast.parse(open('main.py').read()); print('main.py OK')"
=> main.py OK
python3 -c "import ast; ast.parse(open('lib/libsonic/connection.py').read()); print('connection.py OK')"
=> connection.py OK
python3 -c "import ast; ast.parse(open('lib/simpleplugin/simpleplugin.py').read()); print('simpleplugin.py OK')"
=> simpleplugin.py OK

# pytest run (venv Python 3.14 — proxy for 3.8/3.11 structural correctness)
.venv/bin/python -m pytest tests/ -v
=> tests/test_imports.py::test_import_main PASSED
=> tests/test_imports.py::test_import_service PASSED
=> tests/test_imports.py::test_import_libsonic PASSED
=> tests/test_imports.py::test_import_simpleplugin PASSED
=> tests/test_service_import_sys.py::test_import_sys_present PASSED
=> tests/test_service_import_sys.py::test_import_sys_before_sys_path_append PASSED
=> 6 passed in 0.03s
```

---

## Human Verification Items

### 1. CI Matrix Green Run on Python 3.8 and 3.11

**Test:** Push to master (or open a PR) and wait for the GitHub Actions CI run to complete.

**Expected:** All three jobs pass:
- `pytest (Python 3.8)` — 6 tests pass
- `pytest (Python 3.11)` — 6 tests pass
- `Lint (ruff + mypy)` — ruff check, ruff format check, mypy all pass
- `kodi-addon-checker` — addon.xml validates against kodi-version nexus

**Why human:** Local environment runs Python 3.14 (system Arch Linux). Python 3.8 and 3.11 are not installed separately. The CI matrix correctness (correct Python version availability, Kodistubs 21.0.0 installation, kodi-addon-checker action version) can only be confirmed by an actual GitHub Actions execution. All prerequisites (workflow YAML structure, pyproject.toml config, test files) are verified correct locally.

---

## Gaps

None. All automated checks pass. The only outstanding item is a live CI run to confirm the matrix executes correctly on the specified Python versions.

---

## Conclusion

Phase 01 Foundation goal is **structurally achieved**: every code fix is in place and verified, the test scaffold works, and the CI workflow is correctly specified. The three hard crashes (missing `import sys`, `urllib2` in Python 3, and `xbmc.translatePath` on Kodi 20+) are fixed. Bare excepts in the critical `get_connection()` path now log tracebacks. The pytest infrastructure passes 6 tests without Kodi installed. The CI workflow file contains all required jobs with the correct structure.

The single human-needed item is confirming a live GitHub Actions run succeeds on Python 3.8 and 3.11 — a structural verification that cannot be replicated locally without those Python versions installed.

---

_Verified: 2026-04-28_
_Verifier: Claude (gsd-verifier)_
