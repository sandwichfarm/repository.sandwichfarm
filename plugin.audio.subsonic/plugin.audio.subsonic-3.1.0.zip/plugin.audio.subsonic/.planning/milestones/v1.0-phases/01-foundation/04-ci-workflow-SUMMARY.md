---
phase: 01-foundation
plan: "04"
subsystem: infra
tags: [github-actions, pytest, ruff, mypy, kodi-addon-checker, ci, python]

# Dependency graph
requires: []
provides:
  - GitHub Actions CI pipeline with three jobs: pytest matrix (3.8+3.11), ruff+mypy lint, kodi-addon-checker
  - CI runs on push and pull_request to master branch
  - .github/workflows/ci.yml
affects:
  - All future phases (every push gated by CI from this point)

# Tech tracking
tech-stack:
  added:
    - "GitHub Actions (ubuntu-latest)"
    - "pytest==9.0.* (CI only)"
    - "Kodistubs==21.0.0 (CI only)"
    - "ruff==0.15.* (CI only)"
    - "mypy==1.20.* (CI only)"
    - "xbmc/action-kodi-addon-checker@v1.2"
  patterns:
    - "matrix strategy with fail-fast: false for full cross-version visibility"
    - "mypy run-on/target-for split: runs on Python 3.11, targets Python 3.8 via pyproject.toml"

key-files:
  created:
    - .github/workflows/ci.yml
  modified: []

key-decisions:
  - "fail-fast: false on pytest matrix — both Python 3.8 and 3.11 always run so failures on either version are always visible"
  - "lint job runs on Python 3.11 — mypy 1.20 dropped support for running on Python 3.9; pyproject.toml sets python_version=3.8 so mypy checks for 3.8 compatibility"
  - "kodi-version: nexus — minimum supported Kodi target (20); kodi-addon-checker validates addon.xml against this baseline"
  - "Kodistubs==21.0.0 installed in both test and lint jobs — provides Kodi API type stubs for pytest and mypy"

patterns-established:
  - "CI-first: every future change is gated by pytest (3.8+3.11), ruff, mypy, and kodi-addon-checker"

requirements-completed: [TEST-08, TEST-09, TEST-10]

# Metrics
duration: 1min
completed: "2026-04-28"
---

# Phase 01 Plan 04: CI Workflow Summary

**GitHub Actions CI pipeline with three jobs: pytest matrix on Python 3.8+3.11, ruff+mypy lint on 3.11, and kodi-addon-checker@v1.2 with kodi-version nexus**

## Performance

- **Duration:** ~1 min
- **Started:** 2026-04-28T14:42:20Z
- **Completed:** 2026-04-28T14:42:58Z
- **Tasks:** 1 completed
- **Files modified:** 1

## Accomplishments

- Created `.github/workflows/ci.yml` with three CI jobs triggered on push and pull_request to master
- Test job uses matrix strategy (Python 3.8 + 3.11) with fail-fast disabled for full failure visibility
- Lint job runs ruff check, ruff format check, and mypy on Python 3.11 (mypy 1.20 run-on/target-for split)
- addon-check job validates addon.xml against Kodi Nexus baseline using xbmc/action-kodi-addon-checker@v1.2

## Task Commits

1. **Task 1: Create .github/workflows/ci.yml** - `ff00a4b` (feat)

**Plan metadata:** `fe0ea0b` (docs)

## Files Created/Modified

- `.github/workflows/ci.yml` — Three-job CI pipeline: pytest matrix, ruff+mypy lint, kodi-addon-checker

## Decisions Made

- `fail-fast: false` on the pytest matrix: both Python versions run even if one fails, giving full failure info on both 3.8 and 3.11 simultaneously
- Lint job runs on Python 3.11 because mypy 1.20 dropped support for running on Python 3.9; the `python_version = "3.8"` setting in pyproject.toml makes it check for 3.8 compatibility (run-on/target-for split)
- `kodi-version: nexus` is the minimum target (Kodi 20); validates addon.xml against this baseline
- `addon-id: plugin.audio.subsonic` confirmed from addon.xml `id=` attribute

## Deviations from Plan

None — plan executed exactly as written.

## Issues Encountered

None.

## User Setup Required

None — no external service configuration required. GitHub Actions will pick up `.github/workflows/ci.yml` automatically on the next push.

## Next Phase Readiness

- CI pipeline is in place; every future push and PR will be gated by pytest (3.8+3.11), ruff, mypy, and kodi-addon-checker
- Tests directory (`tests/`) must exist with at least one test for the pytest job to pass (Phase 01 plans 01-03 scaffold the test infrastructure)

---
*Phase: 01-foundation*
*Completed: 2026-04-28*
