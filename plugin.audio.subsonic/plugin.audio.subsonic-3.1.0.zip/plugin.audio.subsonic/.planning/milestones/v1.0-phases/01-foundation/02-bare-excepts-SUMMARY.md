---
phase: 01-foundation
plan: "02"
subsystem: error-handling
tags: [python, kodi, exception-handling, traceback, logging, service]

# Dependency graph
requires:
  - phase: 01-foundation/01-crash-fixes
    provides: import sys in service.py and main.py — prerequisite for files to be importable
provides:
  - get_connection() in main.py uses except Exception as exc with xbmc.log(traceback.format_exc())
  - get_connection() in service.py uses except Exception as exc with xbmc.log(traceback.format_exc())
  - scrobbleEnabled settings read in service.py uses except Exception as exc with traceback logging
affects: [01-foundation, auth-migration, debugging, ci]

# Tech tracking
tech-stack:
  added: [traceback (stdlib — import added to service.py and main.py), xbmc (explicit import added to main.py)]
  patterns: [except Exception as exc with traceback.format_exc() at xbmc.LOGERROR for all connection/settings error sites]

key-files:
  created: []
  modified:
    - service.py
    - main.py

key-decisions:
  - "Use except Exception as exc (not bare except:) — catches all real errors while still allowing KeyboardInterrupt and SystemExit to propagate"
  - "Log traceback.format_exc() at xbmc.LOGERROR so full stack trace appears in kodi.log for every connection failure"
  - "Three bare excepts in main.py at lines 410, 475, 711, 1247 left untouched — JSON/params parsing fallbacks deferred to Phase 3 per plan scope"
  - "Added explicit import xbmc to main.py — previously relied on Kodi runtime providing xbmc in scope, explicit import is correct"

patterns-established:
  - "Connection error logging: except Exception as exc: xbmc.log('Subsonic: <context>: %s' % traceback.format_exc(), xbmc.LOGERROR)"
  - "Settings read fallback: except Exception as exc with log then fall back to safe default"

requirements-completed: [BUG-02]

# Metrics
duration: 5min
completed: 2026-04-28
---

# Phase 01 Plan 02: Bare Excepts Summary

**Replaced silent bare except: pass in get_connection() and service.py settings read with except Exception as exc plus traceback.format_exc() logging at xbmc.LOGERROR**

## Performance

- **Duration:** ~5 min
- **Started:** 2026-04-28T14:47:00Z
- **Completed:** 2026-04-28T14:48:17Z
- **Tasks:** 2
- **Files modified:** 2

## Accomplishments

- service.py: two bare `except:` blocks replaced — scrobbleEnabled read and get_connection() connection init
- main.py: one bare `except: pass` in get_connection() replaced with targeted handler and traceback logging
- Explicit `import xbmc` and `import traceback` added to both files for clarity and correctness
- All 6 existing tests continue to pass after changes

## Task Commits

Each task was committed atomically:

1. **Task 1: Fix bare except in service.py** - `8c2729e` (fix)
2. **Task 2: Fix bare except in main.py get_connection()** - `a6b07e2` (fix)

**Plan metadata:** (docs commit follows)

## Files Created/Modified

- `service.py` - Added `import traceback`; replaced bare `except:` at SITE 1 (scrobbleEnabled) and SITE 2 (get_connection) with `except Exception as exc:` + xbmc.log(traceback.format_exc())
- `main.py` - Added `import traceback` and `import xbmc`; replaced bare `except:` at SITE 3 (get_connection) with `except Exception as exc:` + xbmc.log(traceback.format_exc())

## Decisions Made

- Used `except Exception as exc` rather than a narrower type because connection failures can come from libsonic (network errors, HTTP errors, Subsonic error responses) and from xbmcaddon settings reads — a single catch-all with logging is the correct last-resort at this level
- Three remaining bare excepts in main.py (lines 410, 475, 711, 1247) are JSON/params parsing fallbacks — left untouched per plan scope (Phase 3)
- Added explicit `import xbmc` to main.py — the file uses `xbmc.log()` and `xbmc.executebuiltin()` and previously depended on xbmc being available via Kodi's runtime environment; explicit import is correct and matches service.py

## Deviations from Plan

### Auto-fixed Issues

**1. [Rule 2 - Missing Critical] Added explicit `import xbmc` to main.py**
- **Found during:** Task 2 (Fix bare except in main.py get_connection)
- **Issue:** Plan specified adding `xbmc.log(traceback.format_exc(), xbmc.LOGERROR)` to main.py, but main.py had no explicit `import xbmc`. The file relied on xbmc being implicitly available via Kodi's runtime. Explicit import is required for correctness and test clarity.
- **Fix:** Added `import xbmc` alongside `import traceback` in the stdlib imports block
- **Files modified:** main.py
- **Verification:** All 6 tests pass; python3 AST parse succeeds; xbmc.LOGERROR and xbmc.log references resolve correctly
- **Committed in:** a6b07e2 (Task 2 commit)

---

**Total deviations:** 1 auto-fixed (missing critical import)
**Impact on plan:** Necessary for correctness — xbmc must be explicitly imported when used. No scope creep.

## Issues Encountered

None — plan executed cleanly. Line numbers shifted by +2 in main.py after adding two import lines (407→410, 472→475, 708→711, 1244→1247) but deferred excepts remain untouched.

## User Setup Required

None - no external service configuration required.

## Next Phase Readiness

- Both critical get_connection() sites now log full tracebacks — auth failures, network errors, and import errors during refactor will all produce diagnostics in kodi.log
- Remaining bare excepts in main.py at lines 410, 475, 711, 1247 are lower-risk JSON/params fallbacks; addressed in Phase 3
- No blockers for subsequent plans

---
*Phase: 01-foundation*
*Completed: 2026-04-28*
