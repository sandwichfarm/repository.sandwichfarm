---
phase: 01-foundation
plan: "03"
subsystem: testing
tags: [pytest, unittest.mock, kodi-mocks, conftest, pyproject.toml, ruff, mypy]

requires: []
provides:
  - pytest infrastructure with pyproject.toml (ruff, mypy, pytest config)
  - tests/conftest.py: sys.modules injection for all 5 Kodi API modules before addon import
  - tests/test_imports.py: 4 smoke tests verifying main.py, service.py, libsonic, simpleplugin import cleanly
  - Virtual environment at .venv/ with pytest 9.0.3 installed
affects: [all future test phases, CI configuration]

tech-stack:
  added: [pytest 9.0.3, .venv virtual environment]
  patterns:
    - "Kodi API mocking: sys.modules injection with MagicMock before any addon import"
    - "xbmc.getInfoLabel must return real string for simpleplugin._kodi_major_version() Py3 compat"
    - "get_setting must return '0' not '' to avoid ValueError in int() conversion at module level"

key-files:
  created:
    - pyproject.toml
    - tests/__init__.py
    - tests/conftest.py
    - tests/test_imports.py
  modified:
    - main.py (added missing import sys — Rule 1 bug fix)
    - .gitignore (added .venv/, __pycache__/, cache dirs)

key-decisions:
  - "xbmc.getInfoLabel.return_value must be a real version string ('21.0.0') — MagicMock fails Py3 string comparison in simpleplugin._kodi_major_version()"
  - "get_setting mock returns '0' not '' — main.py module-level int(get_setting('cachetime')) requires parseable integer string"
  - "Virtual environment at .venv/ with pytest 9.0.3 — system Python 3.14 on Arch blocks pip --user; venv is the correct approach per CLAUDE.md"

patterns-established:
  - "conftest.py mock pattern: inject all 5 Kodi modules as MagicMock at module scope, then fine-tune specific return values that cause type errors or ValueError in Py3"
  - "All tests run via: .venv/bin/pytest tests/"

requirements-completed: [TEST-01]

duration: 5min
completed: 2026-04-28
---

# Phase 01 Plan 03: Test Scaffold Summary

**pytest infrastructure with pyproject.toml (ruff/mypy/pytest config), Kodi API MagicMock injection in conftest.py, and 4 passing smoke tests for main, service, libsonic, and simpleplugin imports**

## Performance

- **Duration:** ~5 min
- **Started:** 2026-04-28T14:41:29Z
- **Completed:** 2026-04-28T14:44:52Z
- **Tasks:** 2
- **Files modified:** 6

## Accomplishments
- Created `pyproject.toml` with ruff (target py38), mypy (python_version 3.8), and pytest (testpaths=tests) configuration
- Created `tests/conftest.py` injecting MagicMock for all 5 Kodi modules (xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs) with fine-tuned return values that prevent Py3 TypeError and ValueError
- Created `tests/test_imports.py` with 4 smoke tests that all pass (main, service, libsonic, simpleplugin)
- Installed pytest 9.0.3 in `.venv/` virtual environment

## Task Commits

1. **Task 1: Create pyproject.toml** - `aeb1913` (chore)
2. **Task 2 RED: Failing smoke tests** - `d082f0c` (test)
3. **Task 2 GREEN: conftest.py + main.py sys fix** - `15ad322` (feat)

**Plan metadata:** (docs commit follows)

_Note: TDD task had separate RED (failing test commit) then GREEN (implementation commit)_

## Files Created/Modified
- `pyproject.toml` — ruff target py38, mypy python_version 3.8, pytest testpaths config
- `tests/__init__.py` — empty package marker
- `tests/conftest.py` — MagicMock injection for 5 Kodi modules; fine-tuned return values for getInfoLabel, translatePath, getAddonInfo, get_setting
- `tests/test_imports.py` — 4 smoke tests (test_import_main, test_import_service, test_import_libsonic, test_import_simpleplugin)
- `main.py` — added missing `import sys` (Rule 1 bug fix)
- `.gitignore` — added .venv/, __pycache__/, .pytest_cache/, .mypy_cache/, .ruff_cache/

## Decisions Made
- `xbmc.getInfoLabel.return_value` must return a real version string `"21.0.0"` — simpleplugin calls `.split(' ')[0]` and then does `< '19'` comparison, which raises TypeError in Python 3 if the value is a MagicMock object.
- `get_setting` and `getSetting` mocks return `"0"` (not `""`) — `main.py` at module level calls `int(Addon().get_setting('cachetime'))` which raises `ValueError` on empty string.
- Virtual environment at `.venv/` for pytest — Arch Linux system Python (3.14) blocks pip `--user` installs; `python3 -m venv` is the correct non-root approach per CLAUDE.md.

## Deviations from Plan

### Auto-fixed Issues

**1. [Rule 1 - Bug] Added missing `import sys` to main.py**
- **Found during:** Task 2 (conftest.py + smoke tests)
- **Issue:** `main.py` line 19 calls `sys.path.append(...)` but never imports `sys`, causing `NameError: name 'sys' is not defined` when imported under test mocks.
- **Fix:** Added `import sys` as the first import in `main.py`.
- **Files modified:** `main.py`
- **Verification:** `import main` under mocks no longer raises NameError; all 4 smoke tests pass.
- **Committed in:** `15ad322` (Task 2 GREEN commit)

**2. [Rule 2 - Missing Critical] Added `xbmc.getInfoLabel` mock return value**
- **Found during:** Task 2 (smoke tests — conftest.py implementation)
- **Issue:** The plan's conftest.py template did not include a mock for `xbmc.getInfoLabel`. `simpleplugin._kodi_major_version()` calls `xbmc.getInfoLabel('System.BuildVersion').split(' ')[0]` and then compares the result with `< '19'`. When the return value is a MagicMock, Python 3 raises `TypeError: '<' not supported between instances of 'MagicMock' and 'str'`.
- **Fix:** Added `sys.modules["xbmc"].getInfoLabel.return_value = "21.0.0"` to conftest.py.
- **Files modified:** `tests/conftest.py`
- **Verification:** `Plugin()` constructor no longer raises TypeError; all 4 smoke tests pass.
- **Committed in:** `15ad322` (Task 2 GREEN commit)

**3. [Rule 2 - Missing Critical] Changed `get_setting` mock return value from `""` to `"0"`**
- **Found during:** Task 2 (smoke tests — conftest.py implementation)
- **Issue:** The plan's conftest.py template set `getSetting.return_value = ""`. However, `main.py` module-level code calls `int(Addon().get_setting('cachetime'))`, which raises `ValueError: invalid literal for int() with base 10: ''` on an empty string.
- **Fix:** Changed both `getSetting.return_value` and `get_setting.return_value` to `"0"` in conftest.py, which is a safe parseable default for numeric settings.
- **Files modified:** `tests/conftest.py`
- **Verification:** `int(Addon().get_setting('cachetime'))` evaluates to `0` without error; all 4 smoke tests pass.
- **Committed in:** `15ad322` (Task 2 GREEN commit)

---

**Total deviations:** 3 auto-fixed (1 Rule 1 bug, 2 Rule 2 missing critical)
**Impact on plan:** All auto-fixes were necessary for smoke tests to pass. No scope creep — all fixes directly enable the plan's goal of importable addon modules under mocks.

## Issues Encountered
- System Python 3.14 on Arch Linux blocks `pip install --user` (PEP 668 externally managed environment). Created `.venv/` virtual environment as the correct solution per CLAUDE.md directive to use environments.
- pytest was not pre-installed; required venv setup before tests could run.

## Known Stubs
None — no stub patterns introduced. All mock return values are explicit and functional.

## Next Phase Readiness
- pytest infrastructure is in place; all future test plans can use `.venv/bin/pytest tests/`
- conftest.py Kodi mock pattern is established; future tests inherit these mocks automatically
- pyproject.toml provides ruff/mypy config; linting can be run against the codebase
- The missing `import sys` in `main.py` is now fixed; service.py already had it

## Self-Check: PASSED

- FOUND: pyproject.toml
- FOUND: tests/conftest.py
- FOUND: tests/test_imports.py
- FOUND: tests/__init__.py
- FOUND commit: aeb1913 (pyproject.toml)
- FOUND commit: d082f0c (failing smoke tests)
- FOUND commit: 15ad322 (conftest + main.py fix)

---
*Phase: 01-foundation*
*Completed: 2026-04-28*
