# Phase 1: Foundation - Context

**Gathered:** 2026-04-28
**Status:** Ready for planning
**Mode:** Auto-generated (infrastructure-only phase — discuss skipped)

<domain>
## Phase Boundary

Phase 1 delivers a Kodi addon that loads without crashing on Kodi 20 (Nexus, Python 3.8) and Kodi 21 (Omega, Python 3.11), plus a `pytest` test infrastructure that runs in GitHub Actions on every push. The phase covers the three known crash bugs (`service.py` missing `import sys`, `urllib2` references in vendored `libsonic`, `xbmc.translatePath` removed in Kodi 20), the most dangerous bare `except:` blocks (in `get_connection()` and `service.py`), and the CI scaffolding (Kodistubs-based pytest, ruff, mypy, kodi-addon-checker).

Out of scope for this phase: any structural refactor of `main.py`, any new features, the community PR merges (Phase 2), and the deeper auth or pagination rework (Phases 3–5).

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion
All implementation choices for this phase are at Claude's discretion — pure infrastructure work. Use ROADMAP phase goal, success criteria, requirements (COMPAT-01..04, BUG-01..02, TEST-01, TEST-08..10), `.planning/research/STACK.md`, `.planning/research/PITFALLS.md`, and existing codebase conventions to guide decisions.

Pinned upstream choices already locked by research and PROJECT.md:
- **Test mocks:** Kodistubs 21.0.0 + `unittest.mock.MagicMock` injected into `sys.modules` via `conftest.py`
- **Linter/formatter:** `ruff` with `target-version = "py38"`
- **Type checker:** `mypy 1.20.x` run on Python 3.10+, target Python 3.8
- **CI matrix:** GitHub Actions, Python 3.8 and 3.11
- **Addon-check:** `xbmc/action-kodi-addon-checker@v1.2` (advisory)
- **Crash fixes:** add `import sys` to `service.py`; replace `urllib2` references in `lib/libsonic/connection.py`; replace any `xbmc.translatePath` with `xbmcvfs.translatePath`
- **Bare except scope:** address only the most dangerous sites in this phase (e.g. `get_connection()`, `service.py` monitor loop). The full sweep is BUG-02 territory but Phase 3 will revisit during refactor
- **Settings preservation:** every existing `id=` in `resources/settings.xml` must remain unchanged (COMPAT-06 — Phase 3 concern but easy to start respecting now)

</decisions>

<code_context>
## Existing Code Insights

### Reusable Assets

- `.planning/codebase/STACK.md` — current Python 3 + Kodi addon stack (no third-party runtime deps)
- `.planning/codebase/ARCHITECTURE.md` — current monolith structure; Phase 1 does NOT change it, only patches the live bugs
- `.planning/codebase/CONCERNS.md` — line-referenced inventory of crash sites, bare excepts, urllib2 references
- `.planning/research/STACK.md` — locked tooling choices for tests + CI

### Established Patterns

- Vendored libraries live under `lib/` (`lib/libsonic/`, `lib/simpleplugin/`)
- Plugin entry points are top-level `main.py` (plugin) and `service.py` (background scrobbler)
- Settings come via `xbmcaddon.Addon().getSetting('id')` — preserve all `id=` attributes
- Logging via `xbmc.log()` with severity levels — no logging framework

### Integration Points

- New CI lives under `.github/workflows/` (does not exist yet)
- New test infrastructure lives under `tests/` (does not exist yet) and `pyproject.toml` (does not exist yet)
- `conftest.py` at the repo root injects Kodi API mocks into `sys.modules`
- `addon.xml` line `<import addon="xbmc.python" version="3.0.0"/>` already covers Nexus + Omega — no change needed

</code_context>

<specifics>
## Specific Ideas

- The `import sys` fix in `service.py` is one line — but verify there are no other missing top-level imports in the same file
- For `urllib2` removal in `lib/libsonic/connection.py`: the only legitimate Py3 fix is `import urllib.request as urllib2`-style aliasing OR a real port to `urllib.request` / `http.client`. Real port preferred; aliasing is a band-aid.
- `xbmc.translatePath` may appear in vendored `lib/simpleplugin/simpleplugin.py` (version-guarded). Phase 1 should drop the version guard and use `xbmcvfs.translatePath` unconditionally — we target Kodi 20+ only, so the legacy path is unreachable.
- CI workflow file `.github/workflows/ci.yml` should run on `push` and `pull_request` to `master`, with separate jobs for: pytest matrix, ruff, mypy, kodi-addon-checker.
- `pyproject.toml` should configure ruff (`target-version = "py38"`), mypy (`python_version = "3.8"`, `mypy_path` pointing to test stubs if needed), and pytest (`testpaths = ["tests"]`).
- Smoke test at minimum: a single test that imports `main` and `service` under the mocked `sys.modules`, asserts they don't crash on import.

</specifics>

<deferred>
## Deferred Ideas

- Full bare-except sweep across all of `main.py` — happens in Phase 3 alongside the refactor
- All 8 inline `# TO FIX` resolutions — Phase 3
- Pagination correctness — Phase 3 (PERF-03 / BUG-04)
- Replacing `setInfo('music', ...)` with `InfoTagMusic` — Phase 3 (COMPAT-05)
- Settings facade typing — Phase 3 (ARCH-06)
- Auth modernization — Phase 4
- Any new feature surface — Phase 5
- ReplayGain / lyrics empirical testing — Phase 6 (deferred to v2)

</deferred>
