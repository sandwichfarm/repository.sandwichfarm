---
phase: 01-foundation
plan: 01
subsystem: compatibility
tags: [python3, urllib, kodi, xbmcvfs, service]

# Dependency graph
requires: []
provides:
  - service.py imports sys correctly — scrobble service no longer crashes on startup
  - libsonic _getRequestWithList/_getRequestWithLists use urllib.request.Request — useGET mode works on Python 3
  - simpleplugin translate_path calls xbmcvfs.translatePath unconditionally — no wrong-branch on Kodi 20+
affects: [02-community-prs, 03-refactor, 04-auth, 05-features, 06-polish]

# Tech tracking
tech-stack:
  added: [pytest (dev, venv at /tmp/subsonic-venv)]
  patterns:
    - TDD with source-text grep tests for import ordering (avoids needing Kodi runtime in CI)
    - Surgical single-line fixes — no structural changes to any file

key-files:
  created:
    - tests/test_service_import_sys.py
  modified:
    - service.py
    - lib/libsonic/connection.py
    - lib/simpleplugin/simpleplugin.py

key-decisions:
  - "Keep _kodi_major_version() helper in simpleplugin — still used by log_notice at line 652; only translate_path was simplified"
  - "Remove xbmc.translatePath mention from comment in translate_path to ensure grep-based acceptance check passes cleanly"

patterns-established:
  - "Tests live in tests/ directory; use source-text inspection when Kodi runtime is unavailable"

requirements-completed: [BUG-01, COMPAT-03, COMPAT-04]

# Metrics
duration: 7min
completed: 2026-04-28
---

# Phase 01 Plan 01: Crash Fixes Summary

**Three surgical Python 3 / Kodi 20+ crash fixes: `import sys` in service.py, `urllib.request.Request` replacing `urllib2` in libsonic, and unconditional `xbmcvfs.translatePath` in simpleplugin**

## Performance

- **Duration:** 7 min
- **Started:** 2026-04-28T14:42:17Z
- **Completed:** 2026-04-28T14:44:16Z
- **Tasks:** 3 (+ TDD test commit for Task 1)
- **Files modified:** 3 source files, 1 test file created

## Accomplishments

- Fixed `NameError: name 'sys' is not defined` crash that killed scrobbling on every Kodi install (BUG-01)
- Fixed `NameError: name 'urllib2' is not defined` crash that killed all `useGET=True` star/playlist operations (COMPAT-03)
- Eliminated fragile string version comparison (`'20' < '19'` is `False`) that caused wrong-branch selection in `translate_path`, which could call the removed `xbmc.translatePath` on Kodi 20+ (COMPAT-04)
- Created first test infrastructure for the project (`tests/` directory, pytest via venv)

## Task Commits

Each task was committed atomically:

1. **Task 1: Add missing import sys to service.py** — TDD
   - `79b1238` test(01-01): add failing test for import sys (RED phase)
   - `c7bb114` feat(01-01): add missing import sys to service.py (GREEN phase)

2. **Task 2: Replace urllib2.Request in libsonic** — `4ca26eb` fix(01-01)

3. **Task 3: Drop xbmc.translatePath version guard in simpleplugin** — `a1bcc9d` fix(01-01)

## Files Created/Modified

- `service.py` — Added `import sys` on line 2 (between `import re` and `import xbmc`)
- `lib/libsonic/connection.py` — Replaced `urllib2.Request(url)` with `urllib.request.Request(url)` at lines 2848 and 2875
- `lib/simpleplugin/simpleplugin.py` — `translate_path` now calls `xbmcvfs.translatePath` unconditionally; removed 3-line version guard
- `tests/test_service_import_sys.py` — Two tests: `test_import_sys_present` and `test_import_sys_before_sys_path_append`

## Decisions Made

- **Keep `_kodi_major_version` helper:** It has a second caller at line 652 (`log_notice`, which uses it to choose between `LOGNOTICE` and `LOGINFO`). Only `translate_path` was simplified; the helper function was preserved.
- **Comment wording in translate_path:** Rewrote the comment to avoid mentioning `xbmc.translatePath` by name, ensuring `grep -rn 'xbmc\.translatePath'` acceptance checks pass cleanly with zero hits.

## Deviations from Plan

None — plan executed exactly as written. The `_kodi_major_version` retention was anticipated in the plan's action block ("If it has other callers, only simplify `translate_path` and leave `_kodi_major_version` in place").

## Issues Encountered

- pytest not available system-wide due to PEP 668 restrictions on Arch Linux. Created a temporary venv at `/tmp/subsonic-venv` for test execution. Tests still run correctly; venv is ephemeral (cleaned on reboot).

## User Setup Required

None — no external service configuration required.

## Next Phase Readiness

- All three hard-crash bugs are resolved; the addon can now load on Kodi 20/21 without immediate startup failures
- `tests/` directory established for Phase 01's later test plan (plan 03)
- Phase 02 (community PRs) can proceed without these crashes masking PR behavior

---
*Phase: 01-foundation*
*Completed: 2026-04-28*
