---
phase: 01-foundation
plan: 02
type: execute
wave: 2
depends_on:
  - 01-foundation/01-crash-fixes-PLAN.md
files_modified:
  - main.py
  - service.py
autonomous: true
requirements:
  - BUG-02

must_haves:
  truths:
    - "Connection errors produce a log message with traceback, not silent pass"
    - "service.py top-level settings read does not swallow all exceptions silently"
    - "get_connection() in both main.py and service.py catches specific exception types"
  artifacts:
    - path: "main.py"
      provides: "get_connection() with targeted exception handling and traceback logging"
      contains: "traceback.format_exc"
    - path: "service.py"
      provides: "Settings read and monitor loop with targeted exception handling"
      contains: "traceback.format_exc"
  key_links:
    - from: "main.py get_connection() bare except"
      to: "except Exception as exc: + xbmc.log(traceback.format_exc())"
      via: "replace except: pass at line ~59"
      pattern: "traceback\\.format_exc"
    - from: "service.py top-level scrobbleEnabled read"
      to: "except Exception as exc: with xbmc.log"
      via: "replace bare except: at line ~20"
      pattern: "except Exception"
---

<objective>
Replace the most dangerous bare `except:` blocks in get_connection() (main.py) and service.py with targeted exception handling and meaningful logging.

Purpose: These bare excepts are the reason "Connection error" popups give users zero diagnostic information — every real error (wrong password, bad URL, network timeout, import failure during refactor) is silently swallowed. The get_connection() bare except is especially dangerous: it hides import errors from new modules added during the refactor, making development debugging impossible.

Scope (BUG-02 partial): Phase 1 covers only the three most dangerous sites — the two in get_connection() (main.py and service.py) and the top-level settings read in service.py. The remaining bare excepts in main.py (lines 407, 472, 708) are lower-risk JSON/params parsing fallbacks deferred to Phase 3 per CONTEXT.md.

Output: main.py and service.py with targeted exception handling at the critical sites.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/ROADMAP.md
@.planning/STATE.md
@.planning/codebase/CONCERNS.md
@.planning/research/PITFALLS.md
</context>

<interfaces>
<!-- Key patterns the executor needs. Extracted from the codebase. -->

From service.py (lines 14-55, current state after Plan 01):
```python
try:
    scrobbleEnabled = Addon().get_setting('scrobble')
except:                          # <-- SITE 1: service.py ~line 20
    scrobbleEnabled = False

def get_connection():
    global connection
    if connection==None:
        connected = False
        try:
            connection = libsonic.Connection(...)
            connected = connection.ping()
        except:                  # <-- SITE 2: service.py ~line 48
            pass
        if connected==False:
            popup('Connection error')
            return False
    return connection
```

From main.py (lines 42-65, get_connection):
```python
def get_connection():
    global connection
    if connection==None:
        connected = False
        try:
            connection = libsonic.Connection(...)
            connected = connection.ping()
        except:                  # <-- SITE 3: main.py ~line 59
            pass
        if connected==False:
            popup('Connection error')
            return False
    return connection
```

Kodi log levels: xbmc.LOGDEBUG=0, xbmc.LOGINFO=1, xbmc.LOGWARNING=2, xbmc.LOGERROR=4
</interfaces>

<tasks>

<task type="auto">
  <name>Task 1: Fix bare except in service.py — scrobbleEnabled read and get_connection()</name>
  <files>service.py</files>
  <read_first>
    - service.py (full file — both bare except sites at ~lines 18-21 and ~lines 46-49)
    - .planning/codebase/CONCERNS.md (section "Broad Exception Handling")
    - .planning/research/PITFALLS.md (Pitfall 4)
  </read_first>
  <action>
    Add `import traceback` to the imports at the top of service.py (after `import re`).

    **SITE 1 — scrobbleEnabled settings read (~line 18-21):**

    Current:
    ```python
    try:
        scrobbleEnabled = Addon().get_setting('scrobble')
    except:
        scrobbleEnabled = False
    ```

    Replace with:
    ```python
    try:
        scrobbleEnabled = Addon().get_setting('scrobble')
    except Exception as exc:
        xbmc.log("Subsonic: failed to read scrobble setting: %s" % traceback.format_exc(), xbmc.LOGERROR)
        scrobbleEnabled = False
    ```

    **SITE 2 — get_connection() connection init (~line 46-49):**

    Current:
    ```python
        try:
            connection = libsonic.Connection(
                ...
            )
            connected = connection.ping()
        except:
            pass
    ```

    Replace the bare `except: pass` with:
    ```python
        except Exception as exc:
            xbmc.log("Subsonic service: connection failed: %s" % traceback.format_exc(), xbmc.LOGERROR)
    ```

    The `if connected==False: popup('Connection error')` block that follows remains unchanged — it still handles the user-facing notification.

    Do NOT touch any other lines in service.py.
  </action>
  <verify>
    <automated>grep -c 'except:' /home/sandwich/Develop/plugin.audio.subsonic/service.py && echo "FAIL: bare excepts remain" || echo "PASS: no bare excepts"</automated>
  </verify>
  <acceptance_criteria>
    - `grep -n 'except:$' service.py` returns zero matches
    - `grep -n 'traceback.format_exc' service.py` returns at least 2 matches (one per site)
    - `grep -q 'import traceback' service.py`
    - `python3 -c "import ast; ast.parse(open('service.py').read()); print('OK')"` prints OK
  </acceptance_criteria>
  <done>service.py has no bare `except:` blocks; both sites use `except Exception as exc:` with traceback logging.</done>
</task>

<task type="auto">
  <name>Task 2: Fix bare except in main.py get_connection() (SITE 3)</name>
  <files>main.py</files>
  <read_first>
    - main.py lines 42-70 (get_connection function)
    - main.py lines 1-30 (check if traceback is already imported; check existing xbmc import)
    - .planning/codebase/CONCERNS.md (section "Broad Exception Handling")
    - .planning/research/PITFALLS.md (Pitfall 4)
  </read_first>
  <action>
    Check whether `import traceback` already exists in main.py. If not, add it with the other stdlib imports near the top of the file (after the sys.path.append block, near `import json`).

    **SITE 3 — main.py get_connection() (~line 59):**

    Current:
    ```python
        try:
            connection = libsonic.Connection(
                baseUrl=Addon().get_setting('subsonic_url'),
                username=Addon().get_setting('username', convert=False),
                password=Addon().get_setting('password', convert=False),
                port=Addon().get_setting('port'),
                apiVersion=Addon().get_setting('apiversion'),
                insecure=Addon().get_setting('insecure'),
                legacyAuth=Addon().get_setting('legacyauth'),
                useGET=Addon().get_setting('useget'),
            )
            connected = connection.ping()
        except:
            pass
    ```

    Replace the bare `except: pass` with:
    ```python
        except Exception as exc:
            xbmc.log("Subsonic: connection failed: %s" % traceback.format_exc(), xbmc.LOGERROR)
    ```

    **DO NOT touch the other bare excepts in main.py** at lines 407, 472, 708 — those are out of scope for Phase 1 (lower-risk JSON/params fallbacks, addressed in Phase 3). Only fix the get_connection() bare except.

    After editing, confirm the line count in get_connection() is the same minus one (the `pass` line is replaced by the log line).
  </action>
  <verify>
    <automated>grep -n 'except:$' /home/sandwich/Develop/plugin.audio.subsonic/main.py | grep -v -E '^(407|472|708):' && echo 'FAIL: unexpected bare excepts remain' || echo 'PASS: only deferred excepts remain'</automated>
  </verify>
  <acceptance_criteria>
    - `grep -n 'except:$' main.py` returns lines 407, 472, 708 ONLY (the deferred ones) — NOT line ~59
    - `grep -n 'traceback.format_exc' main.py` returns at least 1 match in get_connection()
    - `python3 -c "import ast; ast.parse(open('main.py').read()); print('OK')"` prints OK
  </acceptance_criteria>
  <done>main.py get_connection() bare except replaced with targeted handler and traceback logging; three other bare excepts (407, 472, 708) remain untouched as per Phase 1 scope.</done>
</task>

</tasks>

<verification>
After both tasks complete:

```bash
# No bare excepts in service.py
! grep -q 'except:$' service.py && echo "service.py PASS"

# Only the deferred excepts remain in main.py
grep -n 'except:$' main.py  # should show only 407, 472, 708

# traceback imported and used
grep -q 'import traceback' service.py && echo "service.py traceback PASS"
grep -q 'import traceback' main.py && echo "main.py traceback PASS"

# Syntax check
python3 -c "import ast; ast.parse(open('service.py').read()); print('service.py OK')"
python3 -c "import ast; ast.parse(open('main.py').read()); print('main.py OK')"
```
</verification>

<success_criteria>
1. `grep -c 'except:$' service.py` == 0
2. `grep -n 'except:$' main.py` shows lines 407, 472, 708 only (not line ~59)
3. `grep -c 'traceback.format_exc' service.py` >= 2
4. `grep -c 'traceback.format_exc' main.py` >= 1 (in get_connection)
5. Both files parse without SyntaxError
</success_criteria>

<output>
After completion, create `.planning/phases/01-foundation/01-foundation-02-SUMMARY.md`
</output>
