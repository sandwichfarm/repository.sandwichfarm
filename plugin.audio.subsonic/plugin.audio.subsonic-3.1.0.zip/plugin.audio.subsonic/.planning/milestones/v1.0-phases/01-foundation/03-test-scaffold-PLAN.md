---
phase: 01-foundation
plan: 03
type: execute
wave: 1
depends_on: []
files_modified:
  - pyproject.toml
  - tests/conftest.py
  - tests/test_imports.py
autonomous: true
requirements:
  - TEST-01

must_haves:
  truths:
    - "pytest can be run with no Kodi installed and tests pass"
    - "Importing main and service under mocks does not crash"
    - "ruff and mypy can read pyproject.toml configuration"
  artifacts:
    - path: "pyproject.toml"
      provides: "Tool configuration for ruff, mypy, pytest"
      contains: "target-version"
    - path: "tests/conftest.py"
      provides: "sys.modules injection of Kodi API mocks before any addon import"
      contains: "sys.modules"
    - path: "tests/test_imports.py"
      provides: "Smoke test: import main and service under mocks without crash"
      contains: "import main"
  key_links:
    - from: "tests/conftest.py"
      to: "sys.modules[xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs]"
      via: "MagicMock injection in module scope before any addon import"
      pattern: "sys\\.modules\\[.xbmc"
    - from: "tests/test_imports.py"
      to: "import main, import service"
      via: "conftest.py autouse fixture loads first"
      pattern: "import main"
---

<objective>
Create the pytest infrastructure: pyproject.toml, tests/conftest.py with Kodi API mocks, and a smoke test that imports main and service without crashing.

Purpose: Without this scaffolding, CI cannot run tests and local verification is manual. The conftest.py Kodi mock pattern is the foundation that every future test builds on. Tests must run with NO Kodi installed — pure Python with unittest.mock.

Output: pyproject.toml, tests/conftest.py, tests/test_imports.py. `pytest` runs and passes from the repo root.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/ROADMAP.md
@.planning/STATE.md
@.planning/research/STACK.md
</context>

<interfaces>
<!-- Key mock pattern from research/STACK.md (HIGH confidence — official Kodistubs docs) -->

```python
# tests/conftest.py — canonical Kodistubs + MagicMock pattern
from unittest.mock import MagicMock
import sys

for module_name in ("xbmc", "xbmcgui", "xbmcplugin", "xbmcaddon", "xbmcvfs"):
    sys.modules[module_name] = MagicMock()

# Fine-tune values that addon code branches on at module level:
sys.modules["xbmc"].LOGDEBUG = 0
sys.modules["xbmc"].LOGINFO = 1
sys.modules["xbmc"].LOGWARNING = 2
sys.modules["xbmc"].LOGERROR = 4
```

Addon modules access xbmcaddon.Addon().getAddonInfo('path') at import time (sys.path.append line).
The MagicMock chain means xbmcaddon.Addon() returns a MagicMock, .getAddonInfo('path') returns a MagicMock,
xbmcvfs.translatePath(MagicMock) returns a MagicMock, os.path.join(MagicMock, 'lib') works.
sys.path.append with a MagicMock string is a no-op but does not crash.

The simpleplugin.Plugin() constructor calls xbmc and xbmcaddon — all MagicMocked so it runs silently.
</interfaces>

<tasks>

<task type="auto">
  <name>Task 1: Create pyproject.toml with ruff, mypy, and pytest configuration</name>
  <files>pyproject.toml</files>
  <read_first>
    - .planning/research/STACK.md (sections "Linting and Formatting" and "GitHub Actions CI Matrix" for exact pyproject.toml content)
  </read_first>
  <action>
    Create `pyproject.toml` in the repo root with this exact content:

    ```toml
    [tool.pytest.ini_options]
    testpaths = ["tests"]
    python_files = ["test_*.py"]
    python_classes = ["Test*"]
    python_functions = ["test_*"]

    [tool.ruff]
    target-version = "py38"
    line-length = 99

    [tool.ruff.lint]
    select = [
        "E",   # pycodestyle errors
        "W",   # pycodestyle warnings
        "F",   # pyflakes
        "I",   # isort
        "UP",  # pyupgrade (flags py38-unsafe constructs)
        "B",   # flake8-bugbear
        "C4",  # flake8-comprehensions
    ]
    ignore = ["E501"]  # line length handled by formatter

    [tool.ruff.format]
    quote-style = "double"

    [tool.mypy]
    python_version = "3.8"
    ignore_missing_imports = true
    warn_unused_ignores = true
    ```

    Note: `ignore_missing_imports = true` in mypy config means mypy will not error on `import xbmc` etc. since those are stubs only present when Kodistubs is installed. This is correct for CI where mypy runs with Kodistubs installed anyway.
  </action>
  <verify>
    <automated>python3 -c "import tomllib; tomllib.loads(open('pyproject.toml').read()); print('PASS: valid TOML')" 2>/dev/null || python3 -c "import tomli; tomli.loads(open('pyproject.toml').read()); print('PASS: valid TOML')" 2>/dev/null || python3 -c "import toml; toml.load('pyproject.toml'); print('PASS: valid TOML')" 2>/dev/null || (grep -q 'target-version' pyproject.toml && grep -q 'python_version' pyproject.toml && grep -q 'testpaths' pyproject.toml && echo "PASS: key fields present")</automated>
  </verify>
  <acceptance_criteria>
    - `grep -q 'target-version = "py38"' pyproject.toml`
    - `grep -q 'python_version = "3.8"' pyproject.toml`
    - `grep -q 'testpaths = \["tests"\]' pyproject.toml`
    - File exists at repo root (not in a subdirectory)
  </acceptance_criteria>
  <done>pyproject.toml exists at repo root with ruff (target py38), mypy (python_version 3.8), and pytest (testpaths=tests) configuration.</done>
</task>

<task type="auto" tdd="true">
  <name>Task 2: Create tests/conftest.py (Kodi API mock injection) and tests/test_imports.py (smoke test)</name>
  <files>tests/conftest.py, tests/test_imports.py</files>
  <read_first>
    - .planning/research/STACK.md (section "Kodi API Mocking Pattern" — exact conftest.py pattern)
    - service.py (understand what module-level code runs on import so conftest can handle it)
    - main.py lines 1-35 (understand what module-level code runs on import)
  </read_first>
  <behavior>
    - `import main` under the mocks must not raise any exception
    - `import service` under the mocks must not raise any exception
    - Tests must pass on Python 3.8 and Python 3.11
    - No Kodi installation required
  </behavior>
  <action>
    **Step 1: Create the `tests/` directory** (it does not exist).

    **Step 2: Create `tests/__init__.py`** — empty file, makes tests/ a package.

    **Step 3: Create `tests/conftest.py`** with this exact content:

    ```python
    """
    Pytest configuration for plugin.audio.subsonic tests.

    Injects MagicMock objects into sys.modules for all Kodi API modules before
    any addon code is imported. This allows tests to run without Kodi installed.

    Pattern source: Kodistubs official docs (romanvm.github.io/Kodistubs/using.html)
    """
    from unittest.mock import MagicMock
    import sys
    import os

    # Inject Kodi API mocks before any addon import
    _KODI_MODULES = ("xbmc", "xbmcgui", "xbmcplugin", "xbmcaddon", "xbmcvfs")
    for _module_name in _KODI_MODULES:
        sys.modules[_module_name] = MagicMock()

    # Set log level constants that addon code compares against
    sys.modules["xbmc"].LOGDEBUG = 0
    sys.modules["xbmc"].LOGINFO = 1
    sys.modules["xbmc"].LOGWARNING = 2
    sys.modules["xbmc"].LOGERROR = 4

    # translatePath returns a real string so os.path.join works
    sys.modules["xbmcvfs"].translatePath.return_value = "/tmp/fake-addon-path"

    # Addon().getAddonInfo('path') returns a real string
    sys.modules["xbmcaddon"].Addon.return_value.getAddonInfo.return_value = "/tmp/fake-addon-path"

    # getSetting returns empty string by default (safe for all settings reads)
    sys.modules["xbmcaddon"].Addon.return_value.getSetting.return_value = ""
    sys.modules["xbmcaddon"].Addon.return_value.get_setting = MagicMock(return_value="")

    # Ensure the repo root and lib/ are on sys.path so imports work
    _REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _REPO_ROOT not in sys.path:
        sys.path.insert(0, _REPO_ROOT)
    _LIB_DIR = os.path.join(_REPO_ROOT, "lib")
    if _LIB_DIR not in sys.path:
        sys.path.insert(0, _LIB_DIR)
    ```

    **Step 4: Create `tests/test_imports.py`** with this content:

    ```python
    """
    Smoke tests: verify addon modules import without crashing under Kodi API mocks.

    These tests address TEST-01 (pytest infrastructure) and verify COMPAT-01/COMPAT-02
    (addon loads without crashing on Python 3.8 and 3.11).

    No Kodi installation required — conftest.py injects all Kodi API mocks.
    """


    def test_import_main():
        """main.py must import without raising any exception under mocks."""
        import main  # noqa: F401


    def test_import_service():
        """service.py must import without raising any exception under mocks."""
        import service  # noqa: F401


    def test_import_libsonic():
        """lib/libsonic/__init__.py must import without raising."""
        import libsonic  # noqa: F401


    def test_import_simpleplugin():
        """lib/simpleplugin/__init__.py must import without raising."""
        from simpleplugin import Plugin, Addon  # noqa: F401
    ```

    Note on the conftest.py `get_setting` mock: `simpleplugin.Addon` is a wrapper around
    `xbmcaddon.Addon`. The Plugin constructor calls `xbmcaddon.Addon().getAddonInfo(...)`.
    `MagicMock()` returns a MagicMock for any attribute access or call, so the chain works
    without further configuration. The explicit `.return_value` assignments just ensure
    `os.path.join` gets a real string rather than a MagicMock (which would not break pytest
    but produces cleaner output).
  </action>
  <verify>
    <automated>cd /home/sandwich/Develop/plugin.audio.subsonic && python3 -m pytest tests/test_imports.py -v 2>&1 | tail -20</automated>
  </verify>
  <acceptance_criteria>
    - `tests/conftest.py` exists and contains `sys.modules["xbmc"]`
    - `tests/test_imports.py` exists and contains `def test_import_main`
    - `pytest tests/test_imports.py` exits 0 (all tests pass)
    - `pytest tests/test_imports.py -v` shows 4 PASSED lines
    - No `ModuleNotFoundError` or `NameError` in pytest output
  </acceptance_criteria>
  <done>tests/conftest.py injects all Kodi API mocks; tests/test_imports.py has 4 passing smoke tests; pytest exits 0.</done>
</task>

</tasks>

<verification>
```bash
cd /home/sandwich/Develop/plugin.audio.subsonic

# Config fields present
grep -q 'target-version = "py38"' pyproject.toml && echo "ruff config OK"
grep -q 'python_version = "3.8"' pyproject.toml && echo "mypy config OK"
grep -q 'testpaths = \["tests"\]' pyproject.toml && echo "pytest config OK"

# Run smoke tests
python3 -m pytest tests/test_imports.py -v
```
</verification>

<success_criteria>
1. `pyproject.toml` exists with ruff, mypy, pytest sections
2. `tests/conftest.py` exists with sys.modules injection for all 5 Kodi modules
3. `tests/test_imports.py` has 4 test functions
4. `pytest tests/test_imports.py` exits 0
</success_criteria>

<output>
After completion, create `.planning/phases/01-foundation/01-foundation-03-SUMMARY.md`
</output>
