# Phase 2: Community PRs - Context

**Gathered:** 2026-04-28
**Status:** Ready for planning
**Mode:** Auto-generated (well-bounded merge phase — diffs already inspected by orchestrator)

<domain>
## Phase Boundary

Phase 2 incorporates three open community PRs from `warwickh/plugin.audio.subsonic` upstream into this hard fork. The work is bounded: read each upstream diff, apply it manually against the current codebase (which differs from upstream's master because Phase 1 modified imports + get_connection in main.py), commit each PR as its own atomic commit attributing the original author, and confirm smoke tests still pass.

Out of scope: any refactoring of touched code (Phase 3), any new features beyond what these PRs deliver, any auth changes, any settings.xml schema changes outside of PR #53's one-line addition.

</domain>

<decisions>
## Implementation Decisions

### Merge mechanics
- Apply each PR via manual `Edit`/`Write` (not `git cherry-pick` from upstream — the upstream branches aren't fetched and the diff context lines would conflict with Phase 1's main.py changes around `get_connection()`)
- Each PR becomes its own commit. Use Co-Authored-By trailers attributing the original PR authors (GioF71, stuaxo) so the contribution is preserved in git log
- Order: #53 → #54 → #49. Reasoning: #53 only touches settings.xml (no conflict surface); #54 is a 3-line surgical insert in play_track (independent); #49 is the substantive one and lands last so any conflicts with the smaller PRs are off the table

### PR #53 — m4a transcoding (stuaxo)
- One-line change to `resources/settings.xml`: append `|m4a` to the `transcode_format_streaming` values list
- Exact change: `values="mp3|raw|flv|ogg"` → `values="mp3|raw|flv|ogg|m4a"`
- File: `resources/settings.xml:16`

### PR #54 — estimateContentLength for gapless (stuaxo)
- Three-line change to `main.py`'s `play_track()` function (~line 657 in pre-Phase-1 state; verify against current state)
- Add `estimateContentLength=True` argument to the `connection.streamUrl(...)` call
- Fix the off-by-one indent in the closing paren that the PR author left (PR has `   )` with 3 spaces; we'll use 4 spaces to match surrounding code)

### PR #49 — Favorite Albums menu (GioF71)
- 4 file changes: `main.py` (3 sites), `resources/language/English/strings.po`, `resources/language/French/strings.po`, `resources/language/German/strings.po`
- Site 1: `menu_albums()` — add `'albums_favorites'` entry to the menu dict (after `random` entry)
- Site 2: `list_albums()` — add `'starred' in query_args` branch in the pagination block (different from the `'artist_id'` branch)
- Site 3: `walk_albums()` — full function rewrite to add a `starred=None` parameter; when truthy, branch to `connection.getStarred2()` instead of `getAlbumList2()`. Manual pagination on the starred list using `albums_per_page` setting
- Site 4: 3 strings.po files — add string id `#30027` "Favorite albums" / equivalent translations
- The PR uses `query_args` in list_albums — verify that variable name is correct in current code (Phase 1 didn't touch this function)
- The PR removes a `walk_albums` ltype-required guard that Phase 3 may want back; preserve the PR's choice for now (Phase 3 can revisit)

### Verification
- After each PR commit: re-run `python -m pytest tests/ -v` (must still pass — should be untouched since PRs don't break imports)
- Final smoke: import main and service under mocks (`tests/test_imports.py` already covers this)
- `# TO FIX` comments inside the diff (e.g., the `# if type(items) != type(True): TO FIX` line) are NOT removed in this phase — they remain Phase 3 territory

### Claude's Discretion
- Exact line numbers in current main.py state may differ slightly from upstream diff context. Use grep to locate anchors (`def menu_albums`, `def list_albums`, `def walk_albums`, `def play_track`) rather than line numbers
- Commit messages: `feat(02-XX): merge PR #NN — <title> (Co-authored)` style
- If any PR fails to apply cleanly due to drift, document it in the SUMMARY and apply the equivalent change manually with notes

</decisions>

<code_context>
## Existing Code Insights

### Reusable Assets
- `tests/test_imports.py` smoke tests — confirm main + service still import after each PR
- `pyproject.toml` and `tests/conftest.py` from Phase 1 — the test infra works
- `gh pr diff <N> --repo warwickh/plugin.audio.subsonic` — already used to extract all 3 diffs; orchestrator captured them in this session

### Established Patterns
- Atomic per-task commits with `--no-verify` (parallel-mode convention from Phase 1)
- Co-Authored-By trailers in commit messages

### Integration Points
- `resources/settings.xml` — `albums_per_page` setting exists and is used by PR #49's manual pagination
- `walk_albums()` is called by `list_albums()` — PR #49 modifies both
- Localized strings via `Addon().get_localized_string(NNNNN)` — string id 30027 must exist in all locale strings.po files

### Files modified (planning level, predicted)
- `resources/settings.xml` (PR #53)
- `main.py` (PR #54 + PR #49 — 3 separate sites in #49)
- `resources/language/English/strings.po`
- `resources/language/French/strings.po`
- `resources/language/German/strings.po`

</code_context>

<specifics>
## Specific Ideas

### Diff snippets the orchestrator pre-extracted

**PR #53 (settings.xml):**
```diff
-        <setting label="30011" id="transcode_format_streaming" type="labelenum"  values="mp3|raw|flv|ogg"/>
+        <setting label="30011" id="transcode_format_streaming" type="labelenum" values="mp3|raw|flv|ogg|m4a"/>
```

**PR #54 (main.py play_track):**
```diff
     url = connection.streamUrl(sid=id,
         maxBitRate=Addon().get_setting('bitrate_streaming'),
-        tformat=Addon().get_setting('transcode_format_streaming')
-    )
+        tformat=Addon().get_setting('transcode_format_streaming'),
+        estimateContentLength=True
+    )
```
(Use 4-space indent on the closing paren, not the 3-space `   )` the PR has.)

**PR #49 menu_albums entry:**
```diff
         },
+        'albums_favorites': {
+            'name':     Addon().get_localized_string(30027),
+            'thumb': None,
+            'args':     {"starred": True}
         }
```

**PR #49 list_albums pagination (replaces the `if not 'artist_id' in params` block):**
```python
if 'starred' in query_args:
    if len(items) == albums_per_page:
        link_next = navigate_next(params)
        listing.append(link_next)
else:
    if not 'artist_id' in params:
        # Pagination if we've not reached the end of the lsit
        # if type(items) != type(True): TO FIX
        link_next = navigate_next(params)
        listing.append(link_next)
```

**PR #49 walk_albums rewrite:** see full diff in CONTEXT (orchestrator captured); function signature changes from `walk_albums(ltype, size=None, ...)` to `walk_albums(ltype=None, size=None, ..., starred=None)` and gains a starred branch.

**PR #49 strings.po (English):**
```po
msgctxt "#30027"
msgid "Favorite albums"
msgstr ""
```
French/German: identical msgctxt + msgid; msgstr is empty. The original PR translates them — pull the actual translations from `gh pr diff 49`.

### Authoring credit
- PR #49: Giovanni Fulco — `Co-Authored-By: Giovanni Fulco <giovanni.fulco.web@gmail.com>` if email is in the PR commits, otherwise omit email
- PR #53, #54: Stuart Axon — `Co-Authored-By: Stuart Axon <stuaxo2@gmail.com>` if visible in commits

The planner/executor should confirm authoring info via `gh pr view <N> --repo warwickh/plugin.audio.subsonic --json commits` if attribution matters precisely.

</specifics>

<deferred>
## Deferred Ideas

- The `# if type(items) != type(True): TO FIX` comment inside PR #49's pagination diff stays as-is — Phase 3 will resolve all `# TO FIX` comments
- Any styling cleanup on the modified functions — Phase 3 (refactor)
- The fact that PR #49 calls `connection.getStarred2()` synchronously without caching — PERF-01 / PERF-02 handle that in Phase 3
- Verifying gapless playback (PR #54) actually works on a real Kodi 21 install — Phase 6
- Verifying m4a transcoding actually streams from a real Subsonic server — Phase 6

</deferred>
