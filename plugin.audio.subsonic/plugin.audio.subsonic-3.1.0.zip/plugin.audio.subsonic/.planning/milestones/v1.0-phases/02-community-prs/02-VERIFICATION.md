---
phase: 02-community-prs
verified: 2026-04-28T00:00:00Z
status: human_needed
score: 3/3 must-haves verified
human_verification:
  - test: "Browse Favorite Albums menu in Kodi and confirm starred albums from the server appear"
    expected: "Albums the user has starred on the Subsonic server are listed under Albums > Favorite Albums"
    why_human: "getStarred2() is a live Subsonic API call; requires a running server with starred albums and a connected Kodi session"
  - test: "Select m4a as transcoding format in addon settings, play a track, and verify the stream URL contains tformat=m4a"
    expected: "Stream URL passed to Kodi includes tformat=m4a (or equivalent); audio plays without error"
    why_human: "Setting is read at runtime via Addon().get_setting(); actual transcoding requires a server that supports AAC and a live playback session"
  - test: "Play a track and confirm estimateContentLength is honoured — gapless playback works across track boundaries on a Kodi build that supports it"
    expected: "No audible gap between consecutive tracks; no Kodi buffering interruption between tracks"
    why_human: "Gapless behaviour is perceptual and requires a live Kodi + server session; cannot be verified from static code analysis"
---

# Phase 2: Community PRs Verification Report

**Phase Goal:** The three community-vetted PRs from warwickh upstream are merged and working on the foundation-fixed codebase.
**Verified:** 2026-04-28
**Status:** human_needed
**Re-verification:** No — initial verification

## Goal Achievement

### Observable Truths

| # | Truth | Status | Evidence |
|---|-------|--------|----------|
| 1 | A user can browse a "Favorite Albums" menu and see their starred/favorited albums | ? HUMAN | `albums_favorites` entry at main.py:175; `walk_albums(starred=None)` at line 1514; `getStarred2()` call at line 1521; string #30027 in all 3 locale files. Runtime Kodi session needed to confirm end-to-end. |
| 2 | A user can select m4a (AAC) as a transcoding option in addon settings and streams use that format | ? HUMAN | `values="mp3|raw|flv|ogg|m4a"` confirmed in resources/settings.xml:16. `tformat=Addon().get_setting('transcode_format_streaming')` wired in play_track() at main.py:673. Live server test needed. |
| 3 | `estimateContentLength` is sent in stream requests; gapless playback works on supported Kodi builds | ? HUMAN | `estimateContentLength=True` confirmed at main.py:674, inside `connection.streamUrl()` call in `play_track()`. Gapless effect is perceptual; needs live Kodi runtime test. |

**Score:** 3/3 truths fully wired in code; all 3 route to human verification for runtime confirmation (expected for a Kodi addon at this phase — Phase 6 covers live server testing)

### Required Artifacts

| Artifact | Expected | Status | Details |
|----------|----------|--------|---------|
| `resources/settings.xml` | transcode_format_streaming with m4a option | VERIFIED | Line 16: `values="mp3|raw|flv|ogg|m4a"` — exact value per plan |
| `main.py` (play_track) | estimateContentLength=True in streamUrl call | VERIFIED | Line 674: `estimateContentLength=True` inside `connection.streamUrl()` |
| `main.py` (menu_albums) | albums_favorites menu entry | VERIFIED | Lines 175-179: entry present with `{"starred": True}` args and `get_localized_string(30027)` label |
| `main.py` (list_albums) | starred pagination branch | VERIFIED | Lines 455-464: `if 'starred' in query_args:` guards next-page link on `len(items) == albums_per_page` |
| `main.py` (walk_albums) | starred=None parameter + getStarred2 branch | VERIFIED | Line 1514 signature; lines 1520-1530 starred branch calls `connection.getStarred2()` |
| `resources/language/English/strings.po` | String #30027 = "Favorite albums" | VERIFIED | msgctxt "#30027" / msgid "Favorite albums" / msgstr "" |
| `resources/language/French/strings.po` | String #30027 = "Albums préférés" | VERIFIED | msgctxt "#30027" / msgid "Favorite albums" / msgstr "Albums préférés" |
| `resources/language/German/strings.po` | String #30027 present (untranslated) | VERIFIED | msgctxt "#30027" / msgid "Favorite Albums" / msgstr "" |

### Key Link Verification

| From | To | Via | Status | Details |
|------|----|-----|--------|---------|
| `resources/settings.xml` transcode_format_streaming | `main.py play_track()` | `Addon().get_setting('transcode_format_streaming')` passed to `streamUrl(tformat=...)` | WIRED | main.py:673 confirms the get_setting call feeds tformat= |
| `menu_albums() albums_favorites` | `list_albums()` | `query_args={"starred": True}` in URL params | WIRED | main.py:178 sets args={"starred": True}; list_albums reads query_args at line 455 |
| `list_albums()` | `walk_albums()` | `walk_albums(**query_args)` passes starred=True | WIRED | main.py:455 starred branch; walk_albums signature accepts starred=None at line 1514 |
| `walk_albums(starred=True)` | `connection.getStarred2()` | starred branch calls getStarred2() not getAlbumList2() | WIRED | main.py:1520-1521: `if starred: response = connection.getStarred2()` |
| `main.py play_track()` | `connection.streamUrl()` | estimateContentLength=True kwarg | WIRED | main.py:674 inside streamUrl call at lines 671-675 |

### Data-Flow Trace (Level 4)

| Artifact | Data Variable | Source | Produces Real Data | Status |
|----------|---------------|--------|--------------------|--------|
| walk_albums (starred branch) | `response['starred2']['album']` | `connection.getStarred2()` — live Subsonic API call | Yes (live API, not static) | FLOWING |
| play_track streamUrl | `url` from `connection.streamUrl(...)` | Live Subsonic API call with sid, bitrate, tformat, estimateContentLength | Yes (live API) | FLOWING |

### Behavioral Spot-Checks

| Behavior | Command | Result | Status |
|----------|---------|--------|--------|
| pytest smoke suite passes after all 3 PRs | `.venv/bin/pytest tests/ -v` | 6 passed in 0.02s | PASS |
| m4a present in settings.xml values | `grep -q 'mp3\|raw\|flv\|ogg\|m4a' resources/settings.xml` | exit 0 | PASS |
| estimateContentLength=True in main.py | `grep -q 'estimateContentLength=True' main.py` | exit 0 | PASS |
| albums_favorites menu entry | `grep -q 'albums_favorites' main.py` | exit 0 | PASS |
| starred=None in walk_albums signature | `grep -q 'starred=None' main.py` | exit 0 | PASS |
| getStarred2 call present | `grep -q 'getStarred2' main.py` | exit 0 | PASS |
| String #30027 in all 3 locale files | `grep -l '#30027' resources/language/*/strings.po` | 3 files matched | PASS |

### Requirements Coverage

| Requirement | Source Plan | Description | Status | Evidence |
|-------------|-------------|-------------|--------|----------|
| PR-01 | 02-03-pr49-favorites-PLAN.md | PR #49 — Favorite Albums menu (GioF71) | SATISFIED | albums_favorites entry, walk_albums starred branch, getStarred2 call, #30027 in all 3 locale files — all confirmed in code |
| PR-02 | 02-01-pr53-settings-PLAN.md | PR #53 — m4a (AAC) transcoding option (stuaxo) | SATISFIED | settings.xml:16 contains `values="mp3|raw|flv|ogg|m4a"` |
| PR-03 | 02-02-pr54-gapless-PLAN.md | PR #54 — estimateContentLength for gapless playback (stuaxo) | SATISFIED | main.py:674 `estimateContentLength=True` inside `connection.streamUrl()` in `play_track()` |

### Anti-Patterns Found

| File | Line | Pattern | Severity | Impact |
|------|------|---------|----------|--------|
| main.py | 462 | `# if type(items) != type(True): TO FIX` comment preserved | Info | Known technical debt; intentionally preserved per plan — Phase 3 scope |

No blockers. One `# TO FIX` comment was deliberately kept (documented in plan decisions).

### Human Verification Required

#### 1. Favorite Albums end-to-end browse

**Test:** Connect the addon to a Subsonic-compatible server (Navidrome recommended), star 2-3 albums on the server, then navigate Albums > Favorite Albums in Kodi.
**Expected:** The starred albums are listed with cover art and correct metadata. Pagination "Next Page" appears only when page is full; absent when all starred albums fit on one page.
**Why human:** `getStarred2()` requires a live authenticated Subsonic session. The starred pagination logic (manual in-Python slicing) can only be exercised at runtime.

#### 2. m4a transcoding format selected and used in stream URL

**Test:** Open addon settings, change Transcoding Format to "m4a", play a track, and inspect the Kodi log for the stream URL.
**Expected:** The stream URL contains `tformat=m4a` (or the Subsonic API equivalent). Audio plays without error.
**Why human:** `Addon().get_setting('transcode_format_streaming')` is a runtime Kodi addon settings read. The mapping of the enum index to the string value "m4a" requires a live Kodi session to confirm.

#### 3. Gapless playback between consecutive tracks

**Test:** Play an album from start to finish on a Kodi build that supports gapless playback (Kodi 20+). Listen across at least one track boundary.
**Expected:** No audible gap or buffering pause between tracks. Kodi log shows the stream URL includes the estimateContentLength parameter.
**Why human:** Gapless quality is a perceptual, real-time characteristic requiring a live Kodi + audio hardware session. Static code analysis cannot confirm the audio outcome.

### Gaps Summary

No gaps found. All three PR changes are present, substantive, and fully wired in the codebase:

- **PR-02 (m4a):** Single-line settings.xml change applied exactly as specified. The enum value `m4a` is appended to the streaming format list and the runtime read path in `play_track()` is confirmed wired.
- **PR-03 (estimateContentLength):** Kwarg inserted in the correct position inside `connection.streamUrl()` within `play_track()`. No stub, no orphan — it is in the live call path.
- **PR-01 (Favorite Albums):** All three main.py modification sites are present and wired in sequence (menu entry → list_albums pagination → walk_albums starred branch → getStarred2 API call). String #30027 exists in all three locale files with correct msgid/msgstr values.

The `human_needed` status reflects that Kodi addon runtime behavior (actual streaming, gapless audio, live API calls) cannot be verified from static analysis. This is expected — Phase 6 covers live server verification.

---

_Verified: 2026-04-28_
_Verifier: Claude (gsd-verifier)_
