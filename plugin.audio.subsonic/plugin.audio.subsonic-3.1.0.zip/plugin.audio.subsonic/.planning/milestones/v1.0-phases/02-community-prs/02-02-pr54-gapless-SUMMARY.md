---
phase: 02-community-prs
plan: 02
subsystem: playback
tags: [gapless, streamUrl, pr-merge, kodi, subsonic]
dependency_graph:
  requires: []
  provides: [estimateContentLength in streamUrl call]
  affects: [main.py play_track()]
tech_stack:
  added: []
  patterns: [Co-Authored-By trailer in commit]
key_files:
  created: []
  modified:
    - main.py
decisions:
  - Use 4-space indent on closing paren (matches codebase style, not 3-space from PR author)
metrics:
  duration: "<1 min"
  completed_date: "2026-04-28"
---

# Phase 02 Plan 02: PR #54 — estimateContentLength for gapless playback Summary

**One-liner:** Added `estimateContentLength=True` to `connection.streamUrl()` in `play_track()` so Kodi can pre-buffer the next track and enable gapless playback on supported builds.

## What Was Done

Applied PR #54 (stuaxo / Stuart Axon) against the current codebase. The change is a 2-line insertion inside `play_track()` in `main.py`:

- Added a trailing comma after the `tformat=...` argument
- Added `estimateContentLength=True` as a new keyword argument before the closing paren

The closing paren was left at 4-space indent to match the surrounding code style. The PR author had used 3 spaces, which was corrected.

## Commits

| Task | Description | Commit | Files |
|------|-------------|--------|-------|
| 1    | Add estimateContentLength=True to streamUrl | c9b3b13 | main.py |

## Deviations from Plan

None — plan executed exactly as written. The 4-space vs 3-space indent correction was expected and called out explicitly in the plan.

## Verification

- `grep -n 'estimateContentLength' main.py` → line 664: `estimateContentLength=True`
- `pytest tests/ -v` → 6 passed in 0.03s

## Known Stubs

None.

## Self-Check: PASSED

- main.py contains `estimateContentLength=True` at line 664: FOUND
- Commit c9b3b13 exists: FOUND
- All 6 tests pass: CONFIRMED
