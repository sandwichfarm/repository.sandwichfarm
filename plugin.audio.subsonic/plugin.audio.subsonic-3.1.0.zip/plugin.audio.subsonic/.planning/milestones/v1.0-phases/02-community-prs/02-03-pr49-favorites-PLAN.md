---
phase: 02-community-prs
plan: 03
type: execute
wave: 2
depends_on:
  - 02-02-pr54-gapless-PLAN.md
files_modified:
  - main.py
  - resources/language/English/strings.po
  - resources/language/French/strings.po
  - resources/language/German/strings.po
autonomous: true
requirements:
  - PR-01

must_haves:
  truths:
    - "A user can browse a 'Favorite Albums' menu entry and see their starred/favorited albums"
    - "String ID 30027 exists in all three locale files"
    - "walk_albums() accepts a starred= parameter and calls getStarred2() when truthy"
  artifacts:
    - path: "main.py"
      provides: "menu_albums with albums_favorites entry; list_albums starred pagination; walk_albums starred branch"
      contains: "albums_favorites"
    - path: "resources/language/English/strings.po"
      provides: "String #30027 = Favorite albums"
      contains: "#30027"
    - path: "resources/language/French/strings.po"
      provides: "String #30027 = Albums préférés"
      contains: "#30027"
    - path: "resources/language/German/strings.po"
      provides: "String #30027 = Favorite Albums (untranslated)"
      contains: "#30027"
  key_links:
    - from: "menu_albums() albums_favorites entry"
      to: "list_albums()"
      via: "query_args={\"starred\": True} in URL params"
      pattern: "starred.*True"
    - from: "list_albums()"
      to: "walk_albums()"
      via: "walk_albums(**query_args) passes starred=True"
      pattern: "walk_albums.*starred"
    - from: "walk_albums(starred=True)"
      to: "connection.getStarred2()"
      via: "starred branch calls getStarred2() not getAlbumList2()"
      pattern: "getStarred2"
---

<objective>
Apply PR #49 (GioF71 / Giovanni Fulco) — add a "Favorite Albums" menu entry that shows the user's starred albums via `connection.getStarred2()`.

Purpose: Users who star albums on their Subsonic server can now browse them from the Albums menu. This is one of the most-requested community features.
Output: `main.py` modified at three sites; four locale strings.po files each gain string #30027; one atomic git commit attributing Giovanni Fulco.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/ROADMAP.md
@.planning/STATE.md
@.planning/phases/02-community-prs/02-CONTEXT.md
</context>

<tasks>

<task type="auto">
  <name>Task 1: Add albums_favorites to menu_albums() and update list_albums() pagination</name>
  <files>main.py</files>
  <read_first>
    - main.py (search `def menu_albums` — read ~60 lines from there to see the menus dict and list_albums)
    - main.py (search `def list_albums` — read ~80 lines from there to see pagination block)
    - .planning/phases/02-community-prs/02-CONTEXT.md (PR #49 diff snippets for both sites)
  </read_first>
  <action>
    ## Site 1: menu_albums() — add albums_favorites entry

    Locate `def menu_albums(params)` in main.py. Find the `menus` dict. The last entry currently ends with:

            'albums_random': {
                'name':     Addon().get_localized_string(30026),
                'thumb': None,
                'args':     {"ltype": "random"}
            }
        }

    Change it to add the `albums_favorites` entry (add trailing comma to `albums_random` closing brace, then add the new entry before the outer `}`):

            'albums_random': {
                'name':     Addon().get_localized_string(30026),
                'thumb': None,
                'args':     {"ltype": "random"}
            },
            'albums_favorites': {
                'name':     Addon().get_localized_string(30027),
                'thumb': None,
                'args':     {"starred": True}
            }
        }

    ## Site 2: list_albums() — replace pagination block

    Locate `def list_albums(params)` in main.py. Find the pagination block which currently reads:

        if not 'artist_id' in params:
            # Pagination if we've not reached the end of the lsit
            # if type(items) != type(True): TO FIX
            link_next = navigate_next(params)
            listing.append(link_next)

    Replace it with (the `starred` branch wraps the existing block inside an `else`; keep the `# TO FIX` comment as-is — Phase 3 will resolve it):

        if 'starred' in query_args:
            if len(items) == albums_per_page:
                link_next = navigate_next(params)
                listing.append(link_next)
        else:
            if not 'artist_id' in params:
                # Pagination if we've not reached the end of the lsit
                # if type(items) != type(True): TO FIX
                link_next = navigate_next(params)
                listing.append(link_next)

    Note: `query_args` is already defined earlier in list_albums() (parsed from params['query_args'] JSON). `albums_per_page` is also already defined in the function. No new variables needed.

    Do NOT stage or commit yet — Task 2 will complete the main.py changes before the commit.
  </action>
  <verify>
    <automated>grep -q 'albums_favorites' main.py && grep -q "'starred' in query_args" main.py && echo "PASS" || echo "FAIL"</automated>
  </verify>
  <acceptance_criteria>
    - `grep -q 'albums_favorites' main.py` exits 0
    - `grep -q "'starred' in query_args" main.py` exits 0
    - `grep -q 'getStarred2' main.py` exits 0 (from Task 2 — but verify after Task 2)
  </acceptance_criteria>
  <done>menu_albums() has albums_favorites entry and list_albums() pagination block handles starred branch</done>
</task>

<task type="auto">
  <name>Task 2: Rewrite walk_albums() with starred branch; add string #30027 to all locale files; commit</name>
  <files>main.py, resources/language/English/strings.po, resources/language/French/strings.po, resources/language/German/strings.po</files>
  <read_first>
    - main.py (search `def walk_albums` — read the full function ~20 lines)
    - resources/language/English/strings.po (lines around #30026 to see insertion point)
    - .planning/phases/02-community-prs/02-CONTEXT.md (PR #49 walk_albums rewrite and strings.po diffs)
  </read_first>
  <action>
    ## Site 3: walk_albums() — full rewrite with starred parameter

    Locate `def walk_albums(ltype, size=None, fromYear=None,toYear=None, genre=None, offset=None):` in main.py.

    Replace the entire function (signature + body) with:

    ```python
    def walk_albums(ltype=None, size=None, fromYear=None,toYear=None, genre=None, offset=None, starred=None):
        """
        (ID3 tags)
        Request all albums for a given genre and iterate over each album.
        """

        if starred:
            response = connection.getStarred2()
            if not response['starred2']['album']: return
            albums = response['starred2']['album']
            offset = 0 if not offset else offset
            if offset >= len(albums): return
            albums_per_page = int(Addon().get_setting('albums_per_page'))
            upper = min(len(albums), offset + albums_per_page)
            albums = albums[offset:upper]
            for album in albums:
                yield album
        else:
            if ltype == 'byGenre' and genre is None:
                return
            
            if ltype == 'byYear' and (fromYear is None or toYear is None):
                return

            response = connection.getAlbumList2(
                ltype=ltype, size=size, fromYear=fromYear, toYear=toYear,genre=genre, offset=offset)

            if not response["albumList2"]["album"]:
                return

            for album in response["albumList2"]["album"]:
                yield album
    ```

    This preserves the original non-starred logic inside the `else` branch.

    ## Locale strings — add #30027 to all three files

    **English** (`resources/language/English/strings.po`):
    After the `#30026` block (which ends with `msgstr ""`), insert before `#30029`:

    ```po
    msgctxt "#30027"
    msgid "Favorite albums"
    msgstr ""

    ```
    (one blank line between each msgctxt block — match surrounding style)

    **French** (`resources/language/French/strings.po`):
    After the `#30026` block (which ends with `msgstr "Albums au hasard"`), insert before `#30029`:

    ```po
    msgctxt "#30027"
    msgid "Favorite albums"
    msgstr "Albums préférés"

    ```

    **German** (`resources/language/German/strings.po`):
    After the `#30026` block (which ends with `msgstr "Zufällige Alben"`), insert before `#30029`:

    ```po
    msgctxt "#30027"
    msgid "Favorite Albums"
    msgstr ""

    ```
    (German has empty msgstr in the upstream PR — leave it empty)

    ## Commit all changes together

    After all four files are edited:
      git add main.py resources/language/English/strings.po resources/language/French/strings.po resources/language/German/strings.po
      git commit -m "feat(02-03): merge PR #49 — Favorite Albums menu (Co-authored)

    Co-Authored-By: Giovanni Fulco <giovanni.fulco.web@gmail.com>"
  </action>
  <verify>
    <automated>grep -q 'starred=None' main.py && grep -q 'getStarred2' main.py && grep -q '#30027' resources/language/English/strings.po && grep -q '#30027' resources/language/French/strings.po && grep -q '#30027' resources/language/German/strings.po && python3 -m pytest tests/ -v && echo "ALL PASS" || echo "FAIL"</automated>
  </verify>
  <acceptance_criteria>
    - `grep -q "starred=None" main.py` exits 0 (new walk_albums signature)
    - `grep -q 'getStarred2' main.py` exits 0 (starred branch uses getStarred2)
    - `grep -q '#30027' resources/language/English/strings.po` exits 0
    - `grep -q 'Albums préférés' resources/language/French/strings.po` exits 0
    - `grep -q '#30027' resources/language/German/strings.po` exits 0
    - `python3 -m pytest tests/ -v` exits 0
  </acceptance_criteria>
  <done>walk_albums() has starred parameter and getStarred2 branch; all three locale files have #30027; git log shows atomic commit attributing Giovanni Fulco; pytest passes</done>
</task>

</tasks>

<verification>
```bash
# Check all three sites in main.py
grep -n 'albums_favorites\|starred.*query_args\|starred=None\|getStarred2' main.py

# Check all locale files
grep -A2 '#30027' resources/language/English/strings.po
grep -A2 '#30027' resources/language/French/strings.po
grep -A2 '#30027' resources/language/German/strings.po

# Smoke tests
python3 -m pytest tests/ -v
```
Expected: four matches in main.py; #30027 present in all three locale files; all tests pass.
</verification>

<success_criteria>
- `main.py` has `albums_favorites` menu entry in `menu_albums()`
- `main.py` pagination in `list_albums()` has `if 'starred' in query_args:` branch
- `walk_albums()` signature is `walk_albums(ltype=None, ..., starred=None)` with `getStarred2()` branch
- All three locale files contain `msgctxt "#30027"` with `msgid "Favorite albums"` (or "Favorite Albums" in German)
- Git log shows atomic commit `feat(02-03): merge PR #49` with Co-Authored-By trailer for Giovanni Fulco
- `python3 -m pytest tests/ -v` exits 0
</success_criteria>

<output>
After completion, create `.planning/phases/02-community-prs/02-03-SUMMARY.md`
</output>
