---
phase: 02-community-prs
plan: 04
type: execute
wave: 3
depends_on:
  - 02-01-pr53-settings-PLAN.md
  - 02-02-pr54-gapless-PLAN.md
  - 02-03-pr49-favorites-PLAN.md
files_modified: []
autonomous: false
requirements:
  - PR-01
  - PR-02
  - PR-03

must_haves:
  truths:
    - "All three PR changes are present in the codebase simultaneously"
    - "pytest passes with all PR changes applied"
    - "main.py and service.py still import cleanly under test mocks"
  artifacts:
    - path: "tests/test_imports.py"
      provides: "Smoke test confirming main + service import without crash"
  key_links:
    - from: "resources/settings.xml"
      to: "main.py"
      via: "transcode_format_streaming setting consumed by play_track()"
      pattern: "transcode_format_streaming"
    - from: "main.py albums_favorites"
      to: "walk_albums(starred=True)"
      via: "list_albums() passes query_args to walk_albums(**query_args)"
      pattern: "walk_albums.*starred"
---

<objective>
Final smoke verification for Phase 2: confirm all three PR changes coexist without breaking imports or tests, and get human sign-off before marking phase complete.

Purpose: Each PR was committed independently — this plan confirms the combined state is clean, pytest still passes, and the code changes are visually correct before proceeding to Phase 3.
Output: Human-approved phase completion; `.planning/phases/02-community-prs/02-04-SUMMARY.md` written.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/ROADMAP.md
@.planning/STATE.md
@.planning/phases/02-community-prs/02-CONTEXT.md
</context>

<tasks>

<task type="auto">
  <name>Task 1: Full combined smoke test — verify all three PRs and pytest</name>
  <files></files>
  <action>
    Run the following checks in order. Each must pass before proceeding to the checkpoint.

    1. Verify PR #53 (settings.xml):
       grep 'transcode_format_streaming' resources/settings.xml
       Expected: line contains `values="mp3|raw|flv|ogg|m4a"`

    2. Verify PR #54 (main.py play_track):
       grep -n 'estimateContentLength' main.py
       Expected: one line inside play_track() showing `estimateContentLength=True`

    3. Verify PR #49 — menu entry:
       grep -n 'albums_favorites' main.py
       Expected: one line in menu_albums() menus dict

    4. Verify PR #49 — list_albums pagination:
       grep -n "starred.*query_args" main.py
       Expected: one line with `if 'starred' in query_args:`

    5. Verify PR #49 — walk_albums signature:
       grep -n 'def walk_albums' main.py
       Expected: `def walk_albums(ltype=None, ..., starred=None):`

    6. Verify PR #49 — getStarred2 call:
       grep -n 'getStarred2' main.py
       Expected: one line inside walk_albums()

    7. Verify all locale strings:
       grep -A2 '#30027' resources/language/English/strings.po
       grep -A2 '#30027' resources/language/French/strings.po
       grep -A2 '#30027' resources/language/German/strings.po
       Expected: each file has msgctxt "#30027" + msgid "Favorite albums" (or "Favorite Albums" in German)

    8. Run full test suite:
       python3 -m pytest tests/ -v
       Expected: all tests pass, exit code 0

    9. Check git log (last 4 commits):
       git log --oneline -4
       Expected: commits for feat(02-01), feat(02-02), feat(02-03) in order
  </action>
  <verify>
    <automated>
      grep -q 'mp3|raw|flv|ogg|m4a' resources/settings.xml &&
      grep -q 'estimateContentLength=True' main.py &&
      grep -q 'albums_favorites' main.py &&
      grep -q "starred.*query_args" main.py &&
      grep -q 'starred=None' main.py &&
      grep -q 'getStarred2' main.py &&
      grep -q '#30027' resources/language/English/strings.po &&
      grep -q '#30027' resources/language/French/strings.po &&
      grep -q '#30027' resources/language/German/strings.po &&
      python3 -m pytest tests/ -v &&
      echo "ALL CHECKS PASS" || echo "CHECKS FAILED — see above"
    </automated>
  </verify>
  <done>All automated checks pass; ready for human checkpoint review</done>
</task>

<task type="checkpoint:human-verify" gate="blocking">
  <name>Task 2: Human sign-off on Phase 2 merged PRs</name>
  <files></files>
  <action>Pause for human review of merged PR changes and test results.</action>
  <verify>
    <automated>echo "checkpoint — human verification required"</automated>
  </verify>
  <done>Human types "approved"</done>
  <what-built>
    Three community PRs manually merged onto the Phase 1 foundation:
    - PR #53: m4a added to transcode format options in settings.xml
    - PR #54: estimateContentLength=True added to streamUrl call in play_track()
    - PR #49: Favorite Albums menu entry, list_albums starred pagination, walk_albums starred branch calling getStarred2(), and string #30027 in English/French/German
    All changes committed as three atomic commits with Co-Authored-By attribution.
  </what-built>
  <how-to-verify>
    Review the three commits:

      git log --oneline -4
      git show HEAD~2 --stat    # PR #53 commit
      git show HEAD~1 --stat    # PR #54 commit
      git show HEAD --stat      # PR #49 commit

    Spot-check key changes:

      grep 'transcode_format_streaming' resources/settings.xml
      grep -n 'estimateContentLength' main.py
      grep -n 'albums_favorites\|getStarred2\|starred=None' main.py

    Confirm tests still pass:

      python3 -m pytest tests/ -v
  </how-to-verify>
  <resume-signal>Type "approved" to mark Phase 2 complete, or describe any issues found</resume-signal>
</task>

</tasks>

<verification>
All automated checks in Task 1 must pass before presenting the checkpoint.
</verification>

<success_criteria>
- `python3 -m pytest tests/ -v` exits 0 with all three PR changes applied
- Human approves the checkpoint
- `.planning/phases/02-community-prs/02-04-SUMMARY.md` is written
- ROADMAP.md Phase 2 marked complete
</success_criteria>

<output>
After checkpoint approval:
1. Create `.planning/phases/02-community-prs/02-04-SUMMARY.md`
2. Update ROADMAP.md: Phase 2 `[ ]` → `[x]`, set completed date
3. Update STATE.md: phase status to complete
</output>
