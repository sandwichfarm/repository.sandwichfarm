---
phase: 02-community-prs
plan: 01
type: execute
wave: 1
depends_on: []
files_modified:
  - resources/settings.xml
autonomous: true
requirements:
  - PR-02

must_haves:
  truths:
    - "A user can select m4a (AAC) as a transcoding option in addon settings"
  artifacts:
    - path: "resources/settings.xml"
      provides: "transcode_format_streaming setting with m4a option"
      contains: "mp3|raw|flv|ogg|m4a"
  key_links:
    - from: "resources/settings.xml"
      to: "main.py play_track()"
      via: "Addon().get_setting('transcode_format_streaming') passed to connection.streamUrl(tformat=...)"
      pattern: "transcode_format_streaming"
---

<objective>
Apply PR #53 (stuaxo) — append `m4a` to the `transcode_format_streaming` labelenum values in settings.xml.

Purpose: Allows users to select AAC/m4a as a transcoding format for streaming. One-line change, isolated to settings.xml with no code changes needed.
Output: `resources/settings.xml` updated; one atomic git commit attributing Stuart Axon.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/ROADMAP.md
@.planning/STATE.md
@.planning/phases/02-community-prs/02-CONTEXT.md
</context>

<tasks>

<task type="auto">
  <name>Task 1: Apply PR #53 — add m4a to transcode_format_streaming</name>
  <files>resources/settings.xml</files>
  <read_first>
    - resources/settings.xml (line 16 — the transcode_format_streaming setting)
    - .planning/phases/02-community-prs/02-CONTEXT.md (PR #53 diff snippet)
  </read_first>
  <action>
    In `resources/settings.xml` at line 16, change the `transcode_format_streaming` setting from:

        <setting label="30011" id="transcode_format_streaming" type="labelenum"  values="mp3|raw|flv|ogg"/>

    To (note: also normalise the double-space before `values=` to single space, as the PR does):

        <setting label="30011" id="transcode_format_streaming" type="labelenum" values="mp3|raw|flv|ogg|m4a"/>

    That is the complete change. Do not modify any other line.

    After editing, commit with:
      git add resources/settings.xml
      git commit -m "feat(02-01): merge PR #53 — add m4a transcoding option (Co-authored)

    Co-Authored-By: Stuart Axon <stuaxo2@gmail.com>"
  </action>
  <verify>
    <automated>grep -q 'mp3|raw|flv|ogg|m4a' resources/settings.xml && echo "PASS: m4a present" || echo "FAIL: m4a missing"</automated>
  </verify>
  <acceptance_criteria>
    - `grep -q 'mp3|raw|flv|ogg|m4a' resources/settings.xml` exits 0
    - `grep -q 'mp3|raw|flv|ogg"' resources/settings.xml` exits 1 (old value gone)
    - `python3 -m pytest tests/ -v` still passes (PR touches no Python)
  </acceptance_criteria>
  <done>settings.xml line 16 has `values="mp3|raw|flv|ogg|m4a"` and git log shows one new commit attributing Stuart Axon</done>
</task>

</tasks>

<verification>
```bash
grep 'transcode_format_streaming' resources/settings.xml
python3 -m pytest tests/ -v
```
Expected: settings line shows m4a in values; all tests pass.
</verification>

<success_criteria>
- `resources/settings.xml` contains `values="mp3|raw|flv|ogg|m4a"` on the transcode_format_streaming line
- Git log shows atomic commit `feat(02-01): merge PR #53` with Co-Authored-By trailer
- `python3 -m pytest tests/ -v` exits 0
</success_criteria>

<output>
After completion, create `.planning/phases/02-community-prs/02-01-SUMMARY.md`
</output>
