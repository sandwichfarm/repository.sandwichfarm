---
phase: 02-community-prs
plan: 02
type: execute
wave: 1
depends_on: []
files_modified:
  - main.py
autonomous: true
requirements:
  - PR-03

must_haves:
  truths:
    - "`estimateContentLength` is sent in stream requests so Kodi can enable gapless playback on supported builds"
  artifacts:
    - path: "main.py"
      provides: "play_track() with estimateContentLength=True in streamUrl call"
      contains: "estimateContentLength=True"
  key_links:
    - from: "main.py play_track()"
      to: "connection.streamUrl()"
      via: "estimateContentLength=True kwarg"
      pattern: "estimateContentLength=True"
---

<objective>
Apply PR #54 (stuaxo) — add `estimateContentLength=True` to the `connection.streamUrl(...)` call in `play_track()`.

Purpose: Enables gapless playback on Kodi builds that support it. The Subsonic API accepts this parameter; without it, Kodi cannot pre-buffer the next track reliably.
Output: `main.py` `play_track()` function updated; one atomic git commit attributing Stuart Axon.
</objective>

<execution_context>
@$HOME/.claude/get-shit-done/workflows/execute-plan.md
@$HOME/.claude/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/ROADMAP.md
@.planning/STATE.md
@.planning/phases/02-community-prs/02-CONTEXT.md
</context>

<tasks>

<task type="auto">
  <name>Task 1: Apply PR #54 — add estimateContentLength to play_track streamUrl call</name>
  <files>main.py</files>
  <read_first>
    - main.py (search for `def play_track` — the function is around line 649; read 20 lines from there)
    - .planning/phases/02-community-prs/02-CONTEXT.md (PR #54 diff snippet)
  </read_first>
  <action>
    Locate `def play_track(params)` in main.py. Inside it, find the `connection.streamUrl(...)` call which currently reads:

        url = connection.streamUrl(sid=id,
            maxBitRate=Addon().get_setting('bitrate_streaming'),
            tformat=Addon().get_setting('transcode_format_streaming')
        )

    Replace it with (4-space indent on closing paren, NOT 3-space as in the raw PR):

        url = connection.streamUrl(sid=id,
            maxBitRate=Addon().get_setting('bitrate_streaming'),
            tformat=Addon().get_setting('transcode_format_streaming'),
            estimateContentLength=True
        )

    The only changes are:
      1. Add a trailing comma after the `tformat=...` line
      2. Add `estimateContentLength=True` as a new argument line before the closing paren
      3. Closing paren stays at 4-space indent (matching surrounding code style)

    Do not modify any other line in play_track() or elsewhere.

    After editing, verify the change looks correct, then commit:
      git add main.py
      git commit -m "feat(02-02): merge PR #54 — estimateContentLength for gapless playback (Co-authored)

    Co-Authored-By: Stuart Axon <stuaxo2@gmail.com>"
  </action>
  <verify>
    <automated>grep -q 'estimateContentLength=True' main.py && echo "PASS" || echo "FAIL"</automated>
  </verify>
  <acceptance_criteria>
    - `grep -q 'estimateContentLength=True' main.py` exits 0
    - `grep -A4 'def play_track' main.py | grep -q 'connection.streamUrl'` — the call is still inside play_track (not accidentally moved)
    - `python3 -m pytest tests/ -v` exits 0
  </acceptance_criteria>
  <done>`play_track()` calls `connection.streamUrl(..., estimateContentLength=True)` and git log shows one new commit attributing Stuart Axon</done>
</task>

</tasks>

<verification>
```bash
grep -n 'estimateContentLength' main.py
python3 -m pytest tests/ -v
```
Expected: one line showing `estimateContentLength=True` inside the streamUrl call; all tests pass.
</verification>

<success_criteria>
- `main.py` contains `estimateContentLength=True` in the `connection.streamUrl()` call inside `play_track()`
- Git log shows atomic commit `feat(02-02): merge PR #54` with Co-Authored-By trailer
- `python3 -m pytest tests/ -v` exits 0
</success_criteria>

<output>
After completion, create `.planning/phases/02-community-prs/02-02-SUMMARY.md`
</output>
