---
status: partial
phase: 02-community-prs
source: [02-VERIFICATION.md]
started: 2026-04-28T17:00:00Z
updated: 2026-04-28T17:00:00Z
---

## Current Test

[awaiting human testing — these are runtime checks for Phase 6 server-verification]

## Tests

### 1. Favorite Albums browse
expected: In a real Kodi 21 install with the plugin loaded and pointed at a server with starred albums, navigate Music → Subsonic → Albums → Favorite Albums. The starred albums appear in the list. If the page is not full, no "Next Page" link is shown.
result: [pending]

### 2. m4a transcoding
expected: With transcoding format set to `m4a` in addon settings, play a track. The constructed stream URL contains `tformat=m4a`. Some clients/devices play this efficiently via hardware AAC decode.
result: [pending]

### 3. estimateContentLength gapless playback
expected: Play two consecutive tracks of a gapless album (e.g. live recording, classical). No audible gap between tracks. Kodi's readahead buffer is enabled because `estimateContentLength=true` is now in stream requests.
result: [pending]

## Summary

total: 3
passed: 0
issues: 0
pending: 3
skipped: 0
blocked: 0

## Gaps

None automated — all three items are runtime concerns deferred to Phase 6 server verification.
