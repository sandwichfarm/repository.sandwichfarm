# Milestones

## v1.0 Modernization (Shipped: 2026-04-28)

**Phases completed:** 6 phases, 27 plans, 26 tasks

**Key accomplishments:**

- Three surgical Python 3 / Kodi 20+ crash fixes: `import sys` in service.py, `urllib.request.Request` replacing `urllib2` in libsonic, and unconditional `xbmcvfs.translatePath` in simpleplugin
- Replaced silent bare except: pass in get_connection() and service.py settings read with except Exception as exc plus traceback.format_exc() logging at xbmc.LOGERROR
- pytest infrastructure with pyproject.toml (ruff/mypy/pytest config), Kodi API MagicMock injection in conftest.py, and 4 passing smoke tests for main, service, libsonic, and simpleplugin imports
- GitHub Actions CI pipeline with three jobs: pytest matrix on Python 3.8+3.11, ruff+mypy lint on 3.11, and kodi-addon-checker@v1.2 with kodi-version nexus
- All 6 pytest smoke tests pass on Python 3.14 (local); CI matrix gates on 3.8 and 3.11 — Phase 01 Foundation fully verified and approved
- Added m4a/AAC as a selectable transcoding format in settings.xml by appending |m4a to the transcode_format_streaming labelenum values
- One-liner:
- Three community PRs (m4a transcoding, gapless estimateContentLength, Favorite Albums) verified coexisting cleanly — pytest 6/6 pass, human-approved
- One-liner:
- One-liner:
- Standalone decorator-based router replacing simpleplugin dispatch — route(), url_for(), dispatch(), set_routes() — 77 LOC, 11 tests, mypy clean
- One-liner:
- One-liner:
- One-liner:
- One-liner:
- conftest.py additions:
- Full automated quality gate passed: 173 tests green, ruff/mypy clean, all 13 sweeps zero — Phase 3 structural refactor confirmed complete by automation; Kodi runtime UAT deferred to Phase 6
- Task 1 (4d26709):
- One-liner:
- One-liner:
- One-liner:
- One-liner:
- One-liner:
- 240 pytest tests pass, mypy --strict zero errors, ruff clean — Phase 5 feature-expansion gates verified and human-approved

---
