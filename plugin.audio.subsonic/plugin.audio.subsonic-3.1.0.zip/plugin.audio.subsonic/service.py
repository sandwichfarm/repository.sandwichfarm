#!/usr/bin/python
"""plugin.audio.subsonic — Kodi background service entry point.

This file is the thin bootstrap only. All scrobbling logic lives in
resources/lib/subsonic/scrobbler.py. See bootstrap.py for the implementation.
"""

import os
import sys

# Add resources/lib to sys.path so `import subsonic.*` works.
_ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(_ADDON_DIR, "lib"))
sys.path.insert(0, os.path.join(_ADDON_DIR, "resources", "lib"))

from subsonic.bootstrap import run_service  # noqa: E402

if __name__ == "__main__":
    run_service()
