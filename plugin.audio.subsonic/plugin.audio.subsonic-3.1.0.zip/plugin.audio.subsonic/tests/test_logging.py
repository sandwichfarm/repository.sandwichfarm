from __future__ import annotations

import os
import sys
from unittest.mock import patch

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LIB = os.path.join(_REPO, "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

import xbmc  # already mocked by conftest


def _import_fresh():
    """Import subsonic.logging fresh so module-level xbmc refs work with mock."""
    import importlib

    import subsonic.logging as mod

    importlib.reload(mod)
    return mod


def test_safe_log_redacts_p_param():
    mod = _import_fresh()
    with patch.object(xbmc, "log") as mock_log:
        mod.safe_log("url?p=mypassword&other=x", xbmc.LOGINFO)
    args = mock_log.call_args[0][0]
    assert "REDACTED" in args
    assert "mypassword" not in args


def test_safe_log_redacts_t_param():
    mod = _import_fresh()
    with patch.object(xbmc, "log") as mock_log:
        mod.safe_log("request?t=abc123&s=salt42", xbmc.LOGINFO)
    args = mock_log.call_args[0][0]
    assert "abc123" not in args
    assert "salt42" not in args


def test_safe_log_redacts_password_param():
    mod = _import_fresh()
    with patch.object(xbmc, "log") as mock_log:
        mod.safe_log("url?password=secret", xbmc.LOGINFO)
    args = mock_log.call_args[0][0]
    assert "secret" not in args
    assert "REDACTED" in args


def test_safe_log_redacts_apikey_param():
    mod = _import_fresh()
    with patch.object(xbmc, "log") as mock_log:
        mod.safe_log("url?apiKey=mykey123", xbmc.LOGINFO)
    args = mock_log.call_args[0][0]
    assert "mykey123" not in args
    assert "REDACTED" in args


def test_safe_log_passes_non_auth_through():
    mod = _import_fresh()
    with patch.object(xbmc, "log") as mock_log:
        mod.safe_log("action=list_albums&page=2", xbmc.LOGINFO)
    args = mock_log.call_args[0][0]
    assert "list_albums" in args
    assert "page=2" in args


def test_safe_log_calls_xbmc_log_once():
    mod = _import_fresh()
    with patch.object(xbmc, "log") as mock_log:
        mod.safe_log("hello", xbmc.LOGINFO)
    assert mock_log.call_count == 1


def test_log_error_uses_logerror():
    mod = _import_fresh()
    with patch.object(xbmc, "log") as mock_log:
        mod.log_error("something broke")
    level = mock_log.call_args[0][1]
    assert level == xbmc.LOGERROR


def test_log_debug_uses_logdebug():
    mod = _import_fresh()
    with patch.object(xbmc, "log") as mock_log:
        mod.log_debug("verbose info")
    level = mock_log.call_args[0][1]
    assert level == xbmc.LOGDEBUG
