"""
Pytest configuration for plugin.audio.subsonic tests.

Injects MagicMock objects into sys.modules for all Kodi API modules before
any addon code is imported. This allows tests to run without Kodi installed.

Pattern source: Kodistubs official docs (romanvm.github.io/Kodistubs/using.html)
"""

import os
import sys
from unittest.mock import MagicMock

# Inject Kodi API mocks before any addon import
_KODI_MODULES = ("xbmc", "xbmcgui", "xbmcplugin", "xbmcaddon", "xbmcvfs")
for _module_name in _KODI_MODULES:
    sys.modules[_module_name] = MagicMock()

# Set log level constants that addon code compares against
sys.modules["xbmc"].LOGDEBUG = 0
sys.modules["xbmc"].LOGINFO = 1
sys.modules["xbmc"].LOGWARNING = 2
sys.modules["xbmc"].LOGERROR = 4

# getInfoLabel('System.BuildVersion') must return a real string so that
# simpleplugin._kodi_major_version() can call .split(' ')[0] and compare
# the result to a string with '<'. MagicMock < '19' raises TypeError in Py3.
sys.modules["xbmc"].getInfoLabel.return_value = "21.0.0"

# translatePath returns a real string so os.path.join works
sys.modules["xbmcvfs"].translatePath.return_value = "/tmp/fake-addon-path"

# Addon().getAddonInfo('path') returns a real string
sys.modules["xbmcaddon"].Addon.return_value.getAddonInfo.return_value = "/tmp/fake-addon-path"

# getSetting / get_setting return '0' so that int(get_setting('cachetime')) works
# in main.py module-level code (returns '0' rather than '' which would raise ValueError)
sys.modules["xbmcaddon"].Addon.return_value.getSetting.return_value = "0"
sys.modules["xbmcaddon"].Addon.return_value.get_setting = MagicMock(return_value="0")

# Ensure the repo root and lib/ are on sys.path so imports work
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)
_LIB_DIR = os.path.join(_REPO_ROOT, "lib")
if _LIB_DIR not in sys.path:
    sys.path.insert(0, _LIB_DIR)

# Add resources/lib so subsonic.* modules are importable in tests
_RESOURCES_LIB = os.path.join(_REPO_ROOT, "resources", "lib")
if _RESOURCES_LIB not in sys.path:
    sys.path.insert(0, _RESOURCES_LIB)

# translatePath returns a real path string (used by Cache in tests)
sys.modules["xbmcvfs"].File = MagicMock()

# ListItem mock with getMusicInfoTag pre-configured
_mock_li = MagicMock()
_mock_li.getMusicInfoTag.return_value = MagicMock()
sys.modules["xbmcgui"].ListItem.return_value = _mock_li
sys.modules["xbmcgui"].INPUT_ALPHANUM = 0
