"""
Unit tests for subsonic.models — TypedDicts and dataclasses.

These tests run without Kodi installed; models.py has zero Kodi dependencies.
"""

from __future__ import annotations

import os
import sys
import time

# Ensure resources/lib is importable
_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LIB = os.path.join(_REPO, "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

from subsonic.models import (
    CacheEntry,
    PageState,
    PlayContext,
    SubsonicAlbum,
    SubsonicArtist,
    SubsonicGenre,
    SubsonicPlaylist,
    SubsonicTrack,
)


def test_subsonic_track_minimal() -> None:
    t: SubsonicTrack = {"id": "1", "title": "Song"}
    assert t["id"] == "1"


def test_subsonic_album_partial() -> None:
    a: SubsonicAlbum = {"id": "2", "name": "Album"}
    assert a["name"] == "Album"
    assert "artist" not in a  # total=False allows partial dicts


def test_subsonic_artist_partial() -> None:
    ar: SubsonicArtist = {"id": "10", "name": "Artist"}
    assert ar["id"] == "10"
    assert "albumCount" not in ar


def test_subsonic_playlist_partial() -> None:
    pl: SubsonicPlaylist = {"id": "99", "name": "My Playlist"}
    assert pl["name"] == "My Playlist"


def test_subsonic_genre_partial() -> None:
    g: SubsonicGenre = {"value": "Rock", "songCount": 42}
    assert g["value"] == "Rock"


def test_page_state_defaults() -> None:
    ps = PageState()
    assert ps.page == 1
    assert ps.page_size == 50
    assert ps.offset == 0
    assert ps.has_more is True


def test_page_state_custom() -> None:
    ps = PageState(page=3, page_size=100, offset=200, has_more=False)
    assert ps.page == 3
    assert not ps.has_more


def test_play_context() -> None:
    pc = PlayContext(stream_url="http://server/stream?id=1", track_id="1", title="Song")
    assert pc.track_id == "1"
    assert pc.duration == 0


def test_play_context_with_duration() -> None:
    pc = PlayContext(
        stream_url="http://server/stream?id=2", track_id="2", title="Track 2", duration=180
    )
    assert pc.duration == 180


def test_cache_entry() -> None:
    entry = CacheEntry(value=[1, 2, 3], expires_at=time.time() + 300)
    assert entry.value == [1, 2, 3]
    assert entry.expires_at > time.time()


def test_cache_entry_expired() -> None:
    entry = CacheEntry(value="old", expires_at=time.time() - 1)
    assert entry.expires_at < time.time()
