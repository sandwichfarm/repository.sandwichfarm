from __future__ import annotations

import json
import os
import sys
from unittest.mock import MagicMock, patch

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LIB = os.path.join(_REPO, "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

from subsonic.cache import Cache


def _make_cache() -> Cache:
    return Cache(cache_dir="/tmp/fake-subsonic-cache")


def test_get_miss_calls_fetcher():
    cache = _make_cache()
    fetcher = MagicMock(return_value=[1, 2, 3])
    result = cache.get("albums", fetcher, ttl=300)
    assert result == [1, 2, 3]
    fetcher.assert_called_once()


def test_get_hit_returns_cached():
    cache = _make_cache()
    fetcher = MagicMock(return_value="data")
    cache.get("key", fetcher, ttl=300)
    result2 = cache.get("key", fetcher, ttl=300)
    assert result2 == "data"
    assert fetcher.call_count == 1  # fetcher called only once


def test_get_after_ttl_expiry_calls_fetcher_again():
    cache = _make_cache()
    fetcher = MagicMock(side_effect=["first", "second"])
    with patch("subsonic.cache.time.time") as mock_time:
        mock_time.return_value = 1000.0
        cache.get("key", fetcher, ttl=60)
        # advance time past TTL
        mock_time.return_value = 1070.0
        result = cache.get("key", fetcher, ttl=60)
    assert result == "second"
    assert fetcher.call_count == 2


def test_invalidate_forces_refetch():
    cache = _make_cache()
    fetcher = MagicMock(side_effect=["v1", "v2"])
    cache.get("key", fetcher, ttl=300)
    cache.invalidate("key")
    result = cache.get("key", fetcher, ttl=300)
    assert result == "v2"
    assert fetcher.call_count == 2


def test_invalidate_nonexistent_key_is_noop():
    cache = _make_cache()
    cache.invalidate("does-not-exist")  # must not raise


def test_persist_write_calls_xbmcvfs(monkeypatch):
    fake_file = MagicMock()
    fake_file.__enter__ = MagicMock(return_value=fake_file)
    fake_file.__exit__ = MagicMock(return_value=False)
    import xbmcvfs

    monkeypatch.setattr(xbmcvfs, "File", MagicMock(return_value=fake_file))
    cache = _make_cache()
    cache.persist_write("starred.json", {"ids": [1, 2]})
    expected = json.dumps({"ids": [1, 2]}).encode("utf-8")
    fake_file.write.assert_called_once_with(bytearray(expected))


def test_persist_read_returns_none_on_error(monkeypatch):
    import xbmcvfs

    monkeypatch.setattr(xbmcvfs, "File", MagicMock(side_effect=OSError("boom")))
    cache = _make_cache()
    result = cache.persist_read("missing.json")
    assert result is None


def test_cache_starred_set_invalidates_on_newer_timestamp(monkeypatch):
    """PERF-02: starred_set calls fetcher when server timestamp is newer."""
    cache = _make_cache()
    # Simulate stored data with an older timestamp
    stored_data = {"updated": "2024-01-01T00:00:00", "value": {"song": ["old"]}}
    cache.persist_read = MagicMock(return_value=stored_data)
    cache.persist_write = MagicMock()
    fetcher = MagicMock(return_value={"song": ["new"]})

    result = cache.starred_set(fetcher, server_updated_ts="2024-06-01T00:00:00")

    fetcher.assert_called_once()
    assert result == {"song": ["new"]}
    cache.persist_write.assert_called_once()


def test_cache_starred_set_no_refresh_when_timestamp_matches(monkeypatch):
    """PERF-02: starred_set skips fetcher when server timestamp == stored timestamp."""
    cache = _make_cache()
    same_ts = "2024-06-01T00:00:00"
    stored_data = {"updated": same_ts, "value": {"song": ["cached"]}}
    cache.persist_read = MagicMock(return_value=stored_data)
    cache.persist_write = MagicMock()
    fetcher = MagicMock(return_value={"song": ["fresh"]})

    result = cache.starred_set(fetcher, server_updated_ts=same_ts)

    fetcher.assert_not_called()
    assert result == {"song": ["cached"]}


def test_cache_starred_set_fetches_when_no_stored_data(monkeypatch):
    """PERF-02: starred_set calls fetcher on first run (nothing persisted)."""
    cache = _make_cache()
    cache.persist_read = MagicMock(return_value=None)
    cache.persist_write = MagicMock()
    fetcher = MagicMock(return_value={"song": ["first"]})

    result = cache.starred_set(fetcher, server_updated_ts="2024-06-01T00:00:00")

    fetcher.assert_called_once()
    assert result == {"song": ["first"]}
