"""
Unit tests for subsonic.browse — pagination correctness and handler smoke tests.

Covers:
- BUG-04: list_albums shows Next Page only when len(items) >= albums_per_page
- BUG-03: list_tracks assigns tracknumber from playlist position
- list_albums: correct offset calculation for page N
- list_artists: calls get_artists and forwards to listings
- No xbmcplugin or xbmcgui imports in browse.py
"""

from __future__ import annotations

import inspect
import os
import sys
from unittest.mock import MagicMock, patch

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LIB = os.path.join(_REPO, "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

import subsonic.browse  # registers routes as side-effect  # noqa: E402


def _make_settings(albums_per_page: int = 50, tracks_per_page: int = 100) -> MagicMock:
    s = MagicMock()
    s.albums_per_page = albums_per_page
    s.tracks_per_page = tracks_per_page
    return s


def _make_client(
    albums: list = None,
    tracks: list = None,
) -> MagicMock:
    client = MagicMock()
    client.get_album_list.return_value = albums or []
    client.get_random_songs.return_value = tracks or []
    client.get_starred.return_value = {}
    client.get_artists.return_value = []
    client.get_cover_art_url.return_value = "http://art?size=512"
    return client


def _run_list_albums(client: MagicMock, settings: MagicMock, **params: str) -> list:
    """Run list_albums with mocked listings calls. Return captured listing items."""
    captured: list = []
    with patch("subsonic.browse.add_items") as mock_add, patch("subsonic.browse.end_directory"):
        mock_add.side_effect = lambda h, items: captured.extend(items)
        subsonic.browse.list_albums(client=client, settings=settings, handle=1, **params)
    return captured


# ---------------------------------------------------------------------------
# list_albums pagination
# ---------------------------------------------------------------------------


def test_list_albums_shows_next_page_when_full() -> None:
    """Next Page link expected when len(items) == albums_per_page."""
    albums = [{"id": str(i), "name": f"Album {i}"} for i in range(50)]
    client = _make_client(albums=albums)
    settings = _make_settings(albums_per_page=50)
    items = _run_list_albums(client, settings, ltype="newest", page="1")
    urls = [item[0] for item in items]
    assert any("page=2" in url for url in urls), (
        "Next Page link expected when len(items) == page_size"
    )


def test_list_albums_no_next_page_on_partial_page() -> None:
    """No Next Page link expected when len(items) < albums_per_page."""
    albums = [{"id": str(i), "name": f"Album {i}"} for i in range(30)]
    client = _make_client(albums=albums)
    settings = _make_settings(albums_per_page=50)
    items = _run_list_albums(client, settings, ltype="newest", page="1")
    urls = [item[0] for item in items]
    assert not any("page=2" in url for url in urls), (
        "No Next Page link expected when len(items) < page_size"
    )


def test_list_albums_no_next_page_on_empty() -> None:
    """No pagination links when result is empty."""
    client = _make_client(albums=[])
    settings = _make_settings(albums_per_page=50)
    items = _run_list_albums(client, settings, ltype="newest", page="1")
    urls = [item[0] for item in items]
    assert not any("page=" in url for url in urls)


def test_list_albums_random_has_no_next_page() -> None:
    """Random albums must never show Next Page even when result fills a full page."""
    albums = [{"id": str(i)} for i in range(50)]
    client = _make_client(albums=albums)
    settings = _make_settings(albums_per_page=50)
    items = _run_list_albums(client, settings, ltype="random", page="1")
    urls = [item[0] for item in items]
    assert not any("page=2" in url for url in urls), "Random albums must never show Next Page"


# ---------------------------------------------------------------------------
# list_albums offset calculation
# ---------------------------------------------------------------------------


def test_list_albums_correct_offset_calculation() -> None:
    """Page 3 with page_size=50 should pass offset=100."""
    client = _make_client(albums=[])
    settings = _make_settings(albums_per_page=50)
    with patch("subsonic.browse.add_items"), patch("subsonic.browse.end_directory"):
        subsonic.browse.list_albums(
            client=client, settings=settings, handle=1, ltype="newest", page="3"
        )
    client.get_album_list.assert_called_once_with(ltype="newest", size=50, offset=100)


def test_list_albums_page_1_offset_is_zero() -> None:
    """Page 1 should use offset=0."""
    client = _make_client(albums=[])
    settings = _make_settings(albums_per_page=50)
    with patch("subsonic.browse.add_items"), patch("subsonic.browse.end_directory"):
        subsonic.browse.list_albums(
            client=client, settings=settings, handle=1, ltype="newest", page="1"
        )
    client.get_album_list.assert_called_once_with(ltype="newest", size=50, offset=0)


# ---------------------------------------------------------------------------
# list_tracks: tracknumber from playlist position (BUG-03)
# ---------------------------------------------------------------------------


def test_list_tracks_assigns_tracknumber_from_playlist_position() -> None:
    """BUG-03 fix: playlist tracks get track number from their enumerate position."""
    playlist_items = [{"id": str(i), "title": f"Song {i}"} for i in range(5)]
    client = MagicMock()
    client.get_playlist.return_value = {"entry": playlist_items}
    client.get_cover_art_url.return_value = ""
    settings = _make_settings()
    with patch("subsonic.browse.add_items"), patch("subsonic.browse.end_directory"), patch(
        "subsonic.browse.build_track_item"
    ) as mock_builder:  # noqa: E501
        mock_builder.side_effect = lambda t, **kw: (kw.get("url", ""), MagicMock(), False)
        subsonic.browse.list_tracks(client=client, settings=settings, handle=1, playlist_id="42")
    for i, call in enumerate(mock_builder.call_args_list):
        track_arg = call.args[0]
        assert track_arg.get("track") == i + 1, f"track at position {i} should have track={i + 1}"


def test_list_tracks_playlist_no_next_page() -> None:
    """Playlist tracks never show a Next Page link."""
    playlist_items = [{"id": str(i)} for i in range(5)]
    client = MagicMock()
    client.get_playlist.return_value = {"entry": playlist_items}
    client.get_cover_art_url.return_value = ""
    settings = _make_settings(tracks_per_page=3)
    captured: list = []
    with patch("subsonic.browse.add_items") as mock_add, patch(
        "subsonic.browse.end_directory"
    ), patch("subsonic.browse.build_track_item") as mock_builder:  # noqa: E501
        mock_add.side_effect = lambda h, items: captured.extend(items)
        mock_builder.side_effect = lambda t, **kw: (kw.get("url", ""), MagicMock(), False)
        subsonic.browse.list_tracks(client=client, settings=settings, handle=1, playlist_id="42")
    urls = [item[0] if isinstance(item, tuple) else "" for item in captured]
    assert not any("page=" in url for url in urls), "Playlist tracks must not paginate"


def test_list_tracks_random_has_no_next_page() -> None:
    """Random tracks must never show a Next Page link."""
    client = MagicMock()
    client.get_random_songs.return_value = [{"id": str(i)} for i in range(100)]
    client.get_cover_art_url.return_value = ""
    settings = _make_settings(tracks_per_page=100)
    captured: list = []
    with patch("subsonic.browse.add_items") as mock_add, patch(
        "subsonic.browse.end_directory"
    ), patch("subsonic.browse.build_track_item") as mock_builder:  # noqa: E501
        mock_add.side_effect = lambda h, items: captured.extend(items)
        mock_builder.side_effect = lambda t, **kw: (kw.get("url", ""), MagicMock(), False)
        subsonic.browse.list_tracks(
            client=client, settings=settings, handle=1, menu_id="tracks_random"
        )
    urls = [item[0] if isinstance(item, tuple) else "" for item in captured]
    assert not any("page=" in url for url in urls), "Random tracks must never show Next Page"


# ---------------------------------------------------------------------------
# list_artists
# ---------------------------------------------------------------------------


def test_list_artists_calls_get_artists() -> None:
    """list_artists should call client.get_artists() and pass items to listings."""
    artists = [{"id": "1", "name": "The Beatles", "coverArt": "ar-1"}]
    client = MagicMock()
    client.get_artists.return_value = artists
    client.get_cover_art_url.return_value = "http://art"
    settings = _make_settings()
    with patch("subsonic.browse.add_items") as mock_add, patch(
        "subsonic.browse.end_directory"
    ), patch("subsonic.browse.build_artist_item") as mock_builder:  # noqa: E501
        mock_builder.return_value = ("url", MagicMock(), True)
        subsonic.browse.list_artists(client=client, settings=settings, handle=1)
    client.get_artists.assert_called_once()
    mock_builder.assert_called_once()
    mock_add.assert_called_once()


# ---------------------------------------------------------------------------
# Module import hygiene
# ---------------------------------------------------------------------------


def test_browse_module_has_no_xbmcplugin_import() -> None:
    """browse.py must contain no xbmcplugin or xbmcgui imports."""
    src = inspect.getsource(subsonic.browse)
    assert "import xbmcplugin" not in src, "xbmcplugin import found in browse.py"
    assert "import xbmcgui" not in src, "xbmcgui import found in browse.py"


# ---------------------------------------------------------------------------
# Phase 5: list_genres tests (FEAT-01)
# ---------------------------------------------------------------------------


def test_list_genres_calls_get_genres() -> None:
    """list_genres should call client.get_genres() and pass items to listings."""
    genres = [{"value": "Rock", "songCount": 5, "albumCount": 2}]
    client = MagicMock()
    client.get_genres.return_value = genres
    settings = _make_settings()

    with patch("subsonic.browse.add_items") as mock_add, patch(
        "subsonic.browse.end_directory"
    ), patch("subsonic.browse.build_genre_item") as mock_builder:  # noqa: E501
        mock_builder.return_value = ("url", MagicMock(), True)
        subsonic.browse.list_genres(client=client, settings=settings, handle=1)

    client.get_genres.assert_called_once()
    mock_builder.assert_called_once()
    mock_add.assert_called_once()


def test_list_genres_skips_empty_value() -> None:
    """list_genres skips genres that have no 'value' key."""
    genres = [
        {"value": "", "songCount": 0},
        {"songCount": 3},
        {"value": "Jazz", "songCount": 10},
    ]
    client = MagicMock()
    client.get_genres.return_value = genres
    settings = _make_settings()

    with patch("subsonic.browse.add_items"), patch("subsonic.browse.end_directory"), patch(
        "subsonic.browse.build_genre_item"
    ) as mock_builder:  # noqa: E501
        mock_builder.return_value = ("url", MagicMock(), True)
        subsonic.browse.list_genres(client=client, settings=settings, handle=1)

    # Only "Jazz" should be passed through (2 entries skipped)
    assert mock_builder.call_count == 1, "Only genre with non-empty value should build"


def test_list_genres_end_directory_content_genres() -> None:
    """list_genres calls end_directory with content='genres'."""
    client = MagicMock()
    client.get_genres.return_value = []
    settings = _make_settings()

    with patch("subsonic.browse.add_items"), patch("subsonic.browse.end_directory") as mock_end:
        subsonic.browse.list_genres(client=client, settings=settings, handle=1)

    mock_end.assert_called_once()
    assert mock_end.call_args.kwargs.get("content") == "genres" or (
        len(mock_end.call_args.args) > 1 and mock_end.call_args.args[1] == "genres"
    ), "end_directory must be called with content='genres'"


# ---------------------------------------------------------------------------
# Phase 5: list_genre_tracks tests (FEAT-01)
# ---------------------------------------------------------------------------


def test_list_genre_tracks_calls_client() -> None:
    """list_genre_tracks should call client.get_songs_by_genre and pass items."""
    tracks = [{"id": "t1", "title": "Song A", "artist": "Band X"}]
    client = MagicMock()
    client.get_songs_by_genre.return_value = tracks
    client.get_cover_art_url.return_value = ""
    settings = _make_settings()

    with patch("subsonic.browse.add_items") as mock_add, patch(
        "subsonic.browse.end_directory"
    ), patch("subsonic.browse.build_track_item") as mock_builder:  # noqa: E501
        mock_builder.return_value = ("url", MagicMock(), False)
        subsonic.browse.list_genre_tracks(client=client, settings=settings, handle=1, genre="Rock")

    client.get_songs_by_genre.assert_called_once_with("Rock", count=100)
    mock_builder.assert_called_once()
    mock_add.assert_called_once()


def test_list_genre_tracks_empty_genre_fails() -> None:
    """list_genre_tracks with genre='' calls end_directory with succeeded=False."""
    client = MagicMock()
    settings = _make_settings()

    with patch("subsonic.browse.add_items") as mock_add, patch(
        "subsonic.browse.end_directory"
    ) as mock_end:  # noqa: E501
        subsonic.browse.list_genre_tracks(client=client, settings=settings, handle=1, genre="")

    client.get_songs_by_genre.assert_not_called()
    mock_add.assert_not_called()
    mock_end.assert_called_once()
    kwargs = mock_end.call_args
    assert kwargs.kwargs.get("succeeded") is False or (
        len(kwargs.args) > 1 and kwargs.args[1] is False
    ), "end_directory must be called with succeeded=False when genre is empty"


# ---------------------------------------------------------------------------
# Phase 5: list_radio_stations tests (FEAT-04)
# ---------------------------------------------------------------------------


def test_list_radio_stations_builds_nav_items() -> None:
    """list_radio_stations builds a nav item for each station with a streamUrl."""
    stations = [{"id": "1", "name": "Radio X", "streamUrl": "http://radio.x/stream"}]
    client = MagicMock()
    client.get_internet_radio_stations.return_value = stations
    settings = _make_settings()

    captured: list = []
    with patch("subsonic.browse.add_items") as mock_add, patch(
        "subsonic.browse.end_directory"
    ), patch("subsonic.browse.build_nav_item") as mock_builder:  # noqa: E501
        mock_builder.return_value = ("url", MagicMock(), True)
        mock_add.side_effect = lambda h, items: captured.extend(items)
        subsonic.browse.list_radio_stations(client=client, settings=settings, handle=1)

    mock_builder.assert_called_once()
    assert len(captured) == 1, "Expected 1 radio station item"


def test_list_radio_stations_skips_missing_url() -> None:
    """list_radio_stations skips stations that have no streamUrl."""
    stations = [
        {"id": "1", "name": "No URL Station"},
        {"id": "2", "name": "Good Station", "streamUrl": "http://good.com/stream"},
    ]
    client = MagicMock()
    client.get_internet_radio_stations.return_value = stations
    settings = _make_settings()

    with patch("subsonic.browse.add_items"), patch("subsonic.browse.end_directory"), patch(
        "subsonic.browse.build_nav_item"
    ) as mock_builder:  # noqa: E501
        mock_builder.return_value = ("url", MagicMock(), True)
        subsonic.browse.list_radio_stations(client=client, settings=settings, handle=1)

    # Only the station with streamUrl should be built
    assert mock_builder.call_count == 1, "Station without streamUrl must be skipped"


def test_list_radio_stations_empty_is_graceful() -> None:
    """list_radio_stations with empty list calls add_items([]) and ends directory."""
    client = MagicMock()
    client.get_internet_radio_stations.return_value = []
    settings = _make_settings()

    with patch("subsonic.browse.add_items") as mock_add, patch(
        "subsonic.browse.end_directory"
    ) as mock_end:  # noqa: E501
        subsonic.browse.list_radio_stations(client=client, settings=settings, handle=1)

    mock_add.assert_called_once()
    mock_end.assert_called_once()


def test_browse_root_has_genres_and_internet_radio() -> None:
    """root menu must contain 'Genres' and 'Internet Radio' entries."""
    src = inspect.getsource(subsonic.browse)
    assert "Genres" in src, "'Genres' entry not found in browse.py root"
    assert "Internet Radio" in src, "'Internet Radio' entry not found in browse.py root"
