"""
Tests for subsonic.actions — star_item cache invalidation, Container.Refresh,
and _parse_bool_param URL param parsing.

BUG-05 coverage: cache.invalidate('starred') and xbmc.executebuiltin('Container.Refresh')
BUG-03 coverage: _parse_bool_param handles all legacy string variants from URL params
"""

from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LIB = os.path.join(_REPO, "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

import subsonic.actions as _actions_mod
import xbmc
from subsonic.actions import _parse_bool_param, rate_track, star_item


def _make_deps(star_success: bool = True):
    """Return (client, settings, cache) mocks for action handler tests."""
    client = MagicMock()
    client.star.return_value = star_success
    client.unstar.return_value = star_success
    settings = MagicMock()
    cache = MagicMock()
    return client, settings, cache


# ---------------------------------------------------------------------------
# _parse_bool_param tests (BUG-03: unstar param parsing)
# ---------------------------------------------------------------------------


def test_parse_bool_param_handles_none_and_strings():
    """_parse_bool_param correctly handles all variants from URL params.

    Original broken code (main.py:684): (unstar) and (unstar != 'None') and (unstar != 'False')
    That fails for: unstar='True' (True), unstar='1' (False — '1' != 'None' but '1' is truthy... wait
    actually the original code returns '1' which is truthy, only breaks on 'False'/'None' edge cases).
    New code handles all cases via lowercase membership test.
    """
    # truthy values
    assert _parse_bool_param("1") is True
    assert _parse_bool_param("true") is True
    assert _parse_bool_param("True") is True
    assert _parse_bool_param("yes") is True
    # falsy values — these are the cases the old code got wrong
    assert _parse_bool_param("false") is False
    assert _parse_bool_param("False") is False
    assert _parse_bool_param("None") is False
    assert _parse_bool_param("") is False
    assert _parse_bool_param("0") is False


# ---------------------------------------------------------------------------
# star_item BUG-05 tests: cache invalidation and Container.Refresh
# ---------------------------------------------------------------------------


def test_star_item_invalidates_cache(monkeypatch):
    """star_item calls cache.invalidate('starred') after a successful star (BUG-05)."""
    client, settings, cache = _make_deps(star_success=True)
    monkeypatch.setattr(xbmc, "executebuiltin", MagicMock())

    star_item(
        client=client,
        settings=settings,
        handle=1,
        cache=cache,
        id="42",
        type="track",
        unstar="false",
    )

    cache.invalidate.assert_called_once_with("starred")


def test_star_item_calls_container_refresh(monkeypatch):
    """star_item calls xbmc.executebuiltin('Container.Refresh') after success (BUG-05)."""
    client, settings, cache = _make_deps(star_success=True)
    mock_builtin = MagicMock()
    monkeypatch.setattr(xbmc, "executebuiltin", mock_builtin)

    star_item(
        client=client,
        settings=settings,
        handle=1,
        cache=cache,
        id="42",
        type="track",
        unstar="false",
    )

    mock_builtin.assert_called_once_with("Container.Refresh")


def test_star_item_no_invalidate_on_failure(monkeypatch):
    """star_item does NOT call cache.invalidate when star returns False."""
    client, settings, cache = _make_deps(star_success=False)
    monkeypatch.setattr(xbmc, "executebuiltin", MagicMock())

    star_item(
        client=client,
        settings=settings,
        handle=1,
        cache=cache,
        id="42",
        type="track",
        unstar="false",
    )

    cache.invalidate.assert_not_called()


def test_star_item_no_container_refresh_on_failure(monkeypatch):
    """star_item does NOT call Container.Refresh when star returns False."""
    client, settings, cache = _make_deps(star_success=False)
    mock_builtin = MagicMock()
    monkeypatch.setattr(xbmc, "executebuiltin", mock_builtin)

    star_item(
        client=client,
        settings=settings,
        handle=1,
        cache=cache,
        id="42",
        type="track",
        unstar="false",
    )

    mock_builtin.assert_not_called()


def test_star_item_unstar_uses_client_unstar(monkeypatch):
    """star_item with unstar='true' calls client.unstar, not client.star."""
    client, settings, cache = _make_deps(star_success=True)
    monkeypatch.setattr(xbmc, "executebuiltin", MagicMock())

    star_item(
        client=client,
        settings=settings,
        handle=1,
        cache=cache,
        id="42",
        type="track",
        unstar="true",
    )

    client.unstar.assert_called_once()
    client.star.assert_not_called()


def test_star_item_unstar_false_uses_client_star(monkeypatch):
    """star_item with unstar='false' calls client.star, not client.unstar."""
    client, settings, cache = _make_deps(star_success=True)
    monkeypatch.setattr(xbmc, "executebuiltin", MagicMock())

    star_item(
        client=client,
        settings=settings,
        handle=1,
        cache=cache,
        id="42",
        type="track",
        unstar="false",
    )

    client.star.assert_called_once()
    client.unstar.assert_not_called()


def test_star_item_no_id_is_noop(monkeypatch):
    """star_item with empty id does nothing (early return)."""
    client, settings, cache = _make_deps(star_success=True)
    monkeypatch.setattr(xbmc, "executebuiltin", MagicMock())

    star_item(
        client=client,
        settings=settings,
        handle=1,
        cache=cache,
        id="",
        type="track",
        unstar="false",
    )

    client.star.assert_not_called()
    client.unstar.assert_not_called()
    cache.invalidate.assert_not_called()


def test_star_item_album_type_uses_album_ids(monkeypatch):
    """star_item with type='album' passes album_ids to client.star."""
    client, settings, cache = _make_deps(star_success=True)
    monkeypatch.setattr(xbmc, "executebuiltin", MagicMock())

    star_item(
        client=client,
        settings=settings,
        handle=1,
        cache=cache,
        id="99",
        type="album",
        unstar="false",
    )

    client.star.assert_called_once_with(
        song_ids=None,
        album_ids=["99"],
        artist_ids=None,
    )


def test_star_item_exception_does_not_invalidate_cache(monkeypatch):
    """star_item does not call cache.invalidate when client raises an exception."""
    client, settings, cache = _make_deps()
    client.star.side_effect = RuntimeError("network error")
    monkeypatch.setattr(xbmc, "executebuiltin", MagicMock())

    # Should not raise
    star_item(
        client=client,
        settings=settings,
        handle=1,
        cache=cache,
        id="42",
        type="track",
        unstar="false",
    )

    cache.invalidate.assert_not_called()


def test_unstar_invalidates_cache(monkeypatch):
    """unstar also triggers cache.invalidate('starred') after success (BUG-05)."""
    client, settings, cache = _make_deps(star_success=True)
    monkeypatch.setattr(xbmc, "executebuiltin", MagicMock())

    star_item(
        client=client,
        settings=settings,
        handle=1,
        cache=cache,
        id="42",
        type="track",
        unstar="True",  # BUG-03: legacy 'True' string must work
    )

    client.unstar.assert_called_once()
    cache.invalidate.assert_called_once_with("starred")


# ---------------------------------------------------------------------------
# rate_track tests (FEAT-03)
# ---------------------------------------------------------------------------


def test_rate_track_calls_set_rating(monkeypatch) -> None:
    """rate_track calls client.set_rating with the selected rating."""
    client = MagicMock()
    client.set_rating.return_value = True
    settings = MagicMock()
    cache = MagicMock()
    monkeypatch.setattr(xbmc, "executebuiltin", MagicMock())
    monkeypatch.setattr(_actions_mod, "show_rating_select", lambda track_id: 3)

    rate_track(client=client, settings=settings, handle=1, cache=cache, id="99")

    client.set_rating.assert_called_once_with(item_id="99", rating=3)


def test_rate_track_cancelled_is_noop(monkeypatch) -> None:
    """rate_track does nothing when show_rating_select returns None (user cancelled)."""
    client = MagicMock()
    settings = MagicMock()
    cache = MagicMock()
    monkeypatch.setattr(_actions_mod, "show_rating_select", lambda track_id: None)

    rate_track(client=client, settings=settings, handle=1, cache=cache, id="99")

    client.set_rating.assert_not_called()


def test_rate_track_no_id_is_noop(monkeypatch) -> None:
    """rate_track does nothing when id is empty."""
    client = MagicMock()
    settings = MagicMock()
    cache = MagicMock()
    mock_select = MagicMock()
    monkeypatch.setattr(_actions_mod, "show_rating_select", mock_select)

    rate_track(client=client, settings=settings, handle=1, cache=cache, id="")

    mock_select.assert_not_called()
    client.set_rating.assert_not_called()


def test_rate_track_success_invalidates_cache(monkeypatch) -> None:
    """rate_track calls cache.invalidate('starred') on successful set_rating."""
    client = MagicMock()
    client.set_rating.return_value = True
    settings = MagicMock()
    cache = MagicMock()
    monkeypatch.setattr(xbmc, "executebuiltin", MagicMock())
    monkeypatch.setattr(_actions_mod, "show_rating_select", lambda track_id: 4)

    rate_track(client=client, settings=settings, handle=1, cache=cache, id="77")

    cache.invalidate.assert_called_once_with("starred")


def test_rate_track_success_refreshes_container(monkeypatch) -> None:
    """rate_track calls xbmc.executebuiltin('Container.Refresh') on success."""
    client = MagicMock()
    client.set_rating.return_value = True
    settings = MagicMock()
    cache = MagicMock()
    mock_builtin = MagicMock()
    monkeypatch.setattr(xbmc, "executebuiltin", mock_builtin)
    monkeypatch.setattr(_actions_mod, "show_rating_select", lambda track_id: 5)

    rate_track(client=client, settings=settings, handle=1, cache=cache, id="55")

    mock_builtin.assert_called_once_with("Container.Refresh")


def test_rate_track_failure_does_not_invalidate_cache(monkeypatch) -> None:
    """rate_track does not invalidate cache when set_rating returns False."""
    client = MagicMock()
    client.set_rating.return_value = False
    settings = MagicMock()
    cache = MagicMock()
    monkeypatch.setattr(xbmc, "executebuiltin", MagicMock())
    monkeypatch.setattr(_actions_mod, "show_rating_select", lambda track_id: 2)

    rate_track(client=client, settings=settings, handle=1, cache=cache, id="33")

    cache.invalidate.assert_not_called()


def test_rate_track_actions_has_no_xbmcgui_import() -> None:
    """actions.py must not import xbmcgui directly (ARCH-05)."""
    import inspect

    src = inspect.getsource(_actions_mod)
    assert "import xbmcgui" not in src, "xbmcgui import found in actions.py (ARCH-05)"
