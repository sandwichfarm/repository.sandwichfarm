"""Tests for subsonic.bootstrap._check_insecure_ssl_acknowledgement (AUTH-07)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from subsonic.bootstrap import _check_insecure_ssl_acknowledgement
from subsonic.settings import Settings


def _make_settings(insecure: str = "false", acknowledged: str = "false") -> Settings:
    """Return a Settings instance backed by a MagicMock addon.

    Parameters
    ----------
    insecure:     raw value for the 'insecure' setting ("true"/"false").
    acknowledged: raw value for 'insecure_ssl_acknowledged' ("true"/"false").
    """
    addon = MagicMock()
    store: dict[str, str] = {
        "insecure": insecure,
        "insecure_ssl_acknowledged": acknowledged,
    }
    addon.getSetting.side_effect = lambda k: store.get(k, "false")
    addon.setSetting = MagicMock()
    return Settings(addon=addon)


def test_insecure_ssl_gate_no_dialog_when_insecure_false() -> None:
    """Dialog must NOT appear when insecure SSL is disabled."""
    settings = _make_settings(insecure="false", acknowledged="false")
    with patch("subsonic.bootstrap.xbmcgui") as mock_gui:
        _check_insecure_ssl_acknowledgement(settings)
        mock_gui.Dialog.return_value.yesno.assert_not_called()


def test_insecure_ssl_gate_no_dialog_when_already_acknowledged() -> None:
    """Dialog must NOT appear when insecure SSL is enabled but already acknowledged."""
    settings = _make_settings(insecure="true", acknowledged="true")
    with patch("subsonic.bootstrap.xbmcgui") as mock_gui:
        _check_insecure_ssl_acknowledgement(settings)
        mock_gui.Dialog.return_value.yesno.assert_not_called()


def test_insecure_ssl_first_enable_shows_dialog_accept() -> None:
    """On first enable + user accepts: acknowledge persisted; insecure NOT reverted."""
    settings = _make_settings(insecure="true", acknowledged="false")
    with patch("subsonic.bootstrap.xbmcgui") as mock_gui:
        mock_gui.Dialog.return_value.yesno.return_value = True
        _check_insecure_ssl_acknowledgement(settings)
        mock_gui.Dialog.return_value.yesno.assert_called_once()
        call_args = settings._addon.setSetting.call_args_list
        ids_set = {c.args[0] for c in call_args}
        assert "insecure_ssl_acknowledged" in ids_set, (
            "set_insecure_ssl_acknowledged should have been called on Accept"
        )
        assert "insecure" not in ids_set, "insecure setting must NOT be reverted when user accepts"


def test_insecure_ssl_first_enable_shows_dialog_decline() -> None:
    """On first enable + user declines: insecure reverted to false; acknowledged NOT set."""
    settings = _make_settings(insecure="true", acknowledged="false")
    with patch("subsonic.bootstrap.xbmcgui") as mock_gui:
        mock_gui.Dialog.return_value.yesno.return_value = False
        _check_insecure_ssl_acknowledgement(settings)
        mock_gui.Dialog.return_value.yesno.assert_called_once()
        call_args = settings._addon.setSetting.call_args_list
        ids_set = {c.args[0] for c in call_args}
        assert "insecure" in ids_set, "set_insecure_ssl(False) should have been called on Decline"
        assert "insecure_ssl_acknowledged" not in ids_set, (
            "insecure_ssl_acknowledged must NOT be set when user declines"
        )
