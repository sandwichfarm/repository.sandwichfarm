from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock

import pytest

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LIB = os.path.join(_REPO, "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

from subsonic.router import PLUGIN_ID, clear_routes, dispatch, route, set_routes, url_for


def setup_function():
    """Clear routes before each test to avoid cross-test pollution."""
    clear_routes()


def test_route_decorator_registers_handler():
    handler = MagicMock()

    @route("root")
    def root_fn():
        handler()

    dispatch(["plugin://plugin.audio.subsonic/", "1", "?action=root"])
    handler.assert_called_once()


def test_route_decorator_is_transparent():
    """@route must return the original function unchanged."""

    def my_fn():
        return 42

    wrapped = route("my_action")(my_fn)
    assert wrapped is my_fn
    assert wrapped() == 42


def test_dispatch_passes_extra_params_as_kwargs():
    received = {}

    @route("list_albums")
    def list_albums_fn(page: str = "1", type: str = "newest", **kw: str):
        received.update(page=page, type=type)

    dispatch(["plugin://...", "1", "?action=list_albums&page=3&type=random"])
    assert received == {"page": "3", "type": "random"}


def test_dispatch_defaults_to_root_when_no_action():
    called = MagicMock()

    @route("root")
    def root_fn():
        called()

    dispatch(["plugin://...", "1", ""])
    called.assert_called_once()


def test_dispatch_raises_for_unknown_action():
    with pytest.raises(ValueError, match="No handler registered"):
        dispatch(["plugin://...", "1", "?action=does_not_exist"])


def test_url_for_basic():
    result = url_for("list_albums")
    assert result == f"plugin://{PLUGIN_ID}/?action=list_albums"


def test_url_for_with_params():
    result = url_for("list_albums", page="2", type="newest")
    assert "action=list_albums" in result
    assert "page=2" in result
    assert "type=newest" in result
    assert result.startswith(f"plugin://{PLUGIN_ID}/")


def test_url_for_encodes_special_chars():
    result = url_for("search", query="rock & roll")
    assert "rock+%26+roll" in result or "rock%20%26%20roll" in result or "rock+%26" in result
    assert "rock & roll" not in result  # must be encoded


def test_multiple_routes_dispatch_correctly():
    handler_a = MagicMock()
    handler_b = MagicMock()

    @route("action_a")
    def fn_a():
        handler_a()

    @route("action_b")
    def fn_b():
        handler_b()

    dispatch(["p", "1", "?action=action_a"])
    dispatch(["p", "1", "?action=action_b"])

    handler_a.assert_called_once()
    handler_b.assert_called_once()


def test_set_routes_round_trips():
    """set_routes() replaces _ROUTES; dispatch uses the new handlers (B4 fix)."""
    original = MagicMock()
    wrapped = MagicMock()

    @route("my_action")
    def original_fn():
        original()

    # Snapshot and wrap (simulates what bootstrap._patch_routes_with_context does)
    from subsonic.router import _ROUTES  # noqa: F401

    set_routes({"my_action": wrapped})

    dispatch(["p", "1", "?action=my_action"])

    original.assert_not_called()
    wrapped.assert_called_once()


def test_set_routes_clears_previous_routes():
    """set_routes with a new dict removes routes not in the dict."""
    called = MagicMock()

    @route("old_action")
    def old_fn():
        called()

    set_routes({"new_action": MagicMock()})

    with pytest.raises(ValueError, match="No handler registered"):
        dispatch(["p", "1", "?action=old_action"])
