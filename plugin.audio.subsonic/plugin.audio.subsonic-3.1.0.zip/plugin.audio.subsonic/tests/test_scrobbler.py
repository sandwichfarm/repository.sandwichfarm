"""
Tests for subsonic.scrobbler.Scrobbler.

Covers:
- _extract_track_id URL parsing (valid, invalid, wrong action, empty)
- 50% progress trigger (direct state assertion)
- Dedup logic — scrobble does NOT fire again when _scrobbled is True
- Reset when progress drops below 50%
- Reset when track ID changes
- client.scrobble called with correct track ID
- onSettingsChanged refreshes Settings instance
"""

from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock, patch

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LIB = os.path.join(_REPO, "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

# xbmc.Monitor is a MagicMock from conftest. That means Scrobbler's class body
# would inherit from a MagicMock and all instances would become mocks themselves.
# Replace xbmc.Monitor with a real no-op class so Scrobbler can be subclassed
# normally. Must be done before importing scrobbler so the class definition
# captures the correct base class.
import xbmc

xbmc.Monitor = type(
    "Monitor",
    (),
    {
        "__init__": lambda self: None,
        "abortRequested": lambda self: False,
        "waitForAbort": lambda self, timeout=1: False,
    },
)  # type: ignore[assignment]

from subsonic.scrobbler import Scrobbler  # noqa: E402


def _make_scrobbler() -> Scrobbler:
    client = MagicMock()
    client.scrobble.return_value = True
    settings = MagicMock()
    return Scrobbler(client=client, settings=settings)


# ---------------------------------------------------------------------------
# URL extraction tests
# ---------------------------------------------------------------------------


def test_extract_track_id_valid():
    """Valid Subsonic play_track URL returns the track id."""
    s = _make_scrobbler()
    url = "plugin://plugin.audio.subsonic/?action=play_track&id=42&estimateContentLength=1"
    assert s._extract_track_id(url) == "42"


def test_extract_track_id_non_subsonic():
    """Non-Subsonic plugin URL returns empty string."""
    s = _make_scrobbler()
    url = "plugin://plugin.video.youtube/?action=play&videoid=abc"
    assert s._extract_track_id(url) == ""


def test_extract_track_id_wrong_action():
    """Subsonic URL with non-play_track action returns empty string."""
    s = _make_scrobbler()
    url = "plugin://plugin.audio.subsonic/?action=list_albums&page=1"
    assert s._extract_track_id(url) == ""


def test_extract_track_id_empty_string():
    """Empty URL returns empty string (no exception)."""
    s = _make_scrobbler()
    assert s._extract_track_id("") == ""


def test_extract_track_id_param_order_insensitive():
    """parse_qs handles any param order — id before action still works."""
    s = _make_scrobbler()
    url = "plugin://plugin.audio.subsonic/?id=55&action=play_track&fmt=mp3"
    assert s._extract_track_id(url) == "55"


def test_extract_track_id_no_id_param():
    """play_track URL missing id param returns empty string."""
    s = _make_scrobbler()
    url = "plugin://plugin.audio.subsonic/?action=play_track"
    assert s._extract_track_id(url) == ""


# ---------------------------------------------------------------------------
# Scrobble logic tests (direct state manipulation — no real monitor loop)
# ---------------------------------------------------------------------------


def test_scrobble_fires_at_50_percent():
    """When progress >= 50 and _scrobbled is False, scrobble is called."""
    s = _make_scrobbler()
    s._current_track_id = "99"
    s._scrobbled = False

    # Simulate the scrobble path directly (mirrors the run() loop logic)
    progress = 50
    if progress >= 50 and not s._scrobbled:
        success = s._client.scrobble("99")
        if success:
            s._scrobbled = True

    assert s._scrobbled is True
    s._client.scrobble.assert_called_once_with("99")


def test_scrobble_dedup_does_not_fire_twice():
    """When _scrobbled is True, the guard prevents a second scrobble call."""
    s = _make_scrobbler()
    s._current_track_id = "99"
    s._scrobbled = True  # already scrobbled

    progress = 75
    # Guard: only scrobble if not already done
    should_scrobble = progress >= 50 and not s._scrobbled
    assert should_scrobble is False
    s._client.scrobble.assert_not_called()


def test_scrobble_reset_on_low_progress():
    """Progress dropping below 50% resets _scrobbled so replay fires again."""
    s = _make_scrobbler()
    s._scrobbled = True

    progress = 30
    if progress < 50:
        s._scrobbled = False

    assert s._scrobbled is False


def test_scrobble_reset_on_track_change():
    """Changing to a different track resets _scrobbled and updates _current_track_id."""
    s = _make_scrobbler()
    s._current_track_id = "old-id"
    s._scrobbled = True

    new_track_id = "new-id"
    # Simulate track change detection from run() loop
    if new_track_id != s._current_track_id:
        s._scrobbled = False
        s._current_track_id = new_track_id

    assert s._scrobbled is False
    assert s._current_track_id == "new-id"


def test_scrobble_client_called_with_correct_id():
    """client.scrobble receives exactly the extracted track id."""
    s = _make_scrobbler()
    track_id = "track-abc-123"
    s._current_track_id = track_id
    s._scrobbled = False

    progress = 65
    if progress >= 50 and not s._scrobbled:
        s._client.scrobble(track_id)
        s._scrobbled = True

    s._client.scrobble.assert_called_once_with("track-abc-123")


def test_scrobble_scrobbled_stays_false_on_client_failure():
    """If client.scrobble returns False, _scrobbled remains False for retry."""
    s = _make_scrobbler()
    s._client.scrobble.return_value = False
    s._current_track_id = "fail-track"
    s._scrobbled = False

    progress = 80
    if progress >= 50 and not s._scrobbled:
        success = s._client.scrobble("fail-track")
        if success:
            s._scrobbled = True

    assert s._scrobbled is False  # stays False — can retry next poll


# ---------------------------------------------------------------------------
# onSettingsChanged
# ---------------------------------------------------------------------------


def test_on_settings_changed_refreshes_settings():
    """onSettingsChanged replaces _settings with a new Settings instance.

    onSettingsChanged does a local import (from subsonic.settings import Settings)
    inside the method body, so we patch subsonic.settings.Settings rather than a
    module-level attribute of scrobbler.
    """
    s = _make_scrobbler()
    original_settings = s._settings
    new_settings = MagicMock()

    # Patch the class in the subsonic.settings module — that's where the
    # local import inside onSettingsChanged will resolve.
    with patch("subsonic.settings.Settings", return_value=new_settings):
        s.onSettingsChanged()

    assert s._settings is new_settings
    assert s._settings is not original_settings
