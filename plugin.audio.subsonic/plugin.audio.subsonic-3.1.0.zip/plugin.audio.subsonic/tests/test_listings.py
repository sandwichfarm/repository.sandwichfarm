"""
Unit tests for subsonic.listings — ListItem builders, directory helpers,
and show_search_dialog UI helper.

Tests verify:
- All item builders use getMusicInfoTag() typed setters, NOT setInfo('music', ...)
- end_directory calls setContent, addSortMethod, endOfDirectory
- add_items calls addDirectoryItem for each item
- show_search_dialog returns user input or None on empty/cancel
"""

from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LIB = os.path.join(_REPO, "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

import xbmc  # noqa: F401 — imported by conftest; here for clarity
import xbmcgui
import xbmcplugin
from subsonic.listings import (
    add_items,
    build_album_item,
    build_artist_item,
    build_genre_item,
    build_track_item,
    end_directory,
    show_rating_select,
    show_search_dialog,
)


def _mock_list_item() -> MagicMock:
    li = MagicMock()
    li.getMusicInfoTag.return_value = MagicMock()
    return li


# ---------------------------------------------------------------------------
# build_track_item
# ---------------------------------------------------------------------------


def test_build_track_uses_get_music_info_tag(monkeypatch: object) -> None:
    mock_li = _mock_list_item()
    monkeypatch.setattr(xbmcgui, "ListItem", MagicMock(return_value=mock_li))
    track = {
        "id": "1",
        "title": "Song",
        "artist": "Artist",
        "album": "Album",
        "duration": 180,
        "track": 3,
        "year": 2020,
    }
    build_track_item(track, url="plugin://...?action=play_track&id=1")
    mock_li.getMusicInfoTag.assert_called_once()
    tag = mock_li.getMusicInfoTag.return_value
    tag.setTitle.assert_called_once_with("Song")
    tag.setArtist.assert_called_once_with("Artist")
    tag.setAlbum.assert_called_once_with("Album")
    tag.setDuration.assert_called_once_with(180)
    tag.setTrackNumber.assert_called_once_with(3)


def test_build_track_does_not_call_setInfo(monkeypatch: object) -> None:
    mock_li = _mock_list_item()
    monkeypatch.setattr(xbmcgui, "ListItem", MagicMock(return_value=mock_li))
    track = {"id": "1", "title": "Song", "artist": "A"}
    build_track_item(track, url="plugin://...")
    mock_li.setInfo.assert_not_called()


def test_build_track_sets_art_with_cover(monkeypatch: object) -> None:
    mock_li = _mock_list_item()
    monkeypatch.setattr(xbmcgui, "ListItem", MagicMock(return_value=mock_li))
    track = {"id": "1", "title": "Song"}
    build_track_item(track, url="p://", cover_url="http://server/art?size=512")
    mock_li.setArt.assert_called_once_with(
        {
            "thumb": "http://server/art?size=512",
            "fanart": "http://server/art?size=512",
        }
    )


def test_build_track_returns_not_folder(monkeypatch: object) -> None:
    mock_li = _mock_list_item()
    monkeypatch.setattr(xbmcgui, "ListItem", MagicMock(return_value=mock_li))
    track = {"id": "1", "title": "Song"}
    url, li, is_folder = build_track_item(track, url="plugin://...")
    assert is_folder is False
    assert url == "plugin://..."


# ---------------------------------------------------------------------------
# build_album_item
# ---------------------------------------------------------------------------


def test_build_album_item_uses_info_tag(monkeypatch: object) -> None:
    mock_li = _mock_list_item()
    monkeypatch.setattr(xbmcgui, "ListItem", MagicMock(return_value=mock_li))
    album = {"id": "2", "name": "Album", "artist": "Artist", "year": 2021}
    build_album_item(album, url="plugin://...?action=list_albums&album_id=2")
    mock_li.getMusicInfoTag.assert_called_once()
    tag = mock_li.getMusicInfoTag.return_value
    tag.setTitle.assert_called_once_with("Album")
    tag.setArtist.assert_called_once_with("Artist")


def test_build_album_item_returns_folder(monkeypatch: object) -> None:
    mock_li = _mock_list_item()
    monkeypatch.setattr(xbmcgui, "ListItem", MagicMock(return_value=mock_li))
    album = {"id": "2", "name": "Album"}
    _, _, is_folder = build_album_item(album, url="plugin://...")
    assert is_folder is True


# ---------------------------------------------------------------------------
# build_artist_item
# ---------------------------------------------------------------------------


def test_build_artist_item_sets_artist(monkeypatch: object) -> None:
    mock_li = _mock_list_item()
    monkeypatch.setattr(xbmcgui, "ListItem", MagicMock(return_value=mock_li))
    artist = {"id": "3", "name": "The Artist"}
    url, li, is_folder = build_artist_item(
        artist, url="plugin://...?action=list_albums&artist_id=3"
    )
    assert is_folder is True
    tag = mock_li.getMusicInfoTag.return_value
    tag.setArtist.assert_called_once_with("The Artist")


# ---------------------------------------------------------------------------
# end_directory
# ---------------------------------------------------------------------------


def test_end_directory_calls_set_content(monkeypatch: object) -> None:
    monkeypatch.setattr(xbmcplugin, "setContent", MagicMock())
    monkeypatch.setattr(xbmcplugin, "addSortMethod", MagicMock())
    monkeypatch.setattr(xbmcplugin, "endOfDirectory", MagicMock())
    end_directory(handle=1, content="albums")
    xbmcplugin.setContent.assert_called_once_with(1, "albums")


def test_end_directory_calls_add_sort_method(monkeypatch: object) -> None:
    monkeypatch.setattr(xbmcplugin, "setContent", MagicMock())
    monkeypatch.setattr(xbmcplugin, "addSortMethod", MagicMock())
    monkeypatch.setattr(xbmcplugin, "endOfDirectory", MagicMock())
    end_directory(handle=1, content="songs", sort_methods=[0, 1])
    assert xbmcplugin.addSortMethod.call_count == 2


def test_end_directory_calls_end_of_directory(monkeypatch: object) -> None:
    monkeypatch.setattr(xbmcplugin, "setContent", MagicMock())
    monkeypatch.setattr(xbmcplugin, "addSortMethod", MagicMock())
    monkeypatch.setattr(xbmcplugin, "endOfDirectory", MagicMock())
    end_directory(handle=42, content="songs", succeeded=True)
    xbmcplugin.endOfDirectory.assert_called_once()
    call_args = xbmcplugin.endOfDirectory.call_args[0]
    assert call_args[0] == 42


def test_end_directory_no_sort_methods_by_default(monkeypatch: object) -> None:
    monkeypatch.setattr(xbmcplugin, "setContent", MagicMock())
    monkeypatch.setattr(xbmcplugin, "addSortMethod", MagicMock())
    monkeypatch.setattr(xbmcplugin, "endOfDirectory", MagicMock())
    end_directory(handle=1, content="songs")
    xbmcplugin.addSortMethod.assert_not_called()


# ---------------------------------------------------------------------------
# add_items
# ---------------------------------------------------------------------------


def test_add_items_calls_add_directory_item(monkeypatch: object) -> None:
    monkeypatch.setattr(xbmcplugin, "addDirectoryItem", MagicMock())
    li1 = MagicMock()
    li2 = MagicMock()
    items = [("url1", li1, True), ("url2", li2, False)]
    add_items(handle=1, items=items)
    assert xbmcplugin.addDirectoryItem.call_count == 2


def test_add_items_passes_correct_args(monkeypatch: object) -> None:
    monkeypatch.setattr(xbmcplugin, "addDirectoryItem", MagicMock())
    li = MagicMock()
    add_items(handle=5, items=[("my_url", li, True)])
    xbmcplugin.addDirectoryItem.assert_called_once_with(5, "my_url", li, True)


# ---------------------------------------------------------------------------
# Source inspection: no setInfo('music', ...) in listings.py
# ---------------------------------------------------------------------------


def test_no_setinfo_music_in_listings_module() -> None:
    """Ensure listings.py does not contain setInfo('music', ...) calls."""
    import inspect

    import subsonic.listings as mod

    src = inspect.getsource(mod)
    assert "setInfo('music'" not in src
    assert 'setInfo("music"' not in src


# ---------------------------------------------------------------------------
# show_search_dialog
# ---------------------------------------------------------------------------


def test_show_search_dialog_returns_query(monkeypatch: object) -> None:
    """show_search_dialog returns user input string when non-empty."""
    mock_dialog = MagicMock()
    mock_dialog.input.return_value = "rock music"
    monkeypatch.setattr(xbmcgui, "Dialog", MagicMock(return_value=mock_dialog))
    result = show_search_dialog("Search")
    assert result == "rock music"
    mock_dialog.input.assert_called_once_with("Search", type=xbmcgui.INPUT_ALPHANUM)


def test_show_search_dialog_returns_none_on_empty(monkeypatch: object) -> None:
    """show_search_dialog returns None when user cancels or enters nothing."""
    mock_dialog = MagicMock()
    mock_dialog.input.return_value = ""
    monkeypatch.setattr(xbmcgui, "Dialog", MagicMock(return_value=mock_dialog))
    result = show_search_dialog("Search")
    assert result is None


# ---------------------------------------------------------------------------
# show_rating_select
# ---------------------------------------------------------------------------


def test_show_rating_select_returns_rating(monkeypatch: object) -> None:
    """Dialog().select returning index 2 maps to rating 3."""
    mock_dialog = MagicMock()
    mock_dialog.select.return_value = 2  # "3 Stars"
    monkeypatch.setattr(xbmcgui, "Dialog", MagicMock(return_value=mock_dialog))
    result = show_rating_select("track-1")
    assert result == 3


def test_show_rating_select_clear(monkeypatch: object) -> None:
    """Dialog().select returning index 5 ("Clear Rating") maps to rating 0."""
    mock_dialog = MagicMock()
    mock_dialog.select.return_value = 5  # "Clear Rating"
    monkeypatch.setattr(xbmcgui, "Dialog", MagicMock(return_value=mock_dialog))
    result = show_rating_select("track-2")
    assert result == 0


def test_show_rating_select_cancel(monkeypatch: object) -> None:
    """Dialog().select returning -1 (cancel) returns None."""
    mock_dialog = MagicMock()
    mock_dialog.select.return_value = -1
    monkeypatch.setattr(xbmcgui, "Dialog", MagicMock(return_value=mock_dialog))
    result = show_rating_select("track-3")
    assert result is None


def test_show_rating_select_first_star(monkeypatch: object) -> None:
    """Dialog().select returning 0 ("1 Star") maps to rating 1."""
    mock_dialog = MagicMock()
    mock_dialog.select.return_value = 0
    monkeypatch.setattr(xbmcgui, "Dialog", MagicMock(return_value=mock_dialog))
    result = show_rating_select("track-4")
    assert result == 1


# ---------------------------------------------------------------------------
# build_genre_item
# ---------------------------------------------------------------------------


def test_build_genre_item_label(monkeypatch: object) -> None:
    """build_genre_item produces label '{name} ({songCount} songs)'."""
    mock_li = _mock_list_item()
    monkeypatch.setattr(xbmcgui, "ListItem", MagicMock(return_value=mock_li))
    genre = {"value": "Rock", "songCount": 5, "albumCount": 2}
    url, li, is_folder = build_genre_item(genre, "plugin://...?action=genre_tracks&genre=Rock")
    assert li is mock_li
    assert is_folder is True
    xbmcgui.ListItem.assert_called_once_with(label="Rock (5 songs)", offscreen=True)


def test_build_genre_item_unknown_name(monkeypatch: object) -> None:
    """build_genre_item falls back to '<Unknown>' when value is absent."""
    mock_li = _mock_list_item()
    monkeypatch.setattr(xbmcgui, "ListItem", MagicMock(return_value=mock_li))
    genre = {"songCount": 3}
    build_genre_item(genre, "plugin://...?genre=")
    xbmcgui.ListItem.assert_called_once_with(label="<Unknown> (3 songs)", offscreen=True)


def test_build_genre_item_returns_url(monkeypatch: object) -> None:
    """build_genre_item returns the url as the first element of the tuple."""
    mock_li = _mock_list_item()
    monkeypatch.setattr(xbmcgui, "ListItem", MagicMock(return_value=mock_li))
    genre = {"value": "Jazz", "songCount": 10}
    result_url, _, _ = build_genre_item(genre, "plugin://jazz-url")
    assert result_url == "plugin://jazz-url"


# ---------------------------------------------------------------------------
# MusicBrainz ID passthrough
# ---------------------------------------------------------------------------


def test_build_track_mbid_calls_setter(monkeypatch: object) -> None:
    """build_track_item with musicBrainzId calls tag.setMusicBrainzTrackID."""
    mock_li = _mock_list_item()
    monkeypatch.setattr(xbmcgui, "ListItem", MagicMock(return_value=mock_li))
    track = {"id": "1", "title": "T", "musicBrainzId": "abc"}
    build_track_item(track, url="plugin://...")
    tag = mock_li.getMusicInfoTag.return_value
    tag.setMusicBrainzTrackID.assert_called_once_with("abc")


def test_build_track_no_mbid_no_setter(monkeypatch: object) -> None:
    """build_track_item without musicBrainzId does NOT call setMusicBrainzTrackID."""
    mock_li = _mock_list_item()
    monkeypatch.setattr(xbmcgui, "ListItem", MagicMock(return_value=mock_li))
    track = {"id": "1", "title": "T"}
    build_track_item(track, url="plugin://...")
    tag = mock_li.getMusicInfoTag.return_value
    tag.setMusicBrainzTrackID.assert_not_called()


def test_build_album_mbid_calls_setter(monkeypatch: object) -> None:
    """build_album_item with musicBrainzId calls tag.setMusicBrainzAlbumID."""
    mock_li = _mock_list_item()
    monkeypatch.setattr(xbmcgui, "ListItem", MagicMock(return_value=mock_li))
    album = {"id": "2", "name": "Album", "musicBrainzId": "def"}
    build_album_item(album, url="plugin://...")
    tag = mock_li.getMusicInfoTag.return_value
    tag.setMusicBrainzAlbumID.assert_called_once_with("def")


def test_build_album_no_mbid_no_setter(monkeypatch: object) -> None:
    """build_album_item without musicBrainzId does NOT call setMusicBrainzAlbumID."""
    mock_li = _mock_list_item()
    monkeypatch.setattr(xbmcgui, "ListItem", MagicMock(return_value=mock_li))
    album = {"id": "2", "name": "Album"}
    build_album_item(album, url="plugin://...")
    tag = mock_li.getMusicInfoTag.return_value
    tag.setMusicBrainzAlbumID.assert_not_called()


def test_build_artist_mbid_calls_setter(monkeypatch: object) -> None:
    """build_artist_item with musicBrainzId calls tag.setMusicBrainzArtistID."""
    mock_li = _mock_list_item()
    monkeypatch.setattr(xbmcgui, "ListItem", MagicMock(return_value=mock_li))
    artist = {"id": "3", "name": "Artist", "musicBrainzId": "ghi"}
    build_artist_item(artist, url="plugin://...")
    tag = mock_li.getMusicInfoTag.return_value
    tag.setMusicBrainzArtistID.assert_called_once_with("ghi")


def test_build_artist_no_mbid_no_setter(monkeypatch: object) -> None:
    """build_artist_item without musicBrainzId does NOT call setMusicBrainzArtistID."""
    mock_li = _mock_list_item()
    monkeypatch.setattr(xbmcgui, "ListItem", MagicMock(return_value=mock_li))
    artist = {"id": "3", "name": "Artist"}
    build_artist_item(artist, url="plugin://...")
    tag = mock_li.getMusicInfoTag.return_value
    tag.setMusicBrainzArtistID.assert_not_called()
