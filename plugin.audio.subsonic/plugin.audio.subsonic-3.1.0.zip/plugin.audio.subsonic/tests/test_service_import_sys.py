"""
TDD test for BUG-01: service.py must have 'import sys' before sys.path.append.

This test checks the source text of service.py directly — it does not execute
the file (which would require a running Kodi environment).  The test passes
only when 'import sys' appears as a top-level import before the line that calls
sys.path.append.
"""

import re

SERVICE_PATH = "service.py"


def _read_service_lines():
    with open(SERVICE_PATH) as f:
        return f.readlines()


def test_import_sys_present():
    """service.py must have a top-level 'import sys' statement."""
    lines = _read_service_lines()
    import_sys_lines = [
        i for i, ln in enumerate(lines, start=1) if re.match(r"^import sys\s*$", ln)
    ]
    assert import_sys_lines, (
        "FAIL: 'import sys' not found in service.py — "
        "sys.path.append on line 7 will raise NameError at runtime (BUG-01)"
    )


def test_import_sys_before_sys_path_append():
    """'import sys' must appear before the first sys.path manipulation call.

    Accepts both sys.path.append and sys.path.insert (the new bootstrap uses
    sys.path.insert which is preferred for priority ordering).
    """
    lines = _read_service_lines()

    import_sys_line = None
    sys_path_line = None

    for i, ln in enumerate(lines, start=1):
        if re.match(r"^import sys\s*$", ln) and import_sys_line is None:
            import_sys_line = i
        if ("sys.path.append" in ln or "sys.path.insert" in ln) and sys_path_line is None:
            sys_path_line = i

    assert import_sys_line is not None, "FAIL: 'import sys' not found in service.py (BUG-01)"
    assert sys_path_line is not None, (
        "Expected to find 'sys.path.append' or 'sys.path.insert' in service.py"
    )
    assert import_sys_line < sys_path_line, (
        f"FAIL: 'import sys' is on line {import_sys_line} but "
        f"sys.path manipulation is on line {sys_path_line} — sys is used before import"
    )
