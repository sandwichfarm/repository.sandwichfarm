"""
Unit tests for subsonic.playback — play_track and play_radio handlers.

Covers:
- play_radio calls setResolvedUrl(handle, True, ...) when stream_url is provided
- play_radio calls setResolvedUrl(handle, False, ...) when stream_url is empty
"""

from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock, patch

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LIB = os.path.join(_REPO, "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

import subsonic.playback  # registers routes as side-effect  # noqa: E402
import xbmcgui  # noqa: E402 — mocked in conftest.py
import xbmcplugin  # noqa: E402 — mocked in conftest.py


def _make_deps() -> tuple[MagicMock, MagicMock]:
    """Return (client, settings) mocks for playback handler tests."""
    client = MagicMock()
    settings = MagicMock()
    settings.bitrate = "0"
    settings.transcode_format = "raw"
    return client, settings


# ---------------------------------------------------------------------------
# play_radio tests (FEAT-04)
# ---------------------------------------------------------------------------


def test_play_radio_calls_setResolvedUrl_true() -> None:
    """play_radio with a valid stream_url calls setResolvedUrl(handle, True, ...)."""
    client, settings = _make_deps()

    with patch.object(xbmcplugin, "setResolvedUrl") as mock_resolve:
        subsonic.playback.play_radio(
            client=client,
            settings=settings,
            handle=1,
            id="42",
            stream_url="http://radio.example.com/stream",
        )

    mock_resolve.assert_called_once()
    args = mock_resolve.call_args.args
    assert args[0] == 1, "handle must be passed through"
    assert args[1] is True, "succeeded must be True when stream_url is provided"


def test_play_radio_missing_url_calls_setResolvedUrl_false() -> None:
    """play_radio with empty stream_url calls setResolvedUrl(handle, False, ...)."""
    client, settings = _make_deps()

    with patch.object(xbmcplugin, "setResolvedUrl") as mock_resolve:
        subsonic.playback.play_radio(
            client=client,
            settings=settings,
            handle=1,
            id="42",
            stream_url="",
        )

    mock_resolve.assert_called_once()
    args = mock_resolve.call_args.args
    assert args[0] == 1, "handle must be passed through"
    assert args[1] is False, "succeeded must be False when stream_url is empty"


def test_play_radio_uses_stream_url_directly() -> None:
    """play_radio creates a ListItem with the stream_url as path (no transcoding)."""
    client, settings = _make_deps()
    stream = "http://radio.example.com/live"

    created_items: list = []

    def capture_list_item(*args: object, **kwargs: object) -> MagicMock:
        li = MagicMock()
        created_items.append(kwargs)
        return li

    with patch.object(xbmcgui, "ListItem", side_effect=capture_list_item), patch.object(
        xbmcplugin, "setResolvedUrl"
    ):  # noqa: E501
        subsonic.playback.play_radio(
            client=client,
            settings=settings,
            handle=1,
            id="99",
            stream_url=stream,
        )

    assert created_items, "ListItem should have been constructed"
    assert created_items[0].get("path") == stream, "ListItem path must be the radio stream_url"
