"""
Unit tests for subsonic.settings — the typed xbmcaddon facade.

Uses unittest.mock to inject a fake Addon so xbmcaddon is never actually called.
All getSetting(id) calls must use the verbatim id= strings from resources/settings.xml
(COMPAT-06).
"""

from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LIB = os.path.join(_REPO, "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

from subsonic.settings import Settings


def _make_settings(**overrides: str) -> Settings:
    """Return a Settings instance backed by a mock Addon with sensible defaults."""
    defaults: dict[str, str] = {
        "subsonic_url": "http://demo.subsonic.org",
        "port": "80",
        "username": "guest3",
        "password": "guest",
        "albums_per_page": "50",
        "tracks_per_page": "100",
        "download_folder": "/tmp/music",
        "transcode_format_streaming": "mp3",
        "bitrate_streaming": "0",
        "apiversion": "1.15.0",
        "insecure": "false",
        "useget": "true",
        "legacyauth": "false",
        "cachetime": "3600",
        "merge": "false",
        "scrobble": "false",
        "subsonic_api_key": "",
        "insecure_ssl_acknowledged": "false",
    }
    defaults.update(overrides)
    addon = MagicMock()
    addon.getSetting.side_effect = lambda key: defaults.get(key, "")
    return Settings(addon=addon)


def test_server_url() -> None:
    s = _make_settings()
    assert s.server_url == "http://demo.subsonic.org"


def test_port_int() -> None:
    s = _make_settings(port="80")
    assert s.port == 80


def test_port_default_on_empty() -> None:
    s = _make_settings(port="")
    assert s.port == 4040


def test_port_default_on_invalid() -> None:
    s = _make_settings(port="notanumber")
    assert s.port == 4040


def test_username() -> None:
    s = _make_settings(username="alice")
    assert s.username == "alice"


def test_password() -> None:
    s = _make_settings(password="secret")
    assert s.password == "secret"


def test_albums_per_page() -> None:
    s = _make_settings(albums_per_page="100")
    assert s.albums_per_page == 100


def test_albums_per_page_default_on_empty() -> None:
    s = _make_settings(albums_per_page="")
    assert s.albums_per_page == 50


def test_tracks_per_page() -> None:
    s = _make_settings(tracks_per_page="250")
    assert s.tracks_per_page == 250


def test_tracks_per_page_default_on_empty() -> None:
    s = _make_settings(tracks_per_page="")
    assert s.tracks_per_page == 100


def test_download_folder() -> None:
    s = _make_settings(download_folder="/home/user/music")
    assert s.download_folder == "/home/user/music"


def test_transcode_format() -> None:
    s = _make_settings(transcode_format_streaming="ogg")
    assert s.transcode_format == "ogg"


def test_bitrate() -> None:
    s = _make_settings(bitrate_streaming="192")
    assert s.bitrate == "192"


def test_api_version() -> None:
    s = _make_settings(apiversion="1.16.0")
    assert s.api_version == "1.16.0"


def test_insecure_false() -> None:
    s = _make_settings(insecure="false")
    assert s.insecure is False


def test_insecure_true() -> None:
    s = _make_settings(insecure="true")
    assert s.insecure is True


def test_insecure_case_insensitive() -> None:
    s = _make_settings(insecure="True")
    assert s.insecure is True


def test_use_get_true() -> None:
    s = _make_settings(useget="true")
    assert s.use_get is True


def test_use_get_false() -> None:
    s = _make_settings(useget="false")
    assert s.use_get is False


def test_legacy_auth_false() -> None:
    s = _make_settings(legacyauth="false")
    assert s.legacy_auth is False


def test_legacy_auth_true() -> None:
    s = _make_settings(legacyauth="true")
    assert s.legacy_auth is True


def test_cache_time() -> None:
    s = _make_settings(cachetime="3600")
    assert s.cache_time == 3600


def test_cache_time_default_on_empty() -> None:
    s = _make_settings(cachetime="")
    assert s.cache_time == 3600


def test_merge_false() -> None:
    s = _make_settings(merge="false")
    assert s.merge is False


def test_merge_true() -> None:
    s = _make_settings(merge="true")
    assert s.merge is True


def test_scrobble_enabled_false() -> None:
    s = _make_settings(scrobble="false")
    assert s.scrobble_enabled is False


def test_scrobble_enabled_true() -> None:
    s = _make_settings(scrobble="true")
    assert s.scrobble_enabled is True


def test_settings_ids_verbatim() -> None:
    """Verify getSetting is called with the EXACT id= strings from resources/settings.xml.

    This is COMPAT-06: no renaming of existing setting ids.
    The 18 ids in settings.xml (16 original + 2 new from Phase 4) are tested here.
    """
    addon = MagicMock()
    addon.getSetting.return_value = "0"
    s = Settings(addon=addon)
    # Trigger every property to exercise all getSetting calls
    _ = (
        s.server_url,
        s.port,
        s.username,
        s.password,
        s.albums_per_page,
        s.tracks_per_page,
        s.download_folder,
        s.transcode_format,
        s.bitrate,
        s.api_version,
        s.insecure,
        s.use_get,
        s.legacy_auth,
        s.cache_time,
        s.merge,
        s.scrobble_enabled,
        s.subsonic_api_key,
        s.insecure_ssl_acknowledged,
    )
    called_ids = {call.args[0] for call in addon.getSetting.call_args_list}
    expected_ids = {
        "subsonic_url",
        "port",
        "username",
        "password",
        "albums_per_page",
        "tracks_per_page",
        "download_folder",
        "transcode_format_streaming",
        "bitrate_streaming",
        "apiversion",
        "insecure",
        "useget",
        "legacyauth",
        "cachetime",
        "merge",
        "scrobble",
        "subsonic_api_key",
        "insecure_ssl_acknowledged",
    }
    assert expected_ids == called_ids, (
        f"Missing ids: {expected_ids - called_ids}\nUnexpected ids: {called_ids - expected_ids}"
    )


def test_subsonic_api_key_returns_value() -> None:
    s = _make_settings(subsonic_api_key="mykey123")
    assert s.subsonic_api_key == "mykey123"


def test_subsonic_api_key_returns_empty_when_not_set() -> None:
    s = _make_settings(subsonic_api_key="")
    assert s.subsonic_api_key == ""


def test_insecure_ssl_acknowledged_false() -> None:
    s = _make_settings(insecure_ssl_acknowledged="false")
    assert s.insecure_ssl_acknowledged is False


def test_insecure_ssl_acknowledged_true() -> None:
    s = _make_settings(insecure_ssl_acknowledged="true")
    assert s.insecure_ssl_acknowledged is True


def test_set_insecure_ssl_acknowledged_true() -> None:
    addon = MagicMock()
    addon.getSetting.return_value = "0"
    addon.setSetting = MagicMock()
    s = Settings(addon=addon)
    s.set_insecure_ssl_acknowledged(True)
    addon.setSetting.assert_called_once_with("insecure_ssl_acknowledged", "true")


def test_set_insecure_ssl_acknowledged_false() -> None:
    addon = MagicMock()
    addon.getSetting.return_value = "0"
    addon.setSetting = MagicMock()
    s = Settings(addon=addon)
    s.set_insecure_ssl_acknowledged(False)
    addon.setSetting.assert_called_once_with("insecure_ssl_acknowledged", "false")


def test_set_insecure_ssl_false() -> None:
    addon = MagicMock()
    addon.getSetting.return_value = "0"
    addon.setSetting = MagicMock()
    s = Settings(addon=addon)
    s.set_insecure_ssl(False)
    addon.setSetting.assert_called_once_with("insecure", "false")
