"""
Smoke tests: verify addon modules import without crashing under Kodi API mocks.

These tests address TEST-01 (pytest infrastructure) and verify COMPAT-01/COMPAT-02
(addon loads without crashing on Python 3.8 and 3.11).

No Kodi installation required — conftest.py injects all Kodi API mocks.
"""


def test_import_main():
    """main.py must import without raising any exception under mocks."""
    import main  # noqa: F401


def test_import_service():
    """service.py must import without raising any exception under mocks."""
    import service  # noqa: F401


def test_import_libsonic():
    """lib/libsonic/__init__.py must import without raising."""
    import libsonic  # noqa: F401


def test_import_simpleplugin():
    """lib/simpleplugin/__init__.py must import without raising."""
    from simpleplugin import Addon, Plugin  # noqa: F401


def test_import_bootstrap():
    """subsonic.bootstrap must import without raising (TEST-07 / ARCH-01 / ARCH-02)."""
    import os
    import sys

    _repo = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    _lib = os.path.join(_repo, "resources", "lib")
    if _lib not in sys.path:
        sys.path.insert(0, _lib)
    from subsonic.bootstrap import _ORIGINAL_ROUTES, run_plugin, run_service  # noqa: F401

    assert callable(run_plugin)
    assert callable(run_service)
    assert isinstance(_ORIGINAL_ROUTES, dict)
    assert len(_ORIGINAL_ROUTES) > 0, "_ORIGINAL_ROUTES is empty — snapshot failed"


def test_import_scrobbler():
    """subsonic.scrobbler must import without raising."""
    import os
    import sys

    _repo = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    _lib = os.path.join(_repo, "resources", "lib")
    if _lib not in sys.path:
        sys.path.insert(0, _lib)
    from subsonic.scrobbler import Scrobbler  # noqa: F401

    assert callable(Scrobbler)


# ---------------------------------------------------------------------------
# New subsonic module smoke tests (Plan 03-09)
# ---------------------------------------------------------------------------


def test_import_subsonic_package():
    """subsonic package __init__ must export __version__."""
    import subsonic  # noqa: F401

    assert hasattr(subsonic, "__version__")


def test_import_models():
    """subsonic.models must export all TypedDicts and dataclasses."""
    from subsonic.models import (  # noqa: F401
        CacheEntry,
        PageState,
        PlayContext,
        SubsonicAlbum,
        SubsonicArtist,
        SubsonicGenre,
        SubsonicPlaylist,
        SubsonicTrack,
    )


def test_import_settings():
    """subsonic.settings must export Settings class."""
    from subsonic.settings import Settings  # noqa: F401

    assert callable(Settings)


def test_import_cache():
    """subsonic.cache must export Cache class."""
    from subsonic.cache import Cache  # noqa: F401

    assert callable(Cache)


def test_import_logging():
    """subsonic.logging must export log helper functions."""
    from subsonic.logging import log_debug, log_error, log_info, safe_log  # noqa: F401

    assert callable(safe_log)
    assert callable(log_debug)
    assert callable(log_info)
    assert callable(log_error)


def test_import_router():
    """subsonic.router must export routing primitives."""
    from subsonic.router import clear_routes, dispatch, route, url_for  # noqa: F401

    assert callable(route)
    assert callable(url_for)
    assert callable(dispatch)
    assert callable(clear_routes)


def test_import_api_client():
    """subsonic.api.client must export ApiClient class."""
    from subsonic.api.client import ApiClient  # noqa: F401

    assert callable(ApiClient)


def test_import_listings():
    """subsonic.listings must export all builder and directory helpers."""
    from subsonic.listings import (  # noqa: F401
        add_items,
        build_album_item,
        build_artist_item,
        build_track_item,
        end_directory,
    )

    assert callable(build_track_item)
    assert callable(build_album_item)
    assert callable(build_artist_item)
    assert callable(end_directory)
    assert callable(add_items)


def test_import_browse():
    """subsonic.browse must import without raising."""
    import subsonic.browse  # noqa: F401


def test_import_search():
    """subsonic.search must import without raising."""
    import subsonic.search  # noqa: F401


def test_import_playback():
    """subsonic.playback must export play_track handler."""
    from subsonic.playback import play_track  # noqa: F401

    assert callable(play_track)


def test_import_actions():
    """subsonic.actions must export star_item and download_item handlers."""
    from subsonic.actions import download_item, star_item  # noqa: F401

    assert callable(star_item)
    assert callable(download_item)
