"""
Unit tests for subsonic.api.client.ApiClient.

Covers TEST-02: auth-mode selection, request building, OpenSubsonic probe parsing.

All libsonic.Connection calls are mocked — no live server required.
"""

from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock, patch

# Ensure resources/lib and lib/ are on sys.path
_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LIB = os.path.join(_REPO, "resources", "lib")
_LIB2 = os.path.join(_REPO, "lib")
for p in (_LIB, _LIB2):
    if p not in sys.path:
        sys.path.insert(0, p)

from subsonic.settings import Settings


def _make_settings(**kw: str) -> Settings:
    defaults = {
        "subsonic_url": "http://localhost",
        "port": "4040",
        "username": "admin",
        "password": "pass",
        "apiversion": "1.15.0",
        "insecure": "false",
        "useget": "true",
        "legacyauth": "false",
        "cachetime": "300",
        "merge": "false",
        "scrobble": "false",
        "albums_per_page": "50",
        "tracks_per_page": "100",
        "download_folder": "",
        "transcode_format_streaming": "mp3",
        "bitrate_streaming": "0",
        "subsonic_api_key": "",
        "insecure_ssl_acknowledged": "false",
    }
    defaults.update(kw)
    addon = MagicMock()
    addon.getSetting.side_effect = lambda k: defaults.get(k, "")
    return Settings(addon=addon)


def _make_client(mock_conn: MagicMock, **kw: str):
    """Return an ApiClient with a mocked libsonic.Connection."""
    from subsonic.api.client import ApiClient

    settings = _make_settings(**kw)
    with patch("subsonic.api.client.libsonic") as mock_libsonic:
        mock_libsonic.Connection.return_value = mock_conn
        client = ApiClient(settings)
        client._conn = mock_conn  # ensure the mock is active post-init
    return client


# ---------------------------------------------------------------------------
# Construction tests
# ---------------------------------------------------------------------------


def test_api_client_constructs_libsonic_connection():
    """ApiClient passes Settings fields to libsonic.Connection kwargs."""
    mock_conn = MagicMock()
    from subsonic.api.client import ApiClient

    settings = _make_settings()
    with patch("subsonic.api.client.libsonic") as mock_libsonic:
        mock_libsonic.Connection.return_value = mock_conn
        ApiClient(settings)
        mock_libsonic.Connection.assert_called_once()
        call_kwargs = mock_libsonic.Connection.call_args[1]
        assert call_kwargs["username"] == "admin"
        assert call_kwargs["baseUrl"] == "http://localhost"
        assert call_kwargs["port"] == 4040


def test_api_client_passes_insecure_flag():
    """ApiClient passes insecure=True when Settings.insecure is True."""
    mock_conn = MagicMock()
    from subsonic.api.client import ApiClient

    settings = _make_settings(insecure="true")
    with patch("subsonic.api.client.libsonic") as mock_libsonic:
        mock_libsonic.Connection.return_value = mock_conn
        ApiClient(settings)
        call_kwargs = mock_libsonic.Connection.call_args[1]
        assert call_kwargs["insecure"] is True


def test_api_client_passes_legacy_auth_false():
    """ApiClient passes legacyAuth=False when Settings.legacy_auth is False."""
    mock_conn = MagicMock()
    from subsonic.api.client import ApiClient

    settings = _make_settings(legacyauth="false")
    with patch("subsonic.api.client.libsonic") as mock_libsonic:
        mock_libsonic.Connection.return_value = mock_conn
        ApiClient(settings)
        call_kwargs = mock_libsonic.Connection.call_args[1]
        assert call_kwargs["legacyAuth"] is False


def test_api_client_passes_legacy_auth_true():
    """ApiClient passes legacyAuth=True when Settings.legacy_auth is True."""
    mock_conn = MagicMock()
    from subsonic.api.client import ApiClient

    settings = _make_settings(legacyauth="true")
    with patch("subsonic.api.client.libsonic") as mock_libsonic:
        mock_libsonic.Connection.return_value = mock_conn
        ApiClient(settings)
        call_kwargs = mock_libsonic.Connection.call_args[1]
        assert call_kwargs["legacyAuth"] is True


def test_api_client_has_no_global_singleton():
    """ApiClient class has no module-level connection=None singleton."""
    import subsonic.api.client as client_mod

    assert not hasattr(client_mod, "connection"), (
        "Module must not have a global 'connection' singleton"
    )


# ---------------------------------------------------------------------------
# ping
# ---------------------------------------------------------------------------


def test_ping_returns_true_on_ok():
    mock_conn = MagicMock()
    mock_conn.ping.return_value = True
    client = _make_client(mock_conn)
    assert client.ping() is True


def test_ping_returns_false_on_exception():
    mock_conn = MagicMock()
    mock_conn.ping.side_effect = Exception("network error")
    client = _make_client(mock_conn)
    assert client.ping() is False


# ---------------------------------------------------------------------------
# get_album_list
# ---------------------------------------------------------------------------


def test_get_album_list_returns_albums():
    mock_conn = MagicMock()
    mock_conn.getAlbumList2.return_value = {
        "albumList2": {"album": [{"id": "1", "name": "Album A"}]}
    }
    client = _make_client(mock_conn)
    result = client.get_album_list(ltype="newest", size=50)
    assert result[0]["name"] == "Album A"
    mock_conn.getAlbumList2.assert_called_once()


def test_get_album_list_returns_empty_on_missing_key():
    mock_conn = MagicMock()
    mock_conn.getAlbumList2.return_value = {"albumList2": {}}
    client = _make_client(mock_conn)
    assert client.get_album_list() == []


def test_get_album_list_returns_empty_on_missing_albumList2():
    mock_conn = MagicMock()
    mock_conn.getAlbumList2.return_value = {}
    client = _make_client(mock_conn)
    assert client.get_album_list() == []


# ---------------------------------------------------------------------------
# get_artists
# ---------------------------------------------------------------------------


def test_get_artists_flattens_index():
    mock_conn = MagicMock()
    mock_conn.getArtists.return_value = {
        "artists": {
            "index": [
                {"letter": "A", "artist": [{"id": "1", "name": "Artist A"}]},
                {"letter": "B", "artist": [{"id": "2", "name": "Artist B"}]},
            ]
        }
    }
    client = _make_client(mock_conn)
    result = client.get_artists()
    assert len(result) == 2
    assert result[0]["name"] == "Artist A"
    assert result[1]["name"] == "Artist B"


def test_get_artists_returns_empty_on_missing_data():
    mock_conn = MagicMock()
    mock_conn.getArtists.return_value = {}
    client = _make_client(mock_conn)
    assert client.get_artists() == []


# ---------------------------------------------------------------------------
# stream_url — must NOT inject credentials directly
# ---------------------------------------------------------------------------


def test_stream_url_delegates_to_libsonic_streamUrl():
    """stream_url() must delegate to libsonic.streamUrl, not build the URL itself."""
    mock_conn = MagicMock()
    mock_conn.streamUrl.return_value = "http://server/stream?id=1&t=token&s=salt"
    client = _make_client(mock_conn)
    url = client.stream_url("1")
    mock_conn.streamUrl.assert_called_once_with(sid="1")
    assert isinstance(url, str)


def test_stream_url_passes_bitrate_and_format():
    mock_conn = MagicMock()
    mock_conn.streamUrl.return_value = "http://server/stream?id=1&maxBitRate=192&format=mp3"
    client = _make_client(mock_conn)
    client.stream_url("1", bitrate="192", fmt="mp3")
    call_kwargs = mock_conn.streamUrl.call_args[1]
    assert call_kwargs["maxBitRate"] == "192"
    assert call_kwargs["format"] == "mp3"


def test_stream_url_skips_zero_bitrate():
    """bitrate='0' means 'original quality' — should not be passed to libsonic."""
    mock_conn = MagicMock()
    mock_conn.streamUrl.return_value = "http://server/stream?id=1"
    client = _make_client(mock_conn)
    client.stream_url("1", bitrate="0")
    call_kwargs = mock_conn.streamUrl.call_args[1]
    assert "maxBitRate" not in call_kwargs


def test_stream_url_skips_raw_format():
    """fmt='raw' means 'no transcoding' — should not be passed to libsonic."""
    mock_conn = MagicMock()
    mock_conn.streamUrl.return_value = "http://server/stream?id=1"
    client = _make_client(mock_conn)
    client.stream_url("1", fmt="raw")
    call_kwargs = mock_conn.streamUrl.call_args[1]
    assert "format" not in call_kwargs


# ---------------------------------------------------------------------------
# star / unstar
# ---------------------------------------------------------------------------


def test_star_returns_true_on_ok():
    mock_conn = MagicMock()
    mock_conn.star.return_value = {"status": "ok"}
    client = _make_client(mock_conn)
    assert client.star(song_ids=["42"]) is True


def test_star_returns_false_on_fail():
    mock_conn = MagicMock()
    mock_conn.star.return_value = {"status": "failed"}
    client = _make_client(mock_conn)
    assert client.star(song_ids=["42"]) is False


def test_unstar_returns_true_on_ok():
    mock_conn = MagicMock()
    mock_conn.unstar.return_value = {"status": "ok"}
    client = _make_client(mock_conn)
    assert client.unstar(song_ids=["42"]) is True


def test_unstar_returns_false_on_fail():
    mock_conn = MagicMock()
    mock_conn.unstar.return_value = {"status": "failed"}
    client = _make_client(mock_conn)
    assert client.unstar(song_ids=["42"]) is False


# ---------------------------------------------------------------------------
# scrobble
# ---------------------------------------------------------------------------


def test_scrobble_returns_true_on_ok():
    mock_conn = MagicMock()
    mock_conn.scrobble.return_value = {"status": "ok"}
    client = _make_client(mock_conn)
    assert client.scrobble("42") is True


def test_scrobble_returns_false_on_fail():
    mock_conn = MagicMock()
    mock_conn.scrobble.return_value = {"status": "failed"}
    client = _make_client(mock_conn)
    assert client.scrobble("42") is False


def test_scrobble_calls_connection_with_track_id():
    mock_conn = MagicMock()
    mock_conn.scrobble.return_value = {"status": "ok"}
    client = _make_client(mock_conn)
    client.scrobble("99")
    mock_conn.scrobble.assert_called_once_with("99")


# ---------------------------------------------------------------------------
# OpenSubsonic extensions probe
# ---------------------------------------------------------------------------


def test_get_open_subsonic_extensions_returns_names():
    mock_conn = MagicMock()
    mock_conn.getOpenSubsonicExtensions.return_value = {
        "openSubsonicExtensions": [
            {"name": "apiKeyAuthentication", "versions": [1]},
            {"name": "formPost", "versions": [1]},
        ]
    }
    client = _make_client(mock_conn)
    exts = client.get_open_subsonic_extensions()
    assert "apiKeyAuthentication" in exts
    assert "formPost" in exts


def test_get_open_subsonic_extensions_returns_empty_on_error():
    mock_conn = MagicMock()
    mock_conn.getOpenSubsonicExtensions.side_effect = Exception("501 Not Supported")
    client = _make_client(mock_conn)
    assert client.get_open_subsonic_extensions() == []


def test_get_open_subsonic_extensions_returns_empty_on_missing_key():
    mock_conn = MagicMock()
    mock_conn.getOpenSubsonicExtensions.return_value = {}
    client = _make_client(mock_conn)
    assert client.get_open_subsonic_extensions() == []


# ---------------------------------------------------------------------------
# Phase 4: Auth-mode selection, make_token_auth, probe_extensions
# ---------------------------------------------------------------------------


def test_make_token_auth_uses_secrets_token_hex():
    """make_token_auth must call secrets.token_hex(8) to generate the salt."""
    from subsonic.api.client import make_token_auth

    with patch(
        "subsonic.api.client.secrets.token_hex", return_value="deadbeef01234567"
    ) as mock_hex:
        make_token_auth("mypassword")
        mock_hex.assert_called_once_with(8)


def test_make_token_auth_token_matches_md5_password_plus_salt():
    """make_token_auth token must equal md5(password+salt).hexdigest()."""
    import hashlib

    from subsonic.api.client import make_token_auth

    with patch("subsonic.api.client.secrets.token_hex", return_value="deadbeef01234567"):
        token, salt = make_token_auth("testpass")
    expected = hashlib.md5(("testpass" + "deadbeef01234567").encode("utf-8")).hexdigest()
    assert token == expected
    assert salt == "deadbeef01234567"


def test_choose_auth_mode_returns_token_default():
    """Default mode is 'token' when legacy_auth=False and no api_key."""
    mock_conn = MagicMock()
    client = _make_client(mock_conn, legacyauth="false", subsonic_api_key="")
    with patch.object(client, "probe_extensions", return_value=set()):
        assert client.choose_auth_mode() == "token"


def test_choose_auth_mode_returns_legacy_when_setting_enabled():
    """Mode is 'legacy' when legacy_auth=True, regardless of probe result."""
    mock_conn = MagicMock()
    client = _make_client(mock_conn, legacyauth="true")
    # probe_extensions should NOT be called when legacy_auth is True
    assert client.choose_auth_mode() == "legacy"


def test_choose_auth_mode_returns_apikey_when_extension_advertised():
    """Mode is 'apikey' when server advertises apiKeyAuthentication AND api_key is set."""
    mock_conn = MagicMock()
    client = _make_client(mock_conn, legacyauth="false", subsonic_api_key="myapikey")
    with patch.object(client, "probe_extensions", return_value={"apiKeyAuthentication"}):
        assert client.choose_auth_mode() == "apikey"


def test_choose_auth_mode_returns_token_when_apikey_empty():
    """Mode falls back to 'token' even when server advertises extension but api_key is empty."""
    mock_conn = MagicMock()
    client = _make_client(mock_conn, legacyauth="false", subsonic_api_key="")
    with patch.object(client, "probe_extensions", return_value={"apiKeyAuthentication"}):
        assert client.choose_auth_mode() == "token"


def test_probe_extensions_caches_result_per_session():
    """probe_extensions must call the network only once; second call uses cache."""
    mock_conn = MagicMock()
    mock_conn.getOpenSubsonicExtensions.return_value = {
        "openSubsonicExtensions": [{"name": "apiKeyAuthentication", "versions": [1]}]
    }
    client = _make_client(mock_conn)
    result1 = client.probe_extensions()
    result2 = client.probe_extensions()
    assert result1 == result2 == {"apiKeyAuthentication"}
    assert mock_conn.getOpenSubsonicExtensions.call_count == 1  # cached — no second call


def test_probe_extensions_handles_any_error_as_no_extensions():
    """Any exception during probe must return empty set (not re-raise)."""
    mock_conn = MagicMock()
    mock_conn.getOpenSubsonicExtensions.side_effect = Exception("404 Not Found")
    client = _make_client(mock_conn)
    result = client.probe_extensions()
    assert result == set()
    # Cache should also be an empty set — second call does not retry the network
    result2 = client.probe_extensions()
    assert result2 == set()
    assert mock_conn.getOpenSubsonicExtensions.call_count == 1


def test_apikey_mode_omits_user_token_salt_password_params():
    """In apikey mode, build_auth_params must return ONLY {'apiKey': ...} — no u/t/s/p."""
    mock_conn = MagicMock()
    mock_conn.getOpenSubsonicExtensions.return_value = {
        "openSubsonicExtensions": [{"name": "apiKeyAuthentication", "versions": [1]}]
    }
    client = _make_client(mock_conn, legacyauth="false", subsonic_api_key="secret-key")
    with patch.object(client, "choose_auth_mode", return_value="apikey"):
        params = client.build_auth_params()
    assert "apiKey" in params
    assert params["apiKey"] == "secret-key"
    for forbidden in ("u", "t", "s", "p"):
        assert forbidden not in params, f"apikey mode must not include param '{forbidden}'"


def test_token_mode_includes_token_and_salt_omits_password():
    """In token mode, build_auth_params returns u/t/s but no p."""
    mock_conn = MagicMock()
    client = _make_client(mock_conn, legacyauth="false", subsonic_api_key="")
    with patch.object(client, "choose_auth_mode", return_value="token"):
        params = client.build_auth_params()
    assert "u" in params
    assert "t" in params
    assert "s" in params
    assert "p" not in params
    assert "apiKey" not in params


def test_legacy_mode_includes_password_param():
    """In legacy mode, build_auth_params returns u/p but no t/s/apiKey."""
    mock_conn = MagicMock()
    client = _make_client(mock_conn, legacyauth="true")
    with patch.object(client, "choose_auth_mode", return_value="legacy"):
        params = client.build_auth_params()
    assert "u" in params
    assert "p" in params
    assert "t" not in params
    assert "s" not in params
    assert "apiKey" not in params


# ---------------------------------------------------------------------------
# Phase 5: Genre, Radio, Rating, search3 methods
# ---------------------------------------------------------------------------


def test_get_genres_returns_genre_list():
    """get_genres extracts the genre list from getGenres response."""
    mock_conn = MagicMock()
    mock_conn.getGenres.return_value = {
        "genres": {"genre": [{"value": "Rock", "songCount": 5, "albumCount": 2}]}
    }
    client = _make_client(mock_conn)
    result = client.get_genres()
    assert result == [{"value": "Rock", "songCount": 5, "albumCount": 2}]
    mock_conn.getGenres.assert_called_once()


def test_get_genres_returns_empty_on_missing_key():
    """get_genres returns [] when genres key is absent."""
    mock_conn = MagicMock()
    mock_conn.getGenres.return_value = {}
    client = _make_client(mock_conn)
    assert client.get_genres() == []


def test_get_genres_returns_empty_on_missing_genre_list():
    """get_genres returns [] when genre list is absent inside genres dict."""
    mock_conn = MagicMock()
    mock_conn.getGenres.return_value = {"genres": {}}
    client = _make_client(mock_conn)
    assert client.get_genres() == []


def test_get_songs_by_genre_returns_song_list():
    """get_songs_by_genre extracts the song list from getSongsByGenre response."""
    mock_conn = MagicMock()
    mock_conn.getSongsByGenre.return_value = {
        "songsByGenre": {"song": [{"id": "1", "title": "Rock Song"}]}
    }
    client = _make_client(mock_conn)
    result = client.get_songs_by_genre("Rock", count=50, offset=0)
    assert result == [{"id": "1", "title": "Rock Song"}]
    mock_conn.getSongsByGenre.assert_called_once_with(genre="Rock", count=50, offset=0)


def test_get_songs_by_genre_returns_empty_on_missing_key():
    """get_songs_by_genre returns [] when response has no song data."""
    mock_conn = MagicMock()
    mock_conn.getSongsByGenre.return_value = {}
    client = _make_client(mock_conn)
    assert client.get_songs_by_genre("Jazz") == []


def test_search3_returns_result_dict():
    """search3 returns the searchResult3 inner dict."""
    mock_conn = MagicMock()
    mock_conn.search3.return_value = {
        "searchResult3": {
            "artist": [],
            "album": [],
            "song": [{"id": "1", "title": "Hit Song"}],
        }
    }
    client = _make_client(mock_conn)
    result = client.search3("hit")
    assert result["song"] == [{"id": "1", "title": "Hit Song"}]
    mock_conn.search3.assert_called_once_with(
        query="hit",
        artistCount=20,
        albumCount=20,
        songCount=40,
    )


def test_search3_returns_empty_dict_on_missing_key():
    """search3 returns {} when searchResult3 key is absent."""
    mock_conn = MagicMock()
    mock_conn.search3.return_value = {}
    client = _make_client(mock_conn)
    assert client.search3("nothing") == {}


def test_set_rating_returns_true_on_ok():
    """set_rating returns True when server responds with status=ok."""
    mock_conn = MagicMock()
    mock_conn.setRating.return_value = {"status": "ok"}
    client = _make_client(mock_conn)
    assert client.set_rating("123", 4) is True
    mock_conn.setRating.assert_called_once_with(id="123", rating=4)


def test_set_rating_returns_false_on_failed_status():
    """set_rating returns False when server responds with status=failed."""
    mock_conn = MagicMock()
    mock_conn.setRating.return_value = {"status": "failed"}
    client = _make_client(mock_conn)
    assert client.set_rating("123", 4) is False


def test_set_rating_returns_false_on_exception():
    """set_rating returns False (not raises) when libsonic raises an exception."""
    mock_conn = MagicMock()
    mock_conn.setRating.side_effect = Exception("server error")
    client = _make_client(mock_conn)
    assert client.set_rating("123", 4) is False


def test_get_internet_radio_stations_returns_station_list():
    """get_internet_radio_stations extracts the station list."""
    mock_conn = MagicMock()
    mock_conn.getInternetRadioStations.return_value = {
        "internetRadioStations": {
            "internetRadioStation": [
                {"id": "1", "name": "Radio X", "streamUrl": "http://stream.example.com/live"}
            ]
        }
    }
    client = _make_client(mock_conn)
    result = client.get_internet_radio_stations()
    assert len(result) == 1
    assert result[0]["name"] == "Radio X"
    mock_conn.getInternetRadioStations.assert_called_once()


def test_get_internet_radio_stations_returns_empty_on_missing_key():
    """get_internet_radio_stations returns [] when response keys are absent."""
    mock_conn = MagicMock()
    mock_conn.getInternetRadioStations.return_value = {}
    client = _make_client(mock_conn)
    assert client.get_internet_radio_stations() == []


def test_get_internet_radio_stations_returns_empty_on_exception():
    """get_internet_radio_stations returns [] (not raises) on exception."""
    mock_conn = MagicMock()
    mock_conn.getInternetRadioStations.side_effect = Exception("not supported")
    client = _make_client(mock_conn)
    assert client.get_internet_radio_stations() == []
