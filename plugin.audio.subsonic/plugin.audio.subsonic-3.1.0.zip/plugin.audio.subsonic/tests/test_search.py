"""
Unit tests for subsonic.search — search and search_album handlers.

Covers:
- search handler calls show_search_dialog and client.search()
- search_album handler passes artistCount=0, songCount=0
- No xbmcgui or xbmcplugin imports in search.py (ARCH-05)
- Cancelled search (empty query) ends directory with succeeded=False
"""

from __future__ import annotations

import inspect
import os
import sys
from unittest.mock import MagicMock, patch

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LIB = os.path.join(_REPO, "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

import subsonic.search  # registers routes as side-effect  # noqa: E402

# ---------------------------------------------------------------------------
# Import hygiene
# ---------------------------------------------------------------------------


def test_search_module_has_no_xbmcgui_import() -> None:
    """search.py must not import xbmcgui or xbmcplugin directly (ARCH-05)."""
    src = inspect.getsource(subsonic.search)
    assert "import xbmcgui" not in src, "xbmcgui import found in search.py"
    assert "import xbmcplugin" not in src, "xbmcplugin import found in search.py"


def test_search_module_uses_show_search_dialog() -> None:
    """search.py must use show_search_dialog from listings (ARCH-05)."""
    src = inspect.getsource(subsonic.search)
    assert "show_search_dialog" in src, "show_search_dialog not found in search.py"


# ---------------------------------------------------------------------------
# search handler
# ---------------------------------------------------------------------------


def test_search_calls_client_search_with_query() -> None:
    """search handler should call client.search3() with the user's query (FEAT-02)."""
    client = MagicMock()
    client.search3.return_value = {"artist": [], "album": [], "song": []}
    client.get_cover_art_url.return_value = ""
    settings = MagicMock()

    with patch("subsonic.search.show_search_dialog", return_value="beatles"), patch(
        "subsonic.search.add_items"
    ), patch("subsonic.search.end_directory"):  # noqa: E501
        subsonic.search.search(client=client, settings=settings, handle=1)

    client.search3.assert_called_once_with(
        query="beatles", artist_count=20, album_count=20, song_count=40
    )


def test_search_cancelled_ends_directory_with_failure() -> None:
    """When show_search_dialog returns None (cancel), end_directory(succeeded=False)."""
    client = MagicMock()
    settings = MagicMock()

    with patch("subsonic.search.show_search_dialog", return_value=None), patch(
        "subsonic.search.end_directory"
    ) as mock_end:  # noqa: E501
        subsonic.search.search(client=client, settings=settings, handle=1)

    mock_end.assert_called_once()
    kwargs = mock_end.call_args
    # succeeded=False must be passed
    assert kwargs.kwargs.get("succeeded") is False or (
        len(kwargs.args) > 1 and kwargs.args[1] is False
    ), "end_directory must be called with succeeded=False on cancel"


def test_search_builds_mixed_result_items() -> None:
    """search should build artist, album, and track items from results (FEAT-02)."""
    client = MagicMock()
    client.search3.return_value = {
        "artist": [{"id": "a1", "name": "The Beatles"}],
        "album": [{"id": "al1", "name": "Abbey Road", "artist": "The Beatles"}],
        "song": [{"id": "s1", "title": "Come Together", "artist": "The Beatles"}],
    }
    client.get_cover_art_url.return_value = ""
    settings = MagicMock()

    captured: list = []
    with patch("subsonic.search.show_search_dialog", return_value="beatles"), patch(
        "subsonic.search.add_items"
    ) as mock_add, patch("subsonic.search.end_directory"), patch(
        "subsonic.search.build_artist_item"
    ) as mock_artist, patch("subsonic.search.build_album_item") as mock_album, patch(
        "subsonic.search.build_track_item"
    ) as mock_track:  # noqa: E501
        for m in (mock_artist, mock_album, mock_track):
            m.return_value = ("url", MagicMock(), True)
        mock_add.side_effect = lambda h, items: captured.extend(items)
        subsonic.search.search(client=client, settings=settings, handle=1)

    mock_artist.assert_called_once()
    mock_album.assert_called_once()
    mock_track.assert_called_once()
    assert len(captured) == 3, "Expected 3 result items (1 artist + 1 album + 1 song)"


# ---------------------------------------------------------------------------
# search_album handler
# ---------------------------------------------------------------------------


def test_search_album_passes_zero_counts_for_artist_and_song() -> None:
    """search_album must pass artist_count=0, song_count=0 to client.search3 (FEAT-02)."""
    client = MagicMock()
    client.search3.return_value = {"album": []}
    client.get_cover_art_url.return_value = ""
    settings = MagicMock()

    with patch("subsonic.search.show_search_dialog", return_value="abbey road"), patch(
        "subsonic.search.add_items"
    ), patch("subsonic.search.end_directory"):  # noqa: E501
        subsonic.search.search_album(client=client, settings=settings, handle=1)

    client.search3.assert_called_once_with(
        query="abbey road", artist_count=0, album_count=50, song_count=0
    )


def test_search_album_cancelled_ends_directory_with_failure() -> None:
    """When show_search_dialog returns None, end_directory(succeeded=False)."""
    client = MagicMock()
    settings = MagicMock()

    with patch("subsonic.search.show_search_dialog", return_value=None), patch(
        "subsonic.search.end_directory"
    ) as mock_end:  # noqa: E501
        subsonic.search.search_album(client=client, settings=settings, handle=1)

    mock_end.assert_called_once()
    kwargs = mock_end.call_args
    assert kwargs.kwargs.get("succeeded") is False or (
        len(kwargs.args) > 1 and kwargs.args[1] is False
    ), "end_directory must be called with succeeded=False on cancel"


def test_search_album_only_builds_album_items() -> None:
    """search_album builds only album items — no artist or track items (FEAT-02)."""
    client = MagicMock()
    client.search3.return_value = {
        "album": [
            {"id": "al1", "name": "Abbey Road"},
            {"id": "al2", "name": "Let It Be"},
        ]
    }
    client.get_cover_art_url.return_value = ""
    settings = MagicMock()

    captured: list = []
    with patch("subsonic.search.show_search_dialog", return_value="beatles"), patch(
        "subsonic.search.add_items"
    ) as mock_add, patch("subsonic.search.end_directory"), patch(
        "subsonic.search.build_album_item"
    ) as mock_album:  # noqa: E501
        mock_album.return_value = ("url", MagicMock(), True)
        mock_add.side_effect = lambda h, items: captured.extend(items)
        subsonic.search.search_album(client=client, settings=settings, handle=1)

    assert mock_album.call_count == 2, "Expected 2 album items built"
    assert len(captured) == 2
