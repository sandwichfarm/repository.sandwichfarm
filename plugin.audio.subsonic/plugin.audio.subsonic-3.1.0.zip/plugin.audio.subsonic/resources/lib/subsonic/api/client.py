"""
subsonic.api.client — Single boundary between addon logic and libsonic.Connection.

ApiClient wraps a libsonic.Connection instance and exposes typed methods that return
plain dicts / lists (matching the Subsonic API response shapes in models.py).

Design constraints (from ARCH-08 through ARCH-11):
- ApiClient is constructed with a Settings object — no global singletons.
- All handler modules import ApiClient, never libsonic directly.
- Phase 3: keeps existing auth behaviour (legacyAuth flag forwarded to libsonic).
- Phase 4: will add salt+token as default and OpenSubsonic API-key auth.
- stream_url() delegates to libsonic.streamUrl() — never injects credentials itself.
- get_open_subsonic_extensions() method exists now (Phase 3 stub) — Phase 4 calls it
  automatically at connect-time to negotiate auth mode.
"""

from __future__ import annotations

import hashlib
import secrets
from typing import Any, Literal

import libsonic
from subsonic.settings import Settings


def make_token_auth(password: str) -> tuple[str, str]:
    """Return (token, salt) for Subsonic salt+token auth (AUTH-01, AUTH-05).

    salt is generated fresh per call via secrets.token_hex(8) — 8 bytes of
    cryptographic entropy encoded as 16 hex chars.
    token = md5(password + salt).hexdigest().
    Never log either value.
    """
    salt = secrets.token_hex(8)
    token = hashlib.md5((password + salt).encode("utf-8")).hexdigest()
    return token, salt


class ApiClient:
    """Single boundary between addon logic and libsonic.Connection.

    Constructs a libsonic Connection from a Settings object (no global state).
    All handler modules use this class — never libsonic directly.

    Phase 3: keeps existing auth behavior (legacyAuth flag passed through).
    Phase 4: adds salt+token as default and OpenSubsonic API-key auth.
    """

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._extensions_cached: set[str] | None = None
        self._conn = libsonic.Connection(
            baseUrl=settings.server_url,
            username=settings.username,
            password=settings.password,
            port=settings.port,
            apiVersion=settings.api_version,
            insecure=settings.insecure,
            legacyAuth=settings.legacy_auth,
            useGET=settings.use_get,
        )

    # ------------------------------------------------------------------
    # Auth-mode selection (AUTH-01..05)
    # ------------------------------------------------------------------

    def probe_extensions(self) -> set[str]:
        """Probe for OpenSubsonic extensions. Lazy — called only when needed.

        Result is cached for this ApiClient instance lifetime (per-session).
        Any error (404, 501, parse failure, network) → empty set, cached.
        Subsequent calls always return the cached result without a network
        round-trip (AUTH-03).
        """
        if self._extensions_cached is not None:
            return self._extensions_cached
        try:
            resp = self._conn.getOpenSubsonicExtensions()
            extensions: set[str] = {
                e["name"]
                for e in (resp.get("openSubsonicExtensions") or [])
                if isinstance(e, dict) and "name" in e
            }
        except Exception:
            extensions = set()
        self._extensions_cached = extensions
        return extensions

    def supports(self, extension: str) -> bool:
        """Return True if the server advertises the named OpenSubsonic extension."""
        return extension in self.probe_extensions()

    def choose_auth_mode(self) -> Literal["apikey", "token", "legacy"]:
        """Select the auth mode for this session (AUTH-01..04).

        Priority:
        1. legacy — explicit user opt-in (LDAP / pre-1.13 escape hatch, AUTH-02)
        2. apikey — server advertises apiKeyAuthentication AND user has set an API key
        3. token  — default for modern servers (Subsonic API >= 1.13)
        """
        if self._settings.legacy_auth:
            return "legacy"
        if self._settings.subsonic_api_key and self.supports("apiKeyAuthentication"):
            return "apikey"
        return "token"

    def build_auth_params(self) -> dict[str, str]:
        """Return the auth query-param dict for the current auth mode (AUTH-04).

        apikey mode: {"apiKey": key}                 — u/t/s/p ALL suppressed
        token  mode: {"u": ..., "t": ..., "s": ...}  — fresh salt per call (AUTH-01)
        legacy mode: {"u": ..., "p": ...}             — plaintext fallback (AUTH-02)
        """
        mode = self.choose_auth_mode()
        if mode == "apikey":
            return {"apiKey": self._settings.subsonic_api_key}
        if mode == "token":
            token, salt = make_token_auth(self._settings.password)
            return {
                "u": self._settings.username,
                "t": token,
                "s": salt,
            }
        # legacy
        return {
            "u": self._settings.username,
            "p": self._settings.password,
        }

    # ------------------------------------------------------------------
    # Connection health
    # ------------------------------------------------------------------

    def ping(self) -> bool:
        """Return True if the server responds to a ping."""
        try:
            return bool(self._conn.ping())
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Album methods
    # ------------------------------------------------------------------

    def get_album_list(
        self,
        ltype: str = "newest",
        size: int = 50,
        offset: int = 0,
        **kwargs: Any,
    ) -> list[dict[str, Any]]:
        """Return a list of album dicts from getAlbumList2."""
        resp = self._conn.getAlbumList2(ltype=ltype, size=size, offset=offset, **kwargs)
        return resp.get("albumList2", {}).get("album") or []

    def get_album(self, album_id: str) -> dict[str, Any]:
        """Return a single album dict including its song list."""
        resp = self._conn.getAlbum(album_id)
        return resp.get("album") or {}

    # ------------------------------------------------------------------
    # Artist methods
    # ------------------------------------------------------------------

    def get_artists(self) -> list[dict[str, Any]]:
        """Return a flat list of artist dicts from getArtists index."""
        resp = self._conn.getArtists()
        artists: list[dict[str, Any]] = []
        for index in resp.get("artists", {}).get("index") or []:
            artists.extend(index.get("artist") or [])
        return artists

    def get_artist(self, artist_id: str) -> dict[str, Any]:
        """Return artist dict (including album list)."""
        resp = self._conn.getArtist(artist_id)
        return resp.get("artist") or {}

    # ------------------------------------------------------------------
    # Playlist methods
    # ------------------------------------------------------------------

    def get_playlists(self) -> list[dict[str, Any]]:
        """Return a list of playlist dicts."""
        resp = self._conn.getPlaylists()
        return resp.get("playlists", {}).get("playlist") or []

    def get_playlist(self, playlist_id: str) -> dict[str, Any]:
        """Return a single playlist dict including its track list."""
        resp = self._conn.getPlaylist(playlist_id)
        return resp.get("playlist") or {}

    # ------------------------------------------------------------------
    # Starred
    # ------------------------------------------------------------------

    def get_starred(self) -> dict[str, list[dict[str, Any]]]:
        """Return {'album': [...], 'song': [...], 'artist': [...]} from getStarred2."""
        resp = self._conn.getStarred2()
        return resp.get("starred2") or {}

    # ------------------------------------------------------------------
    # Track methods
    # ------------------------------------------------------------------

    def get_random_songs(
        self,
        size: int = 50,
        genre: str | None = None,
        from_year: int | None = None,
        to_year: int | None = None,
    ) -> list[dict[str, Any]]:
        """Return a list of random song dicts."""
        resp = self._conn.getRandomSongs(
            size=size, genre=genre, fromYear=from_year, toYear=to_year
        )
        return resp.get("randomSongs", {}).get("song") or []

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def search(
        self,
        query: str,
        artist_count: int = 20,
        album_count: int = 20,
        song_count: int = 20,
    ) -> dict[str, list[dict[str, Any]]]:
        """Return search results dict with 'artist', 'album', 'song' keys."""
        resp = self._conn.search2(
            query=query,
            artistCount=artist_count,
            albumCount=album_count,
            songCount=song_count,
        )
        return resp.get("searchResult2") or {}

    # ------------------------------------------------------------------
    # Playback
    # ------------------------------------------------------------------

    def stream_url(
        self,
        track_id: str,
        bitrate: str | None = None,
        fmt: str | None = None,
    ) -> str:
        """Return the stream URL for a track.

        Delegates entirely to libsonic.streamUrl() — ApiClient does NOT inject
        credentials into the URL string itself. libsonic handles auth params.

        NOTE: The returned URL contains auth credentials (t/s or legacy p= param).
        It must be used only in setResolvedUrl — never stored in a directory listing
        that Kodi caches to disk. (See PITFALLS.md: stream URL credential exposure.)
        """
        kwargs: dict[str, Any] = {}
        if bitrate and bitrate != "0":
            kwargs["maxBitRate"] = bitrate
        if fmt and fmt != "raw":
            kwargs["format"] = fmt
        return str(self._conn.streamUrl(sid=track_id, **kwargs))

    def get_cover_art_url(self, cover_id: str, size: int = 512) -> str:
        """Return a cover art URL with explicit size param (PERF-04).

        Always pass size= to avoid fetching full-resolution images on embedded
        devices (bandwidth and OOM risk).
        """
        return str(self._conn.getCoverArtUrl(cover_id, size=size))

    def download(self, track_id: str) -> Any:
        """Return the raw download response for a track."""
        return self._conn.download(track_id)

    # ------------------------------------------------------------------
    # User actions
    # ------------------------------------------------------------------

    def star(
        self,
        song_ids: list[str] | None = None,
        album_ids: list[str] | None = None,
        artist_ids: list[str] | None = None,
    ) -> bool:
        """Star one or more items. Returns True on success."""
        resp = self._conn.star(
            sids=song_ids or [],
            albumIds=album_ids or [],
            artistIds=artist_ids or [],
        )
        return bool(resp.get("status") == "ok")

    def unstar(
        self,
        song_ids: list[str] | None = None,
        album_ids: list[str] | None = None,
        artist_ids: list[str] | None = None,
    ) -> bool:
        """Unstar one or more items. Returns True on success."""
        resp = self._conn.unstar(
            sids=song_ids or [],
            albumIds=album_ids or [],
            artistIds=artist_ids or [],
        )
        return bool(resp.get("status") == "ok")

    def scrobble(self, track_id: str) -> bool:
        """Submit a scrobble for the given track ID. Returns True on success."""
        resp = self._conn.scrobble(track_id)
        return bool(resp.get("status") == "ok")

    # ------------------------------------------------------------------
    # Phase 5: Genre, Radio, Rating methods
    # ------------------------------------------------------------------

    def get_genres(self) -> list[dict[str, Any]]:
        """Return a list of genre dicts from getGenres (Subsonic 1.9.0+)."""
        resp = self._conn.getGenres()
        return resp.get("genres", {}).get("genre") or []

    def get_songs_by_genre(
        self,
        genre: str,
        count: int = 100,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """Return a list of song dicts for the given genre (Subsonic 1.9.0+)."""
        resp = self._conn.getSongsByGenre(genre=genre, count=count, offset=offset)
        return resp.get("songsByGenre", {}).get("song") or []

    def search3(
        self,
        query: str,
        artist_count: int = 20,
        album_count: int = 20,
        song_count: int = 40,
    ) -> dict[str, list[dict[str, Any]]]:
        """Return search3 results dict with 'artist', 'album', 'song' keys.

        Uses ID3-based results (richer metadata including MusicBrainz IDs and
        genre fields) compared to search2. Replaces client.search() (FEAT-02).
        """
        resp = self._conn.search3(
            query=query,
            artistCount=artist_count,
            albumCount=album_count,
            songCount=song_count,
        )
        return resp.get("searchResult3") or {}

    def set_rating(self, item_id: str, rating: int) -> bool:
        """Set a 1-5 star rating on a track/album/artist. Pass 0 to clear.

        Returns True on success, False on failure (FEAT-03).
        """
        try:
            resp = self._conn.setRating(id=item_id, rating=rating)
            return bool(resp.get("status") == "ok")
        except Exception:
            return False

    def get_internet_radio_stations(self) -> list[dict[str, Any]]:
        """Return a list of internet radio station dicts (Subsonic 1.9.0+).

        Returns empty list if the server does not support this endpoint or
        returns no stations (FEAT-04).
        """
        try:
            resp = self._conn.getInternetRadioStations()
            return resp.get("internetRadioStations", {}).get("internetRadioStation") or []
        except Exception:
            return []

    # ------------------------------------------------------------------
    # OpenSubsonic capability probe (Phase 3 stub — called in Phase 4)
    # ------------------------------------------------------------------

    def get_open_subsonic_extensions(self) -> list[str]:
        """Return extension names. Delegates to probe_extensions() (Phase 4 upgrade).

        Phase 3 stub superseded — probe_extensions() is the canonical implementation.
        Returns a sorted list for stable ordering; callers that only need membership
        testing should use supports() instead.
        """
        return sorted(self.probe_extensions())
