"""subsonic.api — API client sub-package."""

from __future__ import annotations
