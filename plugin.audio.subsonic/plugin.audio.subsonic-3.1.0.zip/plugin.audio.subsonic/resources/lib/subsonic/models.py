"""
subsonic.models — Pure-data type definitions for the Subsonic plugin.

TypedDicts represent API response shapes (dicts returned by libsonic).
Dataclasses represent internal plugin state objects (created by application logic).

All classes are importable without Kodi installed — zero Kodi API dependencies.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

try:
    from typing import TypedDict
except ImportError:
    from typing_extensions import TypedDict


# ---------------------------------------------------------------------------
# Subsonic API response TypedDicts (total=False — all fields optional since
# real-world servers return inconsistent subsets)
# ---------------------------------------------------------------------------


class SubsonicArtist(TypedDict, total=False):
    """Shape of an artist object returned by getArtists / getArtist."""

    id: str
    name: str
    albumCount: int
    coverArt: str | None
    starred: str | None  # ISO 8601 timestamp if starred, else absent
    musicBrainzId: str | None


class SubsonicAlbum(TypedDict, total=False):
    """Shape of an album object returned by getAlbumList2 / getAlbum."""

    id: str
    name: str
    artist: str
    artistId: str
    coverArt: str
    songCount: int
    duration: int
    created: str
    starred: str | None  # ISO 8601 timestamp if starred
    year: int
    genre: str
    musicBrainzId: str


class SubsonicTrack(TypedDict, total=False):
    """Shape of a song/track object returned by getAlbum / search2 / getSong."""

    id: str
    title: str
    artist: str
    artistId: str | None
    album: str
    albumId: str | None
    duration: int
    bitRate: int | None
    contentType: str
    suffix: str
    coverArt: str | None
    year: int | None
    track: int | None
    discNumber: int | None
    starred: str | None  # ISO 8601 timestamp if starred
    musicBrainzId: str | None


class SubsonicPlaylist(TypedDict, total=False):
    """Shape of a playlist object returned by getPlaylists / getPlaylist."""

    id: str
    name: str
    songCount: int
    duration: int
    created: str
    coverArt: str | None
    comment: str | None
    owner: str | None
    public: bool | None


class SubsonicGenre(TypedDict, total=False):
    """Shape of a genre entry returned by getGenres."""

    value: str
    songCount: int
    albumCount: int


class InternetRadioStation(TypedDict, total=False):
    """Shape of a radio station object returned by getInternetRadioStations."""

    id: str
    name: str
    streamUrl: str
    homePageUrl: str | None


# ---------------------------------------------------------------------------
# Internal application state dataclasses
# ---------------------------------------------------------------------------


@dataclass
class PageState:
    """Tracks pagination position for a browse listing."""

    page: int = 1
    page_size: int = 50
    offset: int = 0
    has_more: bool = True


@dataclass
class PlayContext:
    """Resolved playback context passed to xbmcplugin.setResolvedUrl."""

    stream_url: str
    track_id: str
    title: str
    duration: int = 0


@dataclass
class CacheEntry:
    """A single TTL cache entry holding any value with an expiry timestamp."""

    value: Any
    expires_at: float  # Unix timestamp (seconds); compare to time.time()
