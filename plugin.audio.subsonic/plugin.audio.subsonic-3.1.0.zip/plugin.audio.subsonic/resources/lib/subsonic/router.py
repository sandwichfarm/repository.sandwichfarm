from __future__ import annotations

from typing import Any, Callable
from urllib.parse import parse_qsl, urlencode

PLUGIN_ID: str = "plugin.audio.subsonic"

# Module-level route registry. Populated by the @route() decorator.
_ROUTES: dict[str, Callable[..., Any]] = {}


def route(action: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator that registers a handler for the given action name.

    Usage::

        @route("list_albums")
        def list_albums(page: str = "1", **kwargs: str) -> None:
            ...
    """

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        _ROUTES[action] = fn
        return fn

    return decorator


def set_routes(routes_dict: dict[str, Callable[..., Any]]) -> None:
    """Replace _ROUTES wholesale with routes_dict.

    Used by bootstrap._patch_routes_with_context() to swap the original
    @route()-registered handlers with context-wrapped versions without
    re-importing handler modules (Python caches imports; decorators do not
    re-fire on a second import of the same module).

    After calling set_routes(), dispatch() will use the new handlers.
    """
    _ROUTES.clear()
    _ROUTES.update(routes_dict)


def url_for(action: str, **params: Any) -> str:
    """Build a plugin:// URL for the given action with optional query params.

    All param values are URL-encoded, preventing injection via special characters.

    Example::

        url_for("list_albums", page="2", type="newest")
        # -> "plugin://plugin.audio.subsonic/?action=list_albums&page=2&type=newest"
    """
    qs = urlencode({"action": action, **params})
    return f"plugin://{PLUGIN_ID}/?{qs}"


def dispatch(argv: list[str]) -> None:
    """Parse sys.argv and call the registered handler for the given action.

    argv[2] is the query string portion of the plugin URL (may start with '?').
    If no action param is present, dispatches to the 'root' handler.

    Raises ValueError for unknown action names.
    """
    raw_qs = argv[2].lstrip("?") if len(argv) > 2 else ""
    params = dict(parse_qsl(raw_qs))
    action = params.pop("action", "root")
    handler = _ROUTES.get(action)
    if handler is None:
        raise ValueError(
            f"No handler registered for action={action!r}. "
            f"Registered actions: {list(_ROUTES.keys())}"
        )
    handler(**params)


def clear_routes() -> None:
    """Remove all registered routes. Used in tests to reset state."""
    _ROUTES.clear()
