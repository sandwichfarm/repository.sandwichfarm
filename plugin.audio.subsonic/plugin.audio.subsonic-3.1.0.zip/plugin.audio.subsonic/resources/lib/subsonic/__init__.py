"""
subsonic — Kodi audio addon library for Subsonic-API servers.
"""

from __future__ import annotations

__version__ = "3.0.2"
