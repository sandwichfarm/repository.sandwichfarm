"""
subsonic.listings — Single module owning all Kodi UI calls.

All ``xbmcplugin`` and ``xbmcgui.ListItem`` calls live here so that handler
modules (browse, search, playback) remain free of Kodi UI dependencies and are
unit-testable without a running Kodi instance (ARCH-05).

Key design decisions:
- Every ListItem builder uses ``li.getMusicInfoTag()`` typed setters —
  NOT the deprecated dict-based setInfo API (COMPAT-05).
- Cover art URLs are always passed in with an explicit ``size`` param by the
  caller (e.g. ``connection.getCoverArtUrl(id, size=512)``) (PERF-04).
- ``end_directory`` calls ``setContent`` and ``addSortMethod`` before
  ``endOfDirectory`` on every listing (PERF-05).
- ``show_search_dialog`` wraps ``xbmcgui.Dialog().input`` so that search.py
  and other handler modules need not import ``xbmcgui`` directly (ARCH-05).
"""

from __future__ import annotations

import xbmcgui
import xbmcplugin
from subsonic.models import (
    SubsonicAlbum,
    SubsonicArtist,
    SubsonicGenre,
    SubsonicPlaylist,
    SubsonicTrack,
)

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _starred_label(label: str, is_starred: bool) -> str:
    """Prefix *label* with a gold star if *is_starred* is True."""
    if is_starred:
        return f"[COLOR gold]★[/COLOR] {label}"
    return label


# ---------------------------------------------------------------------------
# Public UI helper
# ---------------------------------------------------------------------------


def show_search_dialog(prompt: str = "Search") -> str | None:
    """Show a text-input dialog and return the user's query string.

    Returns ``None`` if the user cancels or submits an empty string.
    Wraps ``xbmcgui.Dialog().input`` so that handler modules (search.py, etc.)
    need not import ``xbmcgui`` directly — keeping them free of Kodi UI
    dependencies (ARCH-05).
    """
    dialog = xbmcgui.Dialog()
    query: str = dialog.input(prompt, type=xbmcgui.INPUT_ALPHANUM)
    return query if query else None


def show_rating_select(track_id: str) -> int | None:
    """Show a rating selection dialog for the given track.

    Returns the selected rating (1-5), 0 to clear, or None if cancelled.
    Wraps ``xbmcgui.Dialog().select`` so that actions.py need not import
    ``xbmcgui`` directly (ARCH-05).

    Args:
        track_id: The Subsonic track ID (used by the caller to dispatch the
                  rate action; not used internally in this function).

    Returns:
        An integer 1-5 (rating), 0 (clear existing rating), or None if the
        user cancelled the dialog.
    """
    options = [
        "1 Star",
        "2 Stars",
        "3 Stars",
        "4 Stars",
        "5 Stars",
        "Clear Rating",
    ]
    dialog = xbmcgui.Dialog()
    idx = dialog.select("Rate", options)
    if idx < 0:
        return None
    # Map index 0-4 → rating 1-5; index 5 → rating 0 (clear)
    return idx + 1 if idx < 5 else 0


# ---------------------------------------------------------------------------
# ListItem builders
# ---------------------------------------------------------------------------


def build_track_item(
    track: SubsonicTrack,
    url: str,
    cover_url: str = "",
    hide_artist: bool = False,
) -> tuple[str, xbmcgui.ListItem, bool]:
    """Build a ``(url, ListItem, is_folder)`` tuple for a playable track.

    Uses ``getMusicInfoTag()`` typed setters — NOT the deprecated dict-based
    setInfo API (COMPAT-05).

    Args:
        track:       Subsonic track dict from the API response.
        url:         Fully-qualified plugin URL for the play action.
        cover_url:   Pre-sized cover art URL (caller must pass size param).
        hide_artist: If True, omit artist prefix from the label.

    Returns:
        ``(url, li, False)`` — tracks are never folders.
    """
    title: str = track.get("title") or "<Unknown>"
    artist: str = track.get("artist") or "<Unknown>"
    label = title if hide_artist else f"{artist} - {title}"
    is_starred = bool(track.get("starred"))
    label = _starred_label(label, is_starred)

    li = xbmcgui.ListItem(label=label, path=url, offscreen=True)
    li.setProperty("IsPlayable", "true")

    if cover_url:
        li.setArt({"thumb": cover_url, "fanart": cover_url})

    tag = li.getMusicInfoTag()
    tag.setTitle(title)
    tag.setArtist(artist)

    album = track.get("album")
    if album:
        tag.setAlbum(album)

    year = track.get("year")
    if year:
        tag.setYear(int(year))

    track_num = track.get("track")
    if track_num:
        tag.setTrackNumber(int(track_num))

    duration = track.get("duration")
    if duration:
        tag.setDuration(int(duration))

    genre = track.get("genre")
    if genre:
        tag.setGenres([genre])

    disc_number = track.get("discNumber")
    if disc_number:
        tag.setDiscNumber(int(disc_number))

    mb_id = track.get("musicBrainzId")
    if mb_id:
        tag.setMusicBrainzTrackID(mb_id)

    return url, li, False


def build_album_item(
    album: SubsonicAlbum,
    url: str,
    cover_url: str = "",
    hide_artist: bool = False,
) -> tuple[str, xbmcgui.ListItem, bool]:
    """Build a ``(url, ListItem, is_folder)`` tuple for an album directory.

    Args:
        album:       Subsonic album dict from the API response.
        url:         Fully-qualified plugin URL for the list-tracks action.
        cover_url:   Pre-sized cover art URL (caller must pass size param).
        hide_artist: If True, omit artist prefix from the label.

    Returns:
        ``(url, li, True)`` — albums are always folders.
    """
    name: str = album.get("name") or "<Unknown>"
    artist: str = album.get("artist") or ""
    if hide_artist or not artist:
        label = name
    else:
        label = f"{artist} - {name}"
    is_starred = bool(album.get("starred"))
    label = _starred_label(label, is_starred)

    li = xbmcgui.ListItem(label=label, offscreen=True)
    if cover_url:
        li.setArt({"thumb": cover_url, "fanart": cover_url})

    tag = li.getMusicInfoTag()
    tag.setTitle(name)
    if artist:
        tag.setArtist(artist)

    year = album.get("year")
    if year:
        tag.setYear(int(year))

    genre = album.get("genre")
    if genre:
        tag.setGenres([genre])

    duration = album.get("duration")
    if duration:
        tag.setDuration(int(duration))

    mb_id = album.get("musicBrainzId")
    if mb_id:
        tag.setMusicBrainzAlbumID(mb_id)

    return url, li, True


def build_artist_item(
    artist: SubsonicArtist,
    url: str,
    cover_url: str = "",
) -> tuple[str, xbmcgui.ListItem, bool]:
    """Build a ``(url, ListItem, is_folder)`` tuple for an artist directory.

    Args:
        artist:    Subsonic artist dict from the API response.
        url:       Fully-qualified plugin URL for the list-albums action.
        cover_url: Pre-sized cover art URL (caller must pass size param).

    Returns:
        ``(url, li, True)`` — artists are always folders.
    """
    name: str = artist.get("name") or "<Unknown>"
    is_starred = bool(artist.get("starred"))
    label = _starred_label(name, is_starred)

    li = xbmcgui.ListItem(label=label, offscreen=True)
    if cover_url:
        li.setArt({"thumb": cover_url, "fanart": cover_url})

    tag = li.getMusicInfoTag()
    tag.setArtist(name)

    mb_id = artist.get("musicBrainzId")
    if mb_id:
        tag.setMusicBrainzArtistID(mb_id)

    return url, li, True


def build_playlist_item(
    playlist: SubsonicPlaylist,
    url: str,
    cover_url: str = "",
) -> tuple[str, xbmcgui.ListItem, bool]:
    """Build a ``(url, ListItem, is_folder)`` tuple for a playlist directory.

    Args:
        playlist:  Subsonic playlist dict from the API response.
        url:       Fully-qualified plugin URL for the list-tracks action.
        cover_url: Pre-sized cover art URL (caller must pass size param).

    Returns:
        ``(url, li, True)`` — playlists are always folders.
    """
    name: str = playlist.get("name") or "<Unknown>"
    li = xbmcgui.ListItem(label=name, offscreen=True)
    if cover_url:
        li.setArt({"thumb": cover_url, "fanart": cover_url})

    tag = li.getMusicInfoTag()
    tag.setTitle(name)

    duration = playlist.get("duration")
    if duration:
        tag.setDuration(int(duration))

    return url, li, True


def build_genre_item(
    genre: SubsonicGenre,
    url: str,
) -> tuple[str, xbmcgui.ListItem, bool]:
    """Build a ``(url, ListItem, is_folder)`` tuple for a genre directory.

    Args:
        genre: Subsonic genre dict (value, songCount, albumCount).
        url:   Fully-qualified plugin URL for the genre-tracks action.

    Returns:
        ``(url, li, True)`` — genres are navigation folders.
    """
    name: str = genre.get("value") or "<Unknown>"
    song_count: int = genre.get("songCount") or 0
    label = f"{name} ({song_count} songs)"
    li = xbmcgui.ListItem(label=label, offscreen=True)
    return url, li, True


def build_nav_item(
    label: str,
    url: str,
) -> tuple[str, xbmcgui.ListItem, bool]:
    """Build a navigation item (e.g. 'Next Page', 'Back to menu').

    Args:
        label: Display text for the item.
        url:   Fully-qualified plugin URL for the navigation action.

    Returns:
        ``(url, li, True)`` — navigation items are folders.
    """
    li = xbmcgui.ListItem(label=label, offscreen=True)
    return url, li, True


# ---------------------------------------------------------------------------
# Directory listing helpers
# ---------------------------------------------------------------------------


def add_items(
    handle: int,
    items: list[tuple[str, xbmcgui.ListItem, bool]],
) -> None:
    """Add all *items* to the directory listing via ``addDirectoryItem``.

    Args:
        handle: Plugin handle from ``sys.argv[1]``.
        items:  List of ``(url, ListItem, is_folder)`` tuples.
    """
    for url, li, is_folder in items:
        xbmcplugin.addDirectoryItem(handle, url, li, is_folder)


def end_directory(
    handle: int,
    content: str = "songs",
    sort_methods: list[int] | None = None,
    succeeded: bool = True,
    update_listing: bool = False,
    cache_to_disk: bool = False,
) -> None:
    """Finalize a directory listing.

    Calls ``setContent``, any requested ``addSortMethod`` calls, then
    ``endOfDirectory`` — in that order (PERF-05).

    Args:
        handle:         Plugin handle from ``sys.argv[1]``.
        content:        Kodi content type — one of ``'songs'``, ``'albums'``,
                        ``'artists'``, ``'playlists'``, ``'genres'``.
        sort_methods:   List of ``xbmcplugin.SORT_METHOD_*`` int constants.
                        Pass an empty list (or omit) for no sort methods.
        succeeded:      Whether the directory was built successfully.
        update_listing: Passed through to ``endOfDirectory``.
        cache_to_disk:  Passed through to ``endOfDirectory``.
    """
    xbmcplugin.setContent(handle, content)
    for method in sort_methods or []:
        xbmcplugin.addSortMethod(handle, method)
    xbmcplugin.endOfDirectory(handle, succeeded, update_listing, cache_to_disk)
