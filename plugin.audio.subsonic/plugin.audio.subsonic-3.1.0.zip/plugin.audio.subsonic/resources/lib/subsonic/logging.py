from __future__ import annotations

import re
import traceback as _traceback

import xbmc

# Matches auth parameters that must never appear in logs.
# Covers: p=, t=, s=, password=, token=, salt=, apiKey=
_AUTH_RE = re.compile(r"\b(p|t|s|password|token|salt|apiKey)=[^&\s]*")


def safe_log(msg: str, level: int = xbmc.LOGINFO) -> None:
    """Log a message after redacting any credential/auth parameters from URLs.

    This is the single route all addon modules should use instead of calling
    xbmc.log() directly. Phase 4 will expand coverage; Phase 3 routes log calls
    here wherever the code is touched.
    """
    sanitized = _AUTH_RE.sub(r"\1=REDACTED", msg)
    xbmc.log("Subsonic: " + sanitized, level)


def log_debug(msg: str) -> None:
    safe_log(msg, xbmc.LOGDEBUG)


def log_info(msg: str) -> None:
    safe_log(msg, xbmc.LOGINFO)


def log_warning(msg: str) -> None:
    safe_log(msg, xbmc.LOGWARNING)


def log_error(msg: str) -> None:
    safe_log(msg, xbmc.LOGERROR)


def log_exception(msg: str) -> None:
    """Log an error message with full traceback appended."""
    full = f"{msg}\n{_traceback.format_exc()}"
    safe_log(full, xbmc.LOGERROR)
