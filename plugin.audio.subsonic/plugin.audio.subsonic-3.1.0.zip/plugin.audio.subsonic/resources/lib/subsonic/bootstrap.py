"""
subsonic.bootstrap — Entry-point wiring for the plugin and service processes.

run_plugin(argv)  is called by main.py.
run_service()     is called by service.py.

Both construct their own independent Settings + ApiClient (ARCH-11 — no shared
module-level singletons between the plugin process and the service process).

B4 fix: _ORIGINAL_ROUTES is a module-load-time snapshot of _ROUTES (taken after
the handler-module imports below fire the @route() decorators exactly once).
_patch_routes_with_context wraps from _ORIGINAL_ROUTES, not from the live _ROUTES.
This prevents an import-cache race: on a second call to run_plugin() in the same
process, re-importing handler modules does NOT re-fire @route() decorators, so if
we tried to snapshot _ROUTES at invocation time it would be empty. (See PLAN 03-08.)
"""

from __future__ import annotations

from typing import Any, Callable

import subsonic.actions  # noqa: F401

# Import handler modules so @route() decorators fire exactly once at module-load
# time. Python caches imports — decorators do NOT re-fire on subsequent imports of
# the same module, which is why the snapshot must happen here (module-load time).
import subsonic.browse  # noqa: F401 — registers @route handlers
import subsonic.playback  # noqa: F401
import subsonic.search  # noqa: F401
import xbmcaddon
import xbmcgui
import xbmcvfs
from subsonic.api.client import ApiClient
from subsonic.cache import Cache
from subsonic.logging import log_exception, log_info
from subsonic.router import _ROUTES, dispatch, set_routes
from subsonic.settings import Settings

# Snapshot original (unwrapped) routes ONCE at module load time (after imports
# above). _patch_routes_with_context wraps from this snapshot every invocation.
# Safe across multiple run_plugin() calls in the same process. (B4 fix)
_ORIGINAL_ROUTES: dict[str, Callable[..., Any]] = dict(_ROUTES)


def _get_cache_dir() -> str:
    """Return the addon's xbmcvfs profile directory for cache persistence."""
    try:
        addon = xbmcaddon.Addon()
        path = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        return str(path)
    except Exception:
        return "/tmp/subsonic-cache/"


def _patch_routes_with_context(
    client: ApiClient,
    settings: Settings,
    cache: Cache,
    handle: int,
) -> None:
    """Wrap all registered route handlers to inject client/settings/cache/handle.

    Wraps from _ORIGINAL_ROUTES (module-load snapshot), NOT from the current
    _ROUTES value. This is safe across multiple run_plugin() calls in the same
    process because the snapshot is taken once at import time. (B4 fix)

    After wrapping, calls set_routes(wrapped) to atomically replace _ROUTES.
    """

    def _make_wrapper(handler: Callable[..., Any]) -> Callable[..., Any]:
        def wrapped_handler(**params: str) -> None:
            handler(
                client=client,
                settings=settings,
                handle=handle,
                cache=cache,
                **params,
            )

        return wrapped_handler

    wrapped = {action: _make_wrapper(fn) for action, fn in _ORIGINAL_ROUTES.items()}
    set_routes(wrapped)


def _check_insecure_ssl_acknowledgement(settings: Settings) -> None:
    """Show a warning dialog the first time insecure SSL is detected enabled.

    Decision tree (AUTH-07):
    - insecure disabled → return immediately (no dialog).
    - insecure enabled AND already acknowledged → return immediately (no dialog).
    - insecure enabled AND NOT acknowledged → show yesno dialog:
        - Accept ("I understand") → persist acknowledgement so dialog never shows again.
        - Cancel               → revert insecure setting to False.

    ARCH-05: bootstrap.py is the ONE permitted place outside listings.py to call
    xbmcgui directly. This dialog is a startup gate, not a UI listing.
    """
    if not settings.insecure:
        return
    if settings.insecure_ssl_acknowledged:
        return
    confirmed: bool = xbmcgui.Dialog().yesno(
        "Insecure SSL warning",
        "Disabling SSL certificate verification leaves traffic vulnerable to "
        "interception. Only enable this for self-signed homelab servers you "
        "control. Continue?",
        nolabel="Cancel",
        yeslabel="I understand",
    )
    if confirmed:
        settings.set_insecure_ssl_acknowledged(True)
    else:
        settings.set_insecure_ssl(False)


def run_plugin(argv: list[str]) -> None:
    """Entry point for main.py (plugin process).

    Constructs Settings, ApiClient, Cache; wraps routes with per-invocation
    context; calls dispatch(argv). All handler state is local to this call —
    no global singletons (ARCH-11).
    """
    try:
        settings = Settings()
        _check_insecure_ssl_acknowledgement(settings)  # AUTH-07
        client = ApiClient(settings)
        cache = Cache(cache_dir=_get_cache_dir())

        _patch_routes_with_context(client, settings, cache, int(argv[1]))
        dispatch(argv)

    except Exception:
        log_exception("run_plugin: unhandled error in plugin dispatch")


def run_service() -> None:
    """Entry point for service.py (long-running background service).

    Constructs its own independent Settings + ApiClient (ARCH-11 — no shared
    globals with the plugin process). Instantiates Scrobbler and runs the
    monitor loop.
    """
    from subsonic.scrobbler import Scrobbler

    try:
        settings = Settings()
        if not settings.scrobble_enabled:
            log_info("Subsonic service: scrobbling disabled — service not started")
            return

        client = ApiClient(settings)
        scrobbler = Scrobbler(client=client, settings=settings)
        log_info("Subsonic service started")
        scrobbler.run()

    except Exception:
        log_exception("run_service: unhandled error in service startup")
