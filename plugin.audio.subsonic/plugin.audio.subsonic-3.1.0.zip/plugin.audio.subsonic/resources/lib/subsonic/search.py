"""
subsonic.search — Search handler module.

ARCH-05 compliance: search.py uses show_search_dialog from subsonic.listings
instead of importing xbmcgui directly. This keeps search.py free of all Kodi
UI dependencies and makes it unit-testable without a running Kodi instance.

Phase 5: migrated from search2 to search3 (FEAT-02) for richer metadata.
"""

from __future__ import annotations

from typing import Any

from subsonic.listings import (
    add_items,
    build_album_item,
    build_artist_item,
    build_track_item,
    end_directory,
    show_search_dialog,
)
from subsonic.router import route, url_for


@route("search")
def search(client: Any, settings: Any, handle: int, **params: str) -> None:
    """Text search across artists, albums, and tracks using search3 (FEAT-02).

    Shows a text-input dialog (via show_search_dialog from listings — no direct
    xbmcgui here per ARCH-05). Dispatches to search3, then presents mixed
    artist / album / song results.
    """
    query = show_search_dialog("Search")
    if not query:
        end_directory(handle, content="songs", succeeded=False)
        return

    results = client.search3(query=query, artist_count=20, album_count=20, song_count=40)

    items: list[Any] = []

    for artist in results.get("artist") or []:
        cover_url = (
            client.get_cover_art_url(artist["coverArt"], size=512)
            if artist.get("coverArt")
            else ""
        )
        items.append(
            build_artist_item(
                artist,
                url=url_for("list_albums", artist_id=artist.get("id", "")),
                cover_url=cover_url,
            )
        )

    for album in results.get("album") or []:
        cover_url = (
            client.get_cover_art_url(album["coverArt"], size=512) if album.get("coverArt") else ""
        )
        items.append(
            build_album_item(
                album,
                url=url_for("list_tracks", album_id=album.get("id", "")),
                cover_url=cover_url,
                hide_artist=False,
            )
        )

    for track in results.get("song") or []:
        cover_url = (
            client.get_cover_art_url(track["coverArt"], size=512) if track.get("coverArt") else ""
        )
        items.append(
            build_track_item(
                track,
                url=url_for("play_track", id=track.get("id", "")),
                cover_url=cover_url,
                hide_artist=False,
            )
        )

    add_items(handle, items)
    end_directory(handle, content="songs")


@route("search_album")
def search_album(client: Any, settings: Any, handle: int, **params: str) -> None:
    """Album-only search using search3 (FEAT-02).

    Shows a text-input dialog (via show_search_dialog — no xbmcgui import per
    ARCH-05). Passes artistCount=0 and songCount=0 so only album results are
    returned from the server.
    """
    query = show_search_dialog("Search Albums")
    if not query:
        end_directory(handle, content="albums", succeeded=False)
        return

    results = client.search3(query=query, artist_count=0, album_count=50, song_count=0)

    items: list[Any] = []
    for album in results.get("album") or []:
        cover_url = (
            client.get_cover_art_url(album["coverArt"], size=512) if album.get("coverArt") else ""
        )
        items.append(
            build_album_item(
                album,
                url=url_for("list_tracks", album_id=album.get("id", "")),
                cover_url=cover_url,
                hide_artist=False,
            )
        )

    add_items(handle, items)
    end_directory(handle, content="albums")
