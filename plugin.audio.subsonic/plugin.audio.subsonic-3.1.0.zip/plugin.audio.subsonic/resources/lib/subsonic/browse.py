"""
subsonic.browse — Browse and navigation handlers.

All handler functions are registered with @route() and contain NO direct Kodi
UI calls (no xbmcplugin, no xbmcgui). All UI operations go through
subsonic.listings (ARCH-05).

Handler signatures: (client, settings, handle, **params)
The bootstrap (Plan 08) resolves context and calls them. In Wave 3 we define
the signatures; bootstrap wiring comes in Plan 08.

Pagination correctness (BUG-04, PERF-03):
- "Next Page" only appears when len(returned_items) >= page_size.
- Random tracks and random albums never paginate.
- Starred albums use in-Python slice pagination (total list from server).

Tracknumber fix (BUG-03):
- Playlist entries get track.setdefault("track", i+1) so the
  InfoTagMusic.setTrackNumber() call in listings.build_track_item works.
"""

from __future__ import annotations

import json
from typing import Any

from subsonic.listings import (
    add_items,
    build_album_item,
    build_artist_item,
    build_genre_item,
    build_nav_item,
    build_playlist_item,
    build_track_item,
    end_directory,
)
from subsonic.models import SubsonicAlbum, SubsonicTrack
from subsonic.router import route, url_for

# ---------------------------------------------------------------------------
# Root menu
# ---------------------------------------------------------------------------


@route("root")
def root(client: Any, settings: Any, handle: int, **params: str) -> None:
    """Main menu listing."""
    items = [
        build_nav_item("Artists", url_for("list_artists")),
        build_nav_item("Albums — Newest", url_for("list_albums", ltype="newest")),
        build_nav_item("Albums — Recent", url_for("list_albums", ltype="recent")),
        build_nav_item("Albums — Frequent", url_for("list_albums", ltype="frequent")),
        build_nav_item("Albums — Random", url_for("list_albums", ltype="random")),
        build_nav_item("Albums — By Year", url_for("menu_albums", menu_id="by_year")),
        build_nav_item("Albums — By Genre", url_for("menu_albums", menu_id="by_genre")),
        build_nav_item("Albums — Starred", url_for("list_albums", ltype="starred")),
        build_nav_item("Tracks — Random", url_for("list_tracks", menu_id="tracks_random")),
        build_nav_item("Tracks — Starred", url_for("list_tracks", menu_id="tracks_starred")),
        build_nav_item("Playlists", url_for("list_playlists")),
        build_nav_item("Search", url_for("search")),
        build_nav_item("Search Albums", url_for("search_album")),
        build_nav_item("Genres", url_for("genres")),
        build_nav_item("Internet Radio", url_for("radio")),
    ]
    add_items(handle, items)
    end_directory(handle, content="albums")


# ---------------------------------------------------------------------------
# Album sub-menus
# ---------------------------------------------------------------------------


@route("menu_albums")
def menu_albums(client: Any, settings: Any, handle: int, menu_id: str = "", **params: str) -> None:
    """Sub-menu for album filter types that require extra parameters."""
    items: list[Any] = []
    if menu_id == "by_year":
        for decade_start in range(1950, 2030, 10):
            label = f"{decade_start}s"
            items.append(
                build_nav_item(
                    label,
                    url_for(
                        "list_albums",
                        ltype="byYear",
                        fromYear=str(decade_start),
                        toYear=str(decade_start + 9),
                    ),
                )
            )
    elif menu_id == "by_genre":
        items.append(build_nav_item("Browse by Genre", url_for("genres")))
    add_items(handle, items)
    end_directory(handle, content="albums")


# ---------------------------------------------------------------------------
# list_albums
# ---------------------------------------------------------------------------


@route("list_albums")
def list_albums(
    client: Any,
    settings: Any,
    handle: int,
    ltype: str = "newest",
    page: str = "1",
    artist_id: str = "",
    album_id: str = "",
    query_args: str = "",
    **params: str,
) -> None:
    """List albums with correct pagination (BUG-04 fix: len < page_size = last page).

    Handles four cases:
    1. artist_id provided  — show all albums for that artist (no pagination).
    2. album_id provided   — redirect to list_tracks for the album.
    3. ltype == "starred"  — in-Python slice pagination of the starred album list.
    4. default             — getAlbumList2 with offset-based pagination.
    """
    albums_per_page: int = settings.albums_per_page
    page_num: int = max(1, int(page))
    offset: int = (page_num - 1) * albums_per_page

    extra: dict[str, Any] = {}
    if query_args:
        try:
            extra = json.loads(query_args)
        except (ValueError, KeyError):
            pass

    items: list[SubsonicAlbum] = []
    if artist_id:
        artist = client.get_artist(artist_id)
        items = artist.get("album") or []
    elif ltype == "starred":
        starred = client.get_starred()
        all_albums: list[SubsonicAlbum] = starred.get("album") or []
        items = all_albums[offset : offset + albums_per_page]
    else:
        items = client.get_album_list(ltype=ltype, size=albums_per_page, offset=offset, **extra)

    # Hide artist name when all albums share one artist (or listing is empty).
    artists = {item.get("artist") for item in items if item.get("artist")}
    hide_artist = len(artists) <= 1

    listing_items: list[Any] = []
    for album in items:
        cover_url = ""
        if album.get("coverArt"):
            cover_url = client.get_cover_art_url(album["coverArt"], size=512)
        listing_items.append(
            build_album_item(
                album,
                url=url_for("list_tracks", album_id=album.get("id", "")),
                cover_url=cover_url,
                hide_artist=hide_artist,
            )
        )

    # Pagination: show Next Page ONLY when server returned a full page (BUG-04).
    # Artist view never paginates (all albums loaded at once).
    # Random albums never paginate (new random set each time is not meaningful).
    if not artist_id:
        is_random = ltype == "random"
        has_more = (not is_random) and (len(items) >= albums_per_page)
        if has_more:
            next_params: dict[str, str] = {
                "ltype": ltype,
                "page": str(page_num + 1),
            }
            if query_args:
                next_params["query_args"] = query_args
            listing_items.append(
                build_nav_item(
                    f"Next ({page_num + 1})",
                    url_for("list_albums", **next_params),
                )
            )

    add_items(handle, listing_items)
    end_directory(handle, content="albums", cache_to_disk=True)


# ---------------------------------------------------------------------------
# list_artists
# ---------------------------------------------------------------------------


@route("list_artists")
def list_artists(client: Any, settings: Any, handle: int, **params: str) -> None:
    """List all artists (ID3 tag library view)."""
    artists = client.get_artists()
    items: list[Any] = []
    for artist in artists:
        cover_url = ""
        if artist.get("coverArt"):
            cover_url = client.get_cover_art_url(artist["coverArt"], size=512)
        items.append(
            build_artist_item(
                artist,
                url=url_for("list_albums", artist_id=artist.get("id", "")),
                cover_url=cover_url,
            )
        )
    add_items(handle, items)
    end_directory(handle, content="artists")


# ---------------------------------------------------------------------------
# list_tracks
# ---------------------------------------------------------------------------


@route("list_tracks")
def list_tracks(
    client: Any,
    settings: Any,
    handle: int,
    menu_id: str = "",
    album_id: str = "",
    playlist_id: str = "",
    page: str = "1",
    query_args: str = "",
    **params: str,
) -> None:
    """List tracks with pagination (BUG-04) and playlist tracknumber fix (BUG-03).

    Cases:
    - album_id:          album tracks (no pagination — all songs in album).
    - playlist_id:       playlist entries with track numbers from position (BUG-03).
    - tracks_starred:    starred songs (no pagination).
    - tracks_random:     random songs (no pagination — new set each time).
    - default:           not reachable in Phase 3 (reserved for future genre/year filters).
    """
    tracks_per_page: int = settings.tracks_per_page
    page_num: int = max(1, int(page))
    (page_num - 1) * tracks_per_page

    extra: dict[str, Any] = {}
    if query_args:
        try:
            extra = json.loads(query_args)
        except (ValueError, KeyError):
            pass

    is_random = False
    items: list[SubsonicTrack] = []

    if album_id:
        album = client.get_album(album_id)
        items = album.get("song") or []
    elif playlist_id:
        playlist = client.get_playlist(playlist_id)
        raw_items = playlist.get("entry") or []
        # BUG-03 fix: assign track numbers from playlist position so that
        # InfoTagMusic.setTrackNumber() in listings.build_track_item works.
        items = []
        for i, item in enumerate(raw_items):
            track_item: SubsonicTrack = dict(item)  # type: ignore[assignment]
            track_item.setdefault("track", i + 1)
            items.append(track_item)
    elif menu_id == "tracks_starred":
        starred = client.get_starred()
        items = starred.get("song") or []
    elif menu_id == "tracks_random":
        is_random = True
        items = client.get_random_songs(size=tracks_per_page, **extra)

    # Hide artist when all tracks share one artist (typical for album view).
    artists_in_list = {item.get("artist") for item in items if item.get("artist")}
    hide_artist = len(artists_in_list) <= 1

    listing_items: list[Any] = []
    for track in items:
        cover_url = ""
        if track.get("coverArt"):
            cover_url = client.get_cover_art_url(track["coverArt"], size=512)
        listing_items.append(
            build_track_item(
                track,
                url=url_for("play_track", id=track.get("id", "")),
                cover_url=cover_url,
                hide_artist=hide_artist,
            )
        )

    # Pagination: only for cases where the server could return more pages.
    # Explicitly excluded: random (is_random), starred, album view, playlist view.
    paginate = not (is_random or menu_id == "tracks_starred" or album_id or playlist_id)
    if paginate and len(items) >= tracks_per_page:
        next_params_t: dict[str, str] = {
            "menu_id": menu_id,
            "page": str(page_num + 1),
        }
        if query_args:
            next_params_t["query_args"] = query_args
        listing_items.append(
            build_nav_item(
                f"Next ({page_num + 1})",
                url_for("list_tracks", **next_params_t),
            )
        )

    add_items(handle, listing_items)
    end_directory(handle, content="songs")


# ---------------------------------------------------------------------------
# list_playlists
# ---------------------------------------------------------------------------


@route("list_playlists")
def list_playlists(client: Any, settings: Any, handle: int, **params: str) -> None:
    """List all playlists."""
    playlists = client.get_playlists()
    items: list[Any] = []
    for pl in playlists:
        cover_url = ""
        if pl.get("coverArt"):
            cover_url = client.get_cover_art_url(pl["coverArt"], size=512)
        items.append(
            build_playlist_item(
                pl,
                url=url_for("list_tracks", playlist_id=pl.get("id", "")),
                cover_url=cover_url,
            )
        )
    add_items(handle, items)
    end_directory(handle, content="playlists")


# ---------------------------------------------------------------------------
# Phase 5: Genre handlers (FEAT-01)
# ---------------------------------------------------------------------------


@route("genres")
def list_genres(client: Any, settings: Any, handle: int, **params: str) -> None:
    """List all genres from getGenres (FEAT-01)."""
    genres = client.get_genres()
    items: list[Any] = []
    for genre in genres:
        name = genre.get("value") or ""
        if not name:
            continue
        items.append(
            build_genre_item(
                genre,
                url=url_for("genre_tracks", genre=name),
            )
        )
    add_items(handle, items)
    end_directory(handle, content="genres")


@route("genre_tracks")
def list_genre_tracks(
    client: Any,
    settings: Any,
    handle: int,
    genre: str = "",
    **params: str,
) -> None:
    """List tracks for a specific genre (FEAT-01)."""
    if not genre:
        end_directory(handle, content="songs", succeeded=False)
        return
    tracks = client.get_songs_by_genre(genre, count=100)
    items: list[Any] = []
    for track in tracks:
        cover_url = ""
        if track.get("coverArt"):
            cover_url = client.get_cover_art_url(track["coverArt"], size=512)
        items.append(
            build_track_item(
                track,
                url=url_for("play_track", id=track.get("id", "")),
                cover_url=cover_url,
                hide_artist=False,
            )
        )
    add_items(handle, items)
    end_directory(handle, content="songs")


# ---------------------------------------------------------------------------
# Phase 5: Internet Radio browse handler (FEAT-04)
# ---------------------------------------------------------------------------


@route("radio")
def list_radio_stations(
    client: Any,
    settings: Any,
    handle: int,
    **params: str,
) -> None:
    """List internet radio stations (FEAT-04)."""
    stations = client.get_internet_radio_stations()
    items: list[Any] = []
    for station in stations:
        name = station.get("name") or "<Unknown Station>"
        stream_url = station.get("streamUrl") or ""
        station_id = station.get("id") or ""
        if not stream_url:
            continue
        items.append(
            build_nav_item(
                name,
                url_for("play_radio", id=station_id, stream_url=stream_url),
            )
        )
    add_items(handle, items)
    end_directory(handle, content="songs")
