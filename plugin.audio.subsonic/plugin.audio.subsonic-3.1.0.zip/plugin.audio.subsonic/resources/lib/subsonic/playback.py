from __future__ import annotations

from typing import Any

import xbmcgui
import xbmcplugin
from subsonic.logging import log_error, log_exception, log_info
from subsonic.router import route


@route("play_track")
def play_track(
    client: Any,
    settings: Any,
    handle: int,
    id: str = "",
    **params: str,
) -> None:
    """Resolve the stream URL for a track and hand it to Kodi.

    Uses setResolvedUrl so the URL is never embedded in a cached directory
    listing (avoids credential-in-cache-file pitfall documented in PITFALLS.md).
    """
    if not id:
        log_error("play_track called without id param")
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    try:
        stream_url = client.stream_url(
            track_id=id,
            bitrate=settings.bitrate if settings.bitrate != "0" else None,
            fmt=settings.transcode_format if settings.transcode_format != "raw" else None,
        )
        log_info(f"Playing track id={id} via setResolvedUrl")
        li = xbmcgui.ListItem(path=stream_url)
        # estimateContentLength=True for gapless playback (PR #54 - Phase 2)
        li.setProperty("EstimateContentLength", "true")
        xbmcplugin.setResolvedUrl(handle, True, li)
    except Exception:
        log_exception(f"Failed to resolve stream URL for track id={id}")
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


@route("play_radio")
def play_radio(
    client: Any,
    settings: Any,
    handle: int,
    id: str = "",
    stream_url: str = "",
    **params: str,
) -> None:
    """Resolve the direct stream URL for an internet radio station (FEAT-04).

    Radio stations use their streamUrl directly — no Subsonic transcoding.
    """
    if not stream_url:
        log_error(f"play_radio called without stream_url param (id={id})")
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    log_info(f"Playing radio station id={id} via setResolvedUrl")
    li = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(handle, True, li)
