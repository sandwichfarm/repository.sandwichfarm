from __future__ import annotations

import os
import shutil
from typing import Any

import xbmc
from subsonic.listings import show_rating_select
from subsonic.logging import log_error, log_exception, log_info
from subsonic.router import route


def _parse_ids(raw: str) -> list[str]:
    """Parse a comma-separated or single-value ID string into a list."""
    if not raw:
        return []
    return [x.strip() for x in raw.split(",") if x.strip()]


def _parse_bool_param(value: str) -> bool:
    """Parse URL param value to bool.

    Fixes main.py:684 TO FIX: 'unstar' param came through as the string 'True',
    'False', 'None', or '1'/'0'. Old code: (unstar) and (unstar != 'None') and ...
    New code: explicit membership check that handles all legacy string variants.
    """
    return str(value).strip().lower() in ("1", "true", "yes")


@route("star_item")
def star_item(
    client: Any,
    settings: Any,
    handle: int,
    cache: Any,
    id: str = "",
    type: str = "track",
    unstar: str = "false",
    **params: str,
) -> None:
    """Star or unstar an item, then invalidate cache and refresh the UI.

    Fixes BUG-05 (main.py:739-740 TO FIX):
    - cache.invalidate('starred') removes stale cached starred set
    - xbmc.executebuiltin('Container.Refresh') updates the visible list icons

    Fixes BUG-03 (main.py:684 TO FIX):
    - unstar bool parsing via _parse_bool_param instead of fragile string checks

    Replaces bare except: at main.py:722 with targeted exception handling.
    """
    ids = _parse_ids(id)
    if not ids:
        log_error("star_item called without id param")
        return

    do_unstar = _parse_bool_param(unstar)

    song_ids: list[str] = []
    album_ids: list[str] = []
    artist_ids: list[str] = []

    if type == "track":
        song_ids = ids
    elif type == "album":
        album_ids = ids
    elif type == "artist":
        artist_ids = ids
    else:
        song_ids = ids  # default to song

    try:
        if do_unstar:
            success = client.unstar(
                song_ids=song_ids or None,
                album_ids=album_ids or None,
                artist_ids=artist_ids or None,
            )
        else:
            success = client.star(
                song_ids=song_ids or None,
                album_ids=album_ids or None,
                artist_ids=artist_ids or None,
            )
    except Exception:
        log_exception(f"star_item failed for id={id} type={type} unstar={unstar}")
        return

    if success:
        action_str = "Unstarred" if do_unstar else "Starred"
        log_info(f"{action_str} {type} id={id}")

        # BUG-05: invalidate cached starred set so next listing re-fetches fresh data
        if cache is not None:
            cache.invalidate("starred")

        # BUG-05: refresh the current container so star icons update immediately
        xbmc.executebuiltin("Container.Refresh")
    else:
        log_error(f"Failed to {'unstar' if do_unstar else 'star'} {type} id={id}")


@route("download_item")
def download_item(
    client: Any,
    settings: Any,
    handle: int,
    cache: Any,
    id: str = "",
    type: str = "track",
    **params: str,
) -> None:
    """Download a track or album to the configured download folder."""
    download_folder: str = settings.download_folder
    if not download_folder:
        log_error("download_item: no download_folder configured")
        return

    if type == "track":
        _download_tracks([id], client, download_folder)
    elif type == "album":
        try:
            album = client.get_album(id)
            track_ids = [s.get("id", "") for s in (album.get("song") or [])]
            _download_tracks(track_ids, client, download_folder)
        except Exception:
            log_exception(f"download_item: failed to get album id={id}")


def _download_tracks(
    track_ids: list[str],
    client: Any,
    download_folder: str,
) -> None:
    """Download a list of track IDs to the download folder."""
    for track_id in track_ids:
        if not track_id:
            continue
        try:
            track_path = os.path.join(download_folder, f"{track_id}.mp3")
            os.makedirs(os.path.dirname(track_path), exist_ok=True)
            file_obj = client.download(track_id)
            with open(track_path, "wb") as f:
                shutil.copyfileobj(file_obj, f)
            log_info(f"Downloaded track id={track_id} to {track_path}")
        except OSError as exc:
            log_error(f"Download failed (disk error) for track id={track_id}: {exc}")
        except Exception:
            log_exception(f"Download failed for track id={track_id}")


@route("rate_track")
def rate_track(
    client: Any,
    settings: Any,
    handle: int,
    cache: Any,
    id: str = "",
    **params: str,
) -> None:
    """Set a 1-5 star rating on a track via context menu (FEAT-03).

    Opens a selection dialog (via show_rating_select from listings — no
    xbmcgui import in actions.py per ARCH-05). Invalidates cache on success.
    """
    if not id:
        log_error("rate_track called without id param")
        return
    rating = show_rating_select(id)
    if rating is None:
        return  # user cancelled
    try:
        success = client.set_rating(item_id=id, rating=rating)
    except Exception:
        log_exception(f"rate_track failed for id={id}")
        return
    if success:
        log_info(f"Rated track id={id} with {rating} stars")
        if cache is not None:
            cache.invalidate("starred")
        xbmc.executebuiltin("Container.Refresh")
    else:
        log_error(f"Failed to rate track id={id}")
