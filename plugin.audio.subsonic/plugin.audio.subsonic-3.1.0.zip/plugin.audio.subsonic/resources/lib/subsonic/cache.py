from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, Callable

import xbmcvfs


@dataclass
class Cache:
    """Per-session in-memory cache with optional xbmcvfs JSON persistence.

    TTL is in seconds. get() is lazy and on-demand only — no background refresh.
    invalidate() is the hook for actions (star/unstar) to force a re-fetch (BUG-05).
    starred_set() implements PERF-02: timestamp-based invalidation backed by xbmcvfs JSON.
    """

    cache_dir: str
    _entries: dict[str, tuple[Any, float]] = field(default_factory=dict, init=False, repr=False)

    def get(self, key: str, fetcher: Callable[[], Any], ttl: float = 300.0) -> Any:
        """Return cached value or call fetcher, cache the result, and return it."""
        now = time.time()
        if key in self._entries:
            value, expires_at = self._entries[key]
            if expires_at > now:
                return value
        value = fetcher()
        self._entries[key] = (value, now + ttl)
        return value

    def invalidate(self, key: str) -> None:
        """Remove a key so the next get() will call the fetcher again."""
        self._entries.pop(key, None)

    def persist_write(self, filename: str, data: Any) -> None:
        """Serialize data as JSON and write to a file in cache_dir via xbmcvfs."""
        path = self.cache_dir.rstrip("/") + "/" + filename
        payload = json.dumps(data).encode("utf-8")
        with xbmcvfs.File(path, "wb") as fh:
            fh.write(bytearray(payload))

    def persist_read(self, filename: str) -> Any | None:
        """Read and deserialize JSON from a file in cache_dir via xbmcvfs.

        Returns None on any error (missing file, decode error, etc.).
        """
        path = self.cache_dir.rstrip("/") + "/" + filename
        try:
            with xbmcvfs.File(path, "rb") as fh:
                raw = bytes(fh.readBytes(1 << 20))
            return json.loads(raw.decode("utf-8")) if raw else None
        except Exception:
            return None

    def starred_set(
        self,
        fetcher: Callable[[], Any],
        server_updated_ts: str | None,
    ) -> Any:
        """Return the starred set, using timestamp-based cache invalidation (PERF-02).

        Reads stored value + stored 'updated' timestamp from xbmcvfs JSON.
        If server_updated_ts > stored_updated_ts (or stored is None), calls fetcher()
        to refresh and persists the new value + new timestamp.
        Otherwise returns the persisted value without a server round-trip.

        Args:
            fetcher: callable returning fresh starred data from the server.
            server_updated_ts: the server's 'lastModified' / 'updated' timestamp
                               string (ISO 8601 or epoch string). May be None.
        """
        stored = self.persist_read("starred_cache.json")
        stored_ts: str | None = None
        stored_value: Any = None

        if isinstance(stored, dict):
            stored_ts = stored.get("updated")
            stored_value = stored.get("value")

        need_refresh = (
            stored_value is None
            or stored_ts is None
            or server_updated_ts is None
            or server_updated_ts > stored_ts
        )

        if need_refresh:
            fresh_value = fetcher()
            self.persist_write(
                "starred_cache.json",
                {"updated": server_updated_ts, "value": fresh_value},
            )
            return fresh_value

        return stored_value
