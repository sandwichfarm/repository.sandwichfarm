"""
subsonic.scrobbler — Background scrobbler as xbmc.Monitor subclass.

Receives an injected ApiClient — no global connection (ARCH-11).
Uses urllib.parse.parse_qs to extract track_id (not regex, per plan must_have).
Fires the scrobble at 50% progress and does not double-scrobble (dedup).
Resets scrobbled=False when progress drops below 50% (handles replay).
Resets scrobbled=False when the current track ID changes.
Implements onSettingsChanged to refresh settings without restarting (Pitfall 10).
"""

from __future__ import annotations

from typing import Any
from urllib.parse import parse_qs, urlparse

import xbmc
from subsonic.logging import log_error, log_exception, log_info


class Scrobbler(xbmc.Monitor):  # type: ignore[misc]
    """Background scrobbler that fires at 50% progress.

    Receives an injected ApiClient — no global connection (ARCH-11).
    Uses urllib.parse.parse_qs to extract track_id (not regex).
    Implements onSettingsChanged to reset state if settings change.
    """

    POLL_INTERVAL = 10  # seconds between progress checks

    def __init__(self, client: Any, settings: Any) -> None:
        super().__init__()
        self._client = client
        self._settings = settings
        self._scrobbled: bool = False
        self._current_track_id: str = ""

    def onSettingsChanged(self) -> None:  # noqa: N802 — Kodi API name
        """Re-read settings when user changes them (Pitfall 10 fix)."""
        from subsonic.settings import Settings

        self._settings = Settings()
        log_info("Subsonic scrobbler: settings refreshed")

    def _extract_track_id(self, url: str) -> str:
        """Extract track id from a plugin:// URL using urllib.parse (not regex).

        Returns empty string if the URL is not a Subsonic play_track URL.
        """
        try:
            parsed = urlparse(url)
            netloc_or_path = parsed.netloc or parsed.path
            if "plugin.audio.subsonic" not in netloc_or_path:
                return ""
            params = parse_qs(parsed.query)
            action = params.get("action", [""])[0]
            if action != "play_track":
                return ""
            ids = params.get("id", [""])
            return ids[0]
        except Exception:
            return ""

    def run(self) -> None:
        """Main monitor loop. Polls for playback progress and scrobbles at 50%."""
        while not self.abortRequested():
            if self.waitForAbort(self.POLL_INTERVAL):
                break

            if not xbmc.getCondVisibility("Player.HasMedia"):
                continue

            try:
                filename = xbmc.getInfoLabel("Player.Filenameandpath")
                track_id = self._extract_track_id(filename)

                if not track_id:
                    # Not a Subsonic track — reset scrobble state
                    self._scrobbled = False
                    self._current_track_id = ""
                    continue

                # Reset scrobble state when track changes
                if track_id != self._current_track_id:
                    self._scrobbled = False
                    self._current_track_id = track_id

                progress_str = xbmc.getInfoLabel("Player.Progress")
                try:
                    progress = int(progress_str)
                except (ValueError, TypeError):
                    continue

                if progress < 50:
                    self._scrobbled = False
                elif not self._scrobbled:
                    log_info(f"Scrobbling track id={track_id} at {progress}%")
                    try:
                        success = self._client.scrobble(track_id)
                        if success:
                            self._scrobbled = True
                        else:
                            log_error(f"Scrobble failed for track id={track_id}")
                    except Exception:
                        log_exception(f"Scrobble exception for track id={track_id}")

            except Exception:
                log_exception("Scrobbler: unexpected error in main loop")
