"""
subsonic.settings — Typed facade over xbmcaddon.Addon().getSetting().

Every getSetting(id) call in this module uses the VERBATIM id= attribute
from resources/settings.xml (COMPAT-06 — existing users keep their values
after upgrading to the refactored addon).

Python property names differ from the XML ids where readability is improved
(e.g., server_url vs subsonic_url), but the getSetting() call is always the
canonical literal string from settings.xml.

Usage:
    from subsonic.settings import Settings
    s = Settings()          # uses real xbmcaddon.Addon()
    s = Settings(addon=mock)  # inject mock for tests
"""

from __future__ import annotations

import xbmcaddon


class Settings:
    """Typed facade over xbmcaddon.Addon().getSetting().

    Every getSetting(id) call uses the VERBATIM id= attribute from
    resources/settings.xml (per COMPAT-06 — existing users keep their values).
    Python attribute names may differ from the XML ids; the getSetting call is
    the canonical source of truth.

    Inject a mock addon in tests:
        addon = MagicMock()
        addon.getSetting.side_effect = lambda k: {"subsonic_url": "http://..."}.get(k, "")
        s = Settings(addon=addon)
    """

    def __init__(self, addon: xbmcaddon.Addon | None = None) -> None:
        self._addon: xbmcaddon.Addon = addon if addon is not None else xbmcaddon.Addon()

    # ------------------------------------------------------------------
    # Connection settings
    # ------------------------------------------------------------------

    @property
    def server_url(self) -> str:
        """Base URL of the Subsonic server (id: subsonic_url)."""
        return str(self._addon.getSetting("subsonic_url"))

    @property
    def port(self) -> int:
        """Server port number (id: port). Defaults to 4040 on parse error."""
        raw = self._addon.getSetting("port")
        try:
            return int(raw)
        except (ValueError, TypeError):
            return 4040

    @property
    def username(self) -> str:
        """Login username (id: username)."""
        return str(self._addon.getSetting("username"))

    @property
    def password(self) -> str:
        """Login password (id: password)."""
        return str(self._addon.getSetting("password"))

    # ------------------------------------------------------------------
    # Paging settings
    # ------------------------------------------------------------------

    @property
    def albums_per_page(self) -> int:
        """Number of albums per page (id: albums_per_page). Defaults to 50."""
        raw = self._addon.getSetting("albums_per_page")
        try:
            return int(raw)
        except (ValueError, TypeError):
            return 50

    @property
    def tracks_per_page(self) -> int:
        """Number of tracks per page (id: tracks_per_page). Defaults to 100."""
        raw = self._addon.getSetting("tracks_per_page")
        try:
            return int(raw)
        except (ValueError, TypeError):
            return 100

    # ------------------------------------------------------------------
    # Download / transcoding settings
    # ------------------------------------------------------------------

    @property
    def download_folder(self) -> str:
        """Local folder path for downloaded tracks (id: download_folder)."""
        return str(self._addon.getSetting("download_folder"))

    @property
    def transcode_format(self) -> str:
        """Transcoding format for streaming (id: transcode_format_streaming)."""
        return str(self._addon.getSetting("transcode_format_streaming"))

    @property
    def bitrate(self) -> str:
        """Streaming bitrate string, e.g. '192' or '0' for original (id: bitrate_streaming)."""
        return str(self._addon.getSetting("bitrate_streaming"))

    # ------------------------------------------------------------------
    # Advanced / auth settings
    # ------------------------------------------------------------------

    @property
    def api_version(self) -> str:
        """Subsonic API version string, e.g. '1.15.0' (id: apiversion)."""
        return str(self._addon.getSetting("apiversion"))

    @property
    def insecure(self) -> bool:
        """Allow self-signed TLS certificates when True (id: insecure)."""
        return bool(self._addon.getSetting("insecure").lower() == "true")

    @property
    def use_get(self) -> bool:
        """Use HTTP GET instead of POST for API requests (id: useget)."""
        return bool(self._addon.getSetting("useget").lower() == "true")

    @property
    def legacy_auth(self) -> bool:
        """Use legacy plaintext password auth instead of token auth (id: legacyauth)."""
        return bool(self._addon.getSetting("legacyauth").lower() == "true")

    @property
    def subsonic_api_key(self) -> str:
        """OpenSubsonic API key (id: subsonic_api_key). Empty string if not set."""
        return str(self._addon.getSetting("subsonic_api_key"))

    @property
    def insecure_ssl_acknowledged(self) -> bool:
        """True once user has acknowledged the insecure-SSL dialog (id: insecure_ssl_acknowledged)."""
        return bool(self._addon.getSetting("insecure_ssl_acknowledged").lower() == "true")

    def set_insecure_ssl_acknowledged(self, value: bool) -> None:
        """Persist insecure_ssl_acknowledged setting (id: insecure_ssl_acknowledged)."""
        self._addon.setSetting("insecure_ssl_acknowledged", "true" if value else "false")

    def set_insecure_ssl(self, value: bool) -> None:
        """Persist insecure setting (id: insecure). Used by dialog gate to revert to false."""
        self._addon.setSetting("insecure", "true" if value else "false")

    # ------------------------------------------------------------------
    # Cache / behaviour settings
    # ------------------------------------------------------------------

    @property
    def cache_time(self) -> int:
        """Cache TTL in seconds (id: cachetime). Defaults to 3600."""
        raw = self._addon.getSetting("cachetime")
        try:
            return int(raw)
        except (ValueError, TypeError):
            return 3600

    @property
    def merge(self) -> bool:
        """Merge artist entries across the library (id: merge)."""
        return bool(self._addon.getSetting("merge").lower() == "true")

    @property
    def scrobble_enabled(self) -> bool:
        """Enable scrobbling played tracks back to the server (id: scrobble)."""
        return bool(self._addon.getSetting("scrobble").lower() == "true")
