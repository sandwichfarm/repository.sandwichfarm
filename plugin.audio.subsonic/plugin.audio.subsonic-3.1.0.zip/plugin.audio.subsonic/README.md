# plugin.audio.subsonic

Kodi music addon for Subsonic-API servers — stream, star, rate, and download from any Subsonic-compatible server, including Subsonic, Airsonic, Navidrome, gonic, and LMS.

[![CI](https://github.com/dskvr/plugin.audio.subsonic/actions/workflows/ci.yml/badge.svg?branch=master)](https://github.com/dskvr/plugin.audio.subsonic/actions/workflows/ci.yml)
[![Python 3.8 | 3.11](https://img.shields.io/badge/python-3.8%20%7C%203.11-blue?logo=python&logoColor=white)](https://github.com/dskvr/plugin.audio.subsonic/actions/workflows/ci.yml)
[![Kodi 20 Nexus | 21 Omega](https://img.shields.io/badge/kodi-20%20Nexus%20%7C%2021%20Omega-9C27B0?logo=kodi&logoColor=white)](https://kodi.tv/download/)
[![Type-checked: mypy --strict](https://img.shields.io/badge/type--checked-mypy%20--strict-blue?logo=python&logoColor=white)](https://mypy.readthedocs.io/)
[![Lint: ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/charliermarsh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![License: MIT](https://img.shields.io/badge/license-MIT-green)](LICENSE)
[![GitHub release](https://img.shields.io/github/v/release/dskvr/plugin.audio.subsonic?display_name=tag&include_prereleases&sort=semver)](https://github.com/dskvr/plugin.audio.subsonic/releases)

> **v3.1.0** — major modernization release. See the [CHANGELOG](CHANGELOG.md) for the full list of fixes and features. Targets Kodi 21 Omega and Kodi 20 Nexus; older Kodi releases are end-of-life for this addon.

## Features

**Browse**
- Artists, albums (newest / most played / recently played / random / starred / by year / by genre), tracks (starred / random), playlists
- **Genres** — full genre browser via `getGenres` + `getSongsByGenre`
- **Internet radio stations** — browse and play radio stations the server provides
- **Favorite Albums** — quick access to your starred albums
- **Search** — uses OpenSubsonic `search3` for richer metadata when the server supports it
- **MusicBrainz IDs** passed through to Kodi for skin scrapers and library matching

**Playback**
- Streams via Subsonic `stream.view` with configurable bitrate
- Transcoding formats: `mp3`, `raw`, `flv`, `ogg`, `m4a`
- Gapless playback hint (`estimateContentLength`) for supported albums

**Library actions**
- Star and unstar tracks, albums, and artists (UI updates without manual refresh)
- 5-star ratings via context menu (`setRating`)
- Download songs to a configured folder
- Background scrobbling at 50% playback progress

**Authentication**
- **Salt+token** auth by default (`t` + `s` params) — secure, no plaintext password on the wire
- **OpenSubsonic API-key** auth when the server advertises `apiKeyAuthentication`
- **Legacy plaintext** fallback preserved for LDAP-backed Airsonic and pre-1.13 servers
- **Insecure SSL bypass** available for self-signed homelab servers (with a one-time confirmation dialog)

**Server compatibility**
- Subsonic
- Airsonic / Airsonic-Advanced
- Navidrome (with OpenSubsonic extensions)
- gonic
- Logitech Media Server (LMS) with Subsonic-API support

## Installation

### From a release zip (recommended)

1. Download the latest zip from [Releases](https://github.com/dskvr/plugin.audio.subsonic/releases).
2. In Kodi: Settings → System → Add-ons → enable **Unknown sources**.
3. Settings → Add-ons → **Install from zip file** → select the downloaded zip.

### From source (developer / bleeding-edge)

```bash
cd ~/.kodi/addons/
git clone https://github.com/dskvr/plugin.audio.subsonic.git
```

Restart Kodi.

### First-run configuration

Open the addon, then **Settings**:

| Field | Description |
|-------|-------------|
| Server URL | Full URL of your Subsonic-API server (e.g. `https://navidrome.example.com`) |
| Username / Password | Server credentials |
| API key (optional) | OpenSubsonic API key — overrides username/password when the server supports it |
| Legacy auth | Enable for LDAP-backed Airsonic or pre-1.13 servers |
| Insecure SSL | Disable certificate verification for self-signed servers (warning dialog will fire on first enable) |
| Transcode format | `mp3` / `raw` / `flv` / `ogg` / `m4a` |
| Bitrate | 0 (auto) – 320 kbps |
| Last.fm scrobbling | Forwarded server-side via Subsonic `scrobble.view` |

## Development

This is a Python-only Kodi addon. No compile step.

### Running the test suite

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install "pytest==8.3.*" "ruff==0.15.*" "mypy==1.20.*" "Kodistubs==21.0.0"
pytest tests/ -v          # 240 unit tests, all mocked Kodi APIs
ruff check .              # lint
ruff format --check .     # format check
mypy --strict resources/lib/subsonic/   # type check
```

### Architecture overview

```
plugin.audio.subsonic/
├── main.py                          # 19-line plugin bootstrap
├── service.py                       # 19-line scrobbler bootstrap
├── addon.xml                        # Kodi addon manifest
├── resources/
│   ├── settings.xml                 # User-facing settings schema
│   ├── language/{en,fr,de}/         # Localized strings
│   └── lib/subsonic/                # Application code
│       ├── bootstrap.py             #   entry-point glue
│       ├── router.py                #   @route() decorator + dispatch
│       ├── settings.py              #   typed facade over xbmcaddon
│       ├── models.py                #   TypedDicts for Subsonic responses
│       ├── api/client.py            #   single boundary to libsonic; auth + probe
│       ├── cache.py                 #   per-session TTL cache + xbmcvfs JSON
│       ├── listings.py              #   all Kodi UI calls + InfoTagMusic
│       ├── browse.py / search.py /  #   route handlers
│       ├── playback.py / actions.py
│       ├── scrobbler.py             #   xbmc.Monitor subclass
│       └── logging.py               #   credential-safe log wrappers
├── lib/
│   ├── libsonic/                    # Vendored py-sonic, modernized in-place
│   └── simpleplugin/                # Vendored, dormant (no longer imported)
└── tests/                           # 240 pytest unit tests, Kodi APIs mocked
```

See [`.planning/milestones/v1.0-ROADMAP.md`](.planning/milestones/v1.0-ROADMAP.md) for the full v1.0 scope and design decisions.

## Project lineage

This is a hard fork in a long line of Kodi Subsonic addons:

[`DarkAllMan/SubKodi`](https://github.com/DarkAllMan/SubKodi) → [`gordielachance`](https://github.com/gordielachance/plugin.audio.subsonic) → [`basilfx`](https://github.com/basilfx/plugin.audio.subsonic) → [`warwickh`](https://github.com/warwickh/plugin.audio.subsonic) → **`dskvr`** (current)

The v3.1.0 release also incorporates community PRs from [GioF71](https://github.com/GioF71) and [stuaxo](https://github.com/stuaxo) that were open against the warwickh fork.

## Bug reports & contributions

Issues: [GitHub Issues](https://github.com/dskvr/plugin.audio.subsonic/issues)
Contributions: PRs welcome — please run `pytest`, `ruff check`, and `mypy --strict resources/lib/subsonic/` locally before submitting.

## License

MIT — see [`LICENSE`](LICENSE).

Additional copyright notices for prior work:
- [`gordielachance/plugin.audio.subsonic`](https://github.com/gordielachance/plugin.audio.subsonic) — earlier version
- [`basilfx/plugin.audio.subsonic`](https://github.com/basilfx/plugin.audio.subsonic) — earlier version
- [`warwickh/plugin.audio.subsonic`](https://github.com/warwickh/plugin.audio.subsonic) — direct fork parent
- [SimplePlugin](https://github.com/vlmaksime/script.module.simpleplugin) by romanvm / vlmaksime — vendored, retired in v3.1.0 (dormant on disk)
- [`py-sonic`](https://github.com/crustymonkey/py-sonic) by crustymonkey — vendored as `lib/libsonic/`, modernized in-place
- [SubKodi](https://github.com/DarkAllMan/SubKodi) — original ancestor
