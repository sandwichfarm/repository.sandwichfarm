#!/usr/bin/python
"""plugin.audio.subsonic — Kodi plugin entry point.

This file is the thin bootstrap only. All handler logic lives under
resources/lib/subsonic/. See bootstrap.py for the entry-point implementation.
"""

import os
import sys

# Add resources/lib to sys.path so `import subsonic.*` works.
_ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(_ADDON_DIR, "lib"))
sys.path.insert(0, os.path.join(_ADDON_DIR, "resources", "lib"))

from subsonic.bootstrap import run_plugin  # noqa: E402

if __name__ == "__main__":
    run_plugin(sys.argv)
