# Changelog

## v3.1.0
Released 29th April 2026 (by dskvr)

Major modernization milestone — hard fork from `warwickh/plugin.audio.subsonic`. Targets Kodi 21 Omega (Python 3.11) and Kodi 20 Nexus (Python 3.8). Drops Kodi 19 Matrix and earlier.

### Crash fixes
* Add missing `import sys` to `service.py` — scrobbling no longer silently crashes on every Kodi launch (BUG-01)
* Replace dead `urllib2` references in vendored libsonic with Python 3 stdlib (COMPAT-03)
* Drop `xbmc.translatePath` version guard — `xbmcvfs.translatePath` used unconditionally (COMPAT-04)
* Replace bare `except:` blocks in `service.py` and `main.py` `get_connection()` with targeted exception handling and meaningful logging (BUG-02)

### Community PRs (warwickh upstream)
* PR #49 — Favorite Albums menu (Co-authored: Giovanni Fulco)
* PR #53 — m4a (AAC) transcoding option (Co-authored: Stuart Axon)
* PR #54 — `estimateContentLength` for gapless playback (Co-authored: Stuart Axon)

### Structural refactor
* `main.py` reduced from 1561 lines to a 19-line bootstrap; `service.py` reduced from 109 to 19 lines
* All handler logic split into focused modules under `resources/lib/subsonic/`: router, settings, models, cache, logging, api/client, listings, browse, search, playback, actions, scrobbler, bootstrap
* First-party decorator router (`@route()`) replaces vendored `simpleplugin` routing
* Type hints throughout new modules; `mypy --strict` clean on 15 source files
* Per-module `pytest` unit tests; 240 tests; CI matrix on Python 3.8 + 3.11
* `ListItem.setInfo('music', ...)` migrated to `InfoTagMusic` typed setters (Kodi 20+ deprecation)
* Pagination correctness: `Next Page` link no longer appears on the last page (BUG-04)
* Star/unstar updates the icon in the current list without manual refresh (BUG-05)
* All 8 inline `# TO FIX` comments resolved (BUG-03)
* Per-session in-memory cache with timestamp invalidation replaces global pickled starred singleton (PERF-01, PERF-02)
* Cover art uses `getCoverArt` with explicit `size` param (PERF-04)
* Listings declare `setContent` and `addSortMethod` for proper skin view rendering (PERF-05)

### Auth modernization
* Default to Subsonic salt+token auth (`secrets.token_hex` for salts) (AUTH-01, AUTH-05)
* Legacy plaintext fallback preserved for LDAP-backed Airsonic (AUTH-02)
* OpenSubsonic capability probe (`getOpenSubsonicExtensions`) — lazy + cached per session (AUTH-03)
* OpenSubsonic API-key auth supported when server advertises `apiKeyAuthentication` extension (AUTH-04)
* Repo-wide credential leak audit — no passwords, tokens, or salts in `xbmc.log` output (AUTH-06)
* `insecure=True` SSL bypass kept but defaults off; first-time enable shows confirmation dialog (AUTH-07)

### New features
* Genre browsing (`getGenres` + `getSongsByGenre`) (FEAT-01)
* `search3` replaces `search2` for richer search results (FEAT-02)
* 5-star rating context menu via `setRating` (FEAT-03)
* Internet radio stations browse view (`getInternetRadioStations`) (FEAT-04)
* MusicBrainz ID passthrough to `InfoTagMusic` for skin scrapers (FEAT-05)

### Tooling
* `pyproject.toml` with ruff (target py38), mypy (target 3.8 via `from __future__ import annotations`), pytest
* `Kodistubs` 21.0.0 + `unittest.mock.MagicMock` injected via `tests/conftest.py` for Kodi-API mocking
* GitHub Actions CI: pytest matrix on Python 3.8 and 3.11 + ruff + mypy + `kodi-addon-checker`

## v3.0.2
Released 29th September 2021 (by warwickh)
* Removed dependency on future and dateutil 
* Simpleplugin modified - no longer py2 compatible

## v3.0.1
Released 2nd September 2021 (by warwickh)
* Added Navidrome compatibility (remove dependency on integer ids)

## v3.0.0
Released 29th June 2021 (by warwickh)
* Basic update to provide Matrix compatility. Not tested on Kodi below v19
* Updates simpleplugin to latest version (3.0.0) https://github.com/vlmaksime/script.module.simpleplugin
* Moves some legacy simpleplugin static routines into main.py
* Removes dependancy on libsonic_extra by moving some walk functions into main.py
* Updates libsonic to latest version and adds functions for returning raw url for populating menus
* Move to version 3+ for diffferentiation from Leia compatible version

## v2.0.8
Released 29th November 2017 (by Heruwar)
* Fixes a security issue where the password is sent as plaintext in the URL query parameters when methods from libsonic_extas are used. 
Also adds Subsonic hex encoding when using legacy auth.
* Adds support for URL paths like https://hostname.com/subsonic as requested in Github issue #17 and also encountered in some of the reports (#14 and #5)
* Fixes an error when the password only contains digits, which simpleplugin converts to a Long, which later fails when libsonic tries to salt the password expecting a string.

## v2.0.7
Released 18 April 2017
* Added Search (by silascutler)

## v2.0.6
Released 14 January 2017
* Upgrade to simpleplugin 2.1.0
* Browse/Library menus (file structure vs ID3 tags)
* Added multilanguage support

## v2.0.5
Released 15 October 2016
* Fixed images when listing entries

## v2.0.4
Released 5 October 2016
* Cache (permanently) starred items so we can know everywhere if an item is starred or not without querying it
* Colorize starred items
* Hide artist in lists if it is unique
* Removed list_artist_albums()
* Include simpleplugin v2.0.1 as library and remove KODI dependency

## v2.0.3
Released 4 October 2016
* Random tracks submenu
* Download tracks
* Star tracks
* Context menu for downloading or marking items as favorite

## v2.0.2
* main code (main.py) fully rewritten
* Use SimplePlugin framework (http://romanvm.github.io/script.module.simpleplugin/index.html)
* Cache datas

## v2.0.1
* New setting 'albums_per_page'
* New menu structure
* Albums : Newest / Most played / Rencently played / by Genre
* Tracks : Starred / Random by genre / Random by year
* Upgraded: libsonic to v.0.5.0 (https://github.com/crustymonkey/py-sonic)
* Code cleanup

## v2.0.0
Released 14 September 2015

Highlight:
* Added: support for starred items.
* Fixed: transcode format property was incorrect.
* Improved: playlist handling.
* Improved: metadata.
* Upgraded: libsonic.
* Upgraded: libsonic_extra.s

The full list of commits can be found [here](https://github.com/rembo10/headphones/compare/v1.0.0...v2.0.0).

## v1.0.0
Released 31 May 2015

Highlights:
* Added: support for playlists.
* Added: number of random items to show.
* Improved: metadata for items.
* Fixed: migrated to [`py-sonic`](https://github.com/crustymonkey/py-sonic) to interact with Subsonic.

The full list of commits can be found [here](https://github.com/rembo10/headphones/compare/ff86dfa49f914a18233dee295df74b73a70200e8...v1.0.0).
